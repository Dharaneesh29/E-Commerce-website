// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { useContext } from "react";
// import { ShopContext } from "../../context/ShopContext";
 
 
// const ProductInfo = ({ product }) => {
//   const [offers, setOffers] = useState([]);
//   const { addToCart } = useContext(ShopContext)
 
//   const basePrice = product?.price || 0;
 
//   useEffect(() => {
//     const fetchCoupons = async () => {
//       try {
//         const res = await axios.get("http://localhost:5000/api/coupon");
//         setOffers(res.data || []);
//       } catch (err) {
//         console.log("Coupon fetch error:", err.message);
//       }
//     };
 
//     fetchCoupons();
//   }, []);
 
//   const calculateOffer = (offer) => {
//     if (!offer || basePrice < offer.minAmount) return null;
 
//     let discount = 0;
 
//     if (offer.discountType === "percentage") {
//       discount = (basePrice * offer.discountValue) / 100;
//       if (offer.maxDiscount) {
//         discount = Math.min(discount, offer.maxDiscount);
//       }
//     } else {
//       discount = offer.discountValue;
//     }
 
//     return {
//       discount: Math.floor(discount),
//       finalPrice: Math.floor(basePrice - discount),
//     };
//   };
 
//   const processedOffers = offers
//     .map((o) => ({ ...o, result: calculateOffer(o) }))
//     .filter((o) => o.result);
 
//   const bestOffer = [...processedOffers].sort(
//     (a, b) => a.result.finalPrice - b.result.finalPrice
//   )[0];
 
//   return (
//     <div className="p-6 max-w-xl bg-white rounded-xl shadow-sm">
 
//       {/* PRODUCT NAME */}
//       <h1 className="text-2xl font-semibold mb-1">
//         {product?.name}
//       </h1>
 
//       {/* BRAND */}
//       <p className="text-sm text-gray-500 mb-2">
//         by <span className="font-medium">{product?.brand || "Brand"}</span>
//       </p>
 
//       {/* ⭐ RATING */}
//       <div className="flex items-center gap-2 mb-3">
//         <span className="text-yellow-500 text-lg">
//           {"★".repeat(Math.round(product?.rating || 0))}
//           {"☆".repeat(5 - Math.round(product?.rating || 0))}
//         </span>
 
//         <span className="text-sm text-gray-600">
//           ({product?.reviews?.length || 0} reviews)
//         </span>
//       </div>
 
//       {/* 💰 PRICE */}
//       <div className="mb-5">
 
//         <div className="flex items-center gap-3">
//           <span className="text-3xl font-bold text-green-600">
//             ₹{basePrice}
//           </span>
 
//           {/* ✅ FIXED LOGIC */}
//           {product?.originalPrice &&
//             product.originalPrice > basePrice && (
//               <>
//                 <span className="text-gray-400 line-through text-lg">
//                   ₹{product.originalPrice}
//                 </span>
 
//                 <span className="text-green-600 text-sm font-medium">
//                   {Math.floor(
//                     ((product.originalPrice - basePrice) /
//                       product.originalPrice) *
//                       100
//                   )}
//                   % OFF
//                 </span>
//               </>
//             )}
//         </div>
 
//         {/* BEST OFFER */}
//         {bestOffer && (
//           <div className="text-sm text-green-700 mt-1 font-medium">
//             Best Deal: {bestOffer.code} → ₹{bestOffer.result.finalPrice}
//             <span className="ml-2 text-gray-500">
//               Save ₹{bestOffer.result.discount}
//             </span>
//           </div>
//         )}
//       </div>
 
//       {/* OFFERS */}
//       <div className="mb-6">
//         <h3 className="font-semibold mb-3 text-lg">Available Offers</h3>
 
//         {processedOffers.length === 0 ? (
//           <p className="text-gray-500 text-sm">No offers available</p>
//         ) : (
//           <div className="flex gap-4 overflow-x-auto pb-2">
//             {processedOffers.map((offer, i) => (
//               <div
//                 key={i}
//                 className={`min-w-[220px] p-4 rounded-xl border transition shadow-sm hover:shadow-lg cursor-pointer ${
//                   bestOffer?.code === offer.code
//                     ? "border-green-500 bg-green-50"
//                     : "border-gray-200 bg-white"
//                 }`}
//               >
//                 <div className="flex flex-col justify-between h-full">
 
//                   <div>
//                     <p className="font-semibold text-sm mb-1">
//                       🏷️ {offer.code}
//                     </p>
 
//                     <p className="text-xs text-gray-600">
//                       {offer.discountType === "percentage"
//                         ? `${offer.discountValue}% OFF`
//                         : `₹${offer.discountValue} OFF`}
//                     </p>
 
//                     <p className="text-xs text-gray-500">
//                       Min ₹{offer.minAmount}
//                     </p>
//                   </div>
 
//                   <div className="mt-3">
//                     <p className="text-sm font-semibold text-green-600">
//                       ₹{offer.result.finalPrice}
//                     </p>
 
//                     <p className="text-xs text-green-700">
//                       Save ₹{offer.result.discount}
//                     </p>
 
//                     {bestOffer?.code === offer.code && (
//                       <span className="text-[10px] bg-green-600 text-white px-2 py-[2px] rounded mt-1 inline-block">
//                         BEST
//                       </span>
//                     )}
//                   </div>
 
//                 </div>
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
 
//       {/* COLORS */}
//       {product?.colors?.length > 0 && (
//         <div className="mb-5">
//           <h3 className="font-semibold mb-2">Colors</h3>
//           <div className="flex gap-3">
//             {product.colors.map((c, i) => (
//               <div
//                 key={i}
//                 className="w-8 h-8 rounded-full border cursor-pointer hover:scale-110 transition"
//                 style={{ background: c }}
//               />
//             ))}
//           </div>
//         </div>
//       )}
 
//       {/* BUTTONS */}
//       <div className="flex gap-4 mt-4">
//         <button onClick={()=>addToCart(product)} className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition shadow-sm">
//           Add to Cart
//         </button>
 
//         {/* <button className="bg-yellow-500 text-white px-6 py-2 rounded-lg hover:bg-yellow-600 transition shadow-sm">
//           Buy Now
//         </button> */}
//       </div>
 
//     </div>
//   );
// };
 
// export default ProductInfo;
 
import React, { useEffect, useState } from "react";
import axios from "axios";
import { useContext } from "react";
import { ShopContext } from "../../context/ShopContext";
 
 
const ProductInfo = ({ product }) => {
  const [offers, setOffers] = useState([]);
  const { addToCart } = useContext(ShopContext)
 
  const basePrice = product?.price || 0;
 
  useEffect(() => {
  const fetchCoupons = async () => {
    try {
      const userInfo = JSON.parse(sessionStorage.getItem("userInfo"));

      const res = await axios.get("http://localhost:5000/api/coupon", {
        headers: {
          Authorization: `Bearer ${userInfo?.token}`,
        },
      });

      setOffers(res.data || []);
    } catch (err) {
      console.log("Coupon fetch error:", err.message);
    }
  };

  fetchCoupons();
}, []);
 
  const calculateOffer = (offer) => {
    if (!offer || basePrice < offer.minAmount) return null;
 
    let discount = 0;
 
    if (offer.discountType === "percentage") {
      discount = (basePrice * offer.discountValue) / 100;
      if (offer.maxDiscount) {
        discount = Math.min(discount, offer.maxDiscount);
      }
    } else {
      discount = offer.discountValue;
    }
 
    return {
      discount: Math.floor(discount),
      finalPrice: Math.floor(basePrice - discount),
    };
  };
 
  const processedOffers = offers
    .map((o) => ({ ...o, result: calculateOffer(o) }))
    .filter((o) => o.result);
 
  const bestOffer = [...processedOffers].sort(
    (a, b) => a.result.finalPrice - b.result.finalPrice
  )[0];
 
  return (
    <div className="p-6 max-w-xl bg-white rounded-xl shadow-sm">
 
      {/* PRODUCT NAME */}
      <h1 className="text-2xl font-semibold mb-1">
        {product?.name}
      </h1>
 
      {/* BRAND */}
      <p className="text-sm text-gray-500 mb-2">
        by <span className="font-medium">{product?.brand || "Brand"}</span>
      </p>
 
      {/* ⭐ RATING */}
      <div className="flex items-center gap-2 mb-3">
        <span className="text-yellow-500 text-lg">
          {"★".repeat(Math.round(product?.rating || 0))}
          {"☆".repeat(5 - Math.round(product?.rating || 0))}
        </span>
 
        <span className="text-sm text-gray-600">
          ({product?.reviews?.length || 0} reviews)
        </span>
      </div>
 
      {/* 💰 PRICE */}
      <div className="mb-5">
 
        <div className="flex items-center gap-3">
          <span className="text-3xl font-bold text-green-600">
            ₹{basePrice}
          </span>
 
          {/* ✅ FIXED LOGIC */}
          {product?.originalPrice &&
            product.originalPrice > basePrice && (
              <>
                <span className="text-gray-400 line-through text-lg">
                  ₹{product.originalPrice}
                </span>
 
                <span className="text-green-600 text-sm font-medium">
                  {Math.floor(
                    ((product.originalPrice - basePrice) /
                      product.originalPrice) *
                      100
                  )}
                  % OFF
                </span>
              </>
            )}
        </div>
 
        {/* BEST OFFER */}
        {bestOffer && (
          <div className="text-sm text-green-700 mt-1 font-medium">
            Best Deal: {bestOffer.code} → ₹{bestOffer.result.finalPrice}
            <span className="ml-2 text-gray-500">
              Save ₹{bestOffer.result.discount}
            </span>
          </div>
        )}
      </div>
 
      {/* OFFERS */}
      <div className="mb-6">
        <h3 className="font-semibold mb-3 text-lg">Available Offers</h3>
 
        {processedOffers.length === 0 ? (
          <p className="text-gray-500 text-sm">No offers available</p>
        ) : (
          <div className="flex gap-4 overflow-x-auto pb-2">
            {processedOffers.map((offer, i) => (
              <div
                key={i}
                className={`min-w-[220px] p-4 rounded-xl border transition shadow-sm hover:shadow-lg cursor-pointer ${
                  bestOffer?.code === offer.code
                    ? "border-green-500 bg-green-50"
                    : "border-gray-200 bg-white"
                }`}
              >
                <div className="flex flex-col justify-between h-full">
 
                  <div>
                    <p className="font-semibold text-sm mb-1">
                      🏷️ {offer.code}
                    </p>
 
                    <p className="text-xs text-gray-600">
                      {offer.discountType === "percentage"
                        ? `${offer.discountValue}% OFF`
                        : `₹${offer.discountValue} OFF`}
                    </p>
 
                    <p className="text-xs text-gray-500">
                      Min ₹{offer.minAmount}
                    </p>
                  </div>
 
                  <div className="mt-3">
                    <p className="text-sm font-semibold text-green-600">
                      ₹{offer.result.finalPrice}
                    </p>
 
                    <p className="text-xs text-green-700">
                      Save ₹{offer.result.discount}
                    </p>
 
                    {bestOffer?.code === offer.code && (
                      <span className="text-[10px] bg-green-600 text-white px-2 py-[2px] rounded mt-1 inline-block">
                        BEST
                      </span>
                    )}
                  </div>
 
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
 
      {/* COLORS */}
      {product?.colors?.length > 0 && (
        <div className="mb-5">
          <h3 className="font-semibold mb-2">Colors</h3>
          <div className="flex gap-3">
            {product.colors.map((c, i) => (
              <div
                key={i}
                className="w-8 h-8 rounded-full border cursor-pointer hover:scale-110 transition"
                style={{ background: c }}
              />
            ))}
          </div>
        </div>
      )}
 
      {/* BUTTONS */}
      <div className="flex gap-4 mt-4">
        <button onClick={()=>addToCart(product)} className="bg-orange-500 text-white px-6 py-2 rounded-lg hover:bg-orange-600 transition shadow-sm">
          Add to Cart
        </button>
 
        {/* <button className="bg-yellow-500 text-white px-6 py-2 rounded-lg hover:bg-yellow-600 transition shadow-sm">
          Buy Now
        </button> */}
      </div>
 
    </div>
  );
};
 
export default ProductInfo;
 