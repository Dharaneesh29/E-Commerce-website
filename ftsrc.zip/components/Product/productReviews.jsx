// import React, { useState } from "react";
// import axios from "axios";
// import { FaStar, FaRegStar, FaStarHalfAlt } from "react-icons/fa";
 
// const ProductReviews = ({ product, refreshProduct }) => {
//   const [showModal, setShowModal] = useState(false);
//   const [rating, setRating] = useState(0);
//   const [hover, setHover] = useState(0);
//   const [comment, setComment] = useState("");
//   const [image, setImage] = useState(null);
//   const [preview, setPreview] = useState(null);
 
//   const token = JSON.parse(sessionStorage.getItem("userInfo"))?.token;
 
//   // ⭐ Submit
//   const handleSubmit = async () => {
//     try {
//       const formData = new FormData();
//       formData.append("rating", rating);
//       formData.append("comment", comment);
//       if (image) formData.append("image", image);
 
//       await axios.post(
//         `http://localhost:5000/api/products/${product._id}/review`,
//         formData,
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//             "Content-Type": "multipart/form-data",
//           },
//         }
//       );
 
//       setShowModal(false);
//       setRating(0);
//       setHover(0);
//       setComment("");
//       setImage(null);
//       setPreview(null);
 
//       refreshProduct();
//     } catch (err) {
//       console.log(err);
//     }
//   };
 
//   // ⭐ Display stars (supports half)
//   const renderStars = (value) => {
//     return (
//       <div className="flex text-orange-500">
//         {[1, 2, 3, 4, 5].map((star) => {
//           if (value >= star) return <FaStar key={star} />;
//           if (value >= star - 0.5) return <FaStarHalfAlt key={star} />;
//           return <FaRegStar key={star} className="text-gray-300" />;
//         })}
//       </div>
//     );
//   };
 
//   return (
//     <div className="mt-10 bg-white p-6 rounded-xl shadow">
 
//       {/* HEADER */}
//       <div className="flex justify-between items-center mb-6">
//         <div>
//           <h2 className="text-2xl font-bold">
//             {product.rating.toFixed(1)} / 5
//           </h2>
//           <p className="text-gray-500">
//             {product.reviews.length} reviews
//           </p>
//           {renderStars(product.rating)}
//         </div>
 
//         <button
//           onClick={() => setShowModal(true)}
//           className="bg-orange-500 text-white px-5 py-2 rounded-lg hover:bg-orange-600"
//         >
//           Write Review
//         </button>
//       </div>
 
//       {/* ================= MODAL ================= */}
//       {showModal && (
//         <div
//           className="fixed inset-0 bg-black/40 flex items-center justify-center z-50"
//           onClick={() => setShowModal(false)}
//         >
//           <div
//             className="bg-white w-full max-w-lg p-6 rounded-xl relative animate-scaleUp"
//             onClick={(e) => e.stopPropagation()}
//           >
 
//             {/* CLOSE */}
//             <button
//               onClick={() => setShowModal(false)}
//               className="absolute top-3 right-3 text-gray-500 hover:text-black"
//             >
//               ✕
//             </button>
 
//             <h2 className="text-xl font-semibold mb-4">
//               Write your review
//             </h2>
 
//             {/* ⭐ RATING SYSTEM (ADVANCED) */}
//             <div className="mb-4">
//               <p className="mb-2">Your Rating:</p>
 
//               <div className="flex text-2xl cursor-pointer">
//                 {[1,2,3,4,5].map((star) => (
//                   <div key={star} className="relative flex">
 
//                     {/* LEFT HALF */}
//                     <div
//                       className="absolute left-0 w-1/2 h-full z-10"
//                       onMouseEnter={() => setHover(star - 0.5)}
//                       onClick={() => setRating(star - 0.5)}
//                     />
 
//                     {/* RIGHT HALF */}
//                     <div
//                       className="w-full"
//                       onMouseEnter={() => setHover(star)}
//                       onClick={() => setRating(star)}
//                     >
//                       {(hover || rating) >= star ? (
//                         <FaStar className="text-orange-500 transition" />
//                       ) : (hover || rating) >= star - 0.5 ? (
//                         <FaStarHalfAlt className="text-orange-500 transition" />
//                       ) : (
//                         <FaRegStar className="text-gray-300" />
//                       )}
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>
 
//             {/* COMMENT */}
//             <textarea
//               placeholder="Write your review..."
//               value={comment}
//               onChange={(e) => setComment(e.target.value)}
//               className="w-full border rounded-lg p-3 mb-4"
//             />
 
//             {/* IMAGE */}
//             <div className="mb-4">
//   <p className="text-sm mb-2">Upload Image</p>
 
//   {/* UPLOAD BOX */}
//   <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-orange-400 transition">
 
//     <div className="flex flex-col items-center justify-center">
//       <p className="text-gray-500 text-sm">
//         Drag & drop image or <span className="text-orange-500">browse</span>
//       </p>
//     </div>
 
//     <input
//       type="file"
//       className="hidden"
//       onChange={(e) => {
//         const file = e.target.files[0];
//         setImage(file);
//         setPreview(URL.createObjectURL(file));
//       }}
//     />
//   </label>
 
//   {/* PREVIEW */}
//   {preview && (
//     <div className="mt-3 relative w-28">
//       <img
//         src={preview}
//         className="w-28 h-28 object-cover rounded-lg border"
//       />
 
//       {/* REMOVE BUTTON */}
//       <button
//         onClick={() => {
//           setImage(null);
//           setPreview(null);
//         }}
//         className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full px-2 text-xs"
//       >
//         ✕
//       </button>
//     </div>
//   )}
// </div>
 
 
//             <button
//               onClick={handleSubmit}
//               className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600"
//             >
//               Submit Review
//             </button>
//           </div>
//         </div>
//       )}
 
//       {/* ================= REVIEWS ================= */}
//       <div className="space-y-4 mt-6">
//         {product.reviews.map((r, i) => (
//           <div key={i} className="border p-4 rounded-lg">
 
//             <div className="flex justify-between">
//               <div>
//                 <p className="font-semibold">{r.name}</p>
//                 <p className="text-sm text-gray-400">Verified Buyer</p>
//               </div>
//               <p className="text-sm text-gray-400">
//                 {new Date(r.createdAt).toLocaleDateString()}
//               </p>
//             </div>
 
//             <div className="mt-1">
//               {renderStars(r.rating)}
//             </div>
 
//             <p className="mt-2">{r.comment}</p>
 
//             {r.image && (
//               <img
//                 src={`http://localhost:5000${r.image}`}
//                 className="mt-2 w-24 h-24 object-cover rounded"
//               />
//             )}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };
 
// export default ProductReviews;
 

import React, { useState } from "react";
import axios from "axios";
import { FaStar, FaRegStar, FaStarHalfAlt } from "react-icons/fa";
 
const ProductReviews = ({ product, refreshProduct }) => {
  const [showModal, setShowModal] = useState(false);
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState("");
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState("");
 
  const token = JSON.parse(sessionStorage.getItem("userInfo"))?.token;
 
  // ⭐ Submit
  const handleSubmit = async () => {
  // ✅ VALIDATION
  if (rating === 0) {
    setError("Please select a star rating");
    return;
  }

  if (!comment.trim()) {
    setError("Please write a review comment");
    return;
  }

  try {
    setError("");

    const formData = new FormData();
    formData.append("rating", rating);
    formData.append("comment", comment);
    if (image) formData.append("image", image);

    await axios.post(
      `http://localhost:5000/api/products/${product._id}/review`,
      formData,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      }
    );

   
   // ✅ RESET
setShowModal(false);
setRating(0);
setHover(0);
setComment("");
setImage(null);
setPreview(null);
setError("");

// ✅ AUTO REFRESH PAGE
window.location.reload();

  } catch (err) {
    console.log(err);
  }
};
  // ⭐ Display stars (supports half)
  const renderStars = (value) => {
    return (
      <div className="flex text-orange-500">
        {[1, 2, 3, 4, 5].map((star) => {
          if (value >= star) return <FaStar key={star} />;
          if (value >= star - 0.5) return <FaStarHalfAlt key={star} />;
          return <FaRegStar key={star} className="text-gray-300" />;
        })}
      </div>
    );
  };
 
  return (
    <div className="mt-10 bg-white p-6 rounded-xl shadow">
 
      {/* HEADER */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold">
            {product.rating.toFixed(1)} / 5
          </h2>
          <p className="text-gray-500">
            {product.reviews.length} reviews
          </p>
          {renderStars(product.rating)}
        </div>
 
        <button
          onClick={() => setShowModal(true)}
          className="bg-orange-500 text-white px-5 py-2 rounded-lg hover:bg-orange-600"
        >
          Write Review
        </button>
      </div>
 
      {/* ================= MODAL ================= */}
      {showModal && (
        <div
          className="fixed inset-0 bg-black/40 flex items-center justify-center z-50"
          onClick={() => setShowModal(false)}
        >
          <div
            className="bg-white w-full max-w-lg p-6 rounded-xl relative animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
 
            {/* CLOSE */}
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-3 right-3 text-gray-500 hover:text-black"
            >
              ✕
            </button>
 
            <h2 className="text-xl font-semibold mb-4">
              Write your review
            </h2>
            {error && (
  <p className="text-red-500 text-sm mb-3">
    {error}
  </p>
)}
 
            {/* ⭐ RATING SYSTEM (ADVANCED) */}
            <div className="mb-4">
              <p className="mb-2">Your Rating:</p>
 
              <div
  className="flex text-2xl cursor-pointer"
  onMouseLeave={() => setHover(0)}
>

                {[1,2,3,4,5].map((star) => (
                  <div key={star} className="relative flex">
 
                    {/* LEFT HALF */}
                    <div
                      className="absolute left-0 w-1/2 h-full z-10"
                      onMouseEnter={() => setHover(star - 0.5)}
                      onClick={() => {
  setRating(star - 0.5);
  setHover(star - 0.5);
  setError("");
}}
                    />
 
                    {/* RIGHT HALF */}
                    <div
                      className="w-full"
                      onMouseEnter={() => setHover(star)}
                      onClick={() => {
  setRating(star);
  setHover(star);
  setError("");
}}
                    >
                      {(hover || rating) >= star ? (
                        <FaStar className="text-orange-500 transition" />
                      ) : (hover || rating) >= star - 0.5 ? (
                        <FaStarHalfAlt className="text-orange-500 transition" />
                      ) : (
                        <FaRegStar className="text-gray-300" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
 
            {/* COMMENT */}
            <textarea
              placeholder="Write your review..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full border rounded-lg p-3 mb-4"
            />
 
            {/* IMAGE */}
            <div className="mb-4">
  <p className="text-sm mb-2">Upload Image</p>
 
  {/* UPLOAD BOX */}
  <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-orange-400 transition">
 
    <div className="flex flex-col items-center justify-center">
      <p className="text-gray-500 text-sm">
        Drag & drop image or <span className="text-orange-500">browse</span>
      </p>
    </div>
 
    <input
      type="file"
      className="hidden"
      onChange={(e) => {
        const file = e.target.files[0];
        setImage(file);
        setPreview(URL.createObjectURL(file));
      }}
    />
  </label>
 
  {/* PREVIEW */}
  {preview && (
    <div className="mt-3 relative w-28">
      <img
        src={preview}
        className="w-28 h-28 object-cover rounded-lg border"
      />
 
      {/* REMOVE BUTTON */}
      <button
        onClick={() => {
          setImage(null);
          setPreview(null);
        }}
        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full px-2 text-xs"
      >
        ✕
      </button>
    </div>
  )}
</div>
 
 
            <button
  onClick={handleSubmit}
  disabled={rating === 0 || !comment.trim()}
  className={`px-4 py-2 rounded-lg text-white
    ${(rating === 0 || !comment.trim())
      ? "bg-gray-400 cursor-not-allowed"
      : "bg-orange-500 hover:bg-orange-600"}
  `}
>
  Submit Review
</button>
          </div>
        </div>
      )}
 
      {/* ================= REVIEWS ================= */}
      <div className="space-y-4 mt-6">
        {product.reviews.map((r, i) => (
          <div key={i} className="border p-4 rounded-lg">
 
            <div className="flex justify-between">
              <div>
                <p className="font-semibold">{r.name}</p>
                <p className="text-sm text-gray-400">Verified Buyer</p>
              </div>
              <p className="text-sm text-gray-400">
                {new Date(r.createdAt).toLocaleDateString()}
              </p>
            </div>
 
            <div className="mt-1">
              {renderStars(r.rating)}
            </div>
 
            <p className="mt-2">{r.comment}</p>
 
            {r.image && (
              <img
                src={`http://localhost:5000${r.image}`}
                className="mt-2 w-24 h-24 object-cover rounded"
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
 
export default ProductReviews;
 

