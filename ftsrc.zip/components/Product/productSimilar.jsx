// import React, { useEffect, useState } from "react";
// import axios from "axios";
 
// const SimilarProducts = ({ productId }) => {
//   const [products, setProducts] = useState([]);
//   console.log(products);
  
 
//   useEffect(() => {
//     const fetchSimilar = async () => {
//       try {
//         const { data } = await axios.get(
//           `http://localhost:5000/api/products/${productId}/similar`
//         );
//         setProducts(data);
//       } catch (err) {
//         console.log(err);
//       }
//     };
 
//     fetchSimilar();
//   }, [productId]);
 
//   return (
//     <div className="mt-12">
 
//       {/* TITLE */}
//       <h2 className="text-2xl font-semibold mb-5">
//         You may also like
//       </h2>
 
//       {/* SCROLL CONTAINER */}
//       <div className="flex gap-5 overflow-x-auto scrollbar-hide">
 
//         {products.map((p) => (
//           <div
//             key={p._id}
//             className="min-w-[220px] bg-white p-3 rounded-xl shadow hover:shadow-lg transition cursor-pointer"
//           >
//             {/* IMAGE */}
//             <img
//   src={
//     p.images && p.images.length > 0
//       ? p.images[0].startsWith("http")
//         ? p.images[0]
//         : `http://localhost:5000${p.images[0]}`
//       : "/placeholder.png"
//   }
//   className="h-40 w-full object-cover rounded-lg"
// />
//             {/* NAME */}
//             <p className="mt-2 text-sm font-medium line-clamp-2">
//               {p.name}
//             </p>
 
//             {/* PRICE */}
//             <p className="text-orange-500 font-semibold mt-1">
//               ₹{p.price}
//             </p>
 
//             {/* RATING */}
//             <p className="text-xs text-gray-500">
//               ⭐ {p.rating?.toFixed(1)}
//             </p>
//           </div>
//         ))}
 
//       </div>
//     </div>
//   );
// };
 
// export default SimilarProducts;


import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
 
const SimilarProducts = ({ productId }) => {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();
 
  useEffect(() => {
    const fetchSimilar = async () => {
      try {
        const { data } = await axios.get(
          `http://localhost:5000/api/products/${productId}/similar`
        );
        setProducts(data);
      } catch (err) {
        console.log(err);
      }
    };
 
    fetchSimilar();
  }, [productId]);
 
  return (
    <div className="mt-12">
      <h2 className="text-2xl font-semibold mb-5">
        You may also like
      </h2>
 
      <div className="flex gap-5 overflow-x-auto scrollbar-hide">
        {products.map((p) => (
          <div
            key={p._id}
            onClick={() => navigate(`/product/${p._id}`)}
            className="min-w-[220px] bg-white p-3 rounded-xl shadow hover:shadow-lg transition cursor-pointer"
          >
            <img
              src={
                p.images && p.images.length > 0
                  ? p.images[0].startsWith("http")
                    ? p.images[0]
                    : `http://localhost:5000${p.images[0]}`
                  : "/placeholder.png"
              }
              className="h-40 w-full object-cover rounded-lg"
            />
 
            <p className="mt-2 text-sm font-medium line-clamp-2">
              {p.name}
            </p>
 
            <p className="text-orange-500 font-semibold mt-1">
              ₹{p.price}
            </p>
 
            <p className="text-xs text-gray-500">
              ⭐ {p.rating?.toFixed(1)}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
 
export default SimilarProducts;
 