import React, { useState, useEffect,useContext } from "react";
import { FaHeart, FaRegHeart } from "react-icons/fa";
import { WishlistContext } from "../../context/WishlistContext";
 
const ProductImages = ({ product }) => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [isZooming, setIsZooming] = useState(false);
  const [zoomStyle, setZoomStyle] = useState({});
  // const [wishlist, setWishlist] = useState(false);
  const { wishlist, toggleWishlist } = useContext(WishlistContext);
   
  const isWishlisted = wishlist.some((p) => p._id === product._id);
 
  // 🔶 IMAGE PATH
  const getImage = (img) => {
    if (!img) return "/placeholder.png";
    return img.startsWith("http")
      ? img
      : `http://localhost:5000${img}`;
  };
 
  // 🔥 CHECK DUPLICATE
  const isDuplicateImages = (images) => {
    return images.every((img) => img === images[0]);
  };
 
  // 🔥 BETTER VARIATIONS (MORE REAL LOOK)
  const generateVariations = (img) => {
    return [
      { src: img, style: {} }, // original
 
      // zoomed center
      { src: img, style: { transform: "scale(1.2)" } },
 
      // left crop feel
      {
        src: img,
        style: {
          transform: "scale(1.3) translateX(-10%)",
        },
      },
 
      // mirrored (fake back feel)
      {
        src: img,
        style: {
          transform: "scaleX(-1)",
        },
      },
    ];
  };
 
  let displayImages = [];
 
  if (!product?.images || product.images.length === 0) {
    displayImages = [];
  } else if (isDuplicateImages(product.images)) {
    displayImages = generateVariations(product.images[0]);
  } else {
    displayImages = product.images.map((img) => ({
      src: img,
      style: {},
    }));
  }
 
  // 🔶 DEFAULT IMAGE
  useEffect(() => {
    if (displayImages.length > 0) {
      setSelectedImage(displayImages[0]);
    }
  }, [product]);
 
  // 🔍 ZOOM
  const handleMouseMove = (e) => {
    const { left, top, width, height } =
      e.currentTarget.getBoundingClientRect();
 
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
 
    setZoomStyle({
      transformOrigin: `${x}% ${y}%`,
      transform: "scale(2)",
    });
  };
 
  return (
    <div className="flex gap-4">
 
      {/* 🔶 THUMBNAILS */}
     <div className="flex flex-col gap-3 items-center">
  {displayImages.map((imgObj, i) => {
    // 🎯 small safe variations (thumbnail only)
    const thumbStyles = [
      {},
      { transform: "scale(1.2)" },
      { filter: "scale(1.3) translateX(-10%)" },
      { transform: "scaleX(-1)" }, // mirror effect
    ];
 
    return (
      <div
        key={i}
        onClick={() => setSelectedImage(imgObj)}
        className={`w-16 h-16 p-1 border rounded-lg cursor-pointer flex items-center justify-center bg-white transition
          ${
            selectedImage?.src === imgObj.src
              ? "border-orange-500"
              : "border-gray-300 hover:border-orange-400"
          }`}
      >
        <img
          src={getImage(imgObj.src)}
          alt=""
          className="w-full h-full object-contain transition"
          style={thumbStyles[i % thumbStyles.length]}
        />
      </div>
    );
  })}
</div>
 
      {/* 🔶 MAIN IMAGE */}
      <div
        className="relative border rounded-xl p-4 bg-white w-[400px] h-[480px] overflow-hidden"
        onMouseEnter={() => setIsZooming(true)}
        onMouseLeave={() => {
          setIsZooming(false);
          setZoomStyle({});
        }}
        onMouseMove={handleMouseMove}
      >
 
        {/* ❤️ WISHLIST */}
        <button
  onClick={(e) => {
    e.stopPropagation();
    toggleWishlist(product._id);
  }}
  className="absolute top-3 right-3 bg-white p-2 rounded-full shadow hover:scale-110 transition z-10"
>
  {isWishlisted ? (
    <FaHeart className="text-orange-500 text-xl" />
  ) : (
    <FaRegHeart className="text-gray-500 text-xl" />
  )}
</button>
 
 
        {/* IMAGE */}
        {selectedImage && (
          <img
            src={getImage(selectedImage.src)}
            alt=""
            className="w-full h-full object-contain transition duration-200"
            style={{
              ...selectedImage.style,
              ...(isZooming ? zoomStyle : {}),
            }}
          />
        )}
      </div>

      
    </div>
  );
};
 
export default ProductImages;
 