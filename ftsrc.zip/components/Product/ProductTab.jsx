import React, { useState } from "react";
 
const ProductTabs = ({ product }) => {
  const [activeTab, setActiveTab] = useState("description");
 
  return (
    <div className="mt-12 bg-white rounded-2xl shadow-lg p-6">
 
      {/* 🔥 TAB HEADER (PILL STYLE) */}
      <div className="flex gap-3 mb-6">
        {["description", "details"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${
              activeTab === tab
                ? "bg-orange-500 text-white shadow-md"
                : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {tab.toUpperCase()}
          </button>
        ))}
      </div>
 
      {/* 🔥 CONTENT */}
      <div className="text-sm text-gray-700">
 
        {/* ================= DESCRIPTION ================= */}
        {activeTab === "description" && (
          <div className="space-y-5">
 
            {/* Main Description */}
            <p className="leading-relaxed text-gray-700">
              {product?.description || "No description available"}
            </p>
 
            {/* Highlights */}
            <div className="bg-orange-50 border border-orange-100 rounded-xl p-4">
              <h4 className="font-semibold text-orange-600 mb-2">
                ✨ Highlights
              </h4>
 
              <ul className="grid grid-cols-2 gap-2 text-gray-600 text-sm">
                <li>✔ Premium quality</li>
                <li>✔ Trusted brand</li>
                <li>✔ Long lasting</li>
                <li>✔ Best seller product</li>
              </ul>
            </div>
 
          </div>
        )}
 
        {/* ================= DETAILS ================= */}
        {activeTab === "details" && (
          <div className="grid md:grid-cols-2 gap-4">
 
            {/* LEFT SIDE */}
            <div className="space-y-3">
              <DetailItem label="Brand" value={product?.brand} />
              <DetailItem label="Category" value={product?.category} />
              <DetailItem label="Stock" value={product?.countInStock} />
            </div>
 
            {/* RIGHT SIDE */}
            <div className="space-y-3">
              <DetailItem label="Delivery" value={product?.delivery || "3-5 Days"} />
              <DetailItem label="Return Policy" value={product?.returnPolicy} />
              <DetailItem label="Warranty" value={product?.warranty || "No Warranty"} />
            </div>
 
          </div>
        )}
 
      </div>
    </div>
  );
};
 
export default ProductTabs;
 
 
 
 
 
// 🔥 SMALL COMPONENT FOR CLEAN UI
const DetailItem = ({ label, value }) => {
  return (
    <div className="flex justify-between items-center bg-gray-50 p-3 rounded-lg border hover:shadow-sm transition">
      <span className="text-gray-500">{label}</span>
      <span className="font-medium text-gray-800">
        {value || "N/A"}
      </span>
    </div>
  );
};
 