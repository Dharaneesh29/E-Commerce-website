import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const BASE = "http://localhost:5000/api/notifications";

const TYPE_CONFIG = {
  order: { icon: "🛒", color: "#3b82f6", bg: "#eff6ff", label: "New Order",  path: "/orders"   },
  user:  { icon: "👤", color: "#8b5cf6", bg: "#f5f3ff", label: "New User",   path: "/user-management" },
  stock: { icon: "⚠️", color: "#f97316", bg: "#fff7ed", label: "Low Stock",  path: "/products"  },
};

export default function NotificationBell() {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount,   setUnreadCount]   = useState(0);
  const [open,          setOpen]          = useState(false);
  const [loading,       setLoading]       = useState(false);
  const dropdownRef = useRef(null);
  const navigate    = useNavigate();

  const getToken = () =>
    JSON.parse(sessionStorage.getItem("userInfo"))?.token;

  const authHeaders = () => ({
    headers: { Authorization: `Bearer ${getToken()}` },
  });

  // ── Fetch notifications ────────────────────────────────────
  const fetchNotifications = async () => {
    try {
      const res = await axios.get(BASE, authHeaders());
      setNotifications(res.data);
      setUnreadCount(res.data.filter((n) => !n.isRead).length);
    } catch (err) {
      console.log("Notification fetch error:", err.response?.data);
    }
  };

  // ── Poll every 30 seconds for new notifications ────────────
  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, []);

  // ── Close dropdown when clicking outside ──────────────────
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // ── Mark single as read ────────────────────────────────────
  const markAsRead = async (notification) => {
    try {
      if (!notification.isRead) {
        await axios.put(
          `${BASE}/${notification._id}/read`,
          {},
          authHeaders()
        );
        setNotifications((prev) =>
          prev.map((n) =>
            n._id === notification._id ? { ...n, isRead: true } : n
          )
        );
        setUnreadCount((c) => Math.max(0, c - 1));
      }
      // Navigate to relevant page
      const config = TYPE_CONFIG[notification.type];
      if (config?.path) {
        setOpen(false);
        navigate(config.path);
      }
    } catch (err) {
      console.log("Mark read error:", err.response?.data);
    }
  };

  // ── Mark all as read ───────────────────────────────────────
  const markAllAsRead = async () => {
    setLoading(true);
    try {
      await axios.put(`${BASE}/mark-all-read`, {}, authHeaders());
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (err) {
      console.log("Mark all read error:", err.response?.data);
    } finally {
      setLoading(false);
    }
  };

  // ── Delete notification ────────────────────────────────────
  const deleteNotification = async (e, id) => {
    e.stopPropagation();
    try {
      await axios.delete(`${BASE}/${id}`, authHeaders());
      setNotifications((prev) => {
        const updated = prev.filter((n) => n._id !== id);
        setUnreadCount(updated.filter((n) => !n.isRead).length);
        return updated;
      });
    } catch (err) {
      console.log("Delete error:", err.response?.data);
    }
  };

  // ── Time ago helper ────────────────────────────────────────
  const timeAgo = (date) => {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    if (seconds < 60)   return "Just now";
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400)return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  return (
    <div style={wrapper} ref={dropdownRef}>

      {/* ── Bell Button ── */}
      <button
        onClick={() => setOpen(!open)}
        style={bellBtn}
        title="Notifications"
      >
        <span style={{ fontSize: 20 }}>🔔</span>
        {unreadCount > 0 && (
          <span style={badge}>
            {unreadCount > 99 ? "99+" : unreadCount}
          </span>
        )}
      </button>

      {/* ── Dropdown ── */}
      {open && (
        <div style={dropdown}>

          {/* Header */}
          <div style={dropHeader}>
            <div>
              <h3 style={dropTitle}>Notifications</h3>
              {unreadCount > 0 && (
                <span style={unreadBadge}>{unreadCount} unread</span>
              )}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  disabled={loading}
                  style={markAllBtn}
                >
                  {loading ? "..." : "Mark all read"}
                </button>
              )}
              <button
                onClick={fetchNotifications}
                style={refreshBtnStyle}
                title="Refresh"
              >
                ↻
              </button>
            </div>
          </div>

          {/* Notification list */}
          <div style={list}>
            {notifications.length === 0 ? (
              <div style={emptyState}>
                <span style={{ fontSize: 32 }}>🔕</span>
                <p style={{ margin: "8px 0 0", color: "#94a3b8", fontSize: 13 }}>
                  No notifications yet
                </p>
              </div>
            ) : (
              notifications.map((n) => {
                const config = TYPE_CONFIG[n.type] || TYPE_CONFIG.order;
                return (
                  <div
                    key={n._id}
                    onClick={() => markAsRead(n)}
                    style={{
                      ...notifItem,
                      background: n.isRead ? "white" : "#fafaf9",
                      borderLeft: n.isRead
                        ? "3px solid transparent"
                        : `3px solid ${config.color}`,
                    }}
                  >
                    {/* Icon */}
                    <div style={{
                      ...notifIcon,
                      background: config.bg,
                    }}>
                      <span style={{ fontSize: 16 }}>{config.icon}</span>
                    </div>

                    {/* Content */}
                    <div style={notifContent}>
                      <div style={notifRow}>
                        <span style={{
                          ...typeBadge,
                          background: config.bg,
                          color: config.color,
                        }}>
                          {config.label}
                        </span>
                        <span style={timeStyle}>{timeAgo(n.createdAt)}</span>
                      </div>
                      <p style={{
                        ...notifMsg,
                        color: n.isRead ? "#64748b" : "#1e293b",
                        fontWeight: n.isRead ? 400 : 600,
                      }}>
                        {n.message}
                      </p>
                    </div>

                    {/* Unread dot + delete */}
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, flexShrink: 0 }}>
                      {!n.isRead && <div style={unreadDot} />}
                      <button
                        onClick={(e) => deleteNotification(e, n._id)}
                        style={deleteBtn}
                        title="Delete"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div style={dropFooter}>
              <span style={{ fontSize: 12, color: "#94a3b8" }}>
                {notifications.length} total notifications
              </span>
              <button
                onClick={() => {
                  setOpen(false);
                  navigate("/notifications");
                }}
                style={viewAllBtn}
              >
                View All →
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ── STYLES ── */
const wrapper = { position: "relative", display: "inline-block" };

const bellBtn = {
  position:    "relative",
  width:       42, height: 42,
  borderRadius: 10,
  background:  "white",
  border:      "1px solid #e2e8f0",
  cursor:      "pointer",
  display:     "flex",
  alignItems:  "center",
  justifyContent: "center",
  boxShadow:   "0 1px 3px rgba(0,0,0,0.06)",
  transition:  "all 0.2s",
};

const badge = {
  position:   "absolute",
  top:        -6, right: -6,
  background: "#ef4444",
  color:      "white",
  fontSize:   10, fontWeight: 700,
  minWidth:   18, height: 18,
  borderRadius: 99,
  display:    "flex",
  alignItems: "center",
  justifyContent: "center",
  padding:    "0 4px",
  border:     "2px solid white",
};

const dropdown = {
  position:   "absolute",
  top:        52, right: 0,
  width:      380,
  maxHeight:  520,
  background: "white",
  borderRadius: 16,
  boxShadow:  "0 20px 60px rgba(0,0,0,0.15), 0 0 0 1px rgba(0,0,0,0.05)",
  zIndex:     1000,
  overflow:   "hidden",
  display:    "flex",
  flexDirection: "column",
};

const dropHeader = {
  display:    "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding:    "16px 16px 12px",
  borderBottom: "1px solid #f1f5f9",
  flexShrink: 0,
};
const dropTitle  = { margin: 0, fontSize: 15, fontWeight: 800, color: "#0f172a" };
const unreadBadge= { fontSize: 11, background: "#fef3c7", color: "#d97706", padding: "2px 8px", borderRadius: 99, fontWeight: 600, marginTop: 2, display: "inline-block" };

const markAllBtn = {
  fontSize:   11, fontWeight: 600,
  color:      "#f97316",
  background: "#fff7ed",
  border:     "1px solid #fed7aa",
  borderRadius: 6,
  padding:    "4px 10px",
  cursor:     "pointer",
};
const refreshBtnStyle = {
  fontSize:   16, color: "#94a3b8",
  background: "none", border: "none",
  cursor:     "pointer", padding: "2px 6px",
  borderRadius: 6,
};

const list = { overflowY: "auto", flex: 1 };

const emptyState = {
  padding:    "40px 20px",
  textAlign:  "center",
  display:    "flex",
  flexDirection: "column",
  alignItems: "center",
};

const notifItem = {
  display:    "flex",
  gap:        10,
  padding:    "12px 14px",
  borderBottom: "1px solid #f8fafc",
  cursor:     "pointer",
  transition: "background 0.15s",
  alignItems: "flex-start",
};
const notifIcon = {
  width:      36, height: 36,
  borderRadius: 10,
  display:    "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
};
const notifContent = { flex: 1, minWidth: 0 };
const notifRow     = { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 };
const typeBadge    = { fontSize: 10, fontWeight: 700, padding: "2px 7px", borderRadius: 99, textTransform: "uppercase", letterSpacing: "0.04em" };
const timeStyle    = { fontSize: 10, color: "#94a3b8", flexShrink: 0 };
const notifMsg     = { fontSize: 12, margin: 0, lineHeight: 1.45, wordBreak: "break-word" };
const unreadDot    = { width: 8, height: 8, borderRadius: "50%", background: "#f97316", marginTop: 2 };
const deleteBtn    = { background: "none", border: "none", cursor: "pointer", color: "#cbd5e1", fontSize: 12, padding: 2, lineHeight: 1 };

const dropFooter = {
  display:    "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding:    "10px 16px",
  borderTop:  "1px solid #f1f5f9",
  flexShrink: 0,
};
const viewAllBtn = {
  fontSize:   12, fontWeight: 600,
  color:      "#f97316",
  background: "none", border: "none",
  cursor:     "pointer", padding: 0,
};
