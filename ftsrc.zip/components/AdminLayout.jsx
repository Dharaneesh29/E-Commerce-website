import Sidebar from "./sidebar";
 
export default function AdminLayout({ children }) {
  return (
    <div style={{ display: "flex" }}>
      <Sidebar />
 
      <div style={{ flex: 1, padding: "20px" }}>
        {children}
      </div>
    </div>
  );
}
 

const main = {
  flex: 1,
  background: "#f1f5f9",
  minHeight: "100vh",
};

const content = {
  padding: "20px",
};
