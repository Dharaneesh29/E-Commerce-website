import React, { useEffect } from "react";
 
const Toast = ({ message, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 2500);
 
    return () => clearTimeout(timer);
  }, []);
 
  return (
    <div
      style={{
        position: "fixed",
        bottom: "20px",
        left: "50%",
        transform: "translateX(-50%)",
        backgroundColor: "#ff6f00",
        color: "#fff",
        padding: "14px 22px",
        borderRadius: "10px",
        fontWeight: "600",
        fontSize: "14px",
        boxShadow: "0 6px 20px rgba(0,0,0,0.25)",
        zIndex: 999999, // 🔥 VERY IMPORTANT
        animation: "toastSlide 0.4s ease"
      }}
    >
      {message}
    </div>
  );
};
 
export default Toast;
 