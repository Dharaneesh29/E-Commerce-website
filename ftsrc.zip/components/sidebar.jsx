import { useState, useEffect, useRef } from "react";
import { Link, useLocation, useNavigate, Outlet } from "react-router-dom";
import NotificationBell from "./NotificationBell";

const NAV_ITEMS = [
  { to: "/dashboard",       label: "Dashboard",        icon: "📊", color: "#f97316" },
  { to: "/products",        label: "Products",         icon: "📦", color: "#3b82f6" },
  { to: "/user-management", label: "User Management",  icon: "👥", color: "#8b5cf6" },
  { to: "/orders",          label: "Order Management", icon: "🛒", color: "#10b981" },
  { to: "/admin/coupons",   label: "Coupons",          icon: "🎟️", color: "#f59e0b" },
  { to: "/notifications",   label: "Notifications",    icon: "🔔", color: "#ec4899" },
  { to: "/reports",         label: "Reports",          icon: "📈", color: "#06b6d4" },
   { to: "/admin/membership-plans",  label: "Membership Plans", icon: "💳", color: "#14b8a6" }, // ✅ new
  { to: "/admin/members",           label: "Members",          icon: "🪪", color: "#a855f7" }, // ✅ new
];

export default function Sidebar() {
  const location  = useLocation();
  const navigate  = useNavigate();
  const dropRef   = useRef(null);

  const [collapsed,   setCollapsed]   = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [hoveredItem, setHoveredItem] = useState(null);

  const userInfo   = JSON.parse(sessionStorage.getItem("userInfo")) || {};
  const adminName  = userInfo.user?.name  || "Admin";
  const adminEmail = userInfo.user?.email || "admin@shop.com";
  const adminRole  = userInfo.user?.role  || "Administrator";

  // ── Close dropdown when clicking outside ──────────────────
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropRef.current && !dropRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    };
    if (profileOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [profileOpen]);

  const handleLogout = () => {
    sessionStorage.removeItem("userInfo");
    sessionStorage.removeItem("token");
    navigate("/users/login");
  };

  const handleNavigate = (path) => {
    setProfileOpen(false);
    navigate(path);
  };

  const isActive    = (path) => location.pathname === path;
  const currentPage = NAV_ITEMS.find(n => n.to === location.pathname);

  return (
    <div style={{ display:"flex", height:"100vh", fontFamily:"'Segoe UI',sans-serif", background:"#f1f5f9", overflow:"hidden" }}>
      <style>{`
        @keyframes fadeIn  { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes slideIn { from{opacity:0;transform:translateX(-6px)} to{opacity:1;transform:translateX(0)} }
        .nav-lnk:hover .nav-lbl { color:#fff !important; }
        .nav-lnk:hover { background:rgba(255,255,255,0.08) !important; }
        .drop-item:hover  { background:#f8fafc !important; }
        .drop-logout:hover{ background:#fef2f2 !important; }
        .collapse-btn:hover { background:rgba(255,255,255,0.15) !important; }
        .logout-side:hover  { background:rgba(239,68,68,0.18) !important; }
        .header-avatar:hover { opacity:.88 !important; }
      `}</style>

      {/* ══════════ SIDEBAR ══════════ */}
      <aside style={{
        width: collapsed ? 70 : 248,
        background: "linear-gradient(180deg,#0f172a 0%,#1a2540 60%,#0f172a 100%)",
        display: "flex", flexDirection: "column",
        transition: "width 0.28s cubic-bezier(.4,0,.2,1)",
        flexShrink: 0, overflow: "hidden",
        boxShadow: "4px 0 32px rgba(0,0,0,0.22)",
        position: "relative", zIndex: 10,
      }}>

        {/* LOGO */}
        <div style={{ display:"flex", alignItems:"center", gap:10, padding:collapsed?"18px 15px":"18px 18px 14px", minHeight:72 }}>
          <div style={{ width:40, height:40, borderRadius:13, background:"linear-gradient(135deg,#f97316,#ea580c)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0, boxShadow:"0 4px 16px rgba(249,115,22,.45)" }}>
            🛍️
          </div>
          {!collapsed && (
            <div style={{ flex:1, minWidth:0, animation:"slideIn .25s ease" }}>
              <div style={{ fontSize:17, fontWeight:900, color:"#fff", letterSpacing:-.3, lineHeight:1 }}>ShopEasy</div>
              <div style={{ fontSize:11, color:"#64748b", fontWeight:600, marginTop:2 }}>Admin Panel</div>
            </div>
          )}
          <button className="collapse-btn" onClick={() => setCollapsed(c => !c)} style={{
            width:28, height:28, borderRadius:8, background:"rgba(255,255,255,.07)",
            border:"1px solid rgba(255,255,255,.1)", color:"#94a3b8", cursor:"pointer",
            fontSize:14, display:"flex", alignItems:"center", justifyContent:"center",
            flexShrink:0, transition:"background .18s", fontWeight:700
          }}>
            {collapsed ? "›" : "‹"}
          </button>
        </div>

        <div style={{ height:1, background:"rgba(255,255,255,.06)", margin:"0 16px 12px" }} />

        {/* NAV */}
        <nav style={{ flex:1, padding:"0 10px", display:"flex", flexDirection:"column", gap:2, overflowY:"auto", overflowX:"hidden" }}>
          {NAV_ITEMS.map(({ to, label, icon, color }) => {
            const active = isActive(to);
            return (
              <Link key={to} to={to} className="nav-lnk"
                onMouseEnter={() => setHoveredItem(to)}
                onMouseLeave={() => setHoveredItem(null)}
                title={collapsed ? label : ""}
                style={{
                  display:"flex", alignItems:"center",
                  gap: collapsed ? 0 : 12,
                  padding: collapsed ? "11px 0" : "11px 14px",
                  justifyContent: collapsed ? "center" : "flex-start",
                  borderRadius:13, textDecoration:"none",
                  transition:"all .18s",
                  background: active ? `linear-gradient(135deg,${color}22,${color}12)` : "transparent",
                  border: active ? `1px solid ${color}30` : "1px solid transparent",
                  position:"relative",
                }}>
                {active && <div style={{ position:"absolute", left:0, top:"20%", bottom:"20%", width:3, borderRadius:"0 3px 3px 0", background:color }} />}
                <div style={{ width:34, height:34, borderRadius:10, flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", fontSize:17, background:active?`${color}22`:"rgba(255,255,255,.04)", border:`1px solid ${active?color+"33":"transparent"}`, transition:"all .18s" }}>
                  {icon}
                </div>
                {!collapsed && (
                  <span className="nav-lbl" style={{ fontSize:13.5, fontWeight:active?700:500, color:active?"#fff":"#94a3b8", whiteSpace:"nowrap", flex:1, transition:"color .18s" }}>
                    {label}
                  </span>
                )}
                {active && !collapsed && (
                  <div style={{ width:6, height:6, borderRadius:"50%", background:color, boxShadow:`0 0 8px ${color}`, flexShrink:0 }} />
                )}
              </Link>
            );
          })}
        </nav>

        <div style={{ height:1, background:"rgba(255,255,255,.06)", margin:"12px 16px 10px" }} />

        {/* PROFILE BOTTOM */}
        <div style={{ padding:collapsed?"0 15px 18px":"0 12px 18px", display:"flex", alignItems:"center", gap:10 }}>
          <div style={{ width:36, height:36, borderRadius:"50%", background:"linear-gradient(135deg,#f97316,#ea580c)", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:900, fontSize:15, flexShrink:0, boxShadow:"0 2px 10px rgba(249,115,22,.4)" }}>
            {adminName.charAt(0).toUpperCase()}
          </div>
          {!collapsed && (
            <>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:13, fontWeight:700, color:"#e2e8f0", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{adminName}</div>
                <div style={{ fontSize:10, color:"#475569", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{adminEmail}</div>
              </div>
              <button className="logout-side" onClick={handleLogout} title="Logout" style={{ width:30, height:30, borderRadius:8, background:"rgba(239,68,68,.1)", border:"1px solid rgba(239,68,68,.2)", color:"#ef4444", cursor:"pointer", fontSize:15, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:"background .18s" }}>
                ⏻
              </button>
            </>
          )}
        </div>
      </aside>

      {/* ══════════ MAIN ══════════ */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>

        {/* TOPBAR */}
        <header style={{
          height:62, background:"#fff", display:"flex", alignItems:"center",
          justifyContent:"space-between", padding:"0 28px",
          borderBottom:"1px solid #e2e8f0",
          boxShadow:"0 1px 8px rgba(0,0,0,.05)",
          flexShrink:0,
          position:"relative",
          zIndex:200,        // ← high enough so dropdown shows over content
        }}>

          {/* Left — page badge */}
      <div/>

          {/* Right */}
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>

            {/* Date */}
            <div style={{ fontSize:12, color:"#64748b", background:"#f8fafc", padding:"6px 12px", borderRadius:8, border:"1px solid #e2e8f0", fontWeight:600 }}>
              📅 {new Date().toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"})}
            </div>

            {/* Notification bell */}
            <NotificationBell />

            {/* Profile — using ref to detect outside clicks */}
            <div ref={dropRef} style={{ position:"relative" }}>

              {/* Avatar button */}
              <button
                className="header-avatar"
                onClick={() => setProfileOpen(o => !o)}
                style={{
                  width:38, height:38, borderRadius:"50%",
                  background:"linear-gradient(135deg,#f97316,#ea580c)",
                  color:"#fff", border:"none", cursor:"pointer",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontWeight:900, fontSize:15,
                  boxShadow:"0 2px 10px rgba(249,115,22,.35)",
                  transition:"opacity .18s",
                  position:"relative", zIndex:201,
                }}>
                {adminName.charAt(0).toUpperCase()}
              </button>

              {/* DROPDOWN */}
              {profileOpen && (
                <div style={{
                  position:"absolute", top:48, right:0, width:272,
                  background:"#fff", borderRadius:18,
                  boxShadow:"0 20px 64px rgba(0,0,0,.18), 0 0 0 1px rgba(0,0,0,.06)",
                  zIndex:9999,           // ← very high, above everything
                  overflow:"hidden",
                  animation:"fadeIn .2s ease",
                }}>

                  {/* Profile header */}
                  <div style={{ padding:"18px 18px 14px", background:"linear-gradient(135deg,#fff7ed,#fff3e8)" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                      <div style={{ width:48, height:48, borderRadius:"50%", background:"linear-gradient(135deg,#f97316,#ea580c)", color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", fontWeight:900, fontSize:20, boxShadow:"0 4px 14px rgba(249,115,22,.4)", flexShrink:0 }}>
                        {adminName.charAt(0).toUpperCase()}
                      </div>
                      <div style={{ minWidth:0 }}>
                        <div style={{ fontSize:14, fontWeight:800, color:"#0f172a", marginBottom:2 }}>{adminName}</div>
                        <div style={{ fontSize:11, color:"#64748b", marginBottom:6, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{adminEmail}</div>
                        <span style={{ fontSize:10, fontWeight:800, padding:"2px 10px", borderRadius:20, background:"#fff7ed", color:"#f97316", border:"1px solid #fed7aa", textTransform:"uppercase", letterSpacing:.5 }}>
                          {adminRole}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div style={{ height:1, background:"#f1f5f9" }} />

                  {/* Menu items */}
                  <div style={{ padding:"8px" }}>
                    {[
                      { icon:"📊", label:"Dashboard",     path:"/dashboard",     color:"#f97316" },
                      { icon:"👤", label:"My Profile",    path:"/admin/profile", color:"#8b5cf6" },
                      { icon:"🔔", label:"Notifications", path:"/notifications", color:"#ec4899" },
                    ].map(({ icon, label, path, color }) => (
                      <button
                        className="drop-item"
                        key={path}
                        onClick={() => handleNavigate(path)}
                        style={{
                          display:"flex", alignItems:"center", gap:12,
                          width:"100%", padding:"10px 12px",
                          background:"none", border:"none",
                          cursor:"pointer", fontSize:13,
                          color:"#374151", borderRadius:10,
                          transition:"background .15s", textAlign:"left",
                        }}>
                        <div style={{ width:32, height:32, borderRadius:9, background:`${color}15`, border:`1px solid ${color}25`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>
                          {icon}
                        </div>
                        <span style={{ fontWeight:600 }}>{label}</span>
                      </button>
                    ))}
                  </div>

                  <div style={{ height:1, background:"#f1f5f9" }} />

                  {/* Logout */}
                  <div style={{ padding:"8px" }}>
                    <button
                      className="drop-logout"
                      onClick={handleLogout}
                      style={{
                        display:"flex", alignItems:"center", gap:12,
                        width:"100%", padding:"10px 12px",
                        background:"none", border:"none",
                        cursor:"pointer", fontSize:13,
                        color:"#ef4444", fontWeight:700,
                        borderRadius:10, transition:"background .15s",
                        textAlign:"left",
                      }}>
                      <div style={{ width:32, height:32, borderRadius:9, background:"#fef2f2", border:"1px solid #fecaca", display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>
                        ⏻
                      </div>
                      Logout
                    </button>
                  </div>

                </div>
              )}
            </div>
          </div>
        </header>

        {/* PAGE CONTENT */}
        <div style={{ flex:1, overflowY:"auto", background:"#fdf8f3" }}>
          <Outlet />
        
        </div>
      </div>
    </div>
  );
}
