import { useState, useRef, useEffect } from "react";

const API_BASE = "http://localhost:5000/api";

function getToken() {
  return (
    sessionStorage.getItem("token") ||
    localStorage.getItem("token") ||
    sessionStorage.getItem("authToken") ||
    localStorage.getItem("authToken") ||
    null
  );
}

async function fetchUserContext() {
  const token = getToken();
  if (!token) return null;
  const headers = { Authorization: `Bearer ${token}` };
  try {
    const [pR, oR, cR, couR, wR] = await Promise.allSettled([
      fetch(`${API_BASE}/users/profile`, { headers }),
      fetch(`${API_BASE}/orders/my`, { headers }),
      fetch(`${API_BASE}/cart`, { headers }),
      fetch(`${API_BASE}/coupon`, { headers }),
      fetch(`${API_BASE}/wallet`, { headers }),
    ]);
    const profile     = pR.status   === "fulfilled" && pR.value.ok   ? await pR.value.json()   : null;
    const ordersData  = oR.status   === "fulfilled" && oR.value.ok   ? await oR.value.json()   : null;
    const cartData    = cR.status   === "fulfilled" && cR.value.ok   ? await cR.value.json()   : null;
    const couponsData = couR.status === "fulfilled" && couR.value.ok ? await couR.value.json() : null;
    const walletData  = wR.status   === "fulfilled" && wR.value.ok   ? await wR.value.json()   : null;
    // Debug — remove after confirming prices are correct
    if (cartData) console.log("CART:", JSON.stringify(cartData).slice(0, 500));
    if (walletData) console.log("WALLET:", JSON.stringify(walletData).slice(0, 300));
    return { profile, ordersData, cartData, couponsData, walletData };
  } catch { return null; }
}

// ── helpers ──────────────────────────────────────────────────
const getOrderId     = (o) => String(o._id || o.id || "").slice(-6).toUpperCase();
const getOrderStatus = (o) => o.status || o.orderStatus || "Unknown";
const getOrderTotal  = (o) => o.totalPrice || o.originalPrice || o.totalAmount || o.total || o.grandTotal || 0;
const getOrderDate   = (o) => o.createdAt || o.orderDate || null;
const getOrderItems  = (o) => o.orderItems || o.items || o.products || [];
const fmtDate        = (d) => d ? new Date(d).toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"2-digit" }) : "N/A";
const fmtStatus      = (s) => {
  const m = {
    pending:"Pending", confirmed:"Confirmed", processing:"Processing",
    shipped:"Shipped", delivered:"Delivered", cancelled:"Cancelled", returned:"Returned"
  };
  return m[(s||"").toLowerCase()] || (s || "Unknown");
};
const getItemPrice = (i) =>
  i.salePrice || i.discountedPrice || i.offerPrice || i.sellingPrice ||
  i.price || i.productPrice || i.unitPrice ||
  (typeof i.product === "object" ? i.product?.price : 0) || 0;

// ── Main reply engine ─────────────────────────────────────────
function getReply(input, ctx) {
  const msg = input.toLowerCase().trim();
  const is  = (...words) => words.some((w) => msg.includes(w));

  const user    = ctx?.profile?.user || ctx?.profile || {};
  const orders  = ctx ? (Array.isArray(ctx.ordersData) ? ctx.ordersData : ctx.ordersData?.orders || ctx.ordersData?.data || []) : [];
  const rawCart = ctx?.cartData;
  const cartItems = rawCart
    ? (rawCart.items || rawCart.cartItems || rawCart.data?.items || rawCart.cart?.items || (Array.isArray(rawCart) ? rawCart : []))
    : [];
  const rawTotal = rawCart
    ? (rawCart.total || rawCart.totalAmount || rawCart.totalPrice || rawCart.cartTotal || rawCart.data?.total || 0)
    : 0;
  const computedTotal = cartItems.reduce((sum, i) => sum + getItemPrice(i) * (i.quantity || i.qty || 1), 0);
  const cartTotal = rawTotal > 0 ? rawTotal : computedTotal;

  const allCoupons    = ctx ? (Array.isArray(ctx.couponsData) ? ctx.couponsData : ctx.couponsData?.coupons || ctx.couponsData?.data || []) : [];
  const activeCoupons = allCoupons.filter((c) => c.isActive !== false && c.status !== "inactive");

  const walletBalance = ctx ? (ctx.walletData?.balance || ctx.walletData?.wallet?.balance || ctx.walletData?.walletBalance || ctx.walletData?.amount || 0) : 0;
  const walletTxns    = ctx ? (ctx.walletData?.transactions || ctx.walletData?.wallet?.transactions || ctx.walletData?.history || []) : [];

  const name = user.name || user.username || "there";

  // ── Guest (not logged in) ──────────────────────────────────
  if (!ctx) {
    if (is("hi","hello","hey"))
      return { text: "Hi! I'm ShopBot. How can I help you today?", buttons: ["Shipping info","Return policy","Payment options","Contact support"] };
    if (is("ship","deliver","delivery","shipping info","shipping"))
      return { text: "Shipping Options:\n\n- Standard Delivery: 3 to 5 business days\n  Free above Rs.499, else Rs.49\n- Express Delivery: 1 to 2 business days\n  Rs.99 to Rs.149\n\nFree shipping on orders above Rs.499.", buttons: ["Express delivery?","Delivery charges?"] };
    if (is("return","refund","exchange"))
      return { text: "Return Policy:\n- 7 day easy returns\n- Full refund within 30 days\n- Free pickup arranged\n\nLog in to initiate a return for your order.", buttons: ["Contact support"] };
    if (is("pay","payment","upi","cod","emi","card","net banking","payment options","payment method"))
      return { text: "Payment Methods:\n\n- UPI: GPay, PhonePe, Paytm\n- Credit / Debit Card\n- Net Banking\n- Cash on Delivery (COD)\n- ShopEasy Wallet\n- EMI on orders above Rs.3000\n\nAll payments are SSL encrypted.", buttons: ["Is payment secure?","EMI options?","COD available?"] };
    if (is("contact","support","human","agent"))
      return { text: "Contact Support:\nEmail: support@shopeasy.com\nPhone: 1800-XXX-XXXX (9AM to 9PM)\n\nLog in to track your specific orders.", buttons: [] };
    if (is("order","cart","coupon","profile","account","wallet"))
      return { text: "Please log in to access your orders, cart, wallet and account details.", buttons: ["Shipping info","Return policy","Payment options"] };
    return { text: "I can help with shipping, returns, payments and more. Log in for personal help!", buttons: ["Shipping info","Return policy","Payment options","Contact support"] };
  }

  // ── Logged in ──────────────────────────────────────────────

  // Greeting
  if (msg === "hi" || msg === "hello" || msg === "hey")
    return { text: "Hey " + name + "! How can I help you today?", buttons: ["My Orders","My Cart","My Wallet","Available Coupons","Payment options","Shipping info"] };

  // Help menu
  if (is("help","what can","menu"))
    return { text: "Here is everything I can help with:", buttons: ["My Orders","My Cart","My Wallet","Available Coupons","Track my order","Cancel an order","Return an item","Shipping info","Payment options","My Profile","Contact Support"] };

  // Profile
  if (is("my name","my profile","my account","my email","my phone","who am i"))
    return { text: "Your account:\nName: " + (user.name||"N/A") + "\nEmail: " + (user.email||"N/A") + (user.phone ? "\nPhone: " + user.phone : ""), buttons: ["Change my password","Add new address"] };

  if (is("change password","forgot password","reset password"))
    return { text: "To change your password:\n1. Go to Profile page\n2. Click Change Password\n3. Enter current and new password", buttons: [] };

  if (is("add address","new address","change address"))
    return { text: "To add a new address:\n1. Go to Profile page\n2. Click Addresses\n3. Click Add New Address\n4. Fill details and save", buttons: [] };

  // ── ORDERS ────────────────────────────────────────────────
  if (
    (is("my order","recent order","order history","show order","all order","past order","view order","last 5","my orders","orders") ||
     msg === "my orders" || msg === "orders") &&
    !is("cancel","return","track","wrong","damage","missing","modify","last order","latest order")
  ) {
    if (orders.length === 0)
      return { text: "You have not placed any orders yet. Start shopping!", buttons: ["Available Coupons","Shipping info"] };
    const tableRows = orders.slice(0,5).map((o) => ({
      id:     getOrderId(o),
      status: getOrderStatus(o),
      total:  getOrderTotal(o),
      date:   fmtDate(getOrderDate(o)),
      item:   getOrderItems(o).slice(0,1).map(i => i.name || i.productName || (typeof i.product==="object" ? i.product?.name : "") || "").filter(Boolean).join(""),
    }));
    return { text: "Your last " + Math.min(orders.length,5) + " orders:", tableRows, more: orders.length>5 ? orders.length-5 : 0, buttons: ["Track my order","Cancel an order","Return an item","Order not received"] };
  }

  // Latest order
  if (is("last order","latest order") || (is("order status") && !is("all","my order","my orders"))) {
    if (orders.length === 0) return { text: "You have not placed any orders yet." };
    const o = orders[0];
    const items = getOrderItems(o).slice(0,3).map(i => i.name || i.productName || (typeof i.product==="object" ? i.product?.name : "") || "Item").join(", ");
    return { text: "Your latest order:\n\nOrder #" + getOrderId(o) + "\nDate: " + fmtDate(getOrderDate(o)) + "\nStatus: " + fmtStatus(getOrderStatus(o)) + "\nTotal: Rs." + getOrderTotal(o) + (items ? "\nItems: " + items : ""), buttons: ["Track my order","Cancel this order","Return this order","View all orders"] };
  }

  // Track
  if (is("track","where is my order","order location")) {
    if (orders.length === 0) return { text: "You have no orders to track yet." };
    const o = orders[0];
    const s = (getOrderStatus(o)).toLowerCase();
    const sm = { pending:"Your order is pending confirmation.", confirmed:"Your order is confirmed and being prepared.", processing:"Your order is being processed.", shipped:"Your order is out for delivery!", delivered:"Your order has been delivered.", cancelled:"Your order was cancelled." };
    return { text: "Latest order #" + getOrderId(o) + ":\n" + (sm[s] || "Status: " + s), buttons: ["View all orders","Order not received","Return an item"] };
  }

  // Delivered check
  if (is("delivered","arrived") && !is("not delivered","not arrived")) {
    if (orders.length === 0) return { text: "You have no orders yet." };
    const delivered = orders.filter(o => (getOrderStatus(o)).toLowerCase()==="delivered").length;
    const pending   = orders.length - delivered;
    return { text: "Out of " + orders.length + " orders:\nDelivered: " + delivered + "\nPending/Other: " + pending, buttons: ["Return an item","View all orders"] };
  }

  // When will order arrive
  if (is("when will","arrive","expected delivery","delivery date")) {
    const active = orders.find(o => !["delivered","cancelled"].includes((getOrderStatus(o)).toLowerCase()));
    if (!active) return { text: "All your orders have been delivered or cancelled.", buttons: ["View all orders"] };
    return { text: "Your active order status: " + fmtStatus(getOrderStatus(active)) + "\n\nEstimated delivery:\n- Standard: 3 to 5 business days\n- Express: 1 to 2 business days\n\nCheck Orders page for exact date.", buttons: ["Track my order","Contact support"] };
  }

  // Order not received / missing
  if (is("not received","not delivered","missing","order missing","order not received")) {
    return { text: "Sorry to hear that!\n\nIf your order has not arrived:\n1. Check your order status first\n2. Wait 1 to 2 extra days if near expected date\n3. If still missing, contact support\n\nWe will investigate and resolve within 48 hours.", buttons: ["Track my order","Contact support","View all orders"] };
  }

  // Wrong / damaged
  if (is("wrong product","wrong item","damaged","broken","defective","incorrect"))
    return { text: "Sorry about that!\n\nFor wrong or damaged products:\n1. Go to Orders page\n2. Click View Details on the order\n3. Click Return Order\n4. Select reason and submit\n\nWe will arrange free pickup and refund within 3 days.", buttons: ["Return an item","Contact support"] };

  // Cancel
  if (is("cancel order","cancel my order","cancel an order","cancel this order")) {
    const cancellable = orders.filter(o => ["pending","processing","placed"].includes((getOrderStatus(o)).toLowerCase()));
    if (cancellable.length === 0)
      return { text: "No orders are eligible for cancellation.\n\nOrders can only be cancelled when status is Pending or Processing. Once shipped, cancellation is not possible.", buttons: ["Return an item","Contact support"] };
    const list = cancellable.map(o => "- Order #" + getOrderId(o) + " (" + fmtStatus(getOrderStatus(o)) + ")").join("\n");
    return { text: "Orders you can cancel:\n" + list + "\n\nHow to cancel:\n1. Go to Orders page\n2. Click View Details\n3. Scroll down and click Cancel Order\n4. Select a reason and confirm", buttons: ["View all orders","Return an item"] };
  }

  // Return
  if (is("return","exchange") && !is("return policy","can i return")) {
    const returnable = orders.filter(o => (getOrderStatus(o)).toLowerCase()==="delivered");
    if (returnable.length === 0)
      return { text: "No delivered orders found for return.\n\nReturns are accepted within 7 days of delivery.", buttons: ["View all orders","Contact support"] };
    const list = returnable.map(o => "- Order #" + getOrderId(o) + " | " + fmtDate(getOrderDate(o))).join("\n");
    return { text: "Delivered orders eligible for return:\n" + list + "\n\nHow to return:\n1. Go to Orders page\n2. Click View Details\n3. Click Return Order button\n4. Select items and reason\n5. Submit\n\nRefund within 30 days after pickup.", buttons: ["Refund policy","Contact support"] };
  }

  // Refund
  if (is("refund","money back")) {
    if (is("not received","where is","status","pending"))
      return { text: "Refund timelines:\n- UPI / Net Banking: 3 to 5 business days\n- Credit/Debit Card: 5 to 7 business days\n- COD orders: 7 to 10 business days via bank transfer\n\nContact support if it has been longer.", buttons: ["Contact support"] };
    return { text: "Refund Policy:\n- Full refund within 30 days of return approval\n- Refund goes to original payment method\n- COD orders refunded via bank transfer\n\nProcessing time: 3 to 7 business days after pickup.", buttons: ["Return an item","Contact support"] };
  }

  // How many orders
  if (is("how many order","number of order","total order"))
    return { text: "You have placed " + orders.length + " order" + (orders.length!==1?"s":"") + " so far.", buttons: ["View all orders","Track my order"] };

  // Modify order
  if (is("modify order","change order","edit order"))
    return { text: "Orders can only be modified before they are shipped.\n\nFor pending orders:\n1. Go to Orders page\n2. Click View Details\n3. Click Modify Order\n\nIf already shipped, modifications are not possible.", buttons: ["Cancel an order","Contact support"] };

  // ── CART ──────────────────────────────────────────────────
  if ((is("my cart","what is in","what's in","show cart","cart item","view cart") || msg==="my cart") && !is("total","amount","checkout","proceed")) {
    if (cartItems.length === 0)
      return { text: "Your cart is empty! Browse products and add something you like.", buttons: ["Available Coupons","Shipping info"] };
    const list = cartItems.slice(0,5).map(i => {
      const n = i.name || i.productName || (typeof i.product==="object" ? i.product?.name : "") || i.title || "Product";
      const q = i.quantity || i.qty || 1;
      const p = getItemPrice(i);
      return "- " + n + " x" + q + " = Rs." + (p * q);
    }).join("\n");
    const displayTotal = cartTotal > 0 ? cartTotal : computedTotal;
    return { text: "Your cart (" + cartItems.length + " items):\n\n" + list + (cartItems.length>5 ? "\n...and " + (cartItems.length-5) + " more" : "") + "\n\nTotal: Rs." + displayTotal, buttons: ["Cart total & shipping?","Available Coupons","Proceed to checkout?"] };
  }

  // Cart total
  if (is("cart total","total amount","how much is my cart","cart amount","checkout","proceed","cart total & shipping")) {
    if (cartItems.length === 0)
      return { text: "Your cart is empty! Add some products first.", buttons: ["Available Coupons","Shipping info"] };
    const displayTotal = cartTotal > 0 ? cartTotal : computedTotal;
    const freeShip = displayTotal >= 499 ? "Your cart qualifies for FREE shipping!" : "Add Rs." + (499-displayTotal) + " more for free shipping.";
    const emi      = displayTotal >= 3000 ? "Your cart is eligible for EMI!" : "EMI available on orders above Rs.3000.";
    return { text: "Cart total: Rs." + displayTotal + "\n\n" + freeShip + "\n" + emi, buttons: ["Available Coupons","Payment options","Shipping info"] };
  }

  // Free shipping
  if (is("free shipping","free deliver")) {
    const d = cartTotal > 0 ? cartTotal : computedTotal;
    if (d === 0) return { text: "Free shipping on all orders above Rs.499.", buttons: ["My Cart","Shipping info"] };
    if (d >= 499) return { text: "Your cart (Rs." + d + ") qualifies for FREE shipping!", buttons: ["Available Coupons","Proceed to checkout?"] };
    return { text: "You need Rs." + (499-d) + " more for free shipping. Current cart: Rs." + d, buttons: ["My Cart","Available Coupons"] };
  }

  // Out of stock
  if (is("out of stock","back in stock","restock","notify me"))
    return { text: "For out of stock products:\n- Add to Wishlist to save it\n- Check back regularly\n- Contact support to request an item\n\nRestocking typically takes 7 to 14 days.", buttons: ["My Wishlist","Contact support"] };

  // ── WALLET ───────────────────────────────────────────────
  if (is("wallet","my wallet","wallet balance","shopeasy wallet") || msg==="my wallet") {
    const recentTxns = walletTxns.slice(0,3).map(t => {
      const type = (t.type || t.transactionType || "").toLowerCase();
      const amt  = t.amount || 0;
      const desc = t.description || t.note || t.reason || "";
      const icon = (type==="credit"||type==="refund") ? "+" : "-";
      return icon + " Rs." + amt + (desc ? " (" + desc.slice(0,25) + ")" : "");
    }).join("\n");
    if (walletBalance === 0 && walletTxns.length === 0)
      return { text: "Your wallet balance: Rs.0\n\nWallet gets credited when:\n- You cancel a paid order\n- A return is approved\n- Refunds are processed\n\nYou can use wallet balance at checkout!", buttons: ["My Orders","Payment options"] };
    return { text: "Your Wallet\n\nBalance: Rs." + walletBalance + (recentTxns ? "\n\nRecent transactions:\n" + recentTxns : "\n\nNo transactions yet.") + "\n\nUse wallet balance at checkout for instant payment!", buttons: ["My Orders","Payment options","My Cart"] };
  }

  // ── COUPONS ──────────────────────────────────────────────
  if (is("coupon","discount code","promo","offer","voucher","available coupon")) {
    if (is("apply","how to apply"))
      return { text: "To apply a coupon:\n1. Add products to cart\n2. Go to Checkout\n3. Enter coupon code in Apply Coupon field\n4. Click Apply\n\nDiscount applied automatically.", buttons: ["Available Coupons","Coupon not working?"] };
    if (is("not working","invalid","expired","does not work"))
      return { text: "Coupon not working? Check:\n- Coupon may have expired\n- Minimum order amount not met\n- Already used (single use coupons)\n- Not applicable for selected products\n\nContact support if issue persists.", buttons: ["Available Coupons","Contact support"] };
    if (is("multiple","combine","two coupon","stack"))
      return { text: "Only one coupon can be applied per order.\n\nChoose the coupon that gives you the best discount!", buttons: ["Available Coupons"] };
    if (activeCoupons.length === 0)
      return { text: "No active coupons available right now. Check back soon!", buttons: ["Shipping info","Payment options"] };
    const list = activeCoupons.slice(0,5).map(c => {
      const code = c.code || c.couponCode || "N/A";
      const disc = c.discountType==="percentage" ? c.discountValue+"% off" : "Rs."+c.discountValue+" off";
      const min  = c.minOrderAmount ? " (min Rs."+c.minOrderAmount+")" : "";
      return "- " + code + ": " + disc + min;
    }).join("\n");
    return { text: "Available Coupons:\n\n" + list + "\n\nApply at checkout to save!", buttons: ["How to apply coupon?","Can I use multiple coupons?"] };
  }

  // ── SHIPPING ─────────────────────────────────────────────
  if (is("ship","deliver","delivery time","how long","how many days","shipping info","shipping","standard delivery","express delivery") || msg==="shipping info") {
    if (is("sunday","weekend","holiday"))
      return { text: "Delivery Schedule:\n- Standard: Monday to Saturday\n- Express: Monday to Sunday (select cities)\n- Public holidays may cause 1 day delay", buttons: ["Express delivery?","Contact support"] };
    if (is("international","abroad","outside india","foreign"))
      return { text: "ShopEasy currently delivers within India only. International shipping coming soon!", buttons: ["Shipping info","Contact support"] };
    if (is("express","fast","urgent","quick") && !is("shipping info"))
      return { text: "Express Delivery:\n- Delivered in 1 to 2 business days\n- Rs.99 to Rs.149 based on location\n- Available in select cities\n\nCheck availability at checkout.", buttons: ["Standard delivery?","Delivery charges?"] };
    if (is("charge","cost","fee","price of delivery","delivery charges"))
      return { text: "Delivery Charges:\n- Free shipping on orders above Rs.499\n- Standard delivery below Rs.499: Rs.49\n- Express delivery: Rs.99 to Rs.149", buttons: ["Free shipping?","Express delivery?"] };
    const d = cartTotal > 0 ? cartTotal : computedTotal;
    const fs = d >= 499 ? "Your cart qualifies for FREE shipping!" : d > 0 ? "Add Rs." + (499-d) + " more for free shipping!" : "Free shipping on orders above Rs.499.";
    return { text: "Shipping Options:\n\n- Standard Delivery: 3 to 5 business days\n  Free above Rs.499, otherwise Rs.49\n\n- Express Delivery: 1 to 2 business days\n  Rs.99 to Rs.149\n\n" + fs, buttons: ["Delivery charges?","Express delivery?","Deliver on Sundays?"] };
  }

  // ── PAYMENT ──────────────────────────────────────────────
  if (is("pay","payment","upi","cod","cash on delivery","emi","card","net banking","instalment","payment options","payment method","how to pay") || msg==="payment options") {
    if (is("fail","failed","not done","unsuccessful"))
      return { text: "Payment failed? Do not worry!\n\n- If money was deducted it will auto-refund in 3 to 5 business days\n- Order will not be placed for failed payments\n- Try again with a different payment method\n\nContact support if refund is delayed.", buttons: ["Money deducted but no order","Contact support"] };
    if (is("deducted","money gone","charged","debited") && is("not placed","not confirmed","no order"))
      return { text: "Money deducted but order not placed?\n- Auto-resolved within 24 hours\n- Refund in 3 to 5 business days\n\nContact support with your transaction ID if not resolved in 5 days.", buttons: ["Contact support"] };
    if (is("secure","safe","security"))
      return { text: "Yes, your payments are 100% secure!\n\n- SSL encrypted transactions\n- PCI-DSS compliant\n- No card details stored on our servers\n- 3D Secure authentication", buttons: ["Payment options","Contact support"] };
    if (is("which card","card accept","visa","mastercard","rupay","amex"))
      return { text: "Accepted Cards:\n- Visa\n- Mastercard\n- RuPay\n- American Express\n- Maestro\n\nAll major Indian and international cards accepted.", buttons: ["Is payment secure?","EMI options?"] };
    if (is("emi","instalment","installment")) {
      const d = cartTotal > 0 ? cartTotal : computedTotal;
      const e = d >= 3000 ? "Your cart (Rs."+d+") is eligible for EMI!" : d > 0 ? "Add Rs."+(3000-d)+" more for EMI." : "EMI on orders above Rs.3000.";
      return { text: "EMI Options:\n- Available on orders above Rs.3000\n- 3, 6, 9, 12 month plans\n- Available on select cards\n- No-cost EMI on select products\n\n" + e, buttons: ["Which cards accepted?","Is payment secure?"] };
    }
    if (is("cod","cash on delivery","cash"))
      return { text: "Yes, Cash on Delivery (COD) is available!\n\n- Pay cash when your order arrives\n- Available on most products\n- No extra charges for COD\n\nNote: Some high-value orders may not be eligible for COD.", buttons: ["Payment options","Shipping info"] };
    return { text: "Payment Methods Available:\n\n- UPI: GPay, PhonePe, Paytm\n- Credit / Debit Card\n- Net Banking\n- Cash on Delivery (COD)\n- ShopEasy Wallet\n- EMI on orders above Rs.3000\n\nAll payments are SSL encrypted and 100% secure.", buttons: ["Is payment secure?","Which cards accepted?","EMI options?","COD available?","Payment failed?"] };
  }

  // ── WISHLIST ──────────────────────────────────────────────
  if (is("wishlist","saved items","favourite","favorite") || msg==="my wishlist")
    return { text: "Your Wishlist is available on the Wishlist page.\n\nYou can:\n- Add items from any product page using the heart icon\n- Move items from wishlist to cart\n- Remove items you no longer want", buttons: ["My Cart","Available Coupons"] };

  // ── SHOPCOIN ──────────────────────────────────────────────
  if (is("shopcoin","coin","loyalty","reward","point"))
    return { text: "ShopCoins loyalty program is coming soon!\n\nWe are working on it and will notify you when it goes live. Stay tuned for exciting rewards!", buttons: ["Available Coupons","My Wallet"] };

  // ── MEMBERSHIP ───────────────────────────────────────────
  if (is("membership","premium","plan","upgrade","member benefit")) {
    const mem = user.membership;
    const hasMem = mem?.isActive && mem?.planId;
    return { text: "ShopEasy Membership Benefits:\n- Exclusive discounts on every order\n- Free delivery perks\n- Member-only coupon access\n\n" + (hasMem ? "You have an active membership plan!" : "Visit the Membership page to subscribe and start saving!"), buttons: ["Available Coupons","Contact support"] };
  }

  // ── PRODUCT ───────────────────────────────────────────────
  if (is("genuine","original","authentic","fake"))
    return { text: "All products on ShopEasy are 100% genuine and sourced from authorized sellers.\n\nIf you receive a non-genuine product, we offer a full refund.", buttons: ["Return policy","Contact support"] };

  if (is("warranty","guarantee"))
    return { text: "Warranty information varies by product:\n- Electronics: 1 to 2 year manufacturer warranty\n- Appliances: 1 year standard warranty\n- Other products: Check the product page\n\nWarranty card included with eligible products.", buttons: ["Return policy","Contact support"] };

  if (is("size guide","size chart","which size","fit"))
    return { text: "Size guides are available on each product page.\n\nLook for the Size Guide link below the size selector.\n\nNot sure? Order 2 sizes and return the one that does not fit within 7 days.", buttons: ["Return policy","Contact support"] };

  if (is("colour","color","different colour","variant"))
    return { text: "To check other colour or size variants:\n- Open the product page\n- Look for colour and size options below the product image\n- Select your preferred variant\n\nIf a variant is not available, add to wishlist.", buttons: ["My Wishlist","Contact support"] };

  // ── COMPLAINT ────────────────────────────────────────────
  if (is("complaint","complain","report","lodge","escalate"))
    return { text: "To report a complaint, contact our support team:\n\nEmail: support@shopeasy.com\nPhone: 1800-XXX-XXXX (9AM to 9PM, Mon to Sat)\n\nMention your Order ID and describe the issue. Our team responds within 24 hours.", buttons: ["Contact support","My Orders","Return an item"] };

  // ── SUPPORT ──────────────────────────────────────────────
  if (is("contact","support","human","agent","customer care","helpline") || msg==="contact support")
    return { text: "Contact ShopEasy Support:\n\nEmail: support@shopeasy.com\nPhone: 1800-XXX-XXXX (9AM to 9PM, Mon to Sat)\n\nAverage response time: 2 to 4 hours.", buttons: ["Report a complaint","My Orders","Return an item"] };

  // ── THANKS / BYE ──────────────────────────────────────────
  if (is("thank","thanks","thank you"))
    return { text: "You are welcome, " + name + "! Happy shopping at ShopEasy!" };
  if (is("bye","goodbye","see you","exit"))
    return { text: "Goodbye " + name + "! Have a great day and happy shopping!" };

  // ── DEFAULT ───────────────────────────────────────────────
  return { text: "I am not sure about that. Here is what I can help with:", buttons: ["My Orders","My Cart","My Wallet","Available Coupons","Return an item","Shipping info","Payment options","Contact Support"] };
}

// ── Suggestions ───────────────────────────────────────────────
const SUGG_GUEST = ["Shipping info","Return policy","Payment options","Contact support"];
const SUGG_USER  = ["My Orders","My Cart","My Wallet","Available Coupons"];

// ── Component ─────────────────────────────────────────────────
export default function EcommerceChatbot() {
  const [isOpen, setIsOpen]           = useState(false);
  const [messages, setMessages]       = useState([]);
  const [input, setInput]             = useState("");
  const [hasUnread, setHasUnread]     = useState(false);
  const [userContext, setUserContext] = useState(undefined);
  const [userName, setUserName]       = useState("");
  const [loading, setLoading]         = useState(true);

  const endRef   = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    fetchUserContext().then((ctx) => {
      setUserContext(ctx);
      const name = ctx?.profile?.user?.name || ctx?.profile?.name || ctx?.profile?.username || "";
      setUserName(name);
      const greeting = name
        ? "Hey " + name + "! I can see your orders, cart and wallet. How can I help?"
        : "Hi there! I am ShopBot. Ask me about shipping, returns, payments or log in for personal help!";
      setMessages([{ role:"bot", text:greeting, buttons: name ? SUGG_USER : SUGG_GUEST, id:Date.now() }]);
      setLoading(false);
    });
  }, []);

  useEffect(() => {
    if (isOpen) { endRef.current?.scrollIntoView({ behavior:"smooth" }); inputRef.current?.focus(); setHasUnread(false); }
  }, [messages, isOpen]);

  useEffect(() => { if (!isOpen && messages.length > 1) setHasUnread(true); }, [messages]);

  const refreshData = async () => {
    setLoading(true);
    const ctx = await fetchUserContext();
    setUserContext(ctx);
    setLoading(false);
    setMessages(prev => [...prev, { role:"bot", text:"Data refreshed! Your latest info is updated.", id:Date.now() }]);
  };

  const sendMessage = (text) => {
    const userText = (text || input).trim();
    if (!userText) return;
    const reply = getReply(userText, userContext);
    setMessages(prev => [
      ...prev,
      { role:"user", text:userText, id:Date.now() },
      { role:"bot", text:reply.text, buttons:reply.buttons, tableRows:reply.tableRows, more:reply.more, id:Date.now()+1 },
    ]);
    setInput("");
  };

  const handleKey = (e) => { if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } };
  const isLoggedIn = !!userContext;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600&family=Syne:wght@700&display=swap');
        .cr*{box-sizing:border-box;font-family:'DM Sans',sans-serif}
        .cr-fab{position:fixed;bottom:28px;right:28px;z-index:9999;width:62px;height:62px;border-radius:50%;background:linear-gradient(135deg,#ff6f00,#ff8f00);border:none;cursor:pointer;box-shadow:0 4px 24px rgba(255,111,0,.45);display:flex;align-items:center;justify-content:center;transition:transform .25s cubic-bezier(.34,1.56,.64,1)}
        .cr-fab:hover{transform:scale(1.08)}
        .cr-fab svg{width:28px;height:28px;fill:white}
        .cr-badge{position:absolute;top:6px;right:6px;width:14px;height:14px;border-radius:50%;background:#ef4444;border:2px solid white;animation:cr-pulse 1.5s infinite}
        @keyframes cr-pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.2)}}
        .cr-win{position:fixed;bottom:104px;right:28px;z-index:9998;width:385px;height:580px;background:#fff8f2;border-radius:24px;box-shadow:0 20px 60px rgba(0,0,0,.18);display:flex;flex-direction:column;overflow:hidden;transform-origin:bottom right;animation:cr-up .3s cubic-bezier(.34,1.56,.64,1)}
        @keyframes cr-up{from{opacity:0;transform:scale(.85) translateY(20px)}to{opacity:1;transform:scale(1) translateY(0)}}
        .cr-hdr{background:linear-gradient(135deg,#ff6f00,#e65100);padding:16px 18px;display:flex;align-items:center;gap:12px;flex-shrink:0}
        .cr-av{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
        .cr-hi{flex:1}
        .cr-hn{font-family:'Syne',sans-serif;font-size:15px;font-weight:700;color:white;line-height:1}
        .cr-hs{font-size:11.5px;color:rgba(255,255,255,.85);margin-top:3px;display:flex;align-items:center;gap:5px}
        .cr-dot{width:7px;height:7px;border-radius:50%;background:#4ade80;box-shadow:0 0 6px #4ade80}
        .cr-ubadge{font-size:10.5px;background:rgba(255,255,255,.2);color:white;padding:2px 8px;border-radius:20px;margin-top:4px;display:inline-block}
        .cr-close{background:rgba(255,255,255,.2);border:none;cursor:pointer;width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-size:16px}
        .cr-close:hover{background:rgba(255,255,255,.35)}
        .cr-msgs{flex:1;overflow-y:auto;padding:14px 14px 8px;display:flex;flex-direction:column;gap:10px;scroll-behavior:smooth}
        .cr-msgs::-webkit-scrollbar{width:4px}
        .cr-msgs::-webkit-scrollbar-thumb{background:#ffd0a0;border-radius:4px}
        .cr-row{display:flex;gap:8px}
        .cr-row.u{flex-direction:row-reverse}
        .cr-mav{width:28px;height:28px;border-radius:50%;flex-shrink:0;background:linear-gradient(135deg,#ff6f00,#e65100);display:flex;align-items:center;justify-content:center;font-size:13px;margin-top:2px}
        .cr-mav.u{background:linear-gradient(135deg,#7c3aed,#5b21b6)}
        .cr-mc{display:flex;flex-direction:column;gap:6px;max-width:82%}
        .cr-row.u .cr-mc{align-items:flex-end}
        .cr-bub{padding:10px 14px;border-radius:18px;font-size:13.5px;line-height:1.6;word-break:break-word;white-space:pre-wrap}
        .cr-bub.b{background:white;color:#1a1a1a;border-bottom-left-radius:5px;box-shadow:0 2px 10px rgba(0,0,0,.07)}
        .cr-bub.u{background:linear-gradient(135deg,#ff6f00,#e65100);color:white;border-bottom-right-radius:5px}
        .cr-tbl-wrap{background:white;border-radius:12px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,.07);overflow-x:auto;max-width:330px}
        .cr-tbl{width:100%;border-collapse:collapse;font-size:11.5px}
        .cr-tbl th{background:linear-gradient(135deg,#ff6f00,#e65100);color:white;padding:7px 8px;text-align:left;font-weight:600;font-size:10.5px}
        .cr-tbl td{padding:7px 8px;border-bottom:1px solid #f0e6dc;vertical-align:middle}
        .cr-tbl tr:last-child td{border-bottom:none}
        .cr-tbl tr:nth-child(even) td{background:#fff3e6}
        .cr-sb{display:inline-block;padding:2px 7px;border-radius:10px;font-size:10px;font-weight:700;white-space:nowrap}
        .cr-sb.pending{background:#fff3cd;color:#856404}
        .cr-sb.confirmed{background:#d1fae5;color:#065f46}
        .cr-sb.processing{background:#dbeafe;color:#1e40af}
        .cr-sb.shipped{background:#e0f2fe;color:#0369a1}
        .cr-sb.delivered{background:#dcfce7;color:#166534}
        .cr-sb.cancelled{background:#fee2e2;color:#991b1b}
        .cr-sb.returned{background:#f3e8ff;color:#6b21a8}
        .cr-more{padding:5px 10px;font-size:11px;color:#ff6f00;font-weight:500}
        .cr-btns{display:flex;flex-wrap:wrap;gap:6px;margin-top:2px}
        .cr-btn{padding:5px 11px;border-radius:16px;font-size:12px;font-weight:500;border:1.5px solid #ff6f00;color:#ff6f00;background:white;cursor:pointer;white-space:nowrap;transition:all .18s}
        .cr-btn:hover{background:#ff6f00;color:white;transform:translateY(-1px)}
        .cr-sugg{padding:6px 12px 2px;display:flex;gap:7px;flex-wrap:nowrap;overflow-x:auto;flex-shrink:0}
        .cr-sugg::-webkit-scrollbar{display:none}
        .cr-chip{padding:6px 12px;border-radius:20px;font-size:12px;font-weight:500;border:1.5px solid #ff6f00;color:#ff6f00;background:white;cursor:pointer;white-space:nowrap;transition:all .2s;flex-shrink:0}
        .cr-chip:hover{background:#ff6f00;color:white}
        .cr-ref{display:flex;align-items:center;gap:5px;font-size:11px;color:#ff6f00;background:none;border:none;cursor:pointer;padding:2px 12px 6px;opacity:.75;transition:opacity .2s}
        .cr-ref:hover{opacity:1}
        .cr-inp{padding:10px 12px 14px;background:white;border-top:1px solid #f0e6dc;display:flex;gap:10px;align-items:flex-end;flex-shrink:0}
        .cr-ta{flex:1;border:1.5px solid #e8ddd5;border-radius:20px;padding:10px 14px;font-size:13.5px;resize:none;outline:none;font-family:'DM Sans',sans-serif;background:#fff8f2;color:#1a1a1a;line-height:1.4;max-height:100px;transition:border-color .2s}
        .cr-ta:focus{border-color:#ff6f00}
        .cr-ta::placeholder{color:#bfb0a5}
        .cr-send{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#ff6f00,#e65100);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;box-shadow:0 2px 10px rgba(255,111,0,.35)}
        .cr-send:hover{transform:scale(1.08)}
        .cr-send:disabled{opacity:.5;cursor:not-allowed;transform:none}
        .cr-send svg{width:18px;height:18px;fill:white}
        @media(max-width:440px){.cr-win{width:calc(100vw - 24px);right:12px;bottom:90px;height:510px}.cr-fab{bottom:16px;right:16px}}
      `}</style>

      <div className="cr">
        {/* FAB */}
        <button className="cr-fab" onClick={() => setIsOpen(o => !o)}>
          {isOpen
            ? <svg viewBox="0 0 24 24"><path d="M19 6.4L17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12z"/></svg>
            : <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/></svg>
          }
          {hasUnread && !isOpen && <span className="cr-badge" />}
        </button>

        {isOpen && (
          <div className="cr-win">
            {/* Header */}
            <div className="cr-hdr">
              <div className="cr-av">🛍️</div>
              <div className="cr-hi">
                <div className="cr-hn">ShopBot</div>
                <div className="cr-hs"><span className="cr-dot"/>Always here to help</div>
                {isLoggedIn && userName && <span className="cr-ubadge">👤 {userName}</span>}
              </div>
              <button className="cr-close" onClick={() => setIsOpen(false)}>✕</button>
            </div>

            {/* Messages */}
            <div className="cr-msgs">
              {messages.map(msg => (
                <div key={msg.id} className={"cr-row" + (msg.role==="user" ? " u" : "")}>
                  <div className={"cr-mav" + (msg.role==="user" ? " u" : "")}>
                    {msg.role==="user" ? "👤" : "🤖"}
                  </div>
                  <div className="cr-mc">
                    <div className={"cr-bub " + (msg.role==="user" ? "u" : "b")}>{msg.text}</div>

                    {/* Order table */}
                    {msg.tableRows && msg.tableRows.length > 0 && (
                      <div className="cr-tbl-wrap">
                        <table className="cr-tbl">
                          <thead>
                            <tr><th>Order</th><th>Status</th><th>Total</th><th>Date</th></tr>
                          </thead>
                          <tbody>
                            {msg.tableRows.map(r => (
                              <tr key={r.id}>
                                <td>
                                  <div style={{fontWeight:600,fontSize:"11.5px"}}>#{r.id}</div>
                                  {r.item && <div style={{color:"#888",fontSize:"10px",marginTop:"2px"}}>{r.item.slice(0,20)}{r.item.length>20?"...":""}</div>}
                                </td>
                                <td><span className={"cr-sb " + r.status.toLowerCase()}>{fmtStatus(r.status)}</span></td>
                                <td style={{fontWeight:600}}>Rs.{r.total}</td>
                                <td style={{fontSize:"10.5px",color:"#666"}}>{r.date}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                        {msg.more > 0 && <div className="cr-more">+{msg.more} more orders</div>}
                      </div>
                    )}

                    {/* Buttons */}
                    {msg.buttons && msg.buttons.length > 0 && (
                      <div className="cr-btns">
                        {msg.buttons.map(btn => (
                          <button key={btn} className="cr-btn" onClick={() => sendMessage(btn)}>{btn}</button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <div ref={endRef}/>
            </div>

            {/* Initial suggestions */}
            {messages.length <= 2 && (
              <div className="cr-sugg">
                {(isLoggedIn ? SUGG_USER : SUGG_GUEST).map(s => (
                  <button key={s} className="cr-chip" onClick={() => sendMessage(s)}>{s}</button>
                ))}
              </div>
            )}

            {/* Refresh */}
            {isLoggedIn && (
              <button className="cr-ref" onClick={refreshData} disabled={loading}>
                🔄 {loading ? "Refreshing..." : "Refresh my data"}
              </button>
            )}

            {/* Input */}
            <div className="cr-inp">
              <textarea
                ref={inputRef}
                className="cr-ta"
                rows={1}
                placeholder={isLoggedIn ? "Ask about orders, cart, wallet..." : "Ask me anything..."}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKey}
              />
              <button className="cr-send" onClick={() => sendMessage()} disabled={!input.trim()}>
                <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
