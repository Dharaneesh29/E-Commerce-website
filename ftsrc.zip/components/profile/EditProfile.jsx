// import { useState } from "react";
// import axios from "axios";
 
// const EditProfile = ({ user, onClose }) => {
//   const [form, setForm] = useState({
//     name: user?.name || "",
//     phone: user?.phone || "",
//     dob: user?.dob ? user.dob.substring(0, 10) : "",
//     gender: user?.gender || "",
//     bio: user?.bio || "",
//     city: user?.city || "",
//   });
 
//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };
 
//   const handleSave = async () => {
//   try {
//     const token = sessionStorage.getItem("token");
 
//     const { data } = await axios.put(
//       "http://localhost:5000/api/users/profile",
//       form,
//       {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       }
//     );
 
//     // ✅ GET OLD DATA
//     const oldData = JSON.parse(sessionStorage.getItem("userInfo") || "null");
 
//     // ✅ CREATE NEW OBJECT
//     const updatedUserInfo = {
//       user: data.user,        // 🔥 FIX HERE
//       token: oldData?.token,  // keep token
//     };
 
//     // ✅ SAVE AGAIN
//     sessionStorage.setItem("userInfo", JSON.stringify(updatedUserInfo));
 
//     alert("Profile Updated ✅");
 
//   } catch (err) {
//     console.log(err);
//   }
// };
 
 
//   return (
//     <div className="fixed inset-0 bg-black/40 flex justify-center items-center z-50">
 
//       <div className="bg-white p-6 rounded-xl w-[400px] shadow-lg">
 
//         <h2 className="text-xl font-bold mb-4">Edit Profile</h2>
 
//         {/* INPUTS */}
//         <input
//           name="name"
//           value={form.name}
//           onChange={handleChange}
//           placeholder="Name"
//           className="w-full mb-3 p-2 border rounded"
//         />
 
//         <input
//           name="phone"
//           value={form.phone}
//           onChange={handleChange}
//           placeholder="Phone"
//           className="w-full mb-3 p-2 border rounded"
//         />
 
//         <input
//           type="date"
//           name="dob"
//           value={form.dob}
//           onChange={handleChange}
//           className="w-full mb-3 p-2 border rounded"
//         />
 
//         <select
//           name="gender"
//           value={form.gender}
//           onChange={handleChange}
//           className="w-full mb-3 p-2 border rounded"
//         >
//           <option value="">Select Gender</option>
//           <option value="male">Male</option>
//           <option value="female">Female</option>
//           <option value="other">Other</option>
//         </select>
 
//         <input
//           name="city"
//           value={form.city}
//           onChange={handleChange}
//           placeholder="City"
//           className="w-full mb-3 p-2 border rounded"
//         />
 
//         <textarea
//           name="bio"
//           value={form.bio}
//           onChange={handleChange}
//           placeholder="Bio"
//           className="w-full mb-3 p-2 border rounded"
//         />
 
//         {/* BUTTONS */}
//         <div className="flex justify-end gap-3 mt-4">
//           <button onClick={onClose}>Cancel</button>
 
//           <button
//             onClick={handleSave}
//             className="bg-orange-500 text-white px-4 py-2 rounded"
//           >
//             Save
//           </button>
//         </div>
 
//       </div>
//     </div>
//   );
// };
 
// export default EditProfile;
 

import { useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";
 
const EditProfile = ({ user, setUser, onClose }) => {
  const [form, setForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    dob: user?.dob ? user.dob.substring(0, 10) : "",
    gender: user?.gender || "",
    bio: user?.bio || "",
    city: user?.city || "",
  });
 
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(user?.profilePic || "");
  const [loading, setLoading] = useState(false);
 
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
 
  // 🔥 IMAGE SELECT (click)
  const handleImage = (file) => {
    if (!file) return;
    setImage(file);
    setPreview(URL.createObjectURL(file));
  };
 
  // 🔥 DRAG DROP
  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    handleImage(file);
  };
 
  const handleSave = async () => {
    try {
      setLoading(true);
 
      const oldData = JSON.parse(sessionStorage.getItem("userInfo") || "null");
      const token = oldData?.token;
 
      const formData = new FormData();
 
      Object.keys(form).forEach((key) => {
        formData.append(key, form[key]);
      });
 
      if (image) {
        formData.append("profilePic", image);
      }
 
      const { data } = await axios.put(
        "http://localhost:5000/api/users/profile",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
 
      const updatedUserInfo = {
        user: data.user,
        token,
      };
 
      sessionStorage.setItem("userInfo", JSON.stringify(updatedUserInfo));
 
      setUser(data.user); // 🔥 live update
      toast.success("Profile updated 🚀");
 
      onClose();
    } catch (err) {
      console.log(err);
      toast.error("Update failed ❌");
    } finally {
      setLoading(false);
    }
  };
 
  return (
    <div className="fixed inset-0 z-50 flex">
 
      {/* BACKDROP */}
      <div
        className="flex-1 bg-black/40"
        onClick={onClose}
      />
 
      {/* SLIDE PANEL */}
      <div className="w-[380px] bg-white h-full shadow-xl p-6 flex flex-col">
 
        <h2 className="text-xl font-bold mb-4">Edit Profile</h2>
 
        {/* IMAGE */}
        <div
          className="flex justify-center mb-5"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
        >
          <label className="cursor-pointer group relative">
 
            <img
              src={
                preview
                  ? preview.startsWith("http")
                    ? preview
                    : `http://localhost:5000${preview}`
                  : "/avatar.png"
              }
              alt="preview"
              className="w-24 h-24 rounded-full object-cover border"
            />
 
            {/* 🔥 FIXED OVERLAY */}
            <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs">
              Change
            </div>
 
            <input
              type="file"
              hidden
              onChange={(e) => handleImage(e.target.files[0])}
            />
          </label>
        </div>
 
        {/* FORM */}
        <div className="space-y-3 flex-1 overflow-y-auto">
 
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Name"
            className="w-full p-2 border rounded"
          />
 
          <input
            name="phone"
            value={form.phone}
            onChange={handleChange}
            placeholder="Phone"
            className="w-full p-2 border rounded"
          />
 
          <input
            type="date"
            name="dob"
            value={form.dob}
            onChange={handleChange}
            className="w-full p-2 border rounded"
          />
 
          <select
            name="gender"
            value={form.gender}
            onChange={handleChange}
            className="w-full p-2 border rounded"
          >
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
 
          <input
            name="city"
            value={form.city}
            onChange={handleChange}
            placeholder="City"
            className="w-full p-2 border rounded"
          />
 
          <textarea
            name="bio"
            value={form.bio}
            onChange={handleChange}
            placeholder="Bio"
            className="w-full p-2 border rounded"
          />
 
        </div>
 
        {/* BUTTONS */}
        <div className="mt-5 flex justify-between">
          <button onClick={onClose} className="text-gray-500">
            Cancel
          </button>
 
          <button
            onClick={handleSave}
            className="bg-orange-500 text-white px-4 py-2 rounded"
          >
            {loading ? "Saving..." : "Save"}
          </button>
        </div>
 
      </div>
    </div>
  );
};
 
export default EditProfile;
 