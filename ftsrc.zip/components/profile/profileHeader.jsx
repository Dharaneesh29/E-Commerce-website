import React, { useRef, useState } from "react";
import { FaUser } from "react-icons/fa";
import axios from "axios";
import EditProfile from "./EditProfile";
 
const ProfileHeader = ({ user, setUser }) => {
  const fileRef = useRef();
  const [open, setOpen] = useState(false);
  console.log("ProfileHeader setUser:", setUser);
 
 
  // 🔥 Profile Completion (better)
  const getCompletion = () => {
    let score = 0;
 
    if (user?.name) score += 15;
    if (user?.email) score += 15;
    if (user?.phone) score += 15;
    if (user?.dob) score += 10;
    if (user?.profilePic) score += 15;
    if (user?.bio) score += 10;
    if (user?.city) score += 10;
    if (user?.gender) score += 10;
 
    return score;
  };
 
  const completion = getCompletion();
 
  // 🔥 CLICK AVATAR
  const handleClick = () => {
    fileRef.current.click();
  };
 
  // 🔥 UPLOAD IMAGE
  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
 
    const formData = new FormData();
    formData.append("profilePic", file);
 
    try {
      const token = sessionStorage.getItem("token");
 
      const { data } = await axios.put(
        "http://localhost:5000/api/users/profile",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );
 
      sessionStorage.setItem("userInfo", JSON.stringify(data));
      window.location.reload();
 
    } catch (err) {
      console.log(err);
    }
  };
 
  return (
    <>
      <div className="bg-gradient-to-r from-orange-400 to-orange-500 text-white p-6 rounded-2xl shadow flex items-center gap-6">
 
        {/* 🔶 AVATAR */}
        <div
          onClick={handleClick}
          className="w-20 h-20 rounded-full border-4 border-white overflow-hidden flex items-center justify-center bg-orange-100 cursor-pointer hover:scale-105 transition"
        >
          {user?.profilePic ? (
            <img
              src={
                user.profilePic.startsWith("http")
                  ? user.profilePic
                  : `http://localhost:5000${user.profilePic}`
              }
              alt="profile"
              className="w-full h-full object-cover"
            />
          ) : (
            <FaUser className="text-orange-400 text-3xl" />
          )}
        </div>
 
        {/* 🔥 HIDDEN INPUT */}
        <input type="file" ref={fileRef} onChange={handleUpload} hidden />
 
        {/* 🔶 USER INFO */}
        <div className="flex-1">
          <h2 className="text-xl font-bold">{user?.name || "User"}</h2>
 
          <p className="text-sm opacity-90">{user?.email}</p>
 
          {/* EXTRA INFO */}
          <p className="text-xs opacity-80 mt-1">
            {user?.city || "Add city"} • {user?.gender || "Add gender"}
          </p>
 
          {/* 🔥 PROGRESS */}
          <div className="mt-3">
            <p className="text-xs">Profile {completion}% complete</p>
 
            <div className="w-56 bg-white/30 rounded-full h-2 mt-1">
              <div
                className="bg-white h-2 rounded-full transition-all"
                style={{ width: `${completion}%` }}
              />
            </div>
          </div>
        </div>
 
        {/* 🔶 EDIT */}
        <button
          onClick={() => setOpen(true)}
          className="bg-white text-orange-500 px-4 py-2 rounded-lg font-semibold hover:bg-orange-100 transition"
        >
          Edit Profile
        </button>
      </div>
 
      {/* 🔥 MODAL */}
      {open && (
        <EditProfile user={user} setUser={setUser} onClose={() => setOpen(false)} />
      )}
    </>
  );
};
 
export default ProfileHeader;
 