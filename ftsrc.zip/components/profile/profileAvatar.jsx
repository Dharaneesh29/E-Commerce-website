import { FaUser } from "react-icons/fa";
 
const ProfileAvatar = ({ user }) => {
  return (
    <div className="w-20 h-20 rounded-full border-4 border-white overflow-hidden flex items-center justify-center bg-orange-100">
 
      {user?.profilePic ? (
        <img
          src={
            user.profilePic.startsWith("http")
              ? user.profilePic
              : `http://localhost:5000${user.profilePic}`
          }
          alt="profile"
          className="w-full h-full object-cover"
        />
      ) : (
        <FaUser className="text-orange-400 text-3xl" />
      )}
 
    </div>
  );
};
 
export default ProfileAvatar;
 