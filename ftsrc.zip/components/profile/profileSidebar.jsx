import React from "react";
import {
  FaUser,
  FaBox,
  FaMapMarkerAlt,
  FaHeart,
  FaSignOutAlt,
} from "react-icons/fa";
 
const ProfileSidebar = ({ tab, setTab }) => {
 
  const handleLogout = () => {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("userInfo");
    window.location.href = "/login";
  };
 
  const menu = [
    { id: "profile", label: "Profile Info", icon: <FaUser /> },
    { id: "orders", label: "My Orders", icon: <FaBox /> },
    { id: "address", label: "Manage Addresses", icon: <FaMapMarkerAlt /> },
    { id: "wishlist", label: "Wishlist", icon: <FaHeart /> },
    
  ];
 
  return (
    <div className="bg-white shadow-md rounded-xl p-5">
 
      <h2 className="text-lg font-bold mb-5">My Account</h2>
 
      <ul className="space-y-2">
 
        {menu.map((item) => (
          <li
            key={item.id}
            onClick={() => setTab(item.id)}
            className={`flex items-center gap-3 p-2 rounded cursor-pointer transition ${
              tab === item.id
                ? "bg-orange-100 text-orange-600 font-semibold"
                : "hover:bg-gray-100"
            }`}
          >
            {item.icon}
            {item.label}
          </li>
        ))}
 
        {/* 🔥 Logout */}
        <li
          onClick={handleLogout}
          className="flex items-center gap-3 p-2 rounded cursor-pointer text-red-500 hover:bg-red-100"
        >
          <FaSignOutAlt />
          Logout
        </li>
 
      </ul>
    </div>
  );
};
 
export default ProfileSidebar;
 