//  import { ShoppingCart, Heart, Bell, User } from "lucide-react";
// import { useState, useEffect, useContext } from "react";
// import { Link, useNavigate } from "react-router-dom";
 
// const UserHeader = () => {
//   const navigate = useNavigate();
 
//   const [user, setUser] = useState(null);
//   const [showMenu, setShowMenu] = useState(false);
 
//   useEffect(() => {
//     const storedUser = JSON.parse(sessionStorage.getItem("user"));
//     setUser(storedUser || null);
//   }, []);
 
//   const handleLogout = () => {
//     sessionStorage.removeItem("user");
//     setUser(null);
//     window.location.href = "/home";
//   };
 
//   return (
//     <div className="w-full bg-[#fffaf5] backdrop-blur-md sticky top-0 z-50">
 
//       {/* 🔶 TOP BAR */}
//       <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
 
//         {/* LOGO */}
//         <h1
//           onClick={() => navigate("/home")}
//           className="text-2xl font-bold cursor-pointer"
//         >
//           <span className="text-gray-800">Shop</span>
//           <span className="text-orange-500">Easy</span>
//         </h1>
 
//         {/* SEARCH */}
//         <div className="flex w-[45%] bg-white rounded-full shadow-sm overflow-hidden border">
//           <input
//             type="text"
//             placeholder="Search products, brands and more..."
//             className="w-full px-4 py-2 outline-none"
//           />
//           <button className="bg-orange-500 px-4 flex items-center justify-center hover:bg-orange-600 transition">
//             🔍
//           </button>
//         </div>
 
//         {/* RIGHT SIDE */}
//         <div className="flex items-center gap-5">
 
//           {/* 🔔 Notification */}
//           <Bell
//             size={22}
//             className="cursor-pointer text-gray-600 hover:text-orange-500 transition"
//           />
 
//           {/* ❤️ Wishlist */}
//           <Heart
//             size={22}
//             className="cursor-pointer text-gray-600 hover:text-orange-500 transition"
//           />
 
//           {/* 🛒 Cart */}
//           <Link to="/cart" className="relative group">
//             <ShoppingCart
//               size={24}
//               className="text-gray-700 group-hover:text-orange-500 transition"
//             />
//             <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-1.5 rounded-full">
//               2
//             </span>
//           </Link>
 
//           {/* 👤 USER */}
//           {user ? (
//             <div className="relative">
//               <div
//                 onClick={() => setShowMenu(!showMenu)}
//                 className="flex items-center gap-2 cursor-pointer"
//               >
//                 <div className="w-9 h-9 bg-orange-100 rounded-full flex items-center justify-center">
//                   <User size={18} className="text-orange-500" />
//                 </div>
//                 <span className="text-gray-700 hover:text-orange-500">
//                   {user.name}
//                 </span>
//               </div>
 
//               {showMenu && (
//                 <div className="absolute right-0 mt-3 w-44 bg-white rounded-xl shadow-lg border z-50 animate-fadeIn">
//                   <div
//                     onClick={() => navigate("/profile")}
//                     className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
//                   >
//                     My Profile
//                   </div>
//                   <div
//                     onClick={() => navigate("/orders")}
//                     className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
//                   >
//                     My Orders
//                   </div>
//                   <div
//                     onClick={handleLogout}
//                     className="px-4 py-2 hover:bg-red-100 text-red-500 cursor-pointer"
//                   >
//                     Logout
//                   </div>
//                 </div>
//               )}
//             </div>
//           ) : (
//             <span
//               onClick={() => navigate("/users/login")}
//               className="cursor-pointer hover:text-orange-500"
//             >
//               Login
//             </span>
//           )}
//         </div>
//       </div>
 
//       {/* 🔶 NAVBAR */}
//       <div className="max-w-7xl mx-auto px-6 pb-3 flex gap-8 text-gray-600 font-medium text-sm">
 
//         {["Home", "Shop", "Electronics", "Fashion", "Offers", "Blog"].map(
//           (item) => (
//             <span
//               key={item}
//               className="cursor-pointer hover:text-orange-500 transition relative group"
//             >
//               {item}
//               <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-orange-500 transition-all group-hover:w-full"></span>
//             </span>
//           )
//         )}
//       </div>
//     </div>
//   );
// };
 
// export default UserHeader

import { useState, useEffect, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ShoppingCart, Heart, User, Search, X, Bell } from "lucide-react";
import { ShopContext } from "../../context/ShopContext";

const UserHeader = () => {
  const navigate = useNavigate();
  const { cart, products, wishlist } = useContext(ShopContext);

  const [user, setUser] = useState(null);
  const [showCart, setShowCart] = useState(false);
  const [search, setSearch] = useState("");
  const [filtered, setFiltered] = useState([]);
  const [searchFocused, setSearchFocused] = useState(false);
  const [notifications,setNotifications]=useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
 

  useEffect(() => {
    const stored = JSON.parse(sessionStorage.getItem("userInfo"));
    setUser(stored || null);
  }, []);

  const totalItems = cart?.reduce((acc, item) => acc + item.qty, 0) || 0;
  const totalWishlist = wishlist?.length || 0;
  const unreadCount = notifications.filter(
  (n) => !n.isRead
).length;
 

  const handleLogout = () => {
    sessionStorage.removeItem("userInfo");
    sessionStorage.removeItem("token");
    setUser(null);
    navigate("/users/login");
  };

  useEffect(() => {
    if (search.trim() === "") {
      setFiltered([]);
    } else {
      const result = products.filter((p) =>
        p.name.toLowerCase().includes(search.toLowerCase())
      );
      setFiltered(result.slice(0, 5));
    }
  }, [search, products]);

  useEffect(() => {
 
  const fetchNotifications = async () => {
 
  try {
 
    const userInfo = JSON.parse(
      sessionStorage.getItem("userInfo")
    );
 
    const token = userInfo?.token;
 
    const res = await fetch(
      "http://localhost:5000/api/user-notifications",
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
 
    const data = await res.json();
 
    console.log(data);
 
   setNotifications(Array.isArray(data) ? data : []);
 
  } catch (err) {
 
    console.log(err);
 
  }
};
 
 
  fetchNotifications();
 
}, []);
 

  const initials = user?.user?.name
    ?.split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  const cartTotal = cart.reduce(
    (acc, item) => acc + item.product?.price * item.qty,
    0
  );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

        .uh-root {
          font-family: 'Nunito', sans-serif;
          width: 100%;
          background: #fff;
          box-shadow: 0 2px 16px rgba(255,111,0,0.08);
          position: sticky;
          top: 0;
          z-index: 1000;
          border-bottom: 1.5px solid #fff3e6;
        }

        .uh-inner {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 24px;
          height: 66px;
          display: flex;
          align-items: center;
          gap: 24px;
        }

        /* LOGO */
        .uh-logo {
          font-size: 22px;
          font-weight: 900;
          cursor: pointer;
          flex-shrink: 0;
          letter-spacing: -0.5px;
          display: flex;
          align-items: center;
          gap: 1px;
          text-decoration: none;
        }
        .uh-logo-dark { color: #1a1a1a; }
        .uh-logo-orange { color: #ff6f00; }
        .uh-logo-dot {
          width: 6px; height: 6px;
          background: #ff6f00;
          border-radius: 50%;
          margin-left: 1px;
          margin-bottom: 10px;
        }

        /* SEARCH */
        .uh-search-wrap {
          flex: 1;
          max-width: 520px;
          position: relative;
        }
        .uh-search-box {
          display: flex;
          align-items: center;
          background: #fdf5ee;
          border: 1.5px solid #ffe0c2;
          border-radius: 12px;
          overflow: visible;
          transition: border-color 0.2s, box-shadow 0.2s;
        }
        .uh-search-box.focused {
          border-color: #ff6f00;
          box-shadow: 0 0 0 3px rgba(255,111,0,0.1);
          background: #fff;
        }
        .uh-search-input {
          flex: 1;
          padding: 10px 16px;
          border: none;
          background: transparent;
          font-size: 14px;
          font-family: 'Nunito', sans-serif;
          font-weight: 600;
          color: #1a1a1a;
          outline: none;
        }
        .uh-search-input::placeholder { color: #c0a898; font-weight: 600; }
        .uh-search-clear {
          padding: 0 8px;
          cursor: pointer;
          color: #ccc;
          display: flex;
          align-items: center;
          transition: color 0.15s;
        }
        .uh-search-clear:hover { color: #888; }
        .uh-search-btn {
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border: none;
          padding: 10px 16px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 0 10px 10px 0;
          transition: opacity 0.2s;
          flex-shrink: 0;
        }
        .uh-search-btn:hover { opacity: 0.88; }

        /* DROPDOWN */
        .uh-dropdown {
          position: absolute;
          top: calc(100% + 8px);
          left: 0; right: 0;
          background: #fff;
          border: 1.5px solid #ffe0c2;
          border-radius: 14px;
          box-shadow: 0 8px 28px rgba(255,111,0,0.12);
          overflow: hidden;
          z-index: 200;
        }
        .uh-dropdown-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 11px 16px;
          cursor: pointer;
          font-size: 13.5px;
          font-weight: 700;
          color: #333;
          border-bottom: 1px solid #fff8f2;
          transition: background 0.13s;
        }
        .uh-dropdown-item:last-child { border-bottom: none; }
        .uh-dropdown-item:hover { background: #fff8f2; color: #ff6f00; }
        .uh-dropdown-item .di-icon {
          width: 32px; height: 32px;
          border-radius: 8px;
          background: #fff3e6;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
          font-size: 13px;
        }
        .uh-no-results {
          padding: 16px;
          text-align: center;
          font-size: 13px;
          color: #bbb;
          font-weight: 700;
        }

        /* RIGHT ICONS */
        .uh-right {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-left: auto;
          flex-shrink: 0;
        }

        .uh-icon-btn {
          position: relative;
          width: 42px; height: 42px;
          border-radius: 12px;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          transition: background 0.15s, transform 0.1s;
          color: #555;
          text-decoration: none;
          border: none;
          background: transparent;
        }
        .uh-icon-btn:hover {
          background: #fff3e6;
          color: #ff6f00;
          transform: translateY(-1px);
        }
        .uh-badge {
          position: absolute;
          top: 4px; right: 4px;
          min-width: 18px; height: 18px;
          background: #ff6f00;
          color: #fff;
          font-size: 10px;
          font-weight: 900;
          border-radius: 9px;
          display: flex; align-items: center; justify-content: center;
          padding: 0 4px;
          border: 2px solid #fff;
          font-family: 'Nunito', sans-serif;
        }
        .uh-badge.red { background: #e53935; }

        /* DIVIDER */
        .uh-divider {
          width: 1px; height: 28px;
          background: #f0e8e0;
          margin: 0 4px;
        }

        /* USER AREA */
        .uh-user {
          display: flex;
          align-items: center;
          gap: 9px;
          cursor: pointer;
          padding: 6px 12px;
          border-radius: 12px;
          transition: background 0.15s;
          border: 1.5px solid transparent;
        }
        .uh-user:hover {
          background: #fff3e6;
          border-color: #ffe0c2;
        }
        .uh-avatar {
          width: 36px; height: 36px;
          border-radius: 10px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          display: flex; align-items: center; justify-content: center;
          font-size: 13px;
          font-weight: 900;
          color: #fff;
          flex-shrink: 0;
        }
        .uh-username {
          font-size: 13.5px;
          font-weight: 800;
          color: #1a1a1a;
          max-width: 90px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .uh-logout-btn {
          font-size: 11.5px;
          font-weight: 800;
          color: #e53935;
          background: #fff5f5;
          border: 1px solid #ffc9c9;
          border-radius: 7px;
          padding: 3px 9px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          transition: background 0.15s, color 0.15s;
          white-space: nowrap;
        }
        .uh-logout-btn:hover { background: #e53935; color: #fff; border-color: #e53935; }

        .uh-login-btn {
          padding: 8px 18px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 10px;
          font-weight: 800;
          font-size: 13.5px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          box-shadow: 0 3px 10px rgba(255,111,0,0.28);
          transition: opacity 0.2s, transform 0.1s;
        }
        .uh-login-btn:hover { opacity: 0.9; transform: translateY(-1px); }

        /* MINI CART */
        .uh-minicart {
          position: absolute;
          top: calc(100% + 10px);
          right: 0;
          width: 300px;
          background: #fff;
          border: 1.5px solid #ffe0c2;
          border-radius: 18px;
          box-shadow: 0 12px 36px rgba(255,111,0,0.14);
          z-index: 300;
          overflow: hidden;
        }
        .mc-header {
          background: linear-gradient(135deg, #fff8f2, #fff3e6);
          padding: 14px 16px;
          border-bottom: 1.5px solid #ffe0c2;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .mc-header p {
          font-size: 14px;
          font-weight: 800;
          color: #1a1a1a;
        }
        .mc-count {
          font-size: 11px;
          font-weight: 800;
          color: #ff6f00;
          background: #fff3e6;
          border: 1px solid #ffe0c2;
          padding: 2px 8px;
          border-radius: 20px;
        }
        .mc-items {
          max-height: 220px;
          overflow-y: auto;
          padding: 10px 12px;
        }
        .mc-items::-webkit-scrollbar { width: 4px; }
        .mc-items::-webkit-scrollbar-thumb { background: #ffcc99; border-radius: 4px; }
        .mc-item {
          display: flex;
          gap: 10px;
          align-items: center;
          padding: 8px 6px;
          border-radius: 10px;
          border-bottom: 1px solid #fff8f2;
          transition: background 0.13s;
        }
        .mc-item:last-child { border-bottom: none; }
        .mc-item:hover { background: #fff8f2; }
        .mc-img {
          width: 46px; height: 46px;
          border-radius: 9px;
          object-fit: cover;
          border: 1.5px solid #ffe0c2;
          background: #fff8f2;
          flex-shrink: 0;
        }
        .mc-name {
          font-size: 13px;
          font-weight: 700;
          color: #1a1a1a;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 140px;
          margin-bottom: 2px;
        }
        .mc-price { font-size: 12px; color: #ff6f00; font-weight: 800; }
        .mc-qty { font-size: 11.5px; color: #aaa; font-weight: 600; }
        .mc-remove {
          margin-left: auto;
          font-size: 11px;
          font-weight: 800;
          color: #e53935;
          background: none;
          border: none;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          padding: 4px 6px;
          border-radius: 6px;
          transition: background 0.13s;
          flex-shrink: 0;
        }
        .mc-remove:hover { background: #fff5f5; }
        .mc-empty {
          padding: 28px 16px;
          text-align: center;
          font-size: 13px;
          color: #bbb;
          font-weight: 700;
        }
        .mc-empty .mc-empty-icon { font-size: 36px; margin-bottom: 8px; }
        .mc-footer {
          padding: 12px 16px;
          border-top: 1.5px solid #fff3e6;
          background: #fdfaf8;
        }
        .mc-total-row {
          display: flex;
          justify-content: space-between;
          font-size: 13.5px;
          font-weight: 800;
          color: #1a1a1a;
          margin-bottom: 10px;
        }
        .mc-total-row span:last-child { color: #ff6f00; font-size: 16px; }
        .mc-goto-btn {
          width: 100%;
          padding: 11px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 11px;
          font-weight: 800;
          font-size: 13.5px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          box-shadow: 0 3px 10px rgba(255,111,0,0.28);
          transition: opacity 0.2s;
        }
        .mc-goto-btn:hover { opacity: 0.9; }
      `}</style>

      <header className="uh-root">
        <div className="uh-inner">

          {/* LOGO */}
          <div className="uh-logo" onClick={() => navigate("/home")}>
            <span className="uh-logo-dark">Shop</span>
            <span className="uh-logo-orange">Easy</span>
            <span className="uh-logo-dot" />
          </div>

          {/* SEARCH */}
          <div className="uh-search-wrap">
            <div className={`uh-search-box ${searchFocused ? "focused" : ""}`}>
              <input
                type="text"
                placeholder="Search products..."
                className="uh-search-input"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setTimeout(() => setSearchFocused(false), 150)}
              />
              {search && (
                <span className="uh-search-clear" onClick={() => setSearch("")}>
                  <X size={14} />
                </span>
              )}
              <button className="uh-search-btn">
                <Search size={16} color="#fff" />
              </button>
            </div>

            {/* DROPDOWN */}
            {filtered.length > 0 && (
              <div className="uh-dropdown">
                {filtered.map((item) => (
                  <div
                    key={item._id}
                    className="uh-dropdown-item"
                    onClick={() => {
                      navigate(`/product/${item._id}`);
                      setSearch("");
                    }}
                  >
                    <div className="di-icon">🔍</div>
                    {item.name}
                  </div>
                ))}
              </div>
            )}

            {search.trim() && filtered.length === 0 && (
              <div className="uh-dropdown">
                <div className="uh-no-results">No products found for "{search}"</div>
              </div>
            )}
          </div>

          {/* RIGHT */}
          <div className="uh-right">
           <div style={{ position: "relative" }}>
 
  {/* NOTIFICATION BUTTON */}
  <div
    className="uh-icon-btn"
    onClick={async () => {
 
      setShowNotifications(!showNotifications);
 
      // MARK ALL AS READ
      if (!showNotifications) {
 
        try {

  const userInfo = JSON.parse(
    sessionStorage.getItem("userInfo")
  );

  const token = userInfo?.token;

  await fetch(
    "http://localhost:5000/api/user-notifications/read-all",
    {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  setNotifications((prev) =>
    prev.map((n) => ({
      ...n,
      isRead: true,
    }))
  );

} catch (err) {
  console.log(err);
}
      }
    }}
    title="Notifications"
  >
    <Bell size={20} />
 
    {unreadCount > 0 && (
      <span className="uh-badge">
        {unreadCount}
      </span>
    )}
  </div>
 
  {/* DROPDOWN */}
  {showNotifications && (
    <div
      style={{
        position: "absolute",
        top: "52px",
        right: 0,
        width: "360px",
        background: "#fff",
        borderRadius: "20px",
        boxShadow: "0 14px 40px rgba(0,0,0,0.12)",
        border: "1px solid #ffe0c2",
        overflow: "hidden",
        zIndex: 999,
      }}
    >
 
      {/* HEADER */}
      <div
        style={{
          padding: "16px 18px",
          borderBottom: "1px solid #f3e5d8",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          background: "#fffaf5",
        }}
      >
        <div>
          <h4
            style={{
              margin: 0,
              fontSize: "18px",
              fontWeight: 800,
              color: "#222",
            }}
          >
            Notifications
          </h4>
 
          <p
            style={{
              margin: "4px 0 0",
              fontSize: "12px",
              color: "#999",
              fontWeight: 700,
            }}
          >
            {unreadCount} unread
          </p>
        </div>
      </div>
 
      {/* LIST */}
      <div
        style={{
          maxHeight: "400px",
          overflowY: "auto",
        }}
      >
 
        {notifications.length === 0 ? (
          <div
            style={{
              padding: "40px 20px",
              textAlign: "center",
              color: "#aaa",
              fontWeight: 700,
            }}
          >
            No notifications
          </div>
        ) : (
          notifications.map((n) => (
 
            <div
              key={n._id}
              onClick={() => navigate(`/orders/${n.orderId}`)}
              style={{
                padding: "16px",
                borderBottom: "1px solid #f8f2ed",
                background: n.isRead
                  ? "#fff"
                  : "#fff8f2",
                cursor: "pointer",
                transition: "0.2s",
              }}
            >
 
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  gap: 12,
                }}
              >
 
                {/* LEFT */}
                <div style={{ flex: 1 }}>
 
                  {/* MESSAGE */}
                  <p
                    style={{
                      margin: 0,
                      fontSize: "14px",
                      fontWeight: n.isRead
                        ? 700
                        : 800,
                      color: "#222",
                      lineHeight: 1.5,
                    }}
                  >
                    {n.message}
                  </p>
 
                  {/* ORDER ID */}
                  <p
                    style={{
                      margin: "6px 0 0",
                      fontSize: "12px",
                      color: "#888",
                    }}
                  >
                    Order ID:
                    <span
                      style={{
                        color: "#ff6f00",
                        fontWeight: 800,
                      }}
                    >
                      {" "}
                      #{n.orderId?.slice(-6).toUpperCase()}
                    </span>
                  </p>
 
                  {/* DATE */}
                  <p
                    style={{
                      marginTop: 6,
                      fontSize: "11px",
                      color: "#aaa",
                      fontWeight: 600,
                    }}
                  >
                    {new Date(
                      n.createdAt
                    ).toLocaleString()}
                  </p>
                </div>
 
                {/* UNREAD DOT */}
                {!n.isRead && (
                  <div
                    style={{
                      width: 9,
                      height: 9,
                      borderRadius: "50%",
                      background: "#ff6f00",
                      marginTop: 6,
                      flexShrink: 0,
                    }}
                  />
                )}
              </div>
            </div>
          ))
        )}
      </div>
 
      {/* FOOTER */}
      <div
        style={{
          padding: "12px",
          textAlign: "center",
          borderTop: "1px solid #f3e5d8",
          background: "#fffaf5",
        }}
      >
        {/* <button
          onClick={() => navigate("/notifications")}
          style={{
            border: "none",
            background: "transparent",
            color: "#ff6f00",
            fontWeight: 800,
            cursor: "pointer",
            fontSize: "13px",
          }}
        >
          View All →
        </button> */}
      </div>
    </div>
  )}
</div>
 
 
 
            {/* WISHLIST */}
            <div
              className="uh-icon-btn"
              onClick={() => navigate("/wishlist")}
              title="Wishlist"
            >
              <Heart size={20} />
              {totalWishlist > 0 && (
                <span className="uh-badge red">{totalWishlist}</span>
              )}
            </div>

            {/* CART */}
            <div
              style={{ position: "relative" }}
              onMouseEnter={() => setShowCart(true)}
              onMouseLeave={() => setShowCart(false)}
            >
              <Link to="/cart" className="uh-icon-btn" title="Cart">
                <ShoppingCart size={20} />
                {totalItems > 0 && (
                  <span className="uh-badge">{totalItems}</span>
                )}
              </Link>

              {/* MINI CART */}
              {showCart && (
                <div className="uh-minicart">
                  <div className="mc-header">
                    <p>🛒 My Cart</p>
                    {cart.length > 0 && (
                      <span className="mc-count">{totalItems} item{totalItems !== 1 ? "s" : ""}</span>
                    )}
                  </div>

                  {cart.length === 0 ? (
                    <div className="mc-empty">
                      <div className="mc-empty-icon">🛒</div>
                      <p>Your cart is empty</p>
                    </div>
                  ) : (
                    <>
                      <div className="mc-items">
                        {cart.slice(0, 3).map((item) => (
                          <div key={item.product?._id} className="mc-item">
                            <img
                              src={
                                item.product?.images && item.product?.images.length > 0
                                  ? item.product?.images[0].startsWith("http")
                                    ? item.product?.images[0]
                                    : `http://localhost:5000${item.product?.images[0]}`
                                  : "/placeholder.png"
                              }
                              alt="product"
                              className="mc-img"
                            />
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <p className="mc-name">{item.product?.name}</p>
                              <p className="mc-price">₹{item.product?.price}</p>
                              <p className="mc-qty">Qty: {item.qty}</p>
                            </div>
                            <button
                              className="mc-remove"
                              onClick={() => removeFromCart(item.product?._id)}
                            >
                              ✕
                            </button>
                          </div>
                        ))}

                        {cart.length > 3 && (
                          <p style={{ textAlign: "center", fontSize: 12, color: "#aaa", fontWeight: 700, padding: "8px 0" }}>
                            +{cart.length - 3} more item{cart.length - 3 !== 1 ? "s" : ""}
                          </p>
                        )}
                      </div>

                      <div className="mc-footer">
                        <div className="mc-total-row">
                          <span>Total</span>
                          <span>₹{cartTotal}</span>
                        </div>
                        <button className="mc-goto-btn" onClick={() => navigate("/cart")}>
                          View Cart →
                        </button>
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            <div className="uh-divider" />

            {/* USER */}
            {user ? (
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div
                  className="uh-user"
                  onClick={() => navigate("/profile")}
                >
                  <div className="uh-avatar">{initials || <User size={16} />}</div>
                  <span className="uh-username">{user?.user?.name?.split(" ")[0] || "User"}</span>
                </div>

                <button
                  className="uh-logout-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleLogout();
                  }}
                >
                  Logout
                </button>
              </div>
            ) : (
              <button className="uh-login-btn" onClick={() => navigate("/users/login")}>
                Login →
              </button>
            )}

          </div>
        </div>
      </header>
    </>
  );
};

export default UserHeader;
 