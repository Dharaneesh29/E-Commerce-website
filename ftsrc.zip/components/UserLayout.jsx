// import Navbar from "./navbar";
import UserHeader from "./Header/UserHeader";
 
export default function UserLayout({ children }) {
  return (
    <div>
      <UserHeader />
      <div style={{ padding: "20px" }}>
        {children}
      </div>
    </div>
  );
}
 

const main = {
  flex: 1,
  background: "#f1f5f9",
  minHeight: "100vh",
};

const content = {
  padding: "20px",
};
