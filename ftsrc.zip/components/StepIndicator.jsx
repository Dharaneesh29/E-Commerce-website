import React from "react";
 
const StepIndicator = ({ step }) => {
  const steps = ["Cart", "Delivery", "Payment"];
 
  return (
    <div style={{
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: "30px"
    }}>
      {steps.map((label, index) => {
        const isActive = step === index;
        const isCompleted = step > index;
 
        return (
          <React.Fragment key={index}>
            
            {/* STEP */}
            <div style={{ textAlign: "center" }}>
              
              {/* CIRCLE */}
              <div style={{
                width: "40px",
                height: "40px",
                borderRadius: "50%",
                background: isActive || isCompleted ? "#ff6f00" : "#ddd",
                color: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "bold"
              }}>
                {index + 1}
              </div>
 
              {/* LABEL */}
              <p style={{
                marginTop: "8px",
                fontSize: "14px",
                color: isActive ? "#000" : "#aaa",
                fontWeight: isActive ? "600" : "400"
              }}>
                {label}
              </p>
            </div>
 
            {/* LINE */}
            {index < steps.length - 1 && (
              <div style={{
                width: "80px",
                height: "2px",
                background: step > index ? "#ff6f00" : "#ddd",
                margin: "0 10px"
              }} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};
 
export default StepIndicator;
