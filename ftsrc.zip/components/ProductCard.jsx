import React, { useState, useContext } from "react";
import { Star, Heart } from "lucide-react";
import { ShopContext } from "../context/ShopContext";
import { useNavigate } from "react-router-dom";
 
const ProductCard = ({ product }) => {
  const { addToCart } = useContext(ShopContext);
  const [wishlist, setWishlist] = useState(false);
  const navigate = useNavigate();
 
  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );
 
  return (
    <div className="bg-white rounded-xl shadow-md p-4 relative group hover:shadow-xl transition duration-300">
 
      {/* 🔥 Discount Badge */}
      {discountPercent > 0 && (
        <span className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded">
          {discountPercent}% OFF
        </span>
      )}
 
      {/* ❤️ Wishlist */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          setWishlist(!wishlist);
        }}
        className="absolute top-2 right-2"
      >
        <Heart
          size={20}
          className={`${
            wishlist ? "text-red-500 fill-red-500" : "text-gray-400"
          }`}
        />
      </button>
 
      {/* 🖼 Product Image */}
      <div
        className="relative overflow-hidden rounded-lg cursor-pointer"
        onClick={() => navigate(`/product/${product.id}`)}
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-40 object-cover transform group-hover:scale-110 transition duration-300"
        />
 
        {/* ❌ Out of Stock */}
        {product.stock === 0 && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-white font-bold">
            Out of Stock
          </div>
        )}
      </div>
 
      {/* 📦 Details */}
      <h3 className="mt-3 font-semibold truncate">{product.name}</h3>
      <p className="text-gray-500 text-sm">{product.brand}</p>
 
      {/* ⭐ Rating */}
      <div className="flex items-center mt-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            size={16}
            className={
              i < product.rating
                ? "text-yellow-400 fill-yellow-400"
                : "text-gray-300"
            }
          />
        ))}
      </div>
 
      {/* 💰 Price */}
      <div className="mt-2 flex items-center gap-2">
        <span className="text-green-600 font-bold">₹{product.price}</span>
        <span className="text-gray-400 line-through text-sm">
          ₹{product.originalPrice}
        </span>
      </div>
 
      {/* 🔘 Buttons */}
      <div className="mt-3 flex gap-2">
 
        {/* Add to Cart */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            addToCart(product);
          }}
          disabled={product.stock === 0}
          className={`w-full py-2 rounded-lg text-white ${
            product.stock === 0
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 hover:bg-blue-700"
          }`}
        >
          {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
        </button>
 
        {/* View Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/product/${product.id}`);
          }}
          className="w-full py-2 rounded-lg bg-gray-800 text-white hover:bg-gray-900"
        >
          View
        </button>
 
      </div>
    </div>
  );
};
 
export default ProductCard;