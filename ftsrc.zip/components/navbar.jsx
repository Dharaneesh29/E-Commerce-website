

import { useContext } from "react";
import { useNavigate} from "react-router-dom";
import NotificationBell from "./NotificationBell";
import { ShopContext } from "../context/ShopContext";
 
export default function Navbar() {
 
  const { cart } = useContext(ShopContext);
  const navigate=useNavigate();
 
  // ✅ calculate total items
  const totalItems = cart.reduce(
    (total, item) => total + (item.qty || 1),
    0
  );

  const handleLayout=()=>{
    sessionStorage.removeItem("userInfo");
    sessionStorage.removeItem("token");
    navigate("/login");
  };


 
  return (
    <div style={navbar}>
      
      <h3>Shopeasy</h3>
 
      <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>

        <NotificationBell/>
 
        {/* 🛒 CART ICON */}
        <div style={{ position: "relative", cursor: "pointer" }}>
          🛒
 
          {totalItems > 0 && (
            <span style={badge}>
              {totalItems}
            </span>
          )}
        </div>
 
        <button style={button}>Logout</button>
 
      </div>
    </div>
  );
}
 
const navbar = {
  background: "white",
  padding: "15px 20px",
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  borderBottom: "1px solid #e5e7eb",
};
 
const button = {
  background: "#f59e0b",
  color: "white",
  border: "none",
  padding: "6px 12px",
  cursor: "pointer",
};
 
const badge = {
  position: "absolute",
  top: "-8px",
  right: "-10px",
  background: "red",
  color: "white",
  borderRadius: "50%",
  padding: "2px 6px",
  fontSize: "12px",
};