import Sidebar from "./sidebar";
import Navbar from "./navbar";

export default function Layout({ children }) {
  return (
    <div style={{ display: "flex" }}>
      
      <Sidebar />

      <div style={main}>
        <Navbar />

        <div style={content}>
          {children}
        </div>
      </div>

    </div>
  );
}

const main = {
  flex: 1,
  background: "#f1f5f9",
  minHeight: "100vh",
};

const content = {
  padding: "20px",
};
