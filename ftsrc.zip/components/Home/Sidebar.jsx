// import { ChevronRight } from "lucide-react";
 
// const categories = [
//   { name: "Electronics", icon: "📱" },
//   { name: "Fashion", icon: "👕" },
//   { name: "Home & Kitchen", icon: "🏠" },
//   { name: "Appliances", icon: "🧊" },
//   { name: "Beauty", icon: "💄" },
//   { name: "Toys", icon: "🧸" },
//   { name: "Sports", icon: "⚽" },
//   { name: "Books", icon: "📚" },
// ];
 
// const Sidebar = () => {
//   return (
//     <div className="bg-white rounded-2xl shadow-md p-4 h-full">
 
//       {/* TITLE */}
//       <h2 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">
//         All Categories
//       </h2>
 
//       {/* CATEGORY LIST */}
//       <div className="flex flex-col gap-3">
 
//         {categories.map((item, index) => (
//           <div
//             key={index}
//             className="flex items-center justify-between px-2 py-2 rounded-lg cursor-pointer 
//             hover:bg-orange-50 hover:text-orange-500 transition group"
//           >
 
//             {/* LEFT SIDE */}
//             <div className="flex items-center gap-3">
//               <span className="text-lg">{item.icon}</span>
//               <span className="text-sm font-medium">
//                 {item.name}
//               </span>
//             </div>
 
//             {/* RIGHT ARROW */}
//             <ChevronRight
//               size={16}
//               className="text-gray-400 group-hover:text-orange-500 transition"
//             />
 
//           </div>
//         ))}
 
//       </div>
 
//     </div>
//   );
// };
 
// export default Sidebar;

// import React, { useState } from "react";
// import { ChevronRight } from "lucide-react";
// import {
//   Laptop,
//   Shirt,
//   Home,
//   Tv,
//   Heart,
//   Gamepad,
//   Dumbbell,
//   BookOpen,
// } from "lucide-react";
 
// const Sidebar = () => {
//   const [active, setActive] = useState();
 
//   const categories = [
//     { name: "Electronics", icon: <Laptop size={18} /> },
//     { name: "Fashion", icon: <Shirt size={18} /> },
//     { name: "Home & Kitchen", icon: <Home size={18} /> },
//     { name: "Appliances", icon: <Tv size={18} /> },
//     { name: "Beauty", icon: <Heart size={18} /> },
//     { name: "Toys", icon: <Gamepad size={18} /> },
//     { name: "Sports", icon: <Dumbbell size={18} /> },
//     { name: "Books", icon: <BookOpen size={18} /> },
//   ];
 
//   return (
//     <div className="bg-white rounded-2xl shadow-md p-4 h-full">
      
//       {/* TITLE */}
//       <h2 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2">
//         All Categories
//       </h2>
 
//       {/* LIST */}
//       <div className="flex flex-col gap-2">
//         {categories.map((item, index) => (
//           <div
//             key={index}
//             onClick={() => setActive(index)}
//             className={`flex items-center justify-between p-3 rounded-lg cursor-pointer 
//             transition duration-200 group
//             ${
//               active === index
//                 ? "bg-orange-100 text-orange-600 shadow-sm"
//                 : "hover:bg-orange-50 hover:shadow-md hover:translate-x-1"
//             }`}
//           >
//             {/* LEFT */}
//             <div className="flex items-center gap-3">
//               <span className="text-gray-600 group-hover:scale-110 transition">
//                 {item.icon}
//               </span>
 
//               <span className="text-sm font-medium">
//                 {item.name}
//               </span>
//             </div>
 
//             {/* RIGHT ARROW */}
//             <ChevronRight
//               size={16}
//               className={`transition ${
//                 active === index
//                   ? "text-orange-500"
//                   : "text-gray-400 group-hover:text-orange-500"
//               }`}
//             />
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };
 
// export default Sidebar;


 
import React, { useState } from "react";
import { ChevronRight, Laptop, Shirt, Home, Tv, Heart, Gamepad, Dumbbell, BookOpen } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Sidebar = () => {
  const [active, setActive] = useState(null);
  const navigate = useNavigate();

  const categories = [
    { name: "Electronics", icon: <Laptop size={17} />, emoji: "💻", color: "#3b82f6" },
    { name: "Fashion", icon: <Shirt size={17} />, emoji: "👗", color: "#ec4899" },
    { name: "Home & Kitchen", icon: <Home size={17} />, emoji: "🏠", color: "#f59e0b" },
    { name: "Appliances", icon: <Tv size={17} />, emoji: "📺", color: "#8b5cf6" },
    { name: "Beauty", icon: <Heart size={17} />, emoji: "✨", color: "#ef4444" },
    { name: "Toys", icon: <Gamepad size={17} />, emoji: "🎮", color: "#10b981" },
    { name: "Sports", icon: <Dumbbell size={17} />, emoji: "🏋️", color: "#ff6f00" },
    { name: "Books", icon: <BookOpen size={17} />, emoji: "📚", color: "#6366f1" },
  ];

  const handleClick = (item, index) => {
    setActive(index);
    const category = item.name.toLowerCase().replace(/\s+/g, "-");
    navigate(`/category/${category}`);
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

        .sb-wrap {
          font-family: 'Nunito', sans-serif;
          background: #fff;
          border-radius: 20px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 4px 18px rgba(255,111,0,0.07);
          overflow: hidden;
          height: 100%;
          position: relative;
        }
        .sb-wrap::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 4px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
        }

        /* HEADER */
        .sb-header {
          padding: 18px 16px 14px;
          border-bottom: 1.5px solid #fff3e6;
          display: flex;
          align-items: center;
          gap: 9px;
        }
        .sb-header-icon {
          width: 30px; height: 30px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-radius: 8px;
          display: flex; align-items: center; justify-content: center;
          font-size: 14px;
          box-shadow: 0 3px 8px rgba(255,111,0,0.3);
          flex-shrink: 0;
        }
        .sb-title {
          font-size: 14.5px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.3px;
        }

        /* LIST */
        .sb-list {
          display: flex;
          flex-direction: column;
          padding: 10px 10px 14px;
          gap: 2px;
        }

        /* ITEM */
        .sb-item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 10px;
          border-radius: 12px;
          cursor: pointer;
          transition: background 0.15s, transform 0.13s, border-color 0.15s;
          border: 1px solid transparent;
          position: relative;
          overflow: hidden;
        }
        .sb-item::before {
          content: '';
          position: absolute;
          left: 0; top: 0;
          width: 3px; height: 100%;
          border-radius: 2px;
          background: transparent;
          transition: background 0.15s;
        }
        .sb-item:hover {
          background: #fff8f2;
          border-color: #ffe0c2;
          transform: translateX(3px);
        }
        .sb-item:hover::before {
          background: linear-gradient(180deg, #ff6f00, #ffaa5a);
        }
        .sb-item.active {
          background: #fff3e6;
          border-color: #ffcc99;
          transform: translateX(3px);
        }
        .sb-item.active::before {
          background: linear-gradient(180deg, #ff6f00, #ffaa5a);
        }

        /* LEFT CONTENT */
        .sb-left {
          display: flex;
          align-items: center;
          gap: 11px;
        }

        /* ICON BOX */
        .sb-icon-box {
          width: 34px; height: 34px;
          border-radius: 9px;
          display: flex; align-items: center; justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
          transition: transform 0.18s;
          border: 1px solid rgba(0,0,0,0.06);
        }
        .sb-item:hover .sb-icon-box,
        .sb-item.active .sb-icon-box {
          transform: scale(1.12);
        }

        .sb-name {
          font-size: 13px;
          font-weight: 800;
          color: #333;
          transition: color 0.15s;
        }
        .sb-item:hover .sb-name,
        .sb-item.active .sb-name {
          color: #ff6f00;
        }

        /* CHEVRON */
        .sb-chevron {
          color: #ddd;
          transition: color 0.15s, transform 0.15s;
          flex-shrink: 0;
        }
        .sb-item:hover .sb-chevron,
        .sb-item.active .sb-chevron {
          color: #ff6f00;
          transform: translateX(2px);
        }

        /* DIVIDER */
        .sb-divider {
          height: 1px;
          background: #fff8f2;
          margin: 0 6px;
        }

        /* FOOTER PROMO */
        .sb-promo {
          margin: 4px 10px 12px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-radius: 12px;
          padding: 13px 14px;
          display: flex;
          align-items: center;
          gap: 10px;
          box-shadow: 0 4px 14px rgba(255,111,0,0.28);
          cursor: pointer;
          transition: opacity 0.18s, transform 0.13s;
        }
        .sb-promo:hover { opacity: 0.92; transform: translateY(-1px); }
        .sb-promo-icon { font-size: 22px; flex-shrink: 0; }
        .sb-promo-text p:first-child {
          font-size: 12px;
          font-weight: 900;
          color: #fff;
          margin-bottom: 2px;
        }
        .sb-promo-text p:last-child {
          font-size: 11px;
          font-weight: 600;
          color: rgba(255,255,255,0.75);
        }
      `}</style>

      <div className="sb-wrap">
        {/* HEADER */}
        <div className="sb-header">
          <div className="sb-header-icon">☰</div>
          <p className="sb-title">All Categories</p>
        </div>

        {/* LIST */}
        <div className="sb-list">
          {categories.map((item, index) => (
            <React.Fragment key={index}>
              <div
                className={`sb-item ${active === index ? "active" : ""}`}
                onClick={() => handleClick(item, index)}
              >
                <div className="sb-left">
                  {/* ICON BOX with per-category tinted bg */}
                  <div
                    className="sb-icon-box"
                    style={{ background: `${item.color}14` }}
                  >
                    {item.emoji}
                  </div>
                  <span className="sb-name">{item.name}</span>
                </div>

                <ChevronRight size={15} className="sb-chevron" />
              </div>

              {index < categories.length - 1 && (
                <div className="sb-divider" />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* PROMO FOOTER */}
        
      </div>
    </>
  );
};

export default Sidebar;
 