// import React from "react";
 
// import c1 from "../../assets/category/c1.webp";
// import c2 from "../../assets/category/c2.webp";
// import c3 from "../../assets/category/c3.webp";
// import c4 from "../../assets/category/c4.webp";
// import c5 from "../../assets/category/c5.webp";
// import c6 from "../../assets/category/c6.webp";
// import c7 from "../../assets/category/c7.webp";
// import c8 from "../../assets/category/c8.webp";
// import c9 from "../../assets/category/c9.webp";
 
// const Categories = ({setSelectedCategory,selectedCategory}) => {
 
//   const categoryData = [
//     { id: 1, img: c1, text: "Top Offers", value:"top-offers" },
//     { id: 2, img: c2, text: "Grocery" , value:"grocery"},
//     { id: 3, img: c3, text: "Mobile", value:"mobile" },
//     { id: 4, img: c4, text: "Fashion", value:"fashion" },
//     { id: 5, img: c5, text: "Electronics", value:"electronics" },
//     { id: 6, img: c6, text: "Home", value:"home" },
//     { id: 7, img: c7, text: "Appliances", value:"appliances" },
//     { id: 8, img: c8, text: "Travel" , value:"travel"},
//     { id: 9, img: c9, text: "Beauty, Toys & More" , value:"beauty"},
//   ];
 
//   return (
//     <div className="w-full bg-white mt-6 px-6 py-4 shadow-sm rounded-xl">
//  <div className="overflow-hidden w-full">
//       <div className="flex gap-8 animate-marquee w-max hover:[animation-play-state:paused]">
 
//         {categoryData.map((item,index)=> (
//           <div
//             key={index}
//             onClick={() =>
//               setSelectedCategory(item.value)}
          
//            className="flex flex-col items-center min-w-[110px] cursor-pointer group"
//           >
//             {/* Image */}
//             <div className="w-16 h-16 md:w-20 md:h-20 flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
//               <img
//                 src={item.img}
//                 alt={item.text}
//                 className="w-full h-full object-contain transition-transform duration-300 group-hover:scale-110"
//               />
//             </div>
 
//             {/* Text */}
//             <p className="text-sm mt-2 text-gray-700 group-hover:text-blue-600 text-center">
//               {item.text}
//             </p>
//           </div>
//         ))}
 
//       </div>
//     </div>
//     </div>
//   );
// };
 
// export default Categories;


import React from "react";
import { useNavigate } from "react-router-dom";
 
import c1 from "../../assets/category/c1.webp";
import c2 from "../../assets/category/c2.webp";
import c3 from "../../assets/category/c3.webp";
import c4 from "../../assets/category/c4.webp";
import c5 from "../../assets/category/c5.webp";
import c6 from "../../assets/category/c6.webp";
import c7 from "../../assets/category/c7.webp";
import c8 from "../../assets/category/c8.webp";
import c9 from "../../assets/category/c9.webp";
 
const Categories = () => {
  const navigate = useNavigate();
 
  const categoryData = [
    { id: 1, img: c1, text: "Top Offers", value: "top-offers" },
    { id: 2, img: c2, text: "Grocery", value: "grocery" },
    { id: 3, img: c3, text: "Mobile", value: "mobile" },
    { id: 4, img: c4, text: "Fashion", value: "fashion" },
    { id: 5, img: c5, text: "Electronics", value: "electronics" },
    { id: 6, img: c6, text: "Home", value: "home" },
    { id: 7, img: c7, text: "Appliances", value: "appliances" },
    { id: 8, img: c8, text: "Travel", value: "travel" },
    { id: 9, img: c9, text: "Beauty", value: "beauty" },
  ];
 
  return (
    <div className="w-full bg-white mt-6 px-6 py-4 shadow-sm rounded-xl">
      <div className="flex gap-8 overflow-x-auto">
 
        {categoryData.map((item) => (
          <div
            key={item.id}
            onClick={() => navigate(`/category/${item.value}`)}  // ✅ FIX
            className="flex flex-col items-center min-w-[110px] cursor-pointer group"
          >
            <div className="w-16 h-16 md:w-20 md:h-20 flex items-center justify-center">
              <img
                src={item.img}
                alt={item.text}
                className="w-full h-full object-contain transition duration-300 group-hover:scale-110"
              />
            </div>
 
            <p className="text-sm mt-2 text-gray-700 group-hover:text-blue-600 text-center">
              {item.text}
            </p>
          </div>
        ))}
 
      </div>
    </div>
  );
};
 
export default Categories;
 