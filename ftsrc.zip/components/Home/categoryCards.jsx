import React from "react";
import { useNavigate } from "react-router-dom";

// 👉 Import images (put in assets/categories/)
import electronics from "../../assets/categories/electronics.jpg";
import fashion from "../../assets/categories/fashion.jpg";
import home from "../../assets/categories/home.jpg";
import beauty from "../../assets/categories/beauty.jpg";

const CategoryCards = () => {
  const navigate = useNavigate();

  const categories = [
    {
      name: "Electronics",
      image: electronics,
      emoji: "💻",
      tag: "Gadgets & Devices",
      accent: "#3b82f6",
    },
    {
      name: "Fashion",
      image: fashion,
      emoji: "👗",
      tag: "Trending Styles",
      accent: "#ec4899",
    },
    {
      name: "Home & Kitchen",
      image: home,
      emoji: "🏠",
      tag: "Living Essentials",
      accent: "#f59e0b",
    },
    {
      name: "Beauty",
      image: beauty,
      emoji: "✨",
      tag: "Skincare & More",
      accent: "#ef4444",
    },
  ];

  const formatCategory = (name) => {
    return name.toLowerCase().replace(/&/g, "").replace(/\s+/g, "-");
  };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

        .cc-section {
          font-family: 'Nunito', sans-serif;
          padding: 28px 28px 32px;
          background: #fdf5ee;
          border-radius: 22px;
          margin-bottom: 8px;
        }

        /* HEADER */
        .cc-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 22px;
        }
        .cc-title-wrap {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .cc-title-bar {
          width: 4px; height: 28px;
          background: linear-gradient(180deg, #ff6f00, #ffaa5a);
          border-radius: 4px;
          flex-shrink: 0;
        }
        .cc-title {
          font-size: 22px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.4px;
        }
        .cc-see-all {
          font-size: 13px;
          font-weight: 800;
          color: #ff6f00;
          cursor: pointer;
          border: 1.5px solid #ff6f00;
          padding: 6px 14px;
          border-radius: 9px;
          background: transparent;
          font-family: 'Nunito', sans-serif;
          transition: background 0.18s, color 0.18s;
        }
        .cc-see-all:hover { background: #ff6f00; color: #fff; }

        /* GRID */
        .cc-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 16px;
        }

        /* CARD */
        .cc-card {
          position: relative;
          border-radius: 18px;
          overflow: hidden;
          cursor: pointer;
          aspect-ratio: 3/4;
          box-shadow: 0 4px 16px rgba(0,0,0,0.1);
          transition: box-shadow 0.25s, transform 0.22s;
          border: 2px solid transparent;
        }
        .cc-card:hover {
          box-shadow: 0 14px 36px rgba(0,0,0,0.18);
          transform: translateY(-5px);
        }

        /* IMAGE */
        .cc-img {
          width: 100%; height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 0.55s ease;
        }
        .cc-card:hover .cc-img {
          transform: scale(1.1);
        }

        /* OVERLAYS */
        .cc-overlay-dark {
          position: absolute;
          inset: 0;
          background: linear-gradient(
            180deg,
            rgba(0,0,0,0.15) 0%,
            rgba(0,0,0,0.1) 30%,
            rgba(0,0,0,0.65) 70%,
            rgba(0,0,0,0.85) 100%
          );
          transition: background 0.3s;
        }
        .cc-card:hover .cc-overlay-dark {
          background: linear-gradient(
            180deg,
            rgba(0,0,0,0.2) 0%,
            rgba(0,0,0,0.15) 30%,
            rgba(0,0,0,0.7) 70%,
            rgba(0,0,0,0.88) 100%
          );
        }

        /* TOP EMOJI BADGE */
        .cc-emoji-wrap {
          position: absolute;
          top: 14px; left: 14px;
          width: 38px; height: 38px;
          border-radius: 12px;
          background: rgba(255,255,255,0.18);
          border: 1px solid rgba(255,255,255,0.3);
          backdrop-filter: blur(8px);
          display: flex; align-items: center; justify-content: center;
          font-size: 18px;
          transition: transform 0.2s;
          z-index: 3;
        }
        .cc-card:hover .cc-emoji-wrap {
          transform: scale(1.12) rotate(-5deg);
        }

        /* EXPLORE BADGE top-right */
        .cc-explore-badge {
          position: absolute;
          top: 14px; right: 14px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          font-size: 10px;
          font-weight: 900;
          padding: 4px 10px;
          border-radius: 20px;
          letter-spacing: 0.3px;
          z-index: 3;
          opacity: 0;
          transform: translateY(-4px);
          transition: opacity 0.2s, transform 0.2s;
          box-shadow: 0 2px 8px rgba(255,111,0,0.4);
        }
        .cc-card:hover .cc-explore-badge {
          opacity: 1;
          transform: translateY(0);
        }

        /* BOTTOM CONTENT */
        .cc-bottom {
          position: absolute;
          bottom: 0; left: 0; right: 0;
          padding: 14px 14px 16px;
          z-index: 3;
        }
        .cc-tag {
          font-size: 10.5px;
          font-weight: 700;
          color: rgba(255,255,255,0.65);
          margin-bottom: 4px;
          letter-spacing: 0.3px;
          text-transform: uppercase;
        }
        .cc-name {
          font-size: 16px;
          font-weight: 900;
          color: #fff;
          letter-spacing: -0.3px;
          margin-bottom: 10px;
          text-shadow: 0 2px 8px rgba(0,0,0,0.4);
          line-height: 1.1;
        }

        /* Shop now row */
        .cc-shop-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: rgba(255,255,255,0.12);
          border: 1px solid rgba(255,255,255,0.2);
          backdrop-filter: blur(6px);
          border-radius: 9px;
          padding: 7px 11px;
          transition: background 0.2s;
        }
        .cc-card:hover .cc-shop-row {
          background: rgba(255,111,0,0.7);
          border-color: transparent;
        }
        .cc-shop-label {
          font-size: 12px;
          font-weight: 800;
          color: #fff;
        }
        .cc-shop-arrow {
          font-size: 13px;
          color: rgba(255,255,255,0.8);
          transition: transform 0.2s;
        }
        .cc-card:hover .cc-shop-arrow {
          transform: translateX(3px);
          color: #fff;
        }

        /* Accent border on hover */
        .cc-card::after {
          content: '';
          position: absolute;
          inset: 0;
          border-radius: 18px;
          border: 2px solid transparent;
          transition: border-color 0.25s;
          pointer-events: none;
          z-index: 4;
        }
        .cc-card:hover::after {
          border-color: rgba(255,111,0,0.5);
        }

        @media (max-width: 768px) {
          .cc-grid { grid-template-columns: repeat(2, 1fr); }
          .cc-title { font-size: 18px; }
        }
      `}</style>

      <div className="cc-section">
        {/* HEADER */}
        <div className="cc-header">
          <div className="cc-title-wrap">
            <div className="cc-title-bar" />
            <h2 className="cc-title">Shop by Category</h2>
          </div>
          
        </div>

        {/* GRID */}
        <div className="cc-grid">
          {categories.map((cat, index) => (
            <div
              key={index}
              className="cc-card"
              onClick={() => navigate(`/category/${formatCategory(cat.name)}`)}
            >
              {/* IMAGE */}
              <img src={cat.image} alt={cat.name} className="cc-img" />

              {/* DARK OVERLAY */}
              <div className="cc-overlay-dark" />

              {/* EMOJI BADGE */}
              <div className="cc-emoji-wrap">{cat.emoji}</div>

              {/* EXPLORE BADGE (appears on hover) */}
              <div className="cc-explore-badge">EXPLORE →</div>

              {/* BOTTOM */}
              <div className="cc-bottom">
                <p className="cc-tag">{cat.tag}</p>
                <p className="cc-name">{cat.name}</p>
                <div className="cc-shop-row">
                  <span className="cc-shop-label">Shop Now</span>
                  <span className="cc-shop-arrow">→</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default CategoryCards;
