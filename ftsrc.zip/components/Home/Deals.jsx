import React, { useContext, useRef, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ShopContext } from "../../context/ShopContext";

const Deals = () => {
  const { products, addToCart } = useContext(ShopContext);
  const navigate = useNavigate();
  const scrollRef = useRef();
  const [addedIds, setAddedIds] = useState([]);

  // 🔥 OPTION 2 LOGIC (Top Discount Products)
  const deals = useMemo(() => {
    return [...products]
      .filter((item) => item.discount && item.discount > 0)
      .sort((a, b) => b.discount - a.discount)
      .slice(0, 10);
  }, [products]);

  // 🔹 Scroll functions
  const scrollLeft = () => {
    scrollRef.current.scrollBy({ left: -300, behavior: "smooth" });
  };
  const scrollRight = () => {
    scrollRef.current.scrollBy({ left: 300, behavior: "smooth" });
  };

  const handleAddToCart = (e, id) => {
    e.stopPropagation();
    addToCart(id);
    setAddedIds((prev) => [...prev, id]);
    setTimeout(() => setAddedIds((prev) => prev.filter((i) => i !== id)), 1400);
  };

  if (!deals.length) {
    return (
      <div style={{
        fontFamily: "'Nunito', sans-serif",
        background: "linear-gradient(135deg, #1a1a1a, #2d1a00)",
        borderRadius: 20,
        padding: "32px 28px",
        textAlign: "center",
        color: "#fff",
        margin: "8px 0",
      }}>
        <div style={{ fontSize: 40, marginBottom: 10 }}>🔥</div>
        <p style={{ fontWeight: 800, color: "rgba(255,255,255,0.5)" }}>No deals available right now</p>
      </div>
    );
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        * { box-sizing: border-box; }

        /* ── DARK DEALS SECTION ── */
        .deals-section {
          font-family: 'Nunito', sans-serif;
          background: #fdf5ee;
          border-radius: 22px;
          padding: 28px 28px 32px;
          position: relative;
          margin: 8px 0;
          overflow: hidden;
        }

        /* Decorative background orbs */
        .deals-section::before {
          content: '';
          position: absolute;
          top: -60px; right: -60px;
          width: 240px; height: 240px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(255,111,0,0.06), transparent 70%);
          pointer-events: none;
        }
        .deals-section::after {
          content: '';
          position: absolute;
          bottom: -80px; left: 10%;
          width: 300px; height: 300px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(255,149,0,0.04), transparent 70%);
          pointer-events: none;
        }

        /* ── HEADER ── */
        .deals-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 22px;
          position: relative;
          z-index: 2;
        }
        .deals-title-wrap { display: flex; align-items: center; gap: 12px; }
        .deals-fire-icon {
          width: 44px; height: 44px;
          background: linear-gradient(135deg, #ff6f00, #ff3d00);
          border-radius: 14px;
          display: flex; align-items: center; justify-content: center;
          font-size: 20px;
          box-shadow: 0 4px 16px rgba(255,61,0,0.5);
          flex-shrink: 0;
          animation: pulse-fire 2s ease-in-out infinite;
        }
        @keyframes pulse-fire {
          0%, 100% { box-shadow: 0 4px 16px rgba(255,61,0,0.5); }
          50% { box-shadow: 0 4px 28px rgba(255,111,0,0.8); }
        }
        .deals-title {
          font-size: 24px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.4px;
        }
        .deals-title span { color: #ff9500; }
        .deals-subtitle {
          font-size: 12px;
          color: #aaa;
          font-weight: 700;
          margin-top: 2px;
        }

        /* Countdown / deals count badge */
        .deals-badge {
          background: rgba(255,111,0,0.15);
          border: 1px solid rgba(255,111,0,0.35);
          color: #ff9500;
          font-size: 12px;
          font-weight: 800;
          padding: 5px 14px;
          border-radius: 20px;
          display: flex; align-items: center; gap: 6px;
        }
        .deals-badge-dot {
          width: 7px; height: 7px;
          background: #ff6f00;
          border-radius: 50%;
          animation: blink 1.2s ease-in-out infinite;
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.2; }
        }

        /* ── ARROWS ── */
        .deals-arrow {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: 38px; height: 38px;
          background: #fff;
          border: 1.5px solid #ffe0c2;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          z-index: 10;
          font-size: 13px;
          color: #ff9500;
          transition: background 0.18s, transform 0.1s, box-shadow 0.18s;
          outline: none;
          backdrop-filter: blur(6px);
        }
        .deals-arrow:hover {
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #1a1a1a;
          border-color: transparent;
          box-shadow: 0 4px 16px rgba(255,111,0,0.45);
          transform: translateY(-50%) scale(1.1);
        }
        .deals-arrow.left { left: -14px; }
        .deals-arrow.right { right: -14px; }

        /* ── SCROLL ── */
        .deals-scroll-wrap { position: relative; z-index: 2; }
        .deals-scroll {
          display: flex;
          gap: 14px;
          overflow-x: auto;
          padding-bottom: 6px;
          scroll-snap-type: x mandatory;
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        .deals-scroll::-webkit-scrollbar { display: none; }

        /* ── CARD ── */
        .deals-card {
          min-width: 200px;
          max-width: 200px;
          background: #fff;
          border: 1.5px solid #f0e8e0;
          border-radius: 18px;
          overflow: hidden;
          cursor: pointer;
          scroll-snap-align: start;
          flex-shrink: 0;
          transition: background 0.22s, border-color 0.22s, transform 0.2s, box-shadow 0.22s;
          position: relative;
          backdrop-filter: blur(6px);
        }
        .deals-card:hover {
          background: #fff8f2;
          border-color: #ff6f00;
          transform: translateY(-5px);
          box-shadow: 0 12px 36px rgba(255,111,0,0.2);
        }

        /* ── DISCOUNT BADGE ── */
        .discount-badge {
          position: absolute;
          top: 10px; left: 10px;
          z-index: 5;
          background: linear-gradient(135deg, #ff3d00, #ff6f00);
          color: #1a1a1a;
          font-size: 11px;
          font-weight: 900;
          padding: 4px 10px;
          border-radius: 20px;
          box-shadow: 0 3px 10px rgba(255,61,0,0.45);
          letter-spacing: 0.3px;
        }

        /* ── IMAGE AREA ── */
        .deals-img-wrap {
          height: 160px;
          background: #fff8f2;
          display: flex; align-items: center; justify-content: center;
          overflow: hidden;
          position: relative;
        }
        .deals-img {
          width: 100%; height: 100%;
          object-fit: contain;
          padding: 10px;
          transition: transform 0.4s ease;
          filter: drop-shadow(0 4px 12px rgba(0,0,0,0.4));
        }
        .deals-card:hover .deals-img { transform: scale(1.08); }

        /* Rating on image */
        .deals-rating {
          position: absolute;
          bottom: 8px; right: 8px;
          background: rgba(255,255,255,0.92);
          border: 1px solid #ffe0c2;
          border-radius: 20px;
          padding: 3px 9px;
          font-size: 11px;
          font-weight: 800;
          color: #1a1a1a;
          display: flex; align-items: center; gap: 3px;
          backdrop-filter: blur(4px);
        }

        /* ── CARD BODY ── */
        .deals-body { padding: 12px 13px 14px; }

        .deals-brand {
          font-size: 10px;
          font-weight: 700;
          color: #ff9500;
          text-transform: uppercase;
          letter-spacing: 0.6px;
          margin-bottom: 4px;
        }
        .deals-name {
          font-size: 13px;
          font-weight: 800;
          color: #1a1a1a;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          margin-bottom: 10px;
        }

        .deals-price-row {
          display: flex;
          align-items: baseline;
          gap: 8px;
          margin-bottom: 4px;
        }
        .deals-discounted {
          font-size: 18px;
          font-weight: 900;
          color: #ff9500;
        }
        .deals-original {
          font-size: 12.5px;
          color: #bbb;
          text-decoration: line-through;
          font-weight: 600;
        }

        .deals-savings {
          font-size: 11px;
          font-weight: 800;
          color: #4ade80;
          margin-bottom: 12px;
        }

        /* ── BUTTONS ── */
        .deals-btns { display: flex; flex-direction: column; gap: 7px; }

        .btn-deals-cart {
          width: 100%;
          padding: 9px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #1a1a1a;
          border: none;
          border-radius: 10px;
          font-weight: 800;
          font-size: 12.5px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          transition: opacity 0.2s, transform 0.1s;
          box-shadow: 0 3px 12px rgba(255,111,0,0.4);
          display: flex; align-items: center; justify-content: center; gap: 5px;
        }
        .btn-deals-cart:hover { opacity: 0.88; transform: translateY(-1px); }
        .btn-deals-cart.added {
          background: linear-gradient(135deg, #166534, #16a34a);
          box-shadow: 0 3px 12px rgba(22,163,74,0.4);
        }

        .btn-deals-view {
          width: 100%;
          padding: 8px;
          background: transparent;
          color: #ff6f00;
          border: 1.5px solid #ffe0c2;
          border-radius: 10px;
          font-weight: 800;
          font-size: 12.5px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          transition: background 0.18s, border-color 0.18s, color 0.18s;
        }
        .btn-deals-view:hover {
          background: #fff3e6;
          border-color: #ff6f00;
          color: #ff9500;
        }
      `}</style>

      <div className="deals-section">
        {/* HEADER */}
        <div className="deals-header">
          <div className="deals-title-wrap">
            <div className="deals-fire-icon">🔥</div>
            <div>
              <h2 className="deals-title">
                Top <span>Deals</span>
              </h2>
              <p className="deals-subtitle">Limited time offers — grab them fast</p>
            </div>
          </div>

          <div className="deals-badge">
            <span className="deals-badge-dot" />
            {deals.length} Live Deals
          </div>
        </div>

        {/* ARROWS + SCROLL */}
        <div className="deals-scroll-wrap">
          <button className="deals-arrow left" onClick={scrollLeft}>◀</button>

          <div ref={scrollRef} className="deals-scroll">
            {deals.map((item) => {
              const discountedPrice = Math.floor(item.price * (1 - item.discount / 100));
              const savings = item.price - discountedPrice;
              const isAdded = addedIds.includes(item._id);

              return (
                <div
                  key={item._id || item.id}
                  className="deals-card"
                  onClick={() => navigate(`/product/${item._id}`)}
                >
                  {/* DISCOUNT BADGE */}
                  <div className="discount-badge">🏷 {item.discount}% OFF</div>

                  {/* IMAGE */}
                  <div className="deals-img-wrap">
                    <img
                      src={
                        item.images && item.images.length > 0
                          ? item.images[0].startsWith("http")
                            ? item.images[0]
                            : `http://localhost:5000${item.images[0]}`
                          : "/placeholder.png"
                      }
                      alt={item.name}
                      className="deals-img"
                    />
                    {item.rating && (
                      <div className="deals-rating">⭐ {item.rating}</div>
                    )}
                  </div>

                  {/* BODY */}
                  <div className="deals-body">
                    {item.brand && (
                      <p className="deals-brand">{item.brand}</p>
                    )}
                    <h3 className="deals-name">{item.name}</h3>

                    <div className="deals-price-row">
                      <span className="deals-discounted">₹{discountedPrice.toLocaleString("en-IN")}</span>
                      <span className="deals-original">₹{item.price.toLocaleString("en-IN")}</span>
                    </div>
                    <p className="deals-savings">You save ₹{savings.toLocaleString("en-IN")}</p>

                    <div className="deals-btns">
                      <button
                        className={`btn-deals-cart ${isAdded ? "added" : ""}`}
                        onClick={(e) => handleAddToCart(e, item._id)}
                      >
                        {isAdded ? <>✔ Added!</> : <>🛒 Add to Cart</>}
                      </button>

                      <button
                        className="btn-deals-view"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/product/${item._id}`);
                        }}
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <button className="deals-arrow right" onClick={scrollRight}>▶</button>
        </div>
      </div>
    </>
  );
};

export default Deals;