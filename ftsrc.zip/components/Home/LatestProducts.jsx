import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const LatestProducts = () => {
  const [latestProducts, setLatestProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // FETCH DATA
  useEffect(() => {
    const fetchLatest = async () => {
      try {
        const { data } = await API.get("/products/latest");
        setLatestProducts(data);
      } catch (err) {
        console.log(err);
      } finally {
        setLoading(false);
      }
    };
    fetchLatest();
  }, []);

  // 👉 ONLY 8 PRODUCTS
  const visibleProducts = latestProducts.slice(0, 8);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

        .lp-wrap {
          font-family: 'Nunito', sans-serif;
          background: #fff;
          border-radius: 20px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 4px 18px rgba(255,111,0,0.07);
          overflow: hidden;
          margin-top: 16px;
          position: relative;
        }

        /* Orange top bar */
        .lp-wrap::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 4px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
        }

        /* HEADER */
        .lp-header {
          padding: 18px 18px 14px;
          border-bottom: 1.5px solid #fff3e6;
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        .lp-title-row {
          display: flex;
          align-items: center;
          gap: 9px;
        }
        .lp-title-icon {
          width: 32px; height: 32px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-radius: 9px;
          display: flex; align-items: center; justify-content: center;
          font-size: 15px;
          box-shadow: 0 3px 10px rgba(255,111,0,0.3);
          flex-shrink: 0;
        }
        .lp-title {
          font-size: 15px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.3px;
        }
        .lp-badge {
          font-size: 11px;
          font-weight: 800;
          color: #ff6f00;
          background: #fff3e6;
          border: 1px solid #ffe0c2;
          padding: 2px 9px;
          border-radius: 20px;
        }

        /* NEW pill */
        .lp-new-dot {
          display: flex;
          align-items: center;
          gap: 5px;
          font-size: 11px;
          font-weight: 800;
          color: #2e9e5b;
        }
        .lp-new-dot-circle {
          width: 7px; height: 7px;
          background: #2e9e5b;
          border-radius: 50%;
          animation: lp-blink 1.4s ease-in-out infinite;
        }
        @keyframes lp-blink {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.3; transform: scale(0.7); }
        }

        /* SKELETON */
        @keyframes lp-shimmer {
          0% { background-position: -400px 0; }
          100% { background-position: 400px 0; }
        }
        .lp-skeleton {
          background: linear-gradient(90deg, #f5ece4 25%, #ffe8d0 50%, #f5ece4 75%);
          background-size: 400px 100%;
          animation: lp-shimmer 1.3s infinite linear;
          border-radius: 8px;
        }

        /* LIST */
        .lp-list {
          display: flex;
          flex-direction: column;
          padding: 10px 12px 14px;
          gap: 2px;
        }

        /* ITEM */
        .lp-item {
          display: flex;
          gap: 12px;
          align-items: center;
          padding: 9px 8px;
          border-radius: 12px;
          cursor: pointer;
          transition: background 0.15s, transform 0.13s;
          position: relative;
          border: 1px solid transparent;
        }
        .lp-item:hover {
          background: #fff8f2;
          border-color: #ffe0c2;
          transform: translateX(3px);
        }
        .lp-item:hover .lp-arrow { opacity: 1; transform: translateX(0); }

        /* Rank number */
        .lp-rank {
          width: 20px;
          font-size: 11px;
          font-weight: 900;
          color: #ddd;
          text-align: center;
          flex-shrink: 0;
          line-height: 1;
        }
        .lp-rank.top { color: #ff6f00; }

        /* IMAGE */
        .lp-img-wrap {
          width: 52px; height: 52px;
          border-radius: 10px;
          background: #fff8f2;
          border: 1.5px solid #ffe0c2;
          overflow: hidden;
          flex-shrink: 0;
          display: flex; align-items: center; justify-content: center;
        }
        .lp-img {
          width: 46px; height: 46px;
          object-fit: cover;
          transition: transform 0.3s ease;
        }
        .lp-item:hover .lp-img { transform: scale(1.08); }

        /* DETAILS */
        .lp-details { flex: 1; min-width: 0; }
        .lp-name {
          font-size: 13px;
          font-weight: 800;
          color: #1a1a1a;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          margin-bottom: 4px;
          line-height: 1.2;
        }
        .lp-price {
          font-size: 14px;
          font-weight: 900;
          color: #ff6f00;
        }

        /* Arrow indicator */
        .lp-arrow {
          font-size: 13px;
          color: #ff6f00;
          opacity: 0;
          transform: translateX(-4px);
          transition: opacity 0.15s, transform 0.15s;
          flex-shrink: 0;
        }

        /* Divider between items */
        .lp-item-divider {
          height: 1px;
          background: #fff8f2;
          margin: 0 8px;
        }

        /* VIEW ALL FOOTER */
        .lp-footer {
          padding: 12px 16px;
          border-top: 1.5px solid #fff3e6;
          background: #fdfaf8;
        }
        .lp-view-all {
          width: 100%;
          padding: 10px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 11px;
          font-weight: 800;
          font-size: 13px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          box-shadow: 0 3px 10px rgba(255,111,0,0.28);
          transition: opacity 0.2s, transform 0.1s;
          display: flex; align-items: center; justify-content: center; gap: 5px;
        }
        .lp-view-all:hover { opacity: 0.9; transform: translateY(-1px); }
      `}</style>

      <div className="lp-wrap">
        {/* HEADER */}
        <div className="lp-header">
          <div className="lp-title-row">
            <div className="lp-title-icon">✨</div>
            <p className="lp-title">Latest Products</p>
            <span className="lp-badge">{visibleProducts.length}</span>
          </div>
          <div className="lp-new-dot">
            <span className="lp-new-dot-circle" />
            Just In
          </div>
        </div>

        {/* LIST */}
        <motion.div
          className="lp-list"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4 }}
        >
          {loading
            ? [...Array(6)].map((_, i) => (
                <div key={i} style={{ display: "flex", gap: 12, alignItems: "center", padding: "9px 8px" }}>
                  <div className="lp-skeleton" style={{ width: 20, height: 14, borderRadius: 4 }} />
                  <div className="lp-skeleton" style={{ width: 52, height: 52, borderRadius: 10, flexShrink: 0 }} />
                  <div style={{ flex: 1 }}>
                    <div className="lp-skeleton" style={{ height: 13, width: "75%", marginBottom: 6 }} />
                    <div className="lp-skeleton" style={{ height: 13, width: "40%" }} />
                  </div>
                </div>
              ))
            : visibleProducts.map((item, index) => (
                <motion.div
                  key={item._id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <div
                    className="lp-item"
                    onClick={() => navigate(`/product/${item._id}`)}
                  >
                    {/* RANK */}
                    <span className={`lp-rank ${index < 3 ? "top" : ""}`}>
                      {index < 3 ? ["🥇","🥈","🥉"][index] : `${index + 1}`}
                    </span>

                    {/* IMAGE */}
                    <div className="lp-img-wrap">
                      <img
                        src={
                          item.images && item.images.length > 0
                            ? item.images[0].startsWith("http")
                              ? item.images[0]
                              : `http://localhost:5000${item.images[0]}`
                            : "/placeholder.png"
                        }
                        alt={item.name}
                        className="lp-img"
                      />
                    </div>

                    {/* DETAILS */}
                    <div className="lp-details">
                      <p className="lp-name">{item.name}</p>
                      <p className="lp-price">₹{item.price?.toLocaleString("en-IN")}</p>
                    </div>

                    {/* ARROW */}
                    <span className="lp-arrow">→</span>
                  </div>

                  {index < visibleProducts.length - 1 && (
                    <div className="lp-item-divider" />
                  )}
                </motion.div>
              ))}
        </motion.div>

        {/* FOOTER */}
        
      </div>
    </>
  );
};

export default LatestProducts;