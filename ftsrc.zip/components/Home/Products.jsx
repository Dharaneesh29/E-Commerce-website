// import React, { useEffect, useState, useContext ,useRef} from "react";
// import { useNavigate } from "react-router-dom";
// import { ShopContext } from "../../context/ShopContext";

// const Products = ({ category }) => {
//   const navigate = useNavigate();
//   const { products = [], addToCart } = useContext(ShopContext);

//   const [filtered, setFiltered] = useState([]);

//   useEffect(() => {
//     if (category) {
//       const data = products.filter(
//         (item) => item.category === category
//       );
//       setFiltered(data);
//     } else {
//       setFiltered(products);
//     }
//   }, [category, products]);

//   if (!products || products.length === 0) {
//     return (
//       <p className="text-center mt-10 text-gray-500">
//         Loading...
//       </p>
//     );
//   }

//   const displayProducts = category ? filtered : products;

//   return (
//     <div className="p-6">

//       <h2 className="text-2xl font-bold mb-5 capitalize">
//         {category ? category : "Trending Products"}
//       </h2>

//       <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5">

//         {displayProducts.length > 0 ? (
//           displayProducts.map((item) => (
//             <div
//               key={item._id || item.id}
//               className="bg-white p-4 rounded-lg shadow-md hover:shadow-xl transition duration-300"
//               onClick={() =>
//                 navigate(`/product/${item._id || item.id}`)
//               }
//             >
//               <img
//                 src={item.images?.[0]
//                   ? item.images[0].startsWith("http")
//                    ? item.images[0] : `http://localhost:5000${item.images[0]}`
//                   : `https://via.placeholder.com/150`}
//                 alt={item.name}
//                 className="h-40 w-full object-contain bg-gray-100 rounded"
//                 onError={(e) =>
//                   (e.target.src = "https://via.placeholder.com/150")
//                 }
//               />
//               <h3 className="font-semibold mt-2 truncate">
//                 {item.name}
//               </h3>

//               <p className="text-gray-500 text-sm">
//                 {item.brand}
//               </p>

//               <p className="text-green-600 font-bold">
//                 ₹{item.price}
//               </p>

//               <p className="text-yellow-500 text-sm">
//                 ⭐ {item.rating} / 5
//               </p>

//               {/* Buttons */}
//               <div className="flex gap-3 mt-3">
//                 <button
//                   onClick={(e) => {
//                     e.stopPropagation();
//                     addToCart({ ...item, qty: 1 });
//                   }}
//                   className="bg-orage-500 hover:bg-orange-600 text-white w-full py-2 rounded-lg text-sm font-semibold"
//                 >
//                   Add to Cart
//                 </button>

//                 <button
//                   onClick={(e) => {
//                     e.stopPropagation();
//                     navigate(`/product/${item._id || item.id}`);
//                   }}
//                   className="bg-orange-100 text-orange-600 hover:bg-orange-200 w-full py-2 rounded-lg text-sm font-semibold"
//                 >
//                   View
//                 </button>
//               </div>
//             </div>
//           ))
//         ) : (
//           <p className="text-gray-500 col-span-full text-center">
//             No products found
//           </p>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Products;


import React, { useEffect, useState, useContext, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ShopContext } from "../../context/ShopContext";

const Products = ({ category }) => {
  const navigate = useNavigate();
  const { products, addToCart } = useContext(ShopContext);

  const [filtered, setFiltered] = useState([]);
  const [addedIds, setAddedIds] = useState([]);
  const scrollRef = useRef();

  // 🔹 Filter by category
  useEffect(() => {
    if (category) {
      const data = products.filter((item) => item.category === category);
      setFiltered(data);
    } else {
      setFiltered(products);
    }
  }, [category, products]);

  const displayProducts = category ? filtered : products;

  // 🔹 Scroll functions
  const scrollLeft = () => {
    scrollRef.current.scrollBy({ left: -300, behavior: "smooth" });
  };

  const scrollRight = () => {
    scrollRef.current.scrollBy({ left: 300, behavior: "smooth" });
  };

  // Add to cart flash feedback
  const handleAddToCart = (e, id) => {
    e.stopPropagation();
    addToCart(id);
    setAddedIds((prev) => [...prev, id]);
    setTimeout(() => setAddedIds((prev) => prev.filter((i) => i !== id)), 1400);
  };

  if (!products || products.length === 0) {
    return (
      <>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
          @keyframes shimmer {
            0% { background-position: -600px 0; }
            100% { background-position: 600px 0; }
          }
          .prod-skeleton {
            font-family: 'Nunito', sans-serif;
            background: linear-gradient(90deg, #f5ece4 25%, #ffe8d0 50%, #f5ece4 75%);
            background-size: 600px 100%;
            animation: shimmer 1.4s infinite linear;
            border-radius: 16px;
          }
        `}</style>
        <div style={{ padding: "24px 28px", fontFamily: "'Nunito', sans-serif" }}>
          <div className="prod-skeleton" style={{ height: 28, width: 200, marginBottom: 20 }} />
          <div style={{ display: "flex", gap: 16 }}>
            {[...Array(5)].map((_, i) => (
              <div key={i} style={{ minWidth: 210, flexShrink: 0 }}>
                <div className="prod-skeleton" style={{ height: 180, marginBottom: 12 }} />
                <div className="prod-skeleton" style={{ height: 14, width: "75%", marginBottom: 8 }} />
                <div className="prod-skeleton" style={{ height: 12, width: "45%" }} />
              </div>
            ))}
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        * { box-sizing: border-box; }

        .prod-section {
          font-family: 'Nunito', sans-serif;
          padding: 28px 28px 32px;
          position: relative;
          background: #fdf5ee;
          border-radius: 20px;
          margin-bottom: 8px;
        }

        /* ── HEADER ── */
        .prod-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 20px;
        }
        .prod-title-wrap { display: flex; align-items: center; gap: 10px; }
        .prod-title-bar {
          width: 4px; height: 26px;
          background: linear-gradient(180deg, #ff6f00, #ffaa5a);
          border-radius: 4px;
          flex-shrink: 0;
        }
        .prod-title {
          font-size: 22px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.4px;
          text-transform: capitalize;
        }
        .prod-count {
          font-size: 12px;
          font-weight: 800;
          color: #ff6f00;
          background: #fff3e6;
          border: 1px solid #ffe0c2;
          padding: 3px 10px;
          border-radius: 20px;
        }
        .prod-see-all {
          font-size: 13px;
          font-weight: 800;
          color: #ff6f00;
          cursor: pointer;
          border: 1.5px solid #ff6f00;
          padding: 6px 14px;
          border-radius: 9px;
          background: transparent;
          font-family: 'Nunito', sans-serif;
          transition: background 0.18s, color 0.18s;
          display: flex; align-items: center; gap: 5px;
        }
        .prod-see-all:hover { background: #ff6f00; color: #fff; }

        /* ── SCROLL ARROWS ── */
        .prod-arrow {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          width: 38px; height: 38px;
          background: #fff;
          border: 1.5px solid #ffe0c2;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          z-index: 10;
          font-size: 14px;
          color: #ff6f00;
          box-shadow: 0 4px 14px rgba(255,111,0,0.15);
          transition: background 0.15s, color 0.15s, transform 0.1s, box-shadow 0.15s;
          border: none;
          outline: none;
        }
        .prod-arrow:hover {
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          box-shadow: 0 6px 18px rgba(255,111,0,0.3);
          transform: translateY(-50%) scale(1.08);
        }
        .prod-arrow.left { left: -16px; }
        .prod-arrow.right { right: -16px; }

        /* ── SCROLL TRACK ── */
        .prod-scroll-wrap {
          overflow: hidden;
          position: relative;
        }
        .prod-scroll {
          display: flex;
          gap: 16px;
          overflow-x: auto;
          padding-bottom: 6px;
          scroll-snap-type: x mandatory;
          scrollbar-width: none;
          -ms-overflow-style: none;
        }
        .prod-scroll::-webkit-scrollbar { display: none; }

        /* ── CARD ── */
        .prod-card {
          min-width: 210px;
          max-width: 210px;
          background: #fff;
          border-radius: 18px;
          border: 1.5px solid #f0e8e0;
          box-shadow: 0 3px 12px rgba(255,111,0,0.05);
          padding: 0;
          cursor: pointer;
          scroll-snap-align: start;
          flex-shrink: 0;
          overflow: hidden;
          transition: box-shadow 0.22s, border-color 0.22s, transform 0.2s;
          position: relative;
        }
        .prod-card:hover {
          box-shadow: 0 10px 30px rgba(255,111,0,0.15);
          border-color: #ffcc99;
          transform: translateY(-4px);
        }
        .prod-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 3px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
          opacity: 0;
          transition: opacity 0.2s;
          z-index: 2;
        }
        .prod-card:hover::before { opacity: 1; }

        /* IMAGE */
        .prod-img-wrap {
          height: 168px;
          background: #fff8f2;
          overflow: hidden;
          display: flex;
          align-items: center;
          justify-content: center;
          position: relative;
        }
        .prod-img {
          width: 100%; height: 100%;
          object-fit: contain;
          padding: 10px;
          transition: transform 0.4s ease;
        }
        .prod-card:hover .prod-img { transform: scale(1.07); }

        /* Rating badge on image */
        .prod-rating-badge {
          position: absolute;
          bottom: 8px; left: 8px;
          background: rgba(255,255,255,0.92);
          border: 1px solid #ffe0c2;
          border-radius: 20px;
          padding: 3px 9px;
          font-size: 11.5px;
          font-weight: 800;
          color: #1a1a1a;
          display: flex; align-items: center; gap: 3px;
          backdrop-filter: blur(3px);
        }

        /* CARD BODY */
        .prod-body { padding: 13px 13px 14px; }

        .prod-brand {
          font-size: 10.5px;
          font-weight: 700;
          color: #ff6f00;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 4px;
        }
        .prod-name {
          font-size: 13.5px;
          font-weight: 800;
          color: #1a1a1a;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          margin-bottom: 8px;
          line-height: 1.3;
        }
        .prod-price-row {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-bottom: 12px;
        }
        .prod-price {
          font-size: 17px;
          font-weight: 900;
          color: #1a1a1a;
        }

        /* BUTTONS */
        .prod-btns { display: flex; flex-direction: column; gap: 7px; }

        .btn-add-cart {
          width: 100%;
          padding: 9px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 10px;
          font-weight: 800;
          font-size: 12.5px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          transition: opacity 0.2s, transform 0.1s;
          box-shadow: 0 3px 10px rgba(255,111,0,0.28);
          display: flex; align-items: center; justify-content: center; gap: 5px;
        }
        .btn-add-cart:hover { opacity: 0.88; transform: translateY(-1px); }
        .btn-add-cart.added {
          background: linear-gradient(135deg, #2e9e5b, #3ac97a);
          box-shadow: 0 3px 10px rgba(46,158,91,0.28);
        }

        .btn-view {
          width: 100%;
          padding: 8px;
          background: transparent;
          color: #ff6f00;
          border: 1.5px solid #ffcc99;
          border-radius: 10px;
          font-weight: 800;
          font-size: 12.5px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          transition: background 0.18s, border-color 0.18s, color 0.18s;
        }
        .btn-view:hover {
          background: #fff3e6;
          border-color: #ff6f00;
        }
      `}</style>

      <div className="prod-section">
        {/* HEADER */}
        <div className="prod-header">
          <div className="prod-title-wrap">
            <div className="prod-title-bar" />
            <h2 className="prod-title">
              {category ? category : "Trending Products"}
            </h2>
            <span className="prod-count">{displayProducts.slice(0, 10).length}</span>
          </div>

          {/* <button className="prod-see-all" onClick={() => navigate("/home")}>
            See All →
          </button> */}
        </div>

        {/* ARROWS + SCROLL */}
        <div className="prod-scroll-wrap">
          <button className="prod-arrow left" onClick={scrollLeft}>◀</button>

          <div
            ref={scrollRef}
            className="prod-scroll"
          >
            {displayProducts.slice(0, 10).map((item) => {
              const isAdded = addedIds.includes(item._id || item.id);
              return (
                <div
                  key={item._id || item.id}
                  className="prod-card"
                  onClick={() => navigate(`/product/${item._id || item.id}`)}
                >
                  {/* IMAGE */}
                  <div className="prod-img-wrap">
                    <img
                      src={
                        item.images && item.images.length > 0
                          ? item.images[0].startsWith("http")
                            ? item.images[0]
                            : `http://localhost:5000${item.images[0]}`
                          : "/placeholder.png"
                      }
                      alt={item.name}
                      className="prod-img"
                    />
                    {item.rating && (
                      <div className="prod-rating-badge">
                        ⭐ {item.rating}
                      </div>
                    )}
                  </div>

                  {/* BODY */}
                  <div className="prod-body">
                    {item.brand && (
                      <p className="prod-brand">{item.brand}</p>
                    )}
                    <h3 className="prod-name">{item.name}</h3>

                    <div className="prod-price-row">
                      <span className="prod-price">
                        ₹{item.price?.toLocaleString("en-IN")}
                      </span>
                    </div>

                    <div className="prod-btns">
                      <button
                        className={`btn-add-cart ${isAdded ? "added" : ""}`}
                        onClick={(e) => handleAddToCart(e, item._id)}
                      >
                        {isAdded ? <>✔ Added!</> : <>🛒 Add to Cart</>}
                      </button>

                      <button
                        className="btn-view"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/product/${item._id || item.id}`);
                        }}
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <button className="prod-arrow right" onClick={scrollRight}>▶</button>
        </div>
      </div>
    </>
  );
};

export default Products;