// import React, { useEffect, useState } from "react";
 
// import b1 from "../../assets/banner/banner1.webp";
// import b2 from "../../assets/banner/banner2.webp";
// import b3 from "../../assets/banner/banner3.webp";
// import b4 from "../../assets/banner/banner4.webp";
 
// const banners = [
//   {
//     id: 1,
//     image: b1,
//     title: "Upgrade Your Style",
//     subtitle: "Latest Fashion Collection",
//     price: "Starting from ₹999",
//   },
//   {
//     id: 2,
//     image: b2,
//     title: "Smart Electronics",
//     subtitle: "Best Gadgets Deals",
//     price: "Up to 40% OFF",
//   },
//   {
//     id: 3,
//     image: b3,
//     title: "Home Essentials",
//     subtitle: "Make Your Home Beautiful",
//     price: "Flat 30% OFF",
//   },
//   {
//     id: 4,
//     image: b4,
//     title: "Top Offers",
//     subtitle: "Limited Time Deals",
//     price: "Grab Now 🔥",
//   },
// ];
 
// const Banner = () => {
//   const [current, setCurrent] = useState(0);
 
//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrent((prev) => (prev + 1) % banners.length);
//     }, 4000);
//     return () => clearInterval(interval);
//   }, []);
 
//   return (
//     <div className="relative w-full h-[320px] overflow-hidden rounded-2xl">
 
//       {/* IMAGES */}
//       {banners.map((item, index) => (
//         <div
//           key={item.id}
//           className={`absolute w-full h-full transition-all duration-1000 ${
//             index === current
//               ? "opacity-100 scale-100"
//               : "opacity-0 scale-110"
//           }`}
//         >
//           <img
//             src={item.image}
//             alt="banner"
//             className="w-full h-full object-cover"
//           />
 
//           {/* DARK OVERLAY */}
//           <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent"></div>
 
//           {/* TEXT CONTENT */}
//           <div className="absolute left-10 top-1/2 -translate-y-1/2 text-white">
//             <h2 className="text-3xl font-bold mb-2">
//               {item.title}
//             </h2>
//             <p className="text-lg mb-2">{item.subtitle}</p>
//             <p className="text-xl font-semibold mb-4 text-orange-400">
//               {item.price}
//             </p>
 
//             <button className="bg-orange-500 hover:bg-orange-600 px-5 py-2 rounded-full text-sm font-medium transition">
//               Shop Now
//             </button>
//           </div>
//         </div>
//       ))}
 
//       {/* DOTS */}
//       <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
//         {banners.map((_, index) => (
//           <div
//             key={index}
//             onClick={() => setCurrent(index)}
//             className={`h-2 rounded-full cursor-pointer transition-all ${
//               current === index
//                 ? "w-6 bg-white"
//                 : "w-2 bg-white/50"
//             }`}
//           ></div>
//         ))}
//       </div>
//     </div>
//   );
// };
 
// export default Banner;

import React, { useEffect, useState } from "react";

import b1 from "../../assets/banner/banner1.webp";
import b2 from "../../assets/banner/banner2.webp";
import b3 from "../../assets/banner/banner3.webp";
import b4 from "../../assets/banner/banner4.webp";

const banners = [
  {
    id: 1,
    image: b1,
    title: "Upgrade Your Style",
    subtitle: "Latest Fashion Collection",
    price: "Starting from ₹999",
    tag: "NEW ARRIVALS",
    tagColor: "#ff6f00",
  },
  {
    id: 2,
    image: b2,
    title: "Smart Electronics",
    subtitle: "Best Gadgets Deals",
    price: "Up to 40% OFF",
    tag: "HOT DEALS",
    tagColor: "#e53935",
  },
  {
    id: 3,
    image: b3,
    title: "Home Essentials",
    subtitle: "Make Your Home Beautiful",
    price: "Flat 30% OFF",
    tag: "LIMITED OFFER",
    tagColor: "#2e9e5b",
  },
  {
    id: 4,
    image: b4,
    title: "Top Offers",
    subtitle: "Limited Time Deals",
    price: "Grab Now 🔥",
    tag: "TRENDING",
    tagColor: "#9333ea",
  },
];

const Banner = () => {
  const [current, setCurrent] = useState(0);
  const [animating, setAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % banners.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

        .banner-root {
          font-family: 'Nunito', sans-serif;
          position: relative;
          width: 100%;
          height: 340px;
          overflow: hidden;
          border-radius: 22px;
          box-shadow: 0 8px 32px rgba(255,111,0,0.18);
        }

        /* SLIDE */
        .banner-slide {
          position: absolute;
          inset: 0;
          transition: opacity 0.9s ease, transform 1s ease;
        }
        .banner-slide.active { opacity: 1; transform: scale(1); z-index: 2; }
        .banner-slide.inactive { opacity: 0; transform: scale(1.06); z-index: 1; }

        .banner-img {
          width: 100%; height: 100%;
          object-fit: cover;
          display: block;
        }

        /* OVERLAYS */
        .banner-overlay-left {
          position: absolute;
          inset: 0;
          background: linear-gradient(105deg, rgba(10,4,0,0.78) 0%, rgba(20,8,0,0.55) 40%, transparent 70%);
        }
        .banner-overlay-bottom {
          position: absolute;
          inset: 0;
          background: linear-gradient(to top, rgba(0,0,0,0.35) 0%, transparent 50%);
        }

        /* CONTENT */
        .banner-content {
          position: absolute;
          left: 36px;
          top: 50%;
          transform: translateY(-50%);
          z-index: 5;
          max-width: 380px;
        }

        .banner-tag {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 10.5px;
          font-weight: 900;
          color: #fff;
          padding: 4px 12px;
          border-radius: 20px;
          margin-bottom: 14px;
          letter-spacing: 1px;
          border: 1px solid rgba(255,255,255,0.25);
          backdrop-filter: blur(6px);
        }
        .banner-tag-dot {
          width: 6px; height: 6px;
          border-radius: 50%;
          background: #fff;
          animation: b-blink 1.2s ease-in-out infinite;
        }
        @keyframes b-blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }

        .banner-title {
          font-size: 34px;
          font-weight: 900;
          color: #fff;
          line-height: 1.1;
          letter-spacing: -0.6px;
          margin-bottom: 8px;
          text-shadow: 0 2px 12px rgba(0,0,0,0.4);
        }

        .banner-subtitle {
          font-size: 15px;
          font-weight: 600;
          color: rgba(255,255,255,0.78);
          margin-bottom: 10px;
          line-height: 1.4;
        }

        .banner-price {
          font-size: 20px;
          font-weight: 900;
          color: #ffaa5a;
          margin-bottom: 22px;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .banner-price-line {
          height: 2px;
          width: 32px;
          background: #ff6f00;
          border-radius: 2px;
        }

        .banner-btn {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 12px 26px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 50px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          box-shadow: 0 6px 20px rgba(255,111,0,0.45);
          transition: opacity 0.2s, transform 0.15s, box-shadow 0.2s;
          letter-spacing: 0.3px;
        }
        .banner-btn:hover {
          opacity: 0.92;
          transform: translateY(-2px);
          box-shadow: 0 10px 26px rgba(255,111,0,0.55);
        }
        .banner-btn-arrow {
          font-size: 16px;
          transition: transform 0.2s;
        }
        .banner-btn:hover .banner-btn-arrow { transform: translateX(3px); }

        /* SLIDE COUNTER top right */
        .banner-counter {
          position: absolute;
          top: 16px; right: 16px;
          z-index: 10;
          background: rgba(0,0,0,0.38);
          border: 1px solid rgba(255,255,255,0.18);
          backdrop-filter: blur(8px);
          border-radius: 20px;
          padding: 5px 13px;
          font-size: 12px;
          font-weight: 800;
          color: rgba(255,255,255,0.85);
          letter-spacing: 0.5px;
        }
        .banner-counter span { color: #ff9500; }

        /* ARROW BUTTONS */
        .banner-arrow {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          z-index: 10;
          width: 38px; height: 38px;
          background: rgba(255,255,255,0.12);
          border: 1px solid rgba(255,255,255,0.22);
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          color: #fff;
          font-size: 14px;
          backdrop-filter: blur(6px);
          transition: background 0.2s, transform 0.15s;
          user-select: none;
        }
        .banner-arrow:hover {
          background: rgba(255,111,0,0.7);
          transform: translateY(-50%) scale(1.1);
        }
        .banner-arrow.left { left: 14px; }
        .banner-arrow.right { right: 14px; }

        /* DOTS */
        .banner-dots {
          position: absolute;
          bottom: 16px;
          left: 50%;
          transform: translateX(-50%);
          display: flex;
          gap: 7px;
          z-index: 10;
          align-items: center;
        }
        .banner-dot {
          height: 6px;
          border-radius: 3px;
          cursor: pointer;
          transition: all 0.35s ease;
          background: rgba(255,255,255,0.45);
        }
        .banner-dot.active {
          width: 28px;
          background: #ff6f00;
          box-shadow: 0 0 8px rgba(255,111,0,0.6);
        }
        .banner-dot.inactive { width: 6px; }
        .banner-dot:hover { background: rgba(255,255,255,0.75); }

        /* PROGRESS BAR */
        .banner-progress {
          position: absolute;
          bottom: 0; left: 0;
          height: 3px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
          border-radius: 0 3px 0 0;
          z-index: 10;
          animation: banner-prog 4s linear infinite;
        }
        @keyframes banner-prog {
          from { width: 0%; }
          to { width: 100%; }
        }
      `}</style>

      <div className="banner-root">
        {/* PROGRESS BAR */}
        <div key={current} className="banner-progress" />

        {/* SLIDE COUNTER */}
        <div className="banner-counter">
          <span>{current + 1}</span> / {banners.length}
        </div>

        {/* ARROW PREV */}
        <div
          className="banner-arrow left"
          onClick={() => setCurrent((current - 1 + banners.length) % banners.length)}
        >
          ◀
        </div>

        {/* ARROW NEXT */}
        <div
          className="banner-arrow right"
          onClick={() => setCurrent((current + 1) % banners.length)}
        >
          ▶
        </div>

        {/* SLIDES */}
        {banners.map((item, index) => (
          <div
            key={item.id}
            className={`banner-slide ${index === current ? "active" : "inactive"}`}
          >
            <img src={item.image} alt="banner" className="banner-img" />
            <div className="banner-overlay-left" />
            <div className="banner-overlay-bottom" />

            {/* TEXT */}
            <div className="banner-content">
              {/* TAG */}
              <div
                className="banner-tag"
                style={{ background: `${item.tagColor}cc` }}
              >
                <span className="banner-tag-dot" />
                {item.tag}
              </div>

              <h2 className="banner-title">{item.title}</h2>
              <p className="banner-subtitle">{item.subtitle}</p>

              <div className="banner-price">
                <span className="banner-price-line" />
                {item.price}
              </div>

              <button className="banner-btn">
                Shop Now
                <span className="banner-btn-arrow">→</span>
              </button>
            </div>
          </div>
        ))}

        {/* DOTS */}
        <div className="banner-dots">
          {banners.map((_, index) => (
            <div
              key={index}
              onClick={() => setCurrent(index)}
              className={`banner-dot ${index === current ? "active" : "inactive"}`}
            />
          ))}
        </div>
      </div>
    </>
  );
};

export default Banner;

 