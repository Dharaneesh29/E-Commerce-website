import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";

// IMPORT IMAGES FROM ASSETS
import allen from "../../assets/brands/allen.png";
import lakme from "../../assets/brands/lakme.png";
import samsung from "../../assets/brands/samsung.png";
import libas from "../../assets/brands/libas.png";
import puma from "../../assets/brands/puma.png";
import zebronics from "../../assets/brands/zebronics.png";

const banners = [
  { img: allen, name: "Allen Solly", path: "/brand/allensolly", tag: "Fashion", color: "#1a1a2e" },
  { img: lakme, name: "Lakme", path: "/brand/lakme", tag: "Beauty", color: "#3d0a1e" },
  { img: samsung, name: "Samsung", path: "/brand/samsung", tag: "Electronics", color: "#001233" },
  { img: libas, name: "Libas", path: "/brand/libas", tag: "Ethnic Wear", color: "#1a0a2e" },
  { img: puma, name: "Puma", path: "/brand/puma", tag: "Sports", color: "#0a1a0a" },
  { img: zebronics, name: "Zebronics", path: "/brand/zebronics", tag: "Gadgets", color: "#0a0a1a" },
];

const BrandSlider = () => {
  const [index, setIndex] = useState(0);
  const navigate = useNavigate();

  // AUTO SLIDE (SLOW + SMOOTH)
  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

        .bs-wrap {
          font-family: 'Nunito', sans-serif;
          margin-top: 16px;
        }

        /* HEADER */
        .bs-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }
        .bs-title-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .bs-title-icon {
          width: 28px; height: 28px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-radius: 8px;
          display: flex; align-items: center; justify-content: center;
          font-size: 13px;
          box-shadow: 0 3px 8px rgba(255,111,0,0.3);
          flex-shrink: 0;
        }
        .bs-title {
          font-size: 13.5px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.2px;
        }
        .bs-count {
          font-size: 10.5px;
          font-weight: 800;
          color: #ff6f00;
          background: #fff3e6;
          border: 1px solid #ffe0c2;
          padding: 2px 8px;
          border-radius: 20px;
        }

        /* SLIDER CONTAINER */
        .bs-slider {
          position: relative;
          width: 100%;
          border-radius: 18px;
          overflow: hidden;
          cursor: pointer;
          box-shadow: 0 6px 24px rgba(0,0,0,0.14);
          aspect-ratio: 3/4;
        }

        /* SLIDE */
        .bs-slide {
          position: relative;
          width: 100%;
          height: 100%;
        }

        .bs-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
          transition: transform 0.7s ease;
        }
        .bs-slide:hover .bs-img {
          transform: scale(1.05);
        }

        /* OVERLAYS */
        .bs-overlay-top {
          position: absolute;
          inset: 0;
          background: linear-gradient(180deg,
            rgba(0,0,0,0.28) 0%,
            transparent 35%,
            transparent 50%,
            rgba(0,0,0,0.72) 100%
          );
          border-radius: 18px;
        }

        /* TOP BADGE */
        .bs-top-badge {
          position: absolute;
          top: 12px; left: 12px;
          background: rgba(255,255,255,0.15);
          border: 1px solid rgba(255,255,255,0.28);
          backdrop-filter: blur(8px);
          border-radius: 20px;
          padding: 4px 11px;
          font-size: 10.5px;
          font-weight: 800;
          color: #fff;
          letter-spacing: 0.3px;
        }

        /* PROGRESS BAR */
        .bs-progress {
          position: absolute;
          top: 0; left: 0;
          height: 3px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
          border-radius: 0 3px 0 0;
          animation: bs-prog 5s linear infinite;
        }
        @keyframes bs-prog {
          from { width: 0%; }
          to { width: 100%; }
        }

        /* BOTTOM CONTENT */
        .bs-bottom {
          position: absolute;
          bottom: 0; left: 0; right: 0;
          padding: 16px 14px 14px;
          z-index: 5;
        }
        .bs-brand-name {
          font-size: 18px;
          font-weight: 900;
          color: #fff;
          letter-spacing: -0.3px;
          margin-bottom: 6px;
          text-shadow: 0 2px 8px rgba(0,0,0,0.4);
          line-height: 1.1;
        }
        .bs-explore-btn {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          font-size: 11.5px;
          font-weight: 800;
          padding: 6px 13px;
          border-radius: 20px;
          box-shadow: 0 3px 10px rgba(255,111,0,0.45);
          transition: opacity 0.18s, transform 0.13s;
          font-family: 'Nunito', sans-serif;
        }
        .bs-slide:hover .bs-explore-btn {
          opacity: 0.9;
          transform: translateY(-1px);
        }
        .bs-explore-arrow {
          transition: transform 0.18s;
        }
        .bs-slide:hover .bs-explore-arrow {
          transform: translateX(3px);
        }

        /* DOTS */
        .bs-dots {
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 5px;
          margin-top: 10px;
        }
        .bs-dot {
          height: 5px;
          border-radius: 3px;
          cursor: pointer;
          transition: all 0.3s ease;
        }
        .bs-dot.active {
          width: 22px;
          background: #ff6f00;
          box-shadow: 0 0 6px rgba(255,111,0,0.5);
        }
        .bs-dot.inactive {
          width: 5px;
          background: #e8ddd5;
        }
        .bs-dot:hover { background: #ffaa5a; }

        /* THUMB STRIP */
        .bs-thumbs {
          display: flex;
          gap: 6px;
          margin-top: 10px;
          overflow-x: auto;
          scrollbar-width: none;
          padding-bottom: 2px;
        }
        .bs-thumbs::-webkit-scrollbar { display: none; }
        .bs-thumb {
          flex-shrink: 0;
          width: 38px; height: 38px;
          border-radius: 9px;
          overflow: hidden;
          border: 2px solid transparent;
          cursor: pointer;
          transition: border-color 0.2s, transform 0.15s, box-shadow 0.2s;
          background: #f5ece4;
        }
        .bs-thumb.active {
          border-color: #ff6f00;
          box-shadow: 0 0 0 2px rgba(255,111,0,0.2);
          transform: scale(1.06);
        }
        .bs-thumb:hover { border-color: #ffcc99; }
        .bs-thumb img {
          width: 100%; height: 100%;
          object-fit: cover;
          display: block;
        }
      `}</style>

      <div className="bs-wrap">
        {/* HEADER */}
        <div className="bs-header">
          <div className="bs-title-row">
            <div className="bs-title-icon">⭐</div>
            <p className="bs-title">Top Brands</p>
            <span className="bs-count">{banners.length}</span>
          </div>
        </div>

        {/* SLIDER */}
        <div className="bs-slider">
          {/* Progress bar */}
          <div key={index} className="bs-progress" />

          <AnimatePresence mode="wait">
            <motion.div
              key={index}
              className="bs-slide"
              onClick={() => navigate(banners[index].path)}
              initial={{ opacity: 0, scale: 1.04 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.75, ease: "easeInOut" }}
              style={{ position: "absolute", inset: 0 }}
            >
              <img
                src={banners[index].img}
                alt={banners[index].name}
                className="bs-img"
              />

              <div className="bs-overlay-top" />

              {/* TAG BADGE */}
              <div className="bs-top-badge">
                {banners[index].tag}
              </div>

              {/* BOTTOM CONTENT */}
              <div className="bs-bottom">
                <p className="bs-brand-name">{banners[index].name}</p>
                <div className="bs-explore-btn">
                  Explore Now
                  <span className="bs-explore-arrow">→</span>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* THUMBNAIL STRIP */}
        <div className="bs-thumbs">
          {banners.map((b, i) => (
            <div
              key={i}
              className={`bs-thumb ${i === index ? "active" : ""}`}
              onClick={() => setIndex(i)}
            >
              <img src={b.img} alt={b.name} />
            </div>
          ))}
        </div>

        {/* DOTS */}
        <div className="bs-dots">
          {banners.map((_, i) => (
            <div
              key={i}
              className={`bs-dot ${i === index ? "active" : "inactive"}`}
              onClick={() => setIndex(i)}
            />
          ))}
        </div>
      </div>
    </>
  );
};

export default BrandSlider;
