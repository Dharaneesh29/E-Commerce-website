export const navData = [
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/f15c02bfeb02d15d.png?q=100', text: 'Top Offers' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/29327f40e9c4d26b.png?q=100', text: 'Grocery' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/22fddf3c7da4c4f4.png?q=100', text: 'Mobile' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/82b3ca5fb2301045.png?q=100', text: 'Fashion' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/69c6589653afdb9a.png?q=100', text: 'Electronics' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/ee162bad964c46ae.png?q=100', text: 'Home' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/0ff199d1bd27eb98.png?q=100', text: 'Appliances' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/71050627a56b4693.png?q=100', text: 'Travel' },
    { url: 'https://rukminim1.flixcart.com/flap/128/128/image/dff3f7adcf3a90c6.png?q=100', text: 'Beauty, Toys & More' }
];

export const bannerData = [
    { id: 1, url: 'https://rukminim1.flixcart.com/flap/3376/560/image/d117a62eb5fbb8e1.jpg?q=50' },
    { id: 2, url: 'https://rukminim1.flixcart.com/flap/3376/560/image/57267a180af306fe.jpg?q=50' },
    { id: 3, url: 'https://rukminim1.flixcart.com/flap/3376/560/image/ae9966569097a8b7.jpg?q=50' },
    { id: 4, url: 'https://rukminim1.flixcart.com/flap/3376/560/image/f6202f13b6f89b03.jpg?q=50' },
    
]

// export const dealData = [
//     { 
//         id: 'product1',
//         url: 'https://rukminim1.flixcart.com/image/200/200/khf63680/cases-covers/back-cover/d/7/g/spigen-acs02256-original-imafxfgbffqaugur.jpeg?q=70', 
//         detailUrl: '',
//         title: {
//             shortTitle: 'Mobile Covers'
//         }, 
//         discount: 'Extra 10% Off', 
//         tagline: 'Deal of the day' 
//     },
//     { 
//         id: 'product2',
//         url: 'https://rukminim1.flixcart.com/image/200/200/k5lcvbk0/moisturizer-cream/9/w/g/600-body-lotion-aloe-hydration-for-normal-skin-nivea-lotion-original-imafz8jb3ftt8gf9.jpeg?q=70', 
//         title: {
//             shortTitle: 'Skin & Hair Care'
//         },
//         discount: 'From 99+5% Off', 
//         tagline: 'Shampoos, Face Washes & More' 
//     },
//     { 
//         id: 'product3',
//         url: 'https://rukminim1.flixcart.com/flap/200/200/image/74bc985c62f19245.jpeg?q=70', 
//         title: {
//             shortTitle: 'Skybags & Safari'
//         }, 
//         discount: 'Upto 70% Off', 
//         tagline: 'Deal of the Day' 
//     },
//     { 
//         id: 'product4',
//         url: 'https://rukminim1.flixcart.com/image/300/300/kll7bm80/smartwatch/c/1/n/43-mo-sw-sense-500-android-ios-molife-original-imagyzyycnpujyjh.jpeg?q=70', 
//         detailUrl: 'https://rukminim1.flixcart.com/image/416/416/kll7bm80/smartwatch/c/1/n/43-mo-sw-sense-500-android-ios-molife-original-imagyzyycnpujyjh.jpeg?q=70',
//         title: {
//             shortTitle: 'Smart Watches',
//             longTitle: 'Molife Sense 500 Smartwatch  (Black Strap, Freesize)',
//         }, 
//         price: {
//             mrp: 6999,
//             cost: 4049,
//             discount: '42%'
//         },
//         description: 'The Molife Sense 500, a brilliant smartwatch with a beautiful large display. Say hello to the infinity 1.7-inch display with 2.5D curved edges. Thanks to seamless Bluetooth 5.0 connectivity, you wont have to keep waiting. Bring a change to your outfit every day with changeable straps. A splash of color every day keeps the boredom away.',
//         discount: 'Grab Now', 
//         tagline: 'Best Seller' 
//     },
//     { 
//         id: 'product5',
//         url: 'https://rukminim1.flixcart.com/flap/150/150/image/b616a7aa607d3be0.jpg?q=70', 
//         title: {
//             shortTitle: 'Sports & Fitness Essentials'
//         }, 
//         discount: 'Upto 80% Off', 
//         tagline: 'Ab Exerciser, Yoga & more' 
//     }
// ];

// export const furnitureData = [
//     { 
//         url: 'https://rukminim1.flixcart.com/image/300/300/ke7ff680/hammock-swing/j/f/u/q3-jkaf-y3l0-furniture-kart-original-imafux96kpy7grch.jpeg?q=70', 
//         title: {
//             shortTitle: 'Hammock And Swings'
//         }, 
//         discount: 'From ₹199', 
//         tagline: 'Trendy Collection' 
//     },
//     { 
//         url: 'https://rukminim1.flixcart.com/image/300/300/bean-bag/h/v/b/f8-the-furniture-store-xxxl-original-imae65d3wg7qzpkn.jpeg?q=70', 
//         title: {
//             shortTitle: 'Bean Bag Covers'
//         }, 
//         discount: 'Min 80% Off', 
//         tagline: 'XL, XXL & More' 
//     },
//     { 
//         url: 'https://rukminim1.flixcart.com/image/300/300/jlcmavk0/aquarium-tank/s/4/5/usb-desktop-aquarium-with-running-water-calendar-temperature-and-original-imaf8hv4nkv55gx8.jpeg?q=70', 
//         title: {
//             shortTitle: 'Aquarium Tank'
//         }, 
//         discount: 'From ₹299', 
//         tagline: 'Flat, Round, Cube & More' 
//     },
//     { 
//         url: 'https://rukminim1.flixcart.com/image/300/300/jffpoy80/office-study-chair/v/v/z/pp-am-5001cb-apex-original-imaf3u8rbr5cdycv.jpeg?q=70', 
//         title: {
//             shortTitle: 'Office & Study Chairs'
//         }, 
//         discount: 'Min 50% Off', 
//         tagline: 'Fabric & Leatherette' 
//     },
//     { 
//         url: 'https://rukminim1.flixcart.com/image/300/300/jvcp9jk0/recliner/z/w/x/brown-top-grain-leather-sf7018011-1-royaloak-original-imafg9s9hh9vzpf3.jpeg?q=70', 
//         title: {
//             shortTitle: 'Recliner'
//         }, 
//         discount: 'From ₹4999', 
//         tagline: 'Bantia, RoyalOak & More' 
//     },
//     { 
//         url: 'https://rukminim1.flixcart.com/image/300/300/jlqwpe80-1/tv-entertainment-unit/d/t/f/particle-board-holland-tv-unit-black-forzza-black-original-imaf8t5ybywcdtys.jpeg?q=70', 
//         title: {
//             shortTitle: 'Tv Units'
//         }, 
//         discount: 'From ₹2100', 
//         tagline: 'Forzza, Zuari & more' 
//     },
//     { 
//         url: 'https://rukminim1.flixcart.com/image/300/300/inflatable-sofa/6/j/s/wsb031a-velvet-wds-original-imaeaphzbkgrz3xp.jpeg?q=70', 
//         title: {
//             shortTitle: 'Inflatable Sofas'
//         }, 
//         discount: 'Min 50% Off', 
//         tagline: 'Furn Central & more' 
//     },
// ];

export const categoryProducts = [

  // 🎯 TOP OFFERS
  { id: 1, category: "top-offers", name: "Noise Smartwatch", brand: "Noise", price: 1499, rating: 4.3,stock:15, image: "https://m.media-amazon.com/images/I/61epn29QG0L._SL1500_.jpg" },
  { id:2, category: "top-offers", name: "Boat Earbuds", brand: "boAt", price: 999, rating: 4.2, stock:18, image: "https://m.media-amazon.com/images/I/61KNJav3S9L._SL1500_.jpg" },
  { id:3, category: "top-offers", name: "Men Casual Shoes", brand: "Sparx", price: 899, rating: 4.1,stock:20, image: "https://m.media-amazon.com/images/I/51xCyO2HdjL._SX575_.jpg" },
  { id:4,category: "top-offers", name: "Backpack", brand: "Skybags", price: 1299, rating: 4.4,stock:25, image: "https://m.media-amazon.com/images/I/61IOPtBozeL._AC_UL320_.jpg" },
  { id:5, category: "top-offers", name: "Power Bank 20000mAh", brand: "Mi", price: 1499, rating: 4.5,stock:30, image: "https://m.media-amazon.com/images/I/71lVwl3q-kL._SL1500_.jpg" },

  // 🛒 GROCERY
  { id:6, category: "grocery", name: "Aashirvaad Atta 10kg", brand: "Aashirvaad", price: 549, rating: 4.5,stock:35, image: "https://m.media-amazon.com/images/I/51QtHfmr1NL._AC_SR250,250_QL65_.jpg" },
  { id:7, category: "grocery", name: "Fortune Oil 1L", brand: "Fortune", price: 149, rating: 4.4,stock:45, image: "https://m.media-amazon.com/images/I/61RXuvswlmL._AC_UL320_.jpg" },
  { id:8, category: "grocery", name: "Tata Salt 1kg", brand: "Tata", price: 28, rating: 4.6, stock:50,image: "https://m.media-amazon.com/images/I/618W924RcmL._AC_UL320_.jpg" },
  { id:9, category: "grocery", name: "Maggi Pack", brand: "Nestle", price: 168, rating: 4.7, stock:55,image: "https://m.media-amazon.com/images/I/71lXtu5Z8EL._AC_UL320_.jpg" },
  { id:10, category: "grocery", name: "Surf Excel 1kg", brand: "Surf Excel", price: 220, rating: 4.5,stock:60, image: "https://m.media-amazon.com/images/I/619HRPW3elL._AC_UL320_.jpg" },

  // 📱 MOBILE
  { id:11, category: "mobile", name: "iPhone 13", brand: "Apple", price: 59999, rating: 4.8,stock:25, image: "https://m.media-amazon.com/images/I/61-r9zOKBCL._SL1500_.jpg" },
  { id:12, category: "mobile", name: "Samsung S21 FE", brand: "Samsung", price: 34999, rating: 4.5,stock:48, image: "https://m.media-amazon.com/images/I/71V--WZVUIL._SL1500_.jpg" },
  { id:13, category: "mobile", name: "Redmi Note 12", brand: "Redmi", price: 22999, rating: 4.3, stock:50,image: "https://m.media-amazon.com/images/I/71AvQd3VzqL._SL1500_.jpg" },
  { id:14, category: "mobile", name: "Realme Narzo 60", brand: "Realme", price: 17999, rating: 4.2,stock:67, image: "https://m.media-amazon.com/images/I/71dEY4Neo3L._SL1500_.jpg" },
  { id:15, category: "mobile", name: "OnePlus Nord CE 3", brand: "OnePlus", price: 26999, rating: 4.4,stock:70, image: "https://m.media-amazon.com/images/I/71V--WZVUIL._SL1500_.jpg" },

  // 👕 FASHION
  { id:16, category: "fashion", name: "Men Shirt", brand: "Allen Solly", price: 999, rating: 4.3,stock:80, image: "https://m.media-amazon.com/images/I/61h4UqF1PLL._UY879_.jpg" },
  { id:17,category: "fashion", name: "Women Kurti", brand: "Biba", price: 1299, rating: 4.4, stock:38,image: "https://m.media-amazon.com/images/I/71jz4j1R0XL._UY879_.jpg" },
  { id:18, category: "fashion", name: "Running Shoes", brand: "Nike", price: 2999, rating: 4.6, stock:56,image: "https://m.media-amazon.com/images/I/71y5y5F7bXL._UY695_.jpg" },
  { id:19, category: "fashion", name: "Men Jeans", brand: "Levis", price: 1999, rating: 4.5, stock:80,image: "https://m.media-amazon.com/images/I/61a5Z4X6jXL._UX679_.jpg" },
  { id:20, category: "fashion", name: "Handbag", brand: "Lavie", price: 1599, rating: 4.2, stock:85,image: "https://m.media-amazon.com/images/I/71kq8q4ZzVL._UY695_.jpg" },

  // 💻 ELECTRONICS
  { id:21 , category: "electronics", name: "HP Laptop i5", brand: "HP", price: 54999, rating: 4.5, stock:90,image: "https://m.media-amazon.com/images/I/71f5Eu5lJSL._SL1500_.jpg" },
  { id: 22, category: "electronics", name: "Boat Headphones", brand: "boAt", price: 1999, rating: 4.3, stock:100, image: "https://m.media-amazon.com/images/I/61KNJav3S9L._SL1500_.jpg" },
  { id: 23, category: "electronics", name: "Sony LED TV", brand: "Sony", price: 34999, rating: 4.6,stock:50, image: "https://m.media-amazon.com/images/I/81h8Kp2ZpFL._SL1500_.jpg" },
  { id: 24, category: "electronics", name: "Mouse", brand: "Logitech", price: 699, rating: 4.4, stock:30,image: "https://m.media-amazon.com/images/I/61LtuGzXeaL._SL1500_.jpg" },
  { id: 25, category: "electronics", name: "JBL Speaker", brand: "JBL", price: 2999, rating: 4.5, stock:70,image: "https://m.media-amazon.com/images/I/71m5f6hXQpL._SL1500_.jpg" },

  // 🏠 HOME
  { id: 26, category: "home", name: "Sofa Set", brand: "Home Centre", price: 15999, rating: 4.4, stock:39, image: "https://m.media-amazon.com/images/I/71zJt3YQ9VL._SL1500_.jpg" },
  { id: 27, category: "home", name: "Dining Table", brand: "Ikea", price: 8999, rating: 4.3, stock:95,image: "https://m.media-amazon.com/images/I/71xWk1P0RKL._SL1500_.jpg" },
  { id: 28, category: "home", name: "Wall Clock", brand: "Ajanta", price: 499, rating: 4.2, stock:47,image: "https://m.media-amazon.com/images/I/61+Q6Rh3OQL._SL1500_.jpg" },
  { id: 29, category: "home", name: "Bed Sheet", brand: "Bombay Dyeing", price: 999, rating: 4.3, stock:45,image: "https://m.media-amazon.com/images/I/81YvY4J7JPL._SL1500_.jpg" },
  { id: 30, category: "home", name: "Curtains", brand: "Spaces", price: 799, rating: 4.1,stock:29, image: "https://m.media-amazon.com/images/I/71X1VhS1uPL._SL1500_.jpg" },

  // ⚡ APPLIANCES
  { id: 31, category: "appliances", name: "Mixer Grinder", brand: "Prestige", price: 2999, rating: 4.4, stock:75,image: "https://m.media-amazon.com/images/I/71l3G9mYy1L._SL1500_.jpg" },
  { id: 32, category: "appliances", name: "Microwave Oven", brand: "LG", price: 8999, rating: 4.5,stock:82, image: "https://m.media-amazon.com/images/I/71h8c3xH0OL._SL1500_.jpg" },
  { id: 33, category: "appliances", name: "Air Conditioner", brand: "Voltas", price: 34999, rating: 4.3,stock:45, image: "https://m.media-amazon.com/images/I/71U2+7fZpLL._SL1500_.jpg" },
  { id: 34 , category: "appliances", name: "Refrigerator", brand: "Samsung", price: 25999, rating: 4.6, stock:66,image: "https://m.media-amazon.com/images/I/61Y30DpqRVL._SL1500_.jpg" },
  { id: 35, category: "appliances", name: "Washing Machine", brand: "IFB", price: 21999, rating: 4.4, stock:71,image: "https://m.media-amazon.com/images/I/71x6Z7y1aPL._SL1500_.jpg" },

  // ✈️ TRAVEL
  { id: 36, category: "travel", name: "Trolley Bag", brand: "Safari", price: 2499, rating: 4.4,stock:92, image: "https://m.media-amazon.com/images/I/81N4aR+4YhL._SL1500_.jpg" },
  { id: 37, category: "travel", name: "Travel Backpack", brand: "Wildcraft", price: 1999, rating: 4.5, stock:35,image: "https://m.media-amazon.com/images/I/81Zt42ioCgL._SL1500_.jpg" },
  { id: 38, category: "travel", name: "Neck Pillow", brand: "AmazonBasics", price: 699, rating: 4.2, stock:90,image: "https://m.media-amazon.com/images/I/61s6g8bWlGL._SL1500_.jpg" },
  { id: 39, category: "travel", name: "Travel Organizer", brand: "F Gear", price: 499, rating: 4.3,stock:55, image: "https://m.media-amazon.com/images/I/71x3Qm8sJXL._SL1500_.jpg" },
  { id: 40, category: "travel", name: "Duffel Bag", brand: "Puma", price: 1799, rating: 4.4, stock:91,image: "https://m.media-amazon.com/images/I/71g7tZK+YlL._SL1500_.jpg" },

  // 💄 BEAUTY
  { id: 41,category: "beauty", name: "Face Wash", brand: "Himalaya", price: 199, rating: 4.5,stock:99, image: "https://m.media-amazon.com/images/I/61H2xZL5yCL._SL1500_.jpg" },
  { id: 42,category: "beauty", name: "Lipstick", brand: "Lakme", price: 399, rating: 4.4, stock:45,image: "https://m.media-amazon.com/images/I/61uY5t5GvAL._SL1500_.jpg" },
  { id: 43,category: "beauty", name: "Perfume", brand: "Fogg", price: 499, rating: 4.3, stock:55,image: "https://m.media-amazon.com/images/I/61+9l5n3oPL._SL1500_.jpg" },
  { id: 44,category: "beauty", name: "Hair Oil", brand: "Parachute", price: 299, rating: 4.6, stock:60,image: "https://m.media-amazon.com/images/I/71dZbXJwWOL._SL1500_.jpg" },
  { id: 45,category: "beauty", name: "Shampoo", brand: "Dove", price: 249, rating: 4.5, stock:90,image: "https://m.media-amazon.com/images/I/61n9F0YxkIL._SL1500_.jpg" },

  // 🧸 TOYS
  { id: 46, category: "toys", name: "Teddy Bear", brand: "Fun Toys", price: 599, rating: 4.5,stock:37, image: "https://m.media-amazon.com/images/I/81R7xY7rZWL._SL1500_.jpg" },
  { id: 47, category: "toys", name: "Remote Car", brand: "Hot Wheels", price: 1299, rating: 4.4, stock:23,image: "https://m.media-amazon.com/images/I/71+z9Z5u2JL._SL1500_.jpg" },
  { id: 48, category: "toys", name: "Building Blocks", brand: "Lego", price: 1999, rating: 4.8, stock:70,image: "https://m.media-amazon.com/images/I/81xQ9gP8xML._SL1500_.jpg" },
  { id: 49, category: "toys", name: "Doll Set", brand: "Barbie", price: 1499, rating: 4.6,stock:39, image: "https://m.media-amazon.com/images/I/71d4F8pT7EL._SL1500_.jpg" },
  { id: 50, category: "toys", name: "Puzzle Game", brand: "Funskool", price: 499, rating: 4.3, stock:88, image: "https://m.media-amazon.com/images/I/71qjzX2F1kL._SL1500_.jpg" }

];