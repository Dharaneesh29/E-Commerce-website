import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";

// ── Auth ──────────────────────────────────────────────────────
import Register        from "./pages/Register";
import Login           from "./pages/Login";
import Landing         from "./pages/Landing";

// ── Admin Layout ──────────────────────────────────────────────
import Sidebar         from "./components/sidebar";

// ── Admin Pages ───────────────────────────────────────────────
import Dashboard       from "./pages/Dashboard";
import Products        from "./pages/products";
import AddProduct      from "./pages/AddProduct";
import EditProduct     from "./pages/EditProduct";
import ProductManagement from "./pages/ProductManagement";
import AdminUsers      from "./pages/UserMangement";
import OrderManagement from "./pages/OrderManagement";
import AdminCoupons    from "./pages/AdminCoupons";
import NotificationsPage from "./pages/NotificationsPage";

// ── User Layout ───────────────────────────────────────────────
import UserLayout      from "./components/UserLayout";

// ── User Pages ────────────────────────────────────────────────
import Home            from "./pages/Home";
import Cart            from "./pages/Cart";
import ProductDetail from "./pages/ProductDetail";
import Orders          from "./pages/Orders";
import AdminLayout from "./components/AdminLayout";
import Profile         from "./pages/Profile";
import AddAddress      from "./pages/AddAddress";
// import Category        from "./pages/Category";
import Checkout        from "./pages/Checkout";
import Shipping        from "./pages/Shipping";
import Payment         from "./pages/Payment";
import Success         from "./pages/Success";
import CouponsPage     from "./pages/CouponsPage";
import AdminProfile from "./pages/AdminProfile";
import AdminRegister from "./pages/adminRegister";
import ReportsAnalytics from "./pages/ReportsAnalytics";
import Wishlist from "./pages/wishlistPage";
import OrderDetails from "./pages/OrderDetailPage";
import BrandPage  from "./pages/BrandPage";
import CategoryPage from "./pages/CategoryPage";
import AdminMembershipPlans from "./pages/AdminMembershipPlans";
import AdminMembers from "./pages/AdminMembers";
import EcommerceChatbot from './components/EcommerceChatbot';



function App() {
  return (
    <Router>
      <Toaster position="top-center" reverseOrder={false} />
      <Routes>
       

        {/* ── Public routes ── */}
        <Route path="/"                  element={<Landing />} />
        <Route path="/users/register"    element={<Register />} />
        <Route path="/users/login"       element={<Login />} />
          <Route path="/admin/register"  element={<AdminRegister/>}/>

        {/* ── Admin routes — ALL wrapped in Sidebar (renders once) ── */}
        <Route element={<Sidebar />}>
          <Route path="/dashboard"         element={<Dashboard />} />
          <Route path="/products"          element={<Products />} />
          <Route path="/add-product"       element={<AddProduct />} />
          <Route path="/edit-product/:id"  element={<EditProduct />} />
          <Route path="/user-management"   element={<AdminUsers />} />
          <Route path="/orders"            element={<OrderManagement />} />
          <Route path="/admin/coupons"     element={<AdminCoupons />} />
          <Route path="/notifications"     element={<NotificationsPage />} />
          <Route path="/admin/profile"  element={<AdminProfile/>}/>
          <Route path="/reports" element={<ReportsAnalytics/>}/>
          <Route path="/admin/membership-plans" element={<AdminMembershipPlans />} />
          <Route path="/admin/members" element={<AdminMembers />} />
        </Route>

        {/* ── User routes ── */}
        <Route path="/home"              element={<UserLayout><Home /></UserLayout>} />
        <Route path="/product/:id"       element={<UserLayout><ProductDetail /></UserLayout>} />
        <Route path="/category/:name"    element={<UserLayout><CategoryPage /></UserLayout>} />
        <Route path="/cart"              element={<Cart />} />
        <Route path="/profile"           element={<Profile />} />
        <Route path="/address/add" element={<AddAddress />} />
        <Route path="/add-address"       element={<AddAddress />} />
        <Route path="/checkout"          element={<Checkout />} />
        <Route path="/shipping"          element={<Shipping />} />
        <Route path="/payment"           element={<Payment />} />
        <Route path="/success"           element={<Success />} />
        <Route path="/coupons"           element={<CouponsPage />} />
        <Route path="/product/:id" element={<UserLayout><ProductDetail/></UserLayout>}/>
        <Route path="/wishlist" element={<UserLayout><Wishlist/></UserLayout>}/>
        <Route path="/order/:id"  element={<OrderDetails/>}/>
        <Route path="/brand/:brand"  element={<BrandPage/>}/>
        <Route path="/products" element={<AdminLayout><ProductManagement /></AdminLayout>}/>
        <Route path="/orders/:id" element={<OrderDetails />} />


      </Routes>
      <EcommerceChatbot/>
    </Router>

    
        
        
  );
}

export default App;
