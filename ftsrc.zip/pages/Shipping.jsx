// import React, { useEffect, useState, useContext } from "react";
// import StepIndicator from "../components/StepIndicator";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import { ShopContext } from "../context/ShopContext";
 
// const Shipping = () => {
//   const [addresses, setAddresses] = useState([]);
//   const [selected, setSelected] = useState(null);
//   const [showList, setShowList] = useState(false);
 
//   const { cart } = useContext(ShopContext);
//   const navigate = useNavigate();
 
//   // ✅ Total calculation
//   const total = cart.reduce(
//     (acc, item) => acc + item.product.price * item.qty,
//     0
//   );

//   const getDeliveryDate = () => {
//   const today = new Date();
 
//   // random between 3 to 5 days
//   const days = Math.floor(Math.random() * 3) + 3;
 
//   today.setDate(today.getDate() + days);
 
//   const options = { day: "numeric", month: "long" };
//   return today.toLocaleDateString("en-IN", options);
// };
 
// const date=getDeliveryDate();
// sessionStorage.setItem("deliveryDate",date)
//   // ✅ Fetch addresses
//   useEffect(() => {
//     const fetchAddresses = async () => {
//       const token = sessionStorage.getItem("token");
 
//       const res = await axios.get("http://localhost:5000/api/address", {
//         headers: { Authorization: `Bearer ${token}` },
//       });
 
//       setAddresses(res.data);
//       setSelected(res.data[0]);
//       sessionStorage.setItem("selectedAddress",res.data[0]._id)
//     };
 
//     fetchAddresses();
//   }, []);
 
//   return (
//     <div style={{ padding: "20px", background: "#f5f5f5", minHeight: "100vh" }}>
      
//       {/* STEP INDICATOR */}
//       <StepIndicator step={1} />
 
//       <div style={{ display: "flex", gap: "20px", marginTop: "20px" }}>
        
//         {/* LEFT SIDE */}
//         <div style={{ flex: 2 }}>
 
//           <h2>Delivery Address</h2>
//           <p style={{ color: "gray" }}>
//             We will deliver your order to this address
//           </p>
 
//           {/* ✅ Selected Address */}
//           {!showList && selected && (
//             <div style={cardStyle}>
//               <h4>{selected.name}</h4>
//               <p>{selected.phone}</p>
//               <p>{selected.address}</p>
//               <p>{selected.city} - {selected.pincode}</p>
 
//               <p
//                 onClick={() => setShowList(true)}
//                 style={changeBtn}
//               >
//                 Change Address
//               </p>
//             </div>
//           )}
 
//           {/* 🔥 Address List */}
//           {showList && (
//             <div>
//               <h3>Select Address</h3>
 
//               {addresses.map((addr) => (
//                 <div
//                   key={addr._id}
//                   onClick={() => {setSelected(addr);
//                     sessionStorage.setItem("selectedAddress",addr._id);
//                   }}
//                   style={{
//                     ...cardStyle,
//                     border:
//                       selected?._id === addr._id
//                         ? "2px solid #ff6f00"
//                         : "1px solid #ddd",
//                     cursor: "pointer"
//                   }}
//                 >
//                   <h4>{addr.name}</h4>
//                   <p>{addr.phone}</p>
//                   <p>{addr.address}</p>
//                   <p>{addr.city} - {addr.pincode}</p>
 
//                   {selected?._id === addr._id && (
//                     <p style={{ color: "#ff6f00" }}>✔ Selected</p>
//                   )}
//                 </div>
//               ))}
 
//               <button
//                 onClick={() => setShowList(false)}
//                 style={btnPrimary}
//               >
//                 CONFIRM ADDRESS
//               </button>
//             </div>
//           )}
 
//           {/* 🚚 Expected Delivery */}
//           <div style={{ marginTop: "30px" }}>
//             <h3>Expected Delivery</h3>
 
//             {cart.map((item) => (
//               <div
//                 key={item._id}
//                 style={{
//                   display: "flex",
//                   gap: "10px",
//                   marginTop: "10px",
//                   background: "#fff",
//                   padding: "10px",
//                   borderRadius: "8px",
//                   alignItems: "center"
//                 }}
//               >
//                 <img
//                   src={
//                     item.product.image?.startsWith("http")
//                       ? item.product.image
//                       : `http://localhost:5000${item.product.image}`
//                   }
//                   alt=""
//                   style={{
//                     width: "50px",
//                     height: "50px",
//                     objectFit: "contain"
//                   }}
//                 />
 
//                 <div>
//                   <p>{item.product.name}</p>
//                   <p style={{ color: "gray" }}>
//                     Qty: {item.qty}
//                   </p>
//                   <p style={{ color: "#555" }}>
//                     Delivery by {date} 🚚
//                   </p>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
 
//         {/* RIGHT SIDE */}
//         <div style={summaryStyle}>
//           <h3>Order Details</h3>
 
//           <div style={{ marginTop: "10px" }}>
//             {cart.map((item) => (
//               <div
//                 key={item._id}
//                 style={{
//                   display: "flex",
//                   justifyContent: "space-between",
//                   marginBottom: "8px",
//                   fontSize: "14px"
//                 }}
//               >
//                 <span>
//                   {item.product.name} × {item.qty}
//                 </span>
//                 <span>
//                   ₹{item.product.price * item.qty}
//                 </span>
//               </div>
//             ))}
//           </div>
 
//           <hr />
 
//           <p style={{ marginTop: "10px" }}>Delivery: Free</p>
 
//           <h3 style={{ marginTop: "10px" }}>
//             Total: ₹{total}
//           </h3>
 
//           <p style={{ color: "green", fontSize: "13px" }}>
//             ✔ Cash on delivery available
//           </p>
 
//           <button
//             onClick={() => navigate("/payment")}
//             style={btnPrimary}
//           >
//             PROCEED TO PAYMENT
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };
 
 
// // 🎨 Styles
// const cardStyle = {
//   background: "#fff",
//   padding: "20px",
//   borderRadius: "10px",
//   marginTop: "15px",
//   boxShadow: "0 2px 6px rgba(0,0,0,0.05)"
// };
 
// const summaryStyle = {
//   flex: 1,
//   background: "#fff",
//   padding: "20px",
//   borderRadius: "10px",
//   height: "fit-content",
//   position: "sticky",
//   top: "20px"
// };
 
// const btnPrimary = {
//   marginTop: "15px",
//   width: "100%",
//   padding: "12px",
//   background: "#ff6f00",
//   color: "#fff",
//   border: "none",
//   borderRadius: "8px",
//   fontWeight: "bold",
//   cursor: "pointer"
// };
 
// const changeBtn = {
//   marginTop: "10px",
//   color: "#007185",
//   cursor: "pointer",
//   fontWeight: "500"
// };
 
// export default Shipping;


import React, { useEffect, useState, useContext } from "react";
import StepIndicator from "../components/StepIndicator";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { ShopContext } from "../context/ShopContext";

const Shipping = () => {
  const [addresses, setAddresses] = useState([]);
  const [selected, setSelected] = useState(null);
  const [showList, setShowList] = useState(false);

  const { cart } = useContext(ShopContext);
  const navigate = useNavigate();

  // ✅ Total calculation
  const total = cart.reduce(
    (acc, item) => acc + (item.product?.price || 0) * (item.qty ||0),
    0
  );

  const deliveryFee = total < 500 ? Math.floor(total * 0.05) : 0;


  const getDeliveryDate = () => {
    const existing = sessionStorage.getItem("deliveryDate");

    // ✅ if already exists, don't change
    if (existing) return existing;

    const today = new Date();

    const days = Math.floor(Math.random() * 3) + 3;
    today.setDate(today.getDate() + days);

    const options = { day: "numeric", month: "long" };
    const date = today.toLocaleDateString("en-IN", options);

    sessionStorage.setItem("deliveryDate", date);

    return date;
  };

  const deliveryDate = getDeliveryDate();

  // ✅ Fetch addresses
 useEffect(() => {
  const fetchAddresses = async () => {
    const token = JSON.parse(sessionStorage.getItem("userInfo") || "null")?.token;

    const res = await axios.get("http://localhost:5000/api/address", {
      headers: { Authorization: `Bearer ${token}` },
    });

    setAddresses(res.data);
    setSelected(res.data[0] || null);
    if(res.data[0]){
      sessionStorage.setItem("selectedAddress", res.data[0]._id);
    }
  };

  fetchAddresses();
},[]);



  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        .shipping-root {
          font-family: 'Nunito', sans-serif;
          background: #fdf5ee;
          min-height: 100vh;
          padding: 28px 20px 60px;
        }

        .shipping-layout {
          display: flex;
          gap: 24px;
          margin-top: 28px;
          align-items: flex-start;
        }

        .shipping-left { flex: 2; }
        
        /* ── Section header ── */
        .section-title {
          font-size: 28px;
          font-weight: 800;
          color: #1a1a1a;
          letter-spacing: -0.4px;
          margin-bottom: 2px;
        }
        .section-sub {
          font-size: 14px;
          color: #999;
          margin-top: 6px;
        }

        /* ── Address card ── */
        .addr-card {
          background: #fff;
          border: 1.5px solid #ffe0c2;
          border-radius: 16px;
          padding: 22px 24px;
          margin-top: 18px;
          box-shadow: 0 4px 18px rgba(255,111,0,0.07);
          transition: border-color 0.2s;
          position: relative;
          overflow: hidden;
        }
        .addr-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0;
          width: 4px;
          height: 100%;
          background: linear-gradient(180deg, #ff6f00, #ffaa5a);
          border-radius: 4px 0 0 4px;
        }
        .addr-card h4 {
          font-size: 15px;
          font-weight: 800;
          color: #1a1a1a;
          margin-bottom: 6px;
        }
        .addr-card p {
          font-size: 13.5px;
          color: #555;
          line-height: 1.7;
        }

        .addr-card-selectable {
          cursor: pointer;
          border: 1.5px solid #e8e8e8;
        }
        .addr-card-selectable:hover {
          border-color: #ffaa5a;
          box-shadow: 0 4px 20px rgba(255,111,0,0.1);
        }
        .addr-card-active {
          border: 2px solid #ff6f00 !important;
          background: #fff8f2;
        }
        .addr-card-active::before {
          background: linear-gradient(180deg, #ff6f00, #ff8c00);
        }

        .selected-tag {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          margin-top: 10px;
          font-size: 12px;
          font-weight: 700;
          color: #ff6f00;
          background: #fff3e6;
          padding: 4px 10px;
          border-radius: 20px;
        }

        .change-btn {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          margin-top: 14px;
          font-size: 13px;
          font-weight: 700;
          color: #ff6f00;
          cursor: pointer;
          border: 1.5px solid #ff6f00;
          padding: 6px 14px;
          border-radius: 8px;
          background: transparent;
          transition: background 0.2s, color 0.2s;
        }
        .change-btn:hover {
          background: #ff6f00;
          color: #fff;
        }

        /* ── Address list header ── */
        .list-header {
          font-size: 16px;
          font-weight: 800;
          color: #1a1a1a;
          margin-bottom: 4px;
        }

        /* ── Confirm button ── */
        .btn-primary {
          margin-top: 18px;
          width: 100%;
          padding: 14px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          letter-spacing: 0.5px;
          cursor: pointer;
          transition: opacity 0.2s, transform 0.1s;
          box-shadow: 0 4px 14px rgba(255,111,0,0.35);
          font-family: 'Nunito', sans-serif;
        }
        .btn-primary:hover { opacity: 0.92; transform: translateY(-1px); }
        .btn-primary:active { transform: translateY(0); }

        /* ── Delivery section ── */
        .delivery-section { margin-top: 32px; }
        .delivery-section h3 {
          font-size: 17px;
          font-weight: 800;
          color: #1a1a1a;
          margin-bottom: 12px;
        }

        .delivery-item {
          display: flex;
          gap: 14px;
          margin-top: 12px;
          background: #fff;
          padding: 14px 16px;
          border-radius: 14px;
          align-items: center;
          border: 1.5px solid #f0e8e0;
          box-shadow: 0 2px 10px rgba(0,0,0,0.04);
          transition: box-shadow 0.2s;
        }
        .delivery-item:hover { box-shadow: 0 4px 16px rgba(255,111,0,0.1); }

        .delivery-img-wrap {
          width: 56px;
          height: 56px;
          border-radius: 10px;
          background: #fff8f2;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          border: 1px solid #ffe5cc;
          overflow: hidden;
        }
        .delivery-img-wrap img {
          width: 48px;
          height: 48px;
          object-fit: contain;
        }

        .delivery-info p:first-child {
          font-size: 14px;
          font-weight: 700;
          color: #1a1a1a;
          margin-bottom: 3px;
        }
        .delivery-info .qty-label {
          font-size: 12.5px;
          color: #888;
          margin-bottom: 2px;
        }
        .delivery-info .date-label {
          font-size: 12.5px;
          color: #ff6f00;
          font-weight: 700;
        }

        /* ── Right Summary ── */
        .summary-box {
          flex: 1;
          background: #fff;
          border-radius: 18px;
          padding: 24px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 6px 24px rgba(255,111,0,0.09);
          position: sticky;
          top: 20px;
        }
        .summary-box h3 {
          font-size: 18px;
          font-weight: 800;
          color: #1a1a1a;
          border-bottom: 2px dashed #ffe0c2;
          padding-bottom: 14px;
          margin-bottom: 14px;
        }

        .summary-line {
          display: flex;
          justify-content: space-between;
          margin-bottom: 10px;
          font-size: 13.5px;
          color: #444;
        }
        .summary-line span:last-child { font-weight: 700; color: #222; }

        .summary-divider {
          border: none;
          border-top: 1.5px dashed #ffe0c2;
          margin: 14px 0;
        }

        .delivery-free {
          font-size: 13px;
          color: #777;
          display: flex;
          justify-content: space-between;
          margin-bottom: 6px;
        }
        .delivery-free span:last-child {
          color: #2e9e5b;
          font-weight: 700;
        }

        .total-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: 10px;
          background: #fff8f2;
          border-radius: 10px;
          padding: 12px 14px;
          border: 1.5px solid #ffe0c2;
        }
        .total-row span:first-child {
          font-size: 14px;
          font-weight: 700;
          color: #555;
        }
        .total-row span:last-child {
          font-size: 20px;
          font-weight: 800;
          color: #ff6f00;
        }

        .cod-badge {
          margin-top: 14px;
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12.5px;
          font-weight: 700;
          color: #2e9e5b;
          background: #edfaf4;
          padding: 8px 12px;
          border-radius: 8px;
          border: 1px solid #b6e9cf;
        }

        @media (max-width: 768px) {
          .shipping-layout { flex-direction: column; }
          .summary-box { position: static; }
        }
      `}</style>

      <div className="shipping-root">
        {/* STEP INDICATOR */}
        <StepIndicator step={1} />

        <div className="shipping-layout">
          {/* LEFT SIDE */}
          <div className="shipping-left">
            <p className="section-title">Delivery Address</p>
            <p className="section-sub">We will deliver your order to this address</p>

            {/* ✅ Selected Address */}
            {!showList && selected && (
              <div className="addr-card">
                <h4>{selected.name}</h4>
                <p>{selected.phone}</p>
                <p>{selected.address}</p>
                <p>{selected.city} — {selected.pincode}</p>
                <span
                  className="change-btn"
                  onClick={() => setShowList(true)}
                >
                  ✎ Change Address
                </span>
              </div>
            )}

            {/* 🔥 Address List */}
            {showList && (
              <div style={{ marginTop: "18px" }}>
                <p className="list-header">Select a Delivery Address</p>
                <p className="section-sub" style={{ marginBottom: "6px" }}>Choose where we should deliver</p>

                {addresses.map((addr) => (
                  <div
                    key={addr._id}
                    onClick={() => {
                      setSelected(addr);
                      sessionStorage.setItem("selectedAddress", addr._id);
                    }}
                    className={`addr-card addr-card-selectable ${selected?._id === addr._id ? "addr-card-active" : ""}`}
                  >
                    <h4>{addr.name}</h4>
                    <p>{addr.phone}</p>
                    <p>{addr.address}</p>
                    <p>{addr.city} — {addr.pincode}</p>

                    {selected?._id === addr._id && (
                      <span className="selected-tag">✔ Selected</span>
                    )}
                  </div>
                ))}

                <button
                  onClick={() => setShowList(false)}
                  className="btn-primary"
                >
                  ✔ CONFIRM ADDRESS
                </button>
              </div>
            )}

            {/* 🚚 Expected Delivery */}
            <div className="delivery-section">
              <h3>Expected Delivery</h3>

              {cart.map((item) => (
                <div key={item._id} className="delivery-item">
                  <div className="delivery-img-wrap">
                    <img
                      src={
                        item.product?.images?.length > 0
                          ? item.product.images[0].startsWith("http")
                            ? item.product.images[0]
                            : `http://localhost:5000${item.product.images[0]}`
                          : item.product?.image
                          ? item.product.image.startsWith("http")
                            ? item.product.image
                            : `http://localhost:5000${item.product.image}`
                          : "/placeholder.png"
                      }
                      alt=""
                    />
                  </div>

                  <div className="delivery-info">
                    <p>{item.product.name}</p>
                    <p className="qty-label">Qty: {item.qty}</p>
                    <p className="date-label">🚚 Delivery by {deliveryDate}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT SIDE */}
          <div className="summary-box">
            <h3>Order Summary</h3>

            {cart.map((item) => (
              <div key={item._id} className="summary-line">
                <span>{item.product.name} × {item.qty}</span>
                <span>₹{item.product.price * item.qty}</span>
              </div>
            ))}

            <hr className="summary-divider" />

            <div className="delivery-free">
              <span>Delivery</span>
              <span>{deliveryFee === 0 ? "FREE" : `₹${deliveryFee}`}</span>
            </div>

            <div className="total-row">
              <span>Total Amount</span>
              <span>₹{total+deliveryFee}</span>
            </div>

            <div className="cod-badge">
              ✔ Cash on delivery available
            </div>

            <button
              onClick={() => navigate("/payment")}
              className="btn-primary"
            >
              PROCEED TO PAYMENT →
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Shipping;
 