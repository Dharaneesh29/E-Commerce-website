import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  LineChart, Line, BarChart, Bar,
  PieChart, Pie, Cell, Tooltip, Legend,
  XAxis, YAxis, CartesianGrid, ResponsiveContainer,
} from "recharts";

const TOKEN = () => sessionStorage.getItem("token");
const AUTH  = () => ({ headers: { Authorization: `Bearer ${TOKEN()}` } });
const BASE  = "http://localhost:5000/api";

const COLORS  = ["#ff6f00","#ff8c00","#ffaa44","#ea580c","#f97316","#ffcc88","#fbbf24","#f59e0b"];
const DAYS    = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const MONTHS  = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const PERIODS = ["Today","This Week","This Month","This Year","All Time"];
const STATUS_COLORS = ["#f59e0b","#3b82f6","#10b981","#059669"];
const STATUS_BG     = ["rgba(245,158,11,0.08)","rgba(59,130,246,0.08)","rgba(16,185,129,0.08)","rgba(5,150,105,0.08)"];

const ChartTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background:"#fff", border:"1.5px solid #ffe0c2",
      borderRadius:12, padding:"10px 14px",
      boxShadow:"0 8px 24px rgba(255,111,0,0.15)",
      fontFamily:"'Nunito', sans-serif",
    }}>
      <p style={{ fontSize:11, fontWeight:800, color:"#ff6f00", margin:"0 0 5px" }}>{label}</p>
      {payload.map(p => (
        <p key={p.name} style={{ fontSize:13, fontWeight:700, color:p.color, margin:"2px 0" }}>
          {p.name}:{" "}
          {p.name.toLowerCase().includes("revenue") || p.name.toLowerCase().includes("sales")
            ? `₹${Number(p.value).toLocaleString()}` : p.value}
        </p>
      ))}
    </div>
  );
};

const RADIAN = Math.PI / 180;
const PieLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
  if (percent < 0.05) return null;
  const r = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + r * Math.cos(-midAngle * RADIAN);
  const y = cy + r * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central"
      fontSize={11} fontWeight={700} fontFamily="'Nunito', sans-serif">
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

const SectionCard = ({ title, subtitle, children, style }) => (
  <div style={{
    background:"#fff",
    border:"1.5px solid #ffe0c2",
    borderRadius:18, padding:"22px",
    boxShadow:"0 4px 18px rgba(255,111,0,0.07)",
    position:"relative", overflow:"hidden",
    ...style,
  }}>
    <div style={{ position:"absolute", top:0, left:0, right:0, height:4, background:"linear-gradient(90deg,#ff6f00,#ffaa44)", borderRadius:"18px 18px 0 0" }} />
    <h3 style={{
      fontFamily:"'Nunito', sans-serif",
      fontSize:16, fontWeight:900, color:"#1a1a1a", margin:"4px 0 0",
    }}>{title}</h3>
    {subtitle && (
      <p style={{ fontSize:12, color:"#ffaa70", margin:"4px 0 16px", fontFamily:"'Nunito', sans-serif", fontWeight:700 }}>
        {subtitle}
      </p>
    )}
    {children}
  </div>
);

export default function ReportsAnalytics() {
  const navigate    = useNavigate();
  const [orders,    setOrders]    = useState([]);
  const [products,  setProducts]  = useState([]);
  const [users,     setUsers]     = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [period,    setPeriod]    = useState("This Month");
  const [chartType, setChartType] = useState("Line");

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [oRes, pRes, uRes] = await Promise.all([
        axios.get(`${BASE}/orders/all`, AUTH()),
        axios.get(`${BASE}/products`,   AUTH()),
        axios.get(`${BASE}/users/all`,  AUTH()),
      ]);
      setOrders(oRes.data   || []);
      setProducts(pRes.data || []);
      setUsers(uRes.data    || []);
    } catch (err) {
      console.log("Reports fetch error:", err);
    } finally { setLoading(false); }
  };

  const filteredOrders = useMemo(() => {
    const now = new Date();
    return orders.filter(o => {
      const d = new Date(o.createdAt);
      if (period === "Today")      return d.toDateString() === now.toDateString();
      if (period === "This Week")  { const w = new Date(now); w.setDate(now.getDate()-7); return d >= w; }
      if (period === "This Month") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
      if (period === "This Year")  return d.getFullYear() === now.getFullYear();
      return true;
    });
  }, [orders, period]);

  const trendData = useMemo(() => {
    const map = {}; const now = new Date();
    if (period === "Today") {
      for (let h=0; h<=now.getHours(); h++) map[`${h}:00`] = { name:`${h}:00`, revenue:0, orders:0 };
      filteredOrders.forEach(o => {
        const k = `${new Date(o.createdAt).getHours()}:00`;
        if (map[k]) { map[k].revenue += o.totalPrice||0; map[k].orders++; }
      });
    } else if (period === "This Week") {
      for (let i=6;i>=0;i--) {
        const d = new Date(now); d.setDate(now.getDate()-i);
        const k = `${DAYS[d.getDay()]} ${d.getDate()}`; map[k] = { name:k, revenue:0, orders:0 };
      }
      filteredOrders.forEach(o => {
        const d = new Date(o.createdAt);
        const k = `${DAYS[d.getDay()]} ${d.getDate()}`;
        if (map[k]) { map[k].revenue += o.totalPrice||0; map[k].orders++; }
      });
    } else if (period === "This Month") {
      const days = new Date(now.getFullYear(), now.getMonth()+1, 0).getDate();
      for (let d=1; d<=days; d++) map[`${d}`] = { name:`${d}`, revenue:0, orders:0 };
      filteredOrders.forEach(o => {
        const d = new Date(o.createdAt);
        if (d.getMonth()===now.getMonth()) {
          const k = `${d.getDate()}`; if (map[k]) { map[k].revenue+=o.totalPrice||0; map[k].orders++; }
        }
      });
    } else {
      MONTHS.forEach(m => { map[m] = { name:m, revenue:0, orders:0 }; });
      filteredOrders.forEach(o => {
        const k = MONTHS[new Date(o.createdAt).getMonth()];
        if (map[k]) { map[k].revenue+=o.totalPrice||0; map[k].orders++; }
      });
    }
    return Object.values(map);
  }, [filteredOrders, period]);

  const categoryData = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      (o.orderItems||[]).forEach(item => {
        const cat = products.find(p=>p.name===item.name)?.category || "Other";
        if (!map[cat]) map[cat] = { name:cat, revenue:0, orders:0, qty:0 };
        map[cat].revenue += (item.price*item.qty)||0; map[cat].orders++; map[cat].qty += item.qty||1;
      });
    });
    return Object.values(map).sort((a,b)=>b.revenue-a.revenue).slice(0,8);
  }, [filteredOrders, products]);

  const topProducts = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => {
      (o.orderItems||[]).forEach(item => {
        const n = item.name||"Unknown";
        if (!map[n]) map[n] = { name:n, qty:0, revenue:0 };
        map[n].qty += item.qty||1; map[n].revenue += (item.price*item.qty)||0;
      });
    });
    return Object.values(map).sort((a,b)=>b.qty-a.qty).slice(0,8);
  }, [filteredOrders]);

  const paymentData = useMemo(() => {
    const map = {};
    filteredOrders.forEach(o => { const m=o.paymentMethod||"Unknown"; map[m]=(map[m]||0)+1; });
    return Object.entries(map).map(([name,value])=>({ name,value }));
  }, [filteredOrders]);

  const statusData = useMemo(() => {
    const map = { pending:0, confirmed:0, shipped:0, delivered:0 };
    filteredOrders.forEach(o => { if (map[o.status]!==undefined) map[o.status]++; });
    return Object.entries(map).map(([name,value])=>({
      name: name.charAt(0).toUpperCase()+name.slice(1), value,
    }));
  }, [filteredOrders]);

  const peakHoursData = useMemo(() => {
    const map = {};
    for (let h=0;h<24;h++) map[h]={ hour:`${h}:00`, orders:0, revenue:0 };
    filteredOrders.forEach(o => {
      const h = new Date(o.createdAt).getHours();
      map[h].orders++; map[h].revenue+=o.totalPrice||0;
    });
    return Object.values(map);
  }, [filteredOrders]);

  const dayOfWeekData = useMemo(() => {
    const map = {};
    DAYS.forEach(d=>{ map[d]={ day:d, revenue:0, orders:0 }; });
    filteredOrders.forEach(o => {
      const d = DAYS[new Date(o.createdAt).getDay()];
      map[d].revenue+=o.totalPrice||0; map[d].orders++;
    });
    return DAYS.map(d=>map[d]);
  }, [filteredOrders]);

  const userGrowthData = useMemo(() => {
    const map = {};
    MONTHS.forEach(m=>{ map[m]={ month:m, users:0 }; });
    users.forEach(u => {
      const m = MONTHS[new Date(u.createdAt).getMonth()];
      if (map[m]) map[m].users++;
    });
    return MONTHS.map(m=>map[m]);
  }, [users]);

  const totalRevenue      = filteredOrders.reduce((s,o)=>s+(o.totalPrice||0),0);
  const totalOrders       = filteredOrders.length;
  const avgOrderValue     = totalOrders > 0 ? Math.round(totalRevenue/totalOrders) : 0;
  const paidOrders        = filteredOrders.filter(o=>o.paymentStatus==="paid").length;
  const convRate          = totalOrders > 0 ? ((paidOrders/totalOrders)*100).toFixed(1) : "0.0";
  const totalProductsSold = filteredOrders.reduce((s,o)=>s+(o.orderItems?.length||0),0);

  const kpis = [
    { label:"Total Revenue",   value:`₹${totalRevenue.toLocaleString()}`, icon:"💰", accent:"#ff6f00", light:"#fff7ed", border:"#ffe0c2", badge:"This period" },
    { label:"Total Orders",    value:String(totalOrders),                  icon:"🛍️", accent:"#f97316", light:"#fff3e6", border:"#fed7aa", badge:"Orders placed" },
    { label:"Avg Order Value", value:`₹${avgOrderValue.toLocaleString()}`, icon:"📈", accent:"#fb923c", light:"#fff0e0", border:"#ffcc99", badge:"Per order" },
    { label:"Payment Rate",    value:`${convRate}%`,                       icon:"✅", accent:"#10b981", light:"#ecfdf5", border:"#a7f3d0", badge:"Paid orders" },
    { label:"Products Sold",   value:String(totalProductsSold),            icon:"📦", accent:"#ea580c", light:"#ffeee0", border:"#ffcc99", badge:"Items sold" },
  ];

  if (loading) return (
    <div style={{ minHeight:"100vh", display:"grid", placeItems:"center", background:"#fdf8f3", fontFamily:"'Nunito',sans-serif" }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{ textAlign:"center" }}>
        <div style={{ width:44, height:44, borderRadius:"50%", border:"4px solid #ffe0c2", borderTopColor:"#ff6f00", animation:"spin .8s linear infinite", margin:"0 auto" }}/>
        <p style={{ color:"#ffaa70", marginTop:14, fontWeight:700 }}>Loading analytics…</p>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight:"100vh", background:"#fdf8f3", fontFamily:"'Nunito', sans-serif", padding:"28px 28px 60px" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        @keyframes spin   { to{transform:rotate(360deg)} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        .ra-kpi:hover { transform:translateY(-4px) !important; box-shadow:0 12px 32px rgba(255,111,0,0.18) !important; }
        .ra-btn:hover { opacity:0.88 !important; transform:translateY(-1px) !important; }
        .ra-refresh:hover { background:#fff3e6 !important; border-color:#ff6f00 !important; color:#ff6f00 !important; }
        .recharts-legend-item-text { font-size:12px !important; font-family:'Nunito',sans-serif !important; font-weight:700 !important; }
        .recharts-cartesian-axis-tick-value { font-family:'Nunito',sans-serif !important; }
      `}</style>

      {/* ── HERO HEADER ── */}
      <div style={{
        background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
        borderRadius: 22, padding: "26px 32px", marginBottom: 24,
        position: "relative", overflow: "hidden",
        boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
        animation: "fadeUp 0.4s ease both",
      }}>
        <div style={{ position:"absolute", top:-40, right:-40, width:180, height:180, borderRadius:"50%", background:"rgba(255,255,255,0.08)" }} />
        <div style={{ position:"absolute", bottom:-50, left:"35%", width:220, height:220, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }} />
        <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
          <div>
            <h1 style={{ margin:0, fontSize:28, fontWeight:900, color:"#fff", letterSpacing:-0.5 }}>📊 Reports & Analytics</h1>
            <p style={{ margin:"5px 0 0", fontSize:13, color:"rgba(255,255,255,0.8)", fontWeight:700 }}>Insights and trends for your store</p>
          </div>
          <div style={{ display:"flex", gap:10 }}>
            <button className="ra-refresh" onClick={fetchAll} style={{
              display:"flex", alignItems:"center", gap:6, padding:"10px 18px",
              background:"rgba(255,255,255,0.2)", color:"#fff",
              border:"1.5px solid rgba(255,255,255,0.4)", borderRadius:12,
              fontSize:13, fontWeight:800, cursor:"pointer",
              fontFamily:"inherit", backdropFilter:"blur(8px)", transition:"all .2s",
            }}>↻ Refresh</button>
            <button className="ra-btn" style={{
              display:"flex", alignItems:"center", gap:8, padding:"10px 22px",
              background:"rgba(255,255,255,0.2)", color:"#fff",
              border:"1.5px solid rgba(255,255,255,0.4)", borderRadius:12,
              fontSize:13, fontWeight:800, cursor:"pointer",
              fontFamily:"inherit", backdropFilter:"blur(8px)", transition:"all .2s",
            }}>⬇ Export Data</button>
          </div>
        </div>
      </div>

      {/* ── PERIOD FILTER ── */}
      <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:24, flexWrap:"wrap", animation:"fadeUp 0.4s ease 0.08s both" }}>
        <span style={{ fontSize:11, fontWeight:800, color:"#ffaa70", textTransform:"uppercase", letterSpacing:0.8, marginRight:4 }}>Period</span>
        {PERIODS.map(p => (
          <button key={p} onClick={()=>setPeriod(p)} style={{
            padding:"7px 18px", borderRadius:50,
            border: period===p ? "none" : "1.5px solid #ffe0c2",
            background: period===p ? "linear-gradient(135deg,#ff6f00,#ff9500)" : "#fff",
            color: period===p ? "#fff" : "#888",
            fontSize:13, fontWeight:800, cursor:"pointer",
            fontFamily:"inherit",
            boxShadow: period===p ? "0 3px 12px rgba(255,111,0,0.32)" : "none",
            transition:"all .18s",
          }}>{p}</button>
        ))}
      </div>

      {/* ── KPI CARDS ── */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(190px,1fr))", gap:16, marginBottom:24, animation:"fadeUp 0.4s ease 0.16s both" }}>
        {kpis.map((k) => (
          <div key={k.label} className="ra-kpi" style={{
            background:"#fff", borderRadius:18, padding:"20px",
            border:"1.5px solid #ffe0c2",
            boxShadow:"0 2px 10px rgba(255,111,0,0.06)",
            position:"relative", overflow:"hidden",
            transition:"all .22s",
          }}>
            <div style={{ position:"absolute", top:0, left:0, right:0, height:4, background:k.accent, borderRadius:"18px 18px 0 0" }} />
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginTop:4 }}>
              <div>
                <p style={{ fontSize:11, fontWeight:800, color:"#aaa", textTransform:"uppercase", letterSpacing:0.8, margin:"0 0 8px" }}>{k.label}</p>
                <p style={{ fontSize:22, fontWeight:900, color:k.accent, margin:0, lineHeight:1, letterSpacing:-0.5 }}>{k.value}</p>
              </div>
              <div style={{ width:44, height:44, borderRadius:12, flexShrink:0, background:k.light, border:`1.5px solid ${k.border}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>{k.icon}</div>
            </div>
            <div style={{ marginTop:10, fontSize:11, fontWeight:800, color:k.accent }}>· {k.badge}</div>
          </div>
        ))}
      </div>

      {/* ── CHART TOGGLE ── */}
      <div style={{ display:"flex", gap:8, marginBottom:18, alignItems:"center", animation:"fadeUp 0.4s ease 0.42s both" }}>
        <span style={{ fontSize:11, color:"#ffaa70", fontWeight:800, textTransform:"uppercase", letterSpacing:0.8, marginRight:4 }}>Trend Chart</span>
        <div style={{ display:"flex", background:"#fff3e6", borderRadius:10, padding:3 }}>
          {["Line","Bar"].map(t => (
            <button key={t} onClick={()=>setChartType(t)} style={{
              padding:"5px 14px", borderRadius:8, border:"none",
              background: chartType===t ? "#ff6f00" : "transparent",
              color: chartType===t ? "#fff" : "#ff6f00",
              fontSize:12, fontWeight:800, cursor:"pointer",
              fontFamily:"inherit", transition:"all .15s",
            }}>{t==="Line" ? "〜 Line" : "▐▐ Bar"}</button>
          ))}
        </div>
      </div>

      {/* ── REVENUE & ORDERS TREND ── */}
      <div style={{ marginBottom:18, animation:"fadeUp 0.4s ease 0.5s both" }}>
        <SectionCard title="📈 Revenue & Orders Trend" subtitle={`${period} performance`}>
          {trendData.every(d=>d.revenue===0&&d.orders===0) ? (
            <div style={{ height:180, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:6 }}>
              <span style={{ fontSize:38 }}>📭</span>
              <p style={{ color:"#ffaa70", margin:0, fontWeight:700 }}>No orders in this period</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              {chartType==="Line" ? (
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6"/>
                  <XAxis dataKey="name" tick={{ fontSize:10, fontFamily:"'Nunito',sans-serif" }} interval={period==="This Month"?4:0}/>
                  <YAxis yAxisId="left"  tick={{ fontSize:10 }} width={65}/>
                  <YAxis yAxisId="right" orientation="right" tick={{ fontSize:10 }} width={35}/>
                  <Tooltip content={<ChartTooltip/>}/>
                  <Legend/>
                  <Line yAxisId="left"  type="monotone" dataKey="revenue" stroke="#ff6f00" strokeWidth={2.5} dot={{ r:3, fill:"#ff6f00" }} activeDot={{ r:6 }} name="Revenue"/>
                  <Line yAxisId="right" type="monotone" dataKey="orders"  stroke="#ffaa44" strokeWidth={2} strokeDasharray="5 3" dot={{ r:3, fill:"#ffaa44" }} name="Orders"/>
                </LineChart>
              ) : (
                <BarChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6"/>
                  <XAxis dataKey="name" tick={{ fontSize:10 }} interval={period==="This Month"?4:0}/>
                  <YAxis tick={{ fontSize:10 }}/>
                  <Tooltip content={<ChartTooltip/>}/>
                  <Legend/>
                  <Bar dataKey="revenue" fill="#ff6f00" name="Revenue" radius={[5,5,0,0]}/>
                  <Bar dataKey="orders"  fill="#ffaa44" name="Orders"  radius={[5,5,0,0]}/>
                </BarChart>
              )}
            </ResponsiveContainer>
          )}
        </SectionCard>
      </div>

      {/* ── CATEGORY + PAYMENT ── */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(340px,1fr))", gap:18, marginBottom:18, animation:"fadeUp 0.4s ease 0.58s both" }}>
        <SectionCard title="🏷️ Category Performance" subtitle="Revenue by category">
          {categoryData.length===0 ? (
            <div style={{ height:180, display:"flex", alignItems:"center", justifyContent:"center" }}><span style={{ fontSize:36 }}>📭</span></div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={categoryData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6" horizontal={false}/>
                  <XAxis type="number" tick={{ fontSize:10 }} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`}/>
                  <YAxis type="category" dataKey="name" tick={{ fontSize:10 }} width={90}/>
                  <Tooltip content={<ChartTooltip/>}/>
                  <Bar dataKey="revenue" name="Revenue" radius={[0,5,5,0]}>
                    {categoryData.map((_,i)=><Cell key={i} fill={COLORS[i%COLORS.length]}/>)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div style={{ display:"flex", flexDirection:"column", marginTop:12 }}>
                {categoryData.slice(0,4).map((c,i)=>(
                  <div key={c.name} style={{ display:"flex", alignItems:"center", gap:8, padding:"7px 0", borderBottom:"1px solid #fff3e6" }}>
                    <div style={{ width:9, height:9, borderRadius:"50%", background:COLORS[i], flexShrink:0 }}/>
                    <span style={{ color:"#888", flex:1, fontSize:12, fontWeight:700 }}>{c.name}</span>
                    <span style={{ color:"#ff6f00", fontSize:13, fontWeight:900 }}>₹{c.revenue.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </SectionCard>

        <SectionCard title="💳 Payment Methods" subtitle="How customers pay">
          {paymentData.length===0 ? (
            <div style={{ height:180, display:"flex", alignItems:"center", justifyContent:"center" }}><span style={{ fontSize:36 }}>📭</span></div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={paymentData} cx="50%" cy="50%" outerRadius={78} dataKey="value" labelLine={false} label={PieLabel}>
                    {paymentData.map((_,i)=><Cell key={i} fill={COLORS[i%COLORS.length]}/>)}
                  </Pie>
                  <Tooltip formatter={(v,n)=>[`${v} orders`,n]}/>
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display:"flex", flexDirection:"column", marginTop:12 }}>
                {paymentData.map((p,i)=>(
                  <div key={p.name} style={{ display:"flex", alignItems:"center", gap:8, padding:"7px 0", borderBottom:"1px solid #fff3e6" }}>
                    <div style={{ width:9, height:9, borderRadius:"50%", background:COLORS[i%COLORS.length], flexShrink:0 }}/>
                    <span style={{ color:"#888", flex:1, fontSize:12, fontWeight:700 }}>{p.name}</span>
                    <span style={{ color:"#ff6f00", fontSize:13, fontWeight:900 }}>
                      {p.value} <span style={{ fontSize:11, color:"#aaa", fontWeight:700 }}>({((p.value/Math.max(totalOrders,1))*100).toFixed(0)}%)</span>
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
        </SectionCard>
      </div>

      {/* ── ORDER STATUS + TOP PRODUCTS ── */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(340px,1fr))", gap:18, marginBottom:18, animation:"fadeUp 0.4s ease 0.65s both" }}>
        <SectionCard title="📦 Order Status" subtitle="Distribution of order statuses">
          {statusData.every(s=>s.value===0) ? (
            <div style={{ height:180, display:"flex", alignItems:"center", justifyContent:"center" }}><span style={{ fontSize:36 }}>📭</span></div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={statusData} cx="50%" cy="50%" innerRadius={48} outerRadius={76} dataKey="value" labelLine={false} label={PieLabel}>
                    {statusData.map((_,i)=><Cell key={i} fill={STATUS_COLORS[i]}/>)}
                  </Pie>
                  <Tooltip formatter={(v,n)=>[`${v} orders`,n]}/>
                  <Legend/>
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:10, marginTop:12 }}>
                {statusData.map((s,i)=>(
                  <div key={s.name} style={{ borderRadius:12, padding:"14px", background:STATUS_BG[i], border:`1.5px solid ${STATUS_COLORS[i]}33`, textAlign:"center" }}>
                    <p style={{ fontSize:26, fontWeight:900, color:STATUS_COLORS[i], margin:0, lineHeight:1 }}>{s.value}</p>
                    <p style={{ fontSize:11, color:"#888", margin:"4px 0 0", fontWeight:700 }}>{s.name}</p>
                  </div>
                ))}
              </div>
            </>
          )}
        </SectionCard>

        <SectionCard title="🏆 Top Products" subtitle="By units sold this period">
          {topProducts.length===0 ? (
            <div style={{ height:180, display:"flex", alignItems:"center", justifyContent:"center" }}><span style={{ fontSize:36 }}>📭</span></div>
          ) : (
            <div style={{ display:"flex", flexDirection:"column", marginTop:8 }}>
              {topProducts.map((p,i)=>(
                <div key={p.name} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 0", borderBottom:"1px solid #fff3e6" }}>
                  <div style={{ width:28, height:28, borderRadius:8, flexShrink:0, background: i<3 ? "linear-gradient(135deg,#ff6f00,#ff9500)" : "#fff3e6", display:"grid", placeItems:"center", fontSize:12, fontWeight:900, color: i<3 ? "#fff" : "#ff6f00" }}>{i+1}</div>
                  <span style={{ fontSize:12, color:"#1a1a1a", flex:1, fontWeight:700, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{p.name}</span>
                  <span style={{ fontSize:11, color:"#aaa", marginRight:8, fontWeight:700 }}>{p.qty} units</span>
                  <span style={{ fontSize:13, color:"#ff6f00", fontWeight:900 }}>₹{p.revenue.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>

      {/* ── PEAK HOURS ── */}
      <div style={{ marginBottom:18, animation:"fadeUp 0.4s ease 0.72s both" }}>
        <SectionCard title="⏰ Peak Sales Hours" subtitle="Best hours for orders">
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={peakHoursData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6"/>
              <XAxis dataKey="hour" tick={{ fontSize:9 }} interval={1}/>
              <YAxis tick={{ fontSize:10 }}/>
              <Tooltip content={<ChartTooltip/>}/>
              <Bar dataKey="orders" name="Orders" radius={[4,4,0,0]}>
                {peakHoursData.map((_,i)=>(
                  <Cell key={i} fill={`rgba(255,111,0,${Math.max(0.15, Math.min(0.9, 0.2+(_.orders||0)*0.15))})`}/>
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>

      {/* ── DAY OF WEEK + USER GROWTH ── */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(340px,1fr))", gap:18, animation:"fadeUp 0.4s ease 0.78s both" }}>
        <SectionCard title="📅 Revenue by Day" subtitle="Which days perform best">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={dayOfWeekData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6"/>
              <XAxis dataKey="day" tick={{ fontSize:11 }}/>
              <YAxis tick={{ fontSize:10 }} tickFormatter={v=>`₹${(v/1000).toFixed(0)}k`}/>
              <Tooltip content={<ChartTooltip/>}/>
              <Bar dataKey="revenue" name="Revenue" radius={[6,6,0,0]}>
                {dayOfWeekData.map((_,i)=><Cell key={i} fill={COLORS[i%COLORS.length]}/>)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </SectionCard>

        <SectionCard title="👥 User Growth" subtitle="New registrations per month">
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={userGrowthData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6"/>
              <XAxis dataKey="month" tick={{ fontSize:10 }}/>
              <YAxis tick={{ fontSize:10 }}/>
              <Tooltip content={<ChartTooltip/>}/>
              <Line type="monotone" dataKey="users" stroke="#ff6f00" strokeWidth={2.5} dot={{ r:4, fill:"#ff6f00", strokeWidth:0 }} activeDot={{ r:6, fill:"#ea580c" }} name="New Users"/>
            </LineChart>
          </ResponsiveContainer>
        </SectionCard>
      </div>

    </div>
  );
}
