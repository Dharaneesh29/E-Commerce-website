import React from "react";
import { useNavigate } from "react-router-dom";

const Landing = () => {
  const navigate = useNavigate();

  return (
    <div
      className="h-screen bg-cover bg-center relative flex items-center justify-center"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1607083206968-13611e3d76db')",
      }}
    >
      {/* 🔥 Dark Overlay */}
      <div className="absolute inset-0 bg-black/70"></div>

      {/* 🔥 Content */}
      <div className="relative z-10 text-center text-white px-4 animate-fadeIn">

        {/* Title */}
        <h1 className="text-5xl font-bold mb-4 drop-shadow-lg text-yellow-300">
          🛒 ShopEasy
        </h1>

        {/* Subtitle */}
        {/* <p className="text-lg mb-8 max-w-md mx-auto">
          Discover amazing products at the best prices with a seamless shopping experience.
        </p> */}

        {/* Buttons */}
        <div className="flex gap-6 justify-center">
          <button
            onClick={() => navigate("/users/login")}
            className="bg-white text-indigo-600 px-6 py-2 rounded-xl font-semibold shadow-lg hover:scale-110 hover:shadow-2xl transition duration-300"
          >
            Login
          </button>

          <button
            onClick={() => navigate("/users/register")}
            className="border border-white px-6 py-2 rounded-xl font-semibold hover:bg-white hover:text-indigo-600 hover:scale-110 transition duration-300"
          >
            Register
          </button>
        </div>

        {/* Glass Card */}
        {/* <div className="mt-10 bg-white/10 backdrop-blur-lg px-6 py-3 rounded-xl shadow-lg inline-block">
          <p className="text-sm">✨ Trusted by 10,000+ users</p>
        </div> */}

      </div>
    </div>
  );
};

export default Landing;
