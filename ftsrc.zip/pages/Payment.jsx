// import React, { useState, useContext, useEffect } from "react";
// import StepIndicator from "../components/StepIndicator";
// import { ShopContext } from "../context/ShopContext";
// import { useNavigate } from "react-router-dom";
// import axios from "axios";
// import { toast } from "react-hot-toast";

// const Payment = () => {
//   const [method, setMethod] = useState("card");
//   const { cart, clearCart } = useContext(ShopContext);
//   const [coupons, setCoupons] = useState([]);
//   const [showPopup, setShowPopup] = useState(false);
//   const [showCoupons, setShowCoupons] = useState(false);
//   const [search, setSearch] = useState("");
//   const [appliedCoupon, setAppliedCoupon] = useState("");
//   const [discount, setDiscount] = useState(0);
//   const [finalTotal, setFinalTotal] = useState(0);
//   const [loading, setLoading] = useState(false);
//   const [membershipDiscount, setMembershipDiscount] = useState(0);
//   const [membershipPlanName, setMembershipPlanName] = useState("");
//   const [cardNumber, setCardNumber] = useState("");
//   const [cardName, setCardName] = useState("");
//   const [expiry, setExpiry] = useState("");
//   const [cvv, setCvv] = useState("");
//   const [saveCard, setSaveCard] = useState(false);
//   const [upiId, setUpiId] = useState("");
//   const [selectedWallet, setSelectedWallet] = useState("");
//   const [selectedEmi, setSelectedEmi] = useState("");
//   const [selectedBank, setSelectedBank] = useState("");

//   const navigate = useNavigate();

//   const total = cart.reduce(
//     (acc, item) => acc + item.product.price * item.qty,
//     0
//   );

//   const deliveryDate = sessionStorage.getItem("deliveryDate") || "";
//   const deliveryFee = total < 500 ? Math.floor(total * 0.05) : 0;

//   // ✅ payAmount with membership discount
//   const payAmount = (finalTotal || total - discount + deliveryFee) - membershipDiscount;

//   useEffect(() => {
//     const code = sessionStorage.getItem("appliedCoupon");
//     const disc = sessionStorage.getItem("discountAmount");
//     const final = sessionStorage.getItem("finalTotal");
//     if (code) setAppliedCoupon(code);
//     if (disc) setDiscount(Number(disc));
//     if (final) setFinalTotal(Number(final));
//   }, []);

//   useEffect(() => {
//     const fetchCoupons = async () => {
//       try {
//         const token = sessionStorage.getItem("token");
//         const res = await axios.get("http://localhost:5000/api/coupon", {
//           headers: { Authorization: `Bearer ${token}` },
//         });
//         setCoupons(res?.data || []);
//       } catch (err) {
//         console.error("Coupon fetch error:", err);
//         setCoupons([]);
//       }
//     };
//     fetchCoupons();
//   }, []);

//   // ✅ Membership fetch — after total is declared
//   useEffect(() => {
//     const fetchMembership = async () => {
//       try {
//         const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
//         const token = userInfo?.token || sessionStorage.getItem("token");
//         if (!token) return;
//         const res = await axios.get(
//           "http://localhost:5000/api/users/my-membership",
//           { headers: { Authorization: `Bearer ${token}` } }
//         );
//         const mem = res.data;
//         if (mem?.isActive && mem?.planId?.discount > 0) {
//           const discAmt = Math.round((total * mem.planId.discount) / 100);
//           setMembershipDiscount(discAmt);
//           setMembershipPlanName(mem.planId.name);
//         }
//       } catch (err) {
//         console.log("Membership fetch error:", err);
//       }
//     };
//     fetchMembership();
//   }, [total]);

//   const applyCoupon = async (code) => {
//     try {
//       const token = sessionStorage.getItem("token");
//       const res = await axios.post(
//         "http://localhost:5000/api/coupon/apply",
//         { code, subtotal: total },
//         { headers: { Authorization: `Bearer ${token}` } }
//       );
//       setDiscount(res.data.discount);
//       setAppliedCoupon(code);
//       const final = total - res.data.discount + deliveryFee;
//       sessionStorage.setItem("appliedCoupon", code);
//       sessionStorage.setItem("discountAmount", res.data.discount);
//       sessionStorage.setItem("finalTotal", final);
//       setShowPopup(true);
//       setTimeout(() => setShowPopup(false), 2500);
//     } catch (err) {
//       alert(err.response?.data?.message);
//     }
//   };

//   const handlePayment = async () => {
//     try {
//       setLoading(true);
//      const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
// const token = userInfo?.token;
//       if (!token) { toast.error("Login required ❌"); setLoading(false); return; }


// // ✅ Prevent empty cart orders
// if (!cart || cart.length === 0) {
//   toast.error("Your cart is empty! Add items first. ❌");
//   setLoading(false);
//   return;
// }
// if (total <= 0) {
//   toast.error("Invalid order amount! ❌");
//   setLoading(false);
//   return;
// }

//       const addressId = sessionStorage.getItem("selectedAddress");
//       if (!addressId) { toast.error("Select address first ❌"); setLoading(false); return; }

//       if (method === "card") {
//         if (!cardNumber || cardNumber.replace(/\s/g, "").length !== 16) { toast.error("Enter valid card number"); setLoading(false); return; }
//         if (!cardName.trim()) { toast.error("Enter card holder name"); setLoading(false); return; }
//         if (!expiry || expiry.length < 5) { toast.error("Enter valid expiry date (MM/YY)"); setLoading(false); return; }
//         if (!cvv || cvv.length !== 3) { toast.error("Enter valid CVV"); setLoading(false); return; }
//       }
//       if (method === "upi") {
//         if (!upiId.trim() || !upiId.includes("@")) { toast.error("Enter valid UPI ID"); setLoading(false); return; }
//       }
//       if (method === "wallet") {
//         if (!selectedWallet) { toast.error("Please select a wallet"); setLoading(false); return; }
//       }
//       if (method === "emi") {
//         if (!selectedBank || !selectedEmi) { toast.error("Please select bank and EMI option"); setLoading(false); return; }
//       }

//       const orderData = {
//         orderItems: cart.map((item) => ({
//           product: item.product._id,
//           name: item.product.name,
//           price: item.product.price,
//           qty: item.qty,
//           image: item.product.images?.[0] || "",
//         })),
//         addressId,
//         totalPrice: payAmount, // ✅ uses discounted price
//         paymentMethod: method.toUpperCase(),
//         estimatedDelivery: deliveryDate,
//       };

//       const res = await fetch("http://localhost:5000/api/orders", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify(orderData),
//       });

//       const data = await res.json();
//       if (!res.ok) { toast.error(data.message || "Order failed ❌"); setLoading(false); return; }

//       toast.success("Order Placed Successfully 🎉");
//       sessionStorage.setItem("orderSuccess", JSON.stringify(data.order));
//       // sessionStorage.removeItem("cart");
//       await clearCart();
//       setTimeout(() => navigate("/success"), 1500);
//     } catch (error) {
//       console.log(error);
//       toast.error("Something went wrong ❌");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const applicableCoupons = coupons.filter((c) => total >= c.minAmount);
//   const notApplicableCoupons = coupons.filter((c) => total < c.minAmount);

//   const payMethods = [
//     { id: "card",   label: "Credit / Debit Card", icon: "💳" },
//     { id: "upi",    label: "UPI",                 icon: "📱" },
//     { id: "wallet", label: "Wallets",              icon: "👛" },
//     { id: "emi",    label: "EMI",                  icon: "🏦" },
//     { id: "cod",    label: "Cash on Delivery",     icon: "💵" },
//   ];

//   const formatCardNumber = (val) =>
//     val.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();

//   return (
//     <>
//       <style>{`
//         @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800&display=swap');
//         * { box-sizing: border-box; margin: 0; padding: 0; }
//         .pay-root { font-family: 'Nunito', sans-serif; background: #fdf5ee; min-height: 100vh; padding: 28px 20px 60px; }
//         .pay-title { font-size: 28px; font-weight: 800; color: #1a1a1a; letter-spacing: -0.4px; margin: 22px 0 20px; }
//         .pay-layout { display: flex; gap: 22px; align-items: flex-start; }
//         .method-tabs { width: 210px; flex-shrink: 0; background: #fff; border-radius: 16px; border: 1.5px solid #ffe0c2; overflow: hidden; box-shadow: 0 4px 16px rgba(255,111,0,0.07); }
//         .method-tab { display: flex; align-items: center; gap: 10px; padding: 14px 16px; cursor: pointer; font-size: 13.5px; font-weight: 600; color: #555; border-bottom: 1px solid #f5ece4; transition: background 0.15s, color 0.15s; position: relative; }
//         .method-tab:last-child { border-bottom: none; }
//         .method-tab:hover { background: #fff8f2; color: #ff6f00; }
//         .method-tab.active { background: #fff8f2; color: #ff6f00; font-weight: 800; }
//         .method-tab.active::before { content: ''; position: absolute; left: 0; top: 0; width: 3px; height: 100%; background: linear-gradient(180deg, #ff6f00, #ffaa5a); border-radius: 0 2px 2px 0; }
//         .method-tab .tab-icon { font-size: 16px; }
//         .pay-center { flex: 1; background: #fff; border-radius: 18px; padding: 28px; border: 1.5px solid #ffe0c2; box-shadow: 0 4px 18px rgba(255,111,0,0.07); }
//         .panel-title { font-size: 18px; font-weight: 800; color: #1a1a1a; margin-bottom: 22px; display: flex; align-items: center; gap: 8px; }
//         .form-label { font-size: 12.5px; font-weight: 700; color: #777; text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 6px; display: block; }
//         .form-input { width: 100%; padding: 12px 14px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 14px; font-family: 'Nunito', sans-serif; color: #1a1a1a; background: #fafafa; margin-bottom: 16px; transition: border-color 0.2s, box-shadow 0.2s; outline: none; }
//         .form-input:focus { border-color: #ff6f00; box-shadow: 0 0 0 3px rgba(255,111,0,0.1); background: #fff; }
//         .form-input::placeholder { color: #ccc; }
//         .form-row { display: flex; gap: 14px; }
//         .form-row .form-input { flex: 1; }
//         .card-preview { background: linear-gradient(135deg, #ff6f00, #ff9500, #ffb347); border-radius: 16px; padding: 22px 24px; margin-bottom: 22px; color: #fff; position: relative; overflow: hidden; box-shadow: 0 8px 24px rgba(255,111,0,0.35); }
//         .card-preview::before { content: ''; position: absolute; top: -30px; right: -30px; width: 120px; height: 120px; border-radius: 50%; background: rgba(255,255,255,0.1); }
//         .card-preview::after { content: ''; position: absolute; bottom: -40px; left: 40px; width: 160px; height: 160px; border-radius: 50%; background: rgba(255,255,255,0.06); }
//         .card-chip { width: 36px; height: 28px; background: rgba(255,255,255,0.3); border-radius: 6px; margin-bottom: 14px; }
//         .card-num { font-size: 18px; font-weight: 700; letter-spacing: 3px; margin-bottom: 14px; font-family: 'Courier New', monospace; }
//         .card-meta { display: flex; justify-content: space-between; font-size: 12px; opacity: 0.85; }
//         .card-meta span { font-weight: 600; }
//         .save-card-row { display: flex; align-items: center; gap: 8px; margin-bottom: 20px; font-size: 13.5px; color: #666; font-weight: 600; }
//         .save-card-row input[type="checkbox"] { accent-color: #ff6f00; width: 16px; height: 16px; cursor: pointer; }
//         .btn-pay { width: 100%; padding: 15px; background: linear-gradient(135deg, #ff6f00, #ff9500); color: #fff; border: none; border-radius: 12px; font-weight: 800; font-size: 15px; letter-spacing: 0.5px; cursor: pointer; transition: opacity 0.2s, transform 0.1s; box-shadow: 0 4px 16px rgba(255,111,0,0.35); font-family: 'Nunito', sans-serif; display: flex; align-items: center; justify-content: center; gap: 8px; }
//         .btn-pay:hover { opacity: 0.92; transform: translateY(-1px); }
//         .btn-pay:active { transform: translateY(0); }
//         .btn-pay:disabled { opacity: 0.6; cursor: not-allowed; }
//         .btn-pay-cod { background: linear-gradient(135deg, #2e9e5b, #3ac97a); box-shadow: 0 4px 16px rgba(46,158,91,0.3); }
//         .secure-note { text-align: center; font-size: 12px; color: #bbb; margin-top: 12px; display: flex; align-items: center; justify-content: center; gap: 5px; font-weight: 600; }
//         .qr-box { background: #fff8f2; border: 1.5px dashed #ffcc99; border-radius: 14px; padding: 20px; text-align: center; margin-bottom: 20px; }
//         .qr-box p { font-size: 13px; color: #888; font-weight: 600; margin-bottom: 12px; }
//         .qr-box img { width: 130px; border-radius: 10px; border: 3px solid #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
//         .upi-divider { text-align: center; color: #ccc; font-size: 13px; font-weight: 700; margin: 16px 0; position: relative; }
//         .upi-divider::before, .upi-divider::after { content: ''; position: absolute; top: 50%; width: 44%; height: 1px; background: #eee; }
//         .upi-divider::before { left: 0; }
//         .upi-divider::after { right: 0; }
//         .wallet-option { display: flex; justify-content: space-between; align-items: center; border: 1.5px solid #e8e8e8; border-radius: 12px; padding: 14px 16px; cursor: pointer; margin-bottom: 12px; transition: border-color 0.2s, box-shadow 0.2s, background 0.15s; font-size: 14px; font-weight: 700; color: #333; }
//         .wallet-option:hover { border-color: #ffcc99; box-shadow: 0 4px 14px rgba(255,111,0,0.1); background: #fff8f2; }
//         .wallet-option.selected { border-color: #ff6f00; background: #fff8f2; }
//         .wallet-option .wallet-left { display: flex; align-items: center; gap: 10px; }
//         .wallet-icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; background: #fff; border: 1px solid #eee; }
//         .wallet-badge { font-size: 11px; font-weight: 700; color: #2e9e5b; background: #edfaf4; padding: 3px 8px; border-radius: 6px; }
//         .bank-select { width: 100%; padding: 12px 14px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 14px; font-family: 'Nunito', sans-serif; color: #1a1a1a; background: #fafafa; margin-bottom: 18px; outline: none; cursor: pointer; transition: border-color 0.2s; }
//         .bank-select:focus { border-color: #ff6f00; }
//         .emi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px; }
//         .emi-card { border: 1.5px solid #e8e8e8; border-radius: 12px; padding: 14px; cursor: pointer; transition: border-color 0.2s, box-shadow 0.2s, background 0.15s; }
//         .emi-card:hover { border-color: #ffcc99; background: #fff8f2; }
//         .emi-card.selected { border-color: #ff6f00; background: #fff8f2; }
//         .emi-card .emi-months { font-size: 14px; font-weight: 800; color: #1a1a1a; margin-bottom: 4px; }
//         .emi-card .emi-amount { font-size: 12px; color: #888; font-weight: 600; }
//         .emi-card .emi-selected-badge { font-size: 11px; color: #ff6f00; font-weight: 700; margin-top: 4px; }
//         .emi-note { font-size: 12px; color: #bbb; font-weight: 600; margin-bottom: 16px; }
//         .cod-box { background: linear-gradient(135deg, #edfaf4, #f0fdf4); border: 1.5px solid #b6e9cf; border-radius: 14px; padding: 28px; text-align: center; margin-bottom: 20px; }
//         .cod-icon { font-size: 52px; margin-bottom: 12px; }
//         .cod-box h4 { font-size: 17px; font-weight: 800; color: #1a1a1a; margin-bottom: 8px; }
//         .cod-box p { font-size: 13.5px; color: #666; line-height: 1.6; font-weight: 600; }
//         .cod-perks { display: flex; justify-content: center; gap: 20px; margin-top: 14px; flex-wrap: wrap; }
//         .cod-perk { font-size: 12px; color: #2e9e5b; font-weight: 700; display: flex; align-items: center; gap: 4px; }
//         .summary-box { width: 320px; flex-shrink: 0; background: #fff; border-radius: 18px; padding: 22px; border: 1.5px solid #ffe0c2; box-shadow: 0 6px 24px rgba(255,111,0,0.09); position: sticky; top: 20px; }
//         .summary-box h3 { font-size: 18px; font-weight: 800; color: #1a1a1a; border-bottom: 2px dashed #ffe0c2; padding-bottom: 14px; margin-bottom: 14px; }
//         .summary-items { max-height: 200px; overflow-y: auto; margin-bottom: 14px; padding-right: 4px; }
//         .summary-items::-webkit-scrollbar { width: 4px; }
//         .summary-items::-webkit-scrollbar-thumb { background: #ffcc99; border-radius: 4px; }
//         .summary-item { display: flex; gap: 10px; align-items: center; margin-bottom: 12px; }
//         .summary-img { width: 44px; height: 44px; border-radius: 8px; object-fit: cover; border: 1.5px solid #ffe0c2; background: #fff8f2; flex-shrink: 0; }
//         .summary-item-info { flex: 1; }
//         .summary-item-name { font-size: 13px; font-weight: 700; color: #1a1a1a; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px; }
//         .summary-item-qty { font-size: 12px; color: #aaa; font-weight: 600; }
//         .summary-item-price { font-size: 13px; font-weight: 800; color: #1a1a1a; }
//         .coupon-section { border-top: 1.5px dashed #ffe0c2; border-bottom: 1.5px dashed #ffe0c2; padding: 12px 0; margin: 4px 0 14px; }
//         .coupon-row { display: flex; justify-content: space-between; align-items: center; font-size: 13.5px; font-weight: 700; color: #333; }
//         .coupon-btn { font-size: 13px; font-weight: 800; color: #ff6f00; cursor: pointer; border: none; background: none; font-family: 'Nunito', sans-serif; padding: 0; }
//         .coupon-applied { display: flex; align-items: center; gap: 6px; margin-top: 8px; font-size: 12px; color: #2e9e5b; font-weight: 700; background: #edfaf4; border: 1px solid #b6e9cf; border-radius: 8px; padding: 7px 10px; }
//         .coupon-remove { margin-left: auto; font-size: 11px; color: #e53935; cursor: pointer; font-weight: 700; border: none; background: none; font-family: 'Nunito', sans-serif; }
//         .price-line { display: flex; justify-content: space-between; font-size: 13.5px; color: #555; margin-bottom: 8px; font-weight: 600; }
//         .price-line .free { color: #2e9e5b; font-weight: 800; }
//         .price-line .saving { color: #2e9e5b; font-weight: 800; }
//         .total-row { display: flex; justify-content: space-between; align-items: center; background: #fff8f2; border-radius: 10px; padding: 12px 14px; border: 1.5px solid #ffe0c2; margin-top: 12px; }
//         .total-row span:first-child { font-size: 14px; font-weight: 700; color: #555; }
//         .total-row span:last-child { font-size: 20px; font-weight: 800; color: #ff6f00; }
//         .coupon-popup { position: fixed; top: 80px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #2e9e5b, #3ac97a); color: #fff; padding: 14px 28px; border-radius: 14px; font-weight: 800; font-size: 15px; box-shadow: 0 8px 24px rgba(46,158,91,0.35); z-index: 1000; display: flex; align-items: center; gap: 8px; animation: slideDown 0.3s ease; }
//         @keyframes slideDown { from { opacity: 0; transform: translateX(-50%) translateY(-12px); } to { opacity: 1; transform: translateX(-50%) translateY(0); } }
//         .loading-spinner { width: 18px; height: 18px; border: 2.5px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; }
//         @keyframes spin { to { transform: rotate(360deg); } }
//         @media (max-width: 900px) { .pay-layout { flex-direction: column; } .method-tabs { width: 100%; display: flex; flex-wrap: wrap; } .method-tab { flex: 1; justify-content: center; border-right: 1px solid #f5ece4; } .summary-box { width: 100%; position: static; } }
//       `}</style>

//       {showPopup && (
//         <div className="coupon-popup">🎉 Coupon applied! You saved ₹{discount}</div>
//       )}

//       <div className="pay-root">
//         <StepIndicator step={3} />
//         <h2 className="pay-title">Select Payment Mode</h2>

//         <div className="pay-layout">
//           {/* LEFT: Method Tabs */}
//           <div className="method-tabs">
//             {payMethods.map((m) => (
//               <div key={m.id} onClick={() => setMethod(m.id)} className={`method-tab ${method === m.id ? "active" : ""}`}>
//                 <span className="tab-icon">{m.icon}</span>
//                 {m.label}
//               </div>
//             ))}
//           </div>

//           {/* CENTER: Payment Panel */}
//           <div className="pay-center">

//             {/* CARD */}
//             {method === "card" && (
//               <div>
//                 <p className="panel-title">💳 Credit / Debit Card</p>
//                 <div className="card-preview">
//                   <div className="card-chip" />
//                   <div className="card-num">{cardNumber || "•••• •••• •••• ••••"}</div>
//                   <div className="card-meta">
//                     <div>
//                       <div style={{ fontSize: 10, opacity: 0.7, marginBottom: 2 }}>CARD HOLDER</div>
//                       <span>{cardName || "YOUR NAME"}</span>
//                     </div>
//                     <div>
//                       <div style={{ fontSize: 10, opacity: 0.7, marginBottom: 2 }}>EXPIRES</div>
//                       <span>{expiry || "MM/YY"}</span>
//                     </div>
//                   </div>
//                 </div>
//                 <label className="form-label">Card Number</label>
//                 <input className="form-input" placeholder="1234 5678 9012 3456" value={cardNumber} onChange={(e) => setCardNumber(formatCardNumber(e.target.value))} maxLength={19} />
//                 <label className="form-label">Name on Card</label>
//                 <input className="form-input" placeholder="John Doe" value={cardName} onChange={(e) => setCardName(e.target.value.toUpperCase())} />
//                 <div className="form-row">
//                   <div style={{ flex: 1 }}>
//                     <label className="form-label">Expiry Date</label>
//                     <input className="form-input" placeholder="MM / YY" value={expiry} onChange={(e) => setExpiry(e.target.value)} maxLength={7} />
//                   </div>
//                   <div style={{ flex: 1 }}>
//                     <label className="form-label">CVV</label>
//                     <input className="form-input" placeholder="•••" type="password" value={cvv} onChange={(e) => setCvv(e.target.value.slice(0, 3))} maxLength={3} />
//                   </div>
//                 </div>
//                 <div className="save-card-row">
//                   <input type="checkbox" checked={saveCard} onChange={(e) => setSaveCard(e.target.checked)} />
//                   Save this card for future payments
//                 </div>
//                 <button onClick={handlePayment} className="btn-pay" disabled={loading}>
//                   {loading ? <span className="loading-spinner" /> : null}
//                   {loading ? "Processing..." : `PAY ₹${payAmount}`}
//                 </button>
//                 <p className="secure-note">🔒 256-bit SSL encrypted • 100% Secure</p>
//               </div>
//             )}

//             {/* UPI */}
//             {method === "upi" && (
//               <div>
//                 <p className="panel-title">📱 UPI Payment</p>
//                 <div className="qr-box">
//                   <p>Scan QR code to pay instantly</p>
//                   <img src="http://localhost:5000/uploads/Qr.png" alt="QR Code" />
//                 </div>
//                 <div className="upi-divider">OR ENTER UPI ID</div>
//                 <label className="form-label">UPI ID</label>
//                 <input className="form-input" placeholder="yourname@upi" value={upiId} onChange={(e) => setUpiId(e.target.value)} />
//                 <button onClick={handlePayment} className="btn-pay" disabled={loading}>
//                   {loading ? <span className="loading-spinner" /> : null}
//                   {loading ? "Processing..." : `PAY ₹${payAmount}`}
//                 </button>
//                 <p className="secure-note">🔒 Payments powered by UPI</p>
//               </div>
//             )}

//             {/* WALLET */}
//             {method === "wallet" && (
//               <div>
//                 <p className="panel-title">👛 Pay via Wallet</p>
//                 {[
//                   { name: "Paytm", icon: "🔵", badge: "Fast" },
//                   { name: "PhonePe", icon: "🟣", badge: "Recommended" },
//                   { name: "Amazon Pay", icon: "🟡", badge: "Cashback" },
//                   { name: "Mobikwik", icon: "🔴", badge: "" },
//                 ].map((w) => (
//                   <div key={w.name} className={`wallet-option ${selectedWallet === w.name ? "selected" : ""}`} onClick={() => setSelectedWallet(w.name)}>
//                     <div className="wallet-left">
//                       <div className="wallet-icon">{w.icon}</div>
//                       {w.name}
//                     </div>
//                     {w.badge && <span className="wallet-badge">{w.badge}</span>}
//                   </div>
//                 ))}
//                 <button onClick={handlePayment} className="btn-pay" disabled={loading}>
//                   {loading ? <span className="loading-spinner" /> : null}
//                   {loading ? "Processing..." : `PAY ₹${payAmount}`}
//                 </button>
//               </div>
//             )}

//             {/* EMI */}
//             {method === "emi" && (
//               <div>
//                 <p className="panel-title">🏦 EMI Options</p>
//                 <label className="form-label">Select Bank</label>
//                 <select className="bank-select" value={selectedBank} onChange={(e) => setSelectedBank(e.target.value)}>
//                   <option value="">Choose your bank</option>
//                   <option>HDFC Bank</option>
//                   <option>SBI</option>
//                   <option>Axis Bank</option>
//                   <option>ICICI Bank</option>
//                   <option>Kotak Bank</option>
//                 </select>
//                 <label className="form-label" style={{ marginBottom: 10 }}>Choose Tenure</label>
//                 <div className="emi-grid">
//                   {[
//                     { months: "3 Months", amount: Math.ceil(payAmount / 3) },
//                     { months: "6 Months", amount: Math.ceil(payAmount / 6) },
//                     { months: "9 Months", amount: Math.ceil(payAmount / 9) },
//                     { months: "12 Months", amount: Math.ceil(payAmount / 12) },
//                   ].map((e) => (
//                     <div key={e.months} className={`emi-card ${selectedEmi === e.months ? "selected" : ""}`} onClick={() => setSelectedEmi(e.months)}>
//                       <p className="emi-months">{e.months}</p>
//                       <p className="emi-amount">₹{e.amount}/month</p>
//                       {selectedEmi === e.months && <p className="emi-selected-badge">✔ Selected</p>}
//                     </div>
//                   ))}
//                 </div>
//                 <p className="emi-note">* Interest rates may vary based on your bank</p>
//                 <button onClick={handlePayment} className="btn-pay" disabled={loading}>
//                   {loading ? <span className="loading-spinner" /> : null}
//                   {loading ? "Processing..." : `PAY ₹${payAmount}`}
//                 </button>
//               </div>
//             )}

//             {/* COD */}
//             {method === "cod" && (
//               <div>
//                 <p className="panel-title">💵 Cash on Delivery</p>
//                 <div className="cod-box">
//                   <div className="cod-icon">🚚</div>
//                   <h4>Pay when your order arrives</h4>
//                   <p>No need to share any payment details.<br />Pay in cash when your order is delivered.</p>
//                   <div className="cod-perks">
//                     <span className="cod-perk">✔ No hidden charges</span>
//                     <span className="cod-perk">✔ 100% Safe</span>
//                     <span className="cod-perk">✔ Easy returns</span>
//                   </div>
//                 </div>
//                 {deliveryDate && (
//                   <div style={{ background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 12, padding: "12px 16px", marginBottom: 18, fontSize: 13.5, fontWeight: 700, color: "#ff6f00", display: "flex", alignItems: "center", gap: 8 }}>
//                     🗓️ Expected delivery by {deliveryDate}
//                   </div>
//                 )}
//                 <button onClick={handlePayment} className="btn-pay btn-pay-cod" disabled={loading}>
//                   {loading ? <span className="loading-spinner" /> : null}
//                   {loading ? "Placing Order..." : "PLACE ORDER →"}
//                 </button>
//                 <p className="secure-note">📦 Order will be confirmed immediately</p>
//               </div>
//             )}
//           </div>

//           {/* RIGHT: Order Summary */}
//           <div className="summary-box">
//             <h3>Order Summary</h3>
//             <div className="summary-items">
//               {cart.map((item) => (
//                 <div key={item._id} className="summary-item">
//                   <img
//                     src={
//                       item.product?.images?.length > 0
//                         ? item.product.images[0].startsWith("http") ? item.product.images[0] : `http://localhost:5000${item.product.images[0]}`
//                         : item.product?.image
//                         ? item.product.image.startsWith("http") ? item.product.image : `http://localhost:5000${item.product.image}`
//                         : "/placeholder.png"
//                     }
//                     alt={item.product.name}
//                     className="summary-img"
//                   />
//                   <div className="summary-item-info">
//                     <p className="summary-item-name">{item.product.name}</p>
//                     <p className="summary-item-qty">Qty: {item.qty}</p>
//                   </div>
//                   <span className="summary-item-price">₹{item.product.price * item.qty}</span>
//                 </div>
//               ))}
//             </div>

//             {/* Coupon */}
//             <div className="coupon-section">
//               <div className="coupon-row">
//                 <span>🏷️ Coupon</span>
//                 <button className="coupon-btn" onClick={() => { if (!appliedCoupon) navigate("/coupons"); }}>
//                   {appliedCoupon ? "Applied ✅" : "Apply →"}
//                 </button>
//               </div>
//               {appliedCoupon && (
//                 <div className="coupon-applied">
//                   ✔ {appliedCoupon} — saved ₹{discount}
//                   <button className="coupon-remove" onClick={() => {
//                     sessionStorage.removeItem("appliedCoupon");
//                     sessionStorage.removeItem("discountAmount");
//                     sessionStorage.removeItem("finalTotal");
//                     setAppliedCoupon(""); setDiscount(0); setFinalTotal(0);
//                   }}>✕ Remove</button>
//                 </div>
//               )}
//             </div>

//             {/* Price Breakdown */}
//             <div style={{ marginBottom: 4 }}>
//               <div className="price-line">
//                 <span>Cart Total</span>
//                 <span>₹{total}</span>
//               </div>
//               <div className="price-line">
//                 <span>Delivery</span>
//                 <span className="free">{deliveryFee === 0 ? "FREE" : `₹${deliveryFee}`}</span>
//               </div>
//               {discount > 0 && (
//                 <div className="price-line">
//                   <span>Coupon Discount</span>
//                   <span className="saving">−₹{discount}</span>
//                 </div>
//               )}
//               {/* ✅ Membership Discount Row */}
//               {membershipDiscount > 0 && (
//                 <div className="price-line" style={{ background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 8, padding: "8px 10px", marginTop: 4 }}>
//                   <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
//                     <span>💳</span>
//                     <span style={{ color: "#ff6f00", fontWeight: 700 }}>{membershipPlanName} Plan</span>
//                   </span>
//                   <span className="saving">−₹{membershipDiscount}</span>
//                 </div>
//               )}
//             </div>

//             {/* ✅ Total with membership discount */}
//             <div className="total-row">
//               <span>Total Payable</span>
//               <span>₹{payAmount}</span>
//             </div>

//             {/* ✅ Savings note */}
//             {membershipDiscount > 0 && (
//               <div style={{ marginTop: 10, background: "linear-gradient(135deg, #fff8f2, #fff3e6)", border: "1.5px solid #ffe0c2", borderRadius: 10, padding: "8px 12px", display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 700, color: "#ff6f00" }}>
//                 🎉 Saving ₹{membershipDiscount} with {membershipPlanName} membership!
//               </div>
//             )}

//             <p style={{ marginTop: 12, textAlign: "center", fontSize: 12, color: "#bbb", fontWeight: 600 }}>
//               🔒 Safe & Secure Payments
//             </p>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default Payment;



import React, { useState, useContext, useEffect } from "react";
import StepIndicator from "../components/StepIndicator";
import { ShopContext } from "../context/ShopContext";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast } from "react-hot-toast";

const Payment = () => {
  const [method, setMethod] = useState("card");
  const { cart } = useContext(ShopContext);
  const [coupons, setCoupons] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [showCoupons, setShowCoupons] = useState(false);
  const [search, setSearch] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState("");
  const [discount, setDiscount] = useState(0);
  const [finalTotal, setFinalTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [membershipDiscount, setMembershipDiscount] = useState(0);
  const [membershipPlanName, setMembershipPlanName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardName, setCardName] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [saveCard, setSaveCard] = useState(false);
  const [upiId, setUpiId] = useState("");
  const [selectedWallet, setSelectedWallet] = useState("");
  const [selectedEmi, setSelectedEmi] = useState("");
  const [selectedBank, setSelectedBank] = useState("");

  const navigate = useNavigate();

  const total = cart.reduce(
    (acc, item) => acc + item.product.price * item.qty,
    0
  );

  const deliveryDate = sessionStorage.getItem("deliveryDate") || "";
  const deliveryFee = total < 500 ? Math.floor(total * 0.05) : 0;

  // ✅ payAmount with membership discount
  const payAmount = (finalTotal || total - discount + deliveryFee) - membershipDiscount;

  useEffect(() => {
    const code = sessionStorage.getItem("appliedCoupon");
    const disc = sessionStorage.getItem("discountAmount");
    const final = sessionStorage.getItem("finalTotal");
    if (code) setAppliedCoupon(code);
    if (disc) setDiscount(Number(disc));
    if (final) setFinalTotal(Number(final));
  }, []);

  useEffect(() => {
    const fetchCoupons = async () => {
      try {
        const token = sessionStorage.getItem("token");
        const res = await axios.get("http://localhost:5000/api/coupon", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setCoupons(res?.data || []);
      } catch (err) {
        console.error("Coupon fetch error:", err);
        setCoupons([]);
      }
    };
    fetchCoupons();
  }, []);

  // ✅ Membership fetch — after total is declared
  useEffect(() => {
    const fetchMembership = async () => {
      try {
        const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
        const token = userInfo?.token || sessionStorage.getItem("token");
        if (!token) return;
        const res = await axios.get(
          "http://localhost:5000/api/users/my-membership",
          { headers: { Authorization: `Bearer ${token}` } }
        );
        const mem = res.data;
        if (mem?.isActive && mem?.planId?.discount > 0) {
          const discAmt = Math.round((total * mem.planId.discount) / 100);
          setMembershipDiscount(discAmt);
          setMembershipPlanName(mem.planId.name);
        }
      } catch (err) {
        console.log("Membership fetch error:", err);
      }
    };
    fetchMembership();
  }, [total]);

  const applyCoupon = async (code) => {
    try {
      const token = sessionStorage.getItem("token");
      const res = await axios.post(
        "http://localhost:5000/api/coupon/apply",
        { code, subtotal: total },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setDiscount(res.data.discount);
      setAppliedCoupon(code);
      const final = total - res.data.discount + deliveryFee;
      sessionStorage.setItem("appliedCoupon", code);
      sessionStorage.setItem("discountAmount", res.data.discount);
      sessionStorage.setItem("finalTotal", final);
      setShowPopup(true);
      setTimeout(() => setShowPopup(false), 2500);
    } catch (err) {
      alert(err.response?.data?.message);
    }
  };

  const handlePayment = async () => {
    try {
      setLoading(true);
      const token = sessionStorage.getItem("token");
      if (!token) { toast.error("Login required ❌"); setLoading(false); return; }

      const addressId = sessionStorage.getItem("selectedAddress");
      if (!addressId) { toast.error("Select address first ❌"); setLoading(false); return; }

      if (method === "card") {
        if (!cardNumber || cardNumber.replace(/\s/g, "").length !== 16) { toast.error("Enter valid card number"); setLoading(false); return; }
        if (!cardName.trim()) { toast.error("Enter card holder name"); setLoading(false); return; }
        if (!expiry || expiry.length < 5) { toast.error("Enter valid expiry date (MM/YY)"); setLoading(false); return; }
        if (!cvv || cvv.length !== 3) { toast.error("Enter valid CVV"); setLoading(false); return; }
      }
      if (method === "upi") {
        if (!upiId.trim() || !upiId.includes("@")) { toast.error("Enter valid UPI ID"); setLoading(false); return; }
      }
      if (method === "wallet") {
        if (!selectedWallet) { toast.error("Please select a wallet"); setLoading(false); return; }
      }
      if (method === "emi") {
        if (!selectedBank || !selectedEmi) { toast.error("Please select bank and EMI option"); setLoading(false); return; }
      }

      const orderData = {
        orderItems: cart.map((item) => ({
          product: item.product._id,
          name: item.product.name,
          price: item.product.price,
          qty: item.qty,
          image: item.product.images?.[0] || "",
        })),
        addressId,
        totalPrice: payAmount, // ✅ uses discounted price
        paymentMethod: method.toUpperCase(),
        estimatedDelivery: deliveryDate,
      };

      const res = await fetch("http://localhost:5000/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(orderData),
      });

      const data = await res.json();
      if (!res.ok) { toast.error(data.message || "Order failed ❌"); setLoading(false); return; }

      toast.success("Order Placed Successfully 🎉");
      sessionStorage.setItem("orderSuccess", JSON.stringify(data.order));
      sessionStorage.removeItem("cart");
      setTimeout(() => navigate("/success"), 1500);
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong ❌");
    } finally {
      setLoading(false);
    }
  };

  const applicableCoupons = coupons.filter((c) => total >= c.minAmount);
  const notApplicableCoupons = coupons.filter((c) => total < c.minAmount);

  const payMethods = [
    { id: "card",   label: "Credit / Debit Card", icon: "💳" },
    { id: "upi",    label: "UPI",                 icon: "📱" },
    { id: "wallet", label: "Wallets",              icon: "👛" },
    { id: "emi",    label: "EMI",                  icon: "🏦" },
    { id: "cod",    label: "Cash on Delivery",     icon: "💵" },
  ];

  const formatCardNumber = (val) =>
    val.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .pay-root { font-family: 'Nunito', sans-serif; background: #fdf5ee; min-height: 100vh; padding: 28px 20px 60px; }
        .pay-title { font-size: 28px; font-weight: 800; color: #1a1a1a; letter-spacing: -0.4px; margin: 22px 0 20px; }
        .pay-layout { display: flex; gap: 22px; align-items: flex-start; }
        .method-tabs { width: 210px; flex-shrink: 0; background: #fff; border-radius: 16px; border: 1.5px solid #ffe0c2; overflow: hidden; box-shadow: 0 4px 16px rgba(255,111,0,0.07); }
        .method-tab { display: flex; align-items: center; gap: 10px; padding: 14px 16px; cursor: pointer; font-size: 13.5px; font-weight: 600; color: #555; border-bottom: 1px solid #f5ece4; transition: background 0.15s, color 0.15s; position: relative; }
        .method-tab:last-child { border-bottom: none; }
        .method-tab:hover { background: #fff8f2; color: #ff6f00; }
        .method-tab.active { background: #fff8f2; color: #ff6f00; font-weight: 800; }
        .method-tab.active::before { content: ''; position: absolute; left: 0; top: 0; width: 3px; height: 100%; background: linear-gradient(180deg, #ff6f00, #ffaa5a); border-radius: 0 2px 2px 0; }
        .method-tab .tab-icon { font-size: 16px; }
        .pay-center { flex: 1; background: #fff; border-radius: 18px; padding: 28px; border: 1.5px solid #ffe0c2; box-shadow: 0 4px 18px rgba(255,111,0,0.07); }
        .panel-title { font-size: 18px; font-weight: 800; color: #1a1a1a; margin-bottom: 22px; display: flex; align-items: center; gap: 8px; }
        .form-label { font-size: 12.5px; font-weight: 700; color: #777; text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 6px; display: block; }
        .form-input { width: 100%; padding: 12px 14px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 14px; font-family: 'Nunito', sans-serif; color: #1a1a1a; background: #fafafa; margin-bottom: 16px; transition: border-color 0.2s, box-shadow 0.2s; outline: none; }
        .form-input:focus { border-color: #ff6f00; box-shadow: 0 0 0 3px rgba(255,111,0,0.1); background: #fff; }
        .form-input::placeholder { color: #ccc; }
        .form-row { display: flex; gap: 14px; }
        .form-row .form-input { flex: 1; }
        .card-preview { background: linear-gradient(135deg, #ff6f00, #ff9500, #ffb347); border-radius: 16px; padding: 22px 24px; margin-bottom: 22px; color: #fff; position: relative; overflow: hidden; box-shadow: 0 8px 24px rgba(255,111,0,0.35); }
        .card-preview::before { content: ''; position: absolute; top: -30px; right: -30px; width: 120px; height: 120px; border-radius: 50%; background: rgba(255,255,255,0.1); }
        .card-preview::after { content: ''; position: absolute; bottom: -40px; left: 40px; width: 160px; height: 160px; border-radius: 50%; background: rgba(255,255,255,0.06); }
        .card-chip { width: 36px; height: 28px; background: rgba(255,255,255,0.3); border-radius: 6px; margin-bottom: 14px; }
        .card-num { font-size: 18px; font-weight: 700; letter-spacing: 3px; margin-bottom: 14px; font-family: 'Courier New', monospace; }
        .card-meta { display: flex; justify-content: space-between; font-size: 12px; opacity: 0.85; }
        .card-meta span { font-weight: 600; }
        .save-card-row { display: flex; align-items: center; gap: 8px; margin-bottom: 20px; font-size: 13.5px; color: #666; font-weight: 600; }
        .save-card-row input[type="checkbox"] { accent-color: #ff6f00; width: 16px; height: 16px; cursor: pointer; }
        .btn-pay { width: 100%; padding: 15px; background: linear-gradient(135deg, #ff6f00, #ff9500); color: #fff; border: none; border-radius: 12px; font-weight: 800; font-size: 15px; letter-spacing: 0.5px; cursor: pointer; transition: opacity 0.2s, transform 0.1s; box-shadow: 0 4px 16px rgba(255,111,0,0.35); font-family: 'Nunito', sans-serif; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .btn-pay:hover { opacity: 0.92; transform: translateY(-1px); }
        .btn-pay:active { transform: translateY(0); }
        .btn-pay:disabled { opacity: 0.6; cursor: not-allowed; }
        .btn-pay-cod { background: linear-gradient(135deg, #2e9e5b, #3ac97a); box-shadow: 0 4px 16px rgba(46,158,91,0.3); }
        .secure-note { text-align: center; font-size: 12px; color: #bbb; margin-top: 12px; display: flex; align-items: center; justify-content: center; gap: 5px; font-weight: 600; }
        .qr-box { background: #fff8f2; border: 1.5px dashed #ffcc99; border-radius: 14px; padding: 20px; text-align: center; margin-bottom: 20px; }
        .qr-box p { font-size: 13px; color: #888; font-weight: 600; margin-bottom: 12px; }
        .qr-box img { width: 130px; border-radius: 10px; border: 3px solid #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .upi-divider { text-align: center; color: #ccc; font-size: 13px; font-weight: 700; margin: 16px 0; position: relative; }
        .upi-divider::before, .upi-divider::after { content: ''; position: absolute; top: 50%; width: 44%; height: 1px; background: #eee; }
        .upi-divider::before { left: 0; }
        .upi-divider::after { right: 0; }
        .wallet-option { display: flex; justify-content: space-between; align-items: center; border: 1.5px solid #e8e8e8; border-radius: 12px; padding: 14px 16px; cursor: pointer; margin-bottom: 12px; transition: border-color 0.2s, box-shadow 0.2s, background 0.15s; font-size: 14px; font-weight: 700; color: #333; }
        .wallet-option:hover { border-color: #ffcc99; box-shadow: 0 4px 14px rgba(255,111,0,0.1); background: #fff8f2; }
        .wallet-option.selected { border-color: #ff6f00; background: #fff8f2; }
        .wallet-option .wallet-left { display: flex; align-items: center; gap: 10px; }
        .wallet-icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 18px; background: #fff; border: 1px solid #eee; }
        .wallet-badge { font-size: 11px; font-weight: 700; color: #2e9e5b; background: #edfaf4; padding: 3px 8px; border-radius: 6px; }
        .bank-select { width: 100%; padding: 12px 14px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 14px; font-family: 'Nunito', sans-serif; color: #1a1a1a; background: #fafafa; margin-bottom: 18px; outline: none; cursor: pointer; transition: border-color 0.2s; }
        .bank-select:focus { border-color: #ff6f00; }
        .emi-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px; }
        .emi-card { border: 1.5px solid #e8e8e8; border-radius: 12px; padding: 14px; cursor: pointer; transition: border-color 0.2s, box-shadow 0.2s, background 0.15s; }
        .emi-card:hover { border-color: #ffcc99; background: #fff8f2; }
        .emi-card.selected { border-color: #ff6f00; background: #fff8f2; }
        .emi-card .emi-months { font-size: 14px; font-weight: 800; color: #1a1a1a; margin-bottom: 4px; }
        .emi-card .emi-amount { font-size: 12px; color: #888; font-weight: 600; }
        .emi-card .emi-selected-badge { font-size: 11px; color: #ff6f00; font-weight: 700; margin-top: 4px; }
        .emi-note { font-size: 12px; color: #bbb; font-weight: 600; margin-bottom: 16px; }
        .cod-box { background: linear-gradient(135deg, #edfaf4, #f0fdf4); border: 1.5px solid #b6e9cf; border-radius: 14px; padding: 28px; text-align: center; margin-bottom: 20px; }
        .cod-icon { font-size: 52px; margin-bottom: 12px; }
        .cod-box h4 { font-size: 17px; font-weight: 800; color: #1a1a1a; margin-bottom: 8px; }
        .cod-box p { font-size: 13.5px; color: #666; line-height: 1.6; font-weight: 600; }
        .cod-perks { display: flex; justify-content: center; gap: 20px; margin-top: 14px; flex-wrap: wrap; }
        .cod-perk { font-size: 12px; color: #2e9e5b; font-weight: 700; display: flex; align-items: center; gap: 4px; }
        .summary-box { width: 320px; flex-shrink: 0; background: #fff; border-radius: 18px; padding: 22px; border: 1.5px solid #ffe0c2; box-shadow: 0 6px 24px rgba(255,111,0,0.09); position: sticky; top: 20px; }
        .summary-box h3 { font-size: 18px; font-weight: 800; color: #1a1a1a; border-bottom: 2px dashed #ffe0c2; padding-bottom: 14px; margin-bottom: 14px; }
        .summary-items { max-height: 200px; overflow-y: auto; margin-bottom: 14px; padding-right: 4px; }
        .summary-items::-webkit-scrollbar { width: 4px; }
        .summary-items::-webkit-scrollbar-thumb { background: #ffcc99; border-radius: 4px; }
        .summary-item { display: flex; gap: 10px; align-items: center; margin-bottom: 12px; }
        .summary-img { width: 44px; height: 44px; border-radius: 8px; object-fit: cover; border: 1.5px solid #ffe0c2; background: #fff8f2; flex-shrink: 0; }
        .summary-item-info { flex: 1; }
        .summary-item-name { font-size: 13px; font-weight: 700; color: #1a1a1a; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px; }
        .summary-item-qty { font-size: 12px; color: #aaa; font-weight: 600; }
        .summary-item-price { font-size: 13px; font-weight: 800; color: #1a1a1a; }
        .coupon-section { border-top: 1.5px dashed #ffe0c2; border-bottom: 1.5px dashed #ffe0c2; padding: 12px 0; margin: 4px 0 14px; }
        .coupon-row { display: flex; justify-content: space-between; align-items: center; font-size: 13.5px; font-weight: 700; color: #333; }
        .coupon-btn { font-size: 13px; font-weight: 800; color: #ff6f00; cursor: pointer; border: none; background: none; font-family: 'Nunito', sans-serif; padding: 0; }
        .coupon-applied { display: flex; align-items: center; gap: 6px; margin-top: 8px; font-size: 12px; color: #2e9e5b; font-weight: 700; background: #edfaf4; border: 1px solid #b6e9cf; border-radius: 8px; padding: 7px 10px; }
        .coupon-remove { margin-left: auto; font-size: 11px; color: #e53935; cursor: pointer; font-weight: 700; border: none; background: none; font-family: 'Nunito', sans-serif; }
        .price-line { display: flex; justify-content: space-between; font-size: 13.5px; color: #555; margin-bottom: 8px; font-weight: 600; }
        .price-line .free { color: #2e9e5b; font-weight: 800; }
        .price-line .saving { color: #2e9e5b; font-weight: 800; }
        .total-row { display: flex; justify-content: space-between; align-items: center; background: #fff8f2; border-radius: 10px; padding: 12px 14px; border: 1.5px solid #ffe0c2; margin-top: 12px; }
        .total-row span:first-child { font-size: 14px; font-weight: 700; color: #555; }
        .total-row span:last-child { font-size: 20px; font-weight: 800; color: #ff6f00; }
        .coupon-popup { position: fixed; top: 80px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg, #2e9e5b, #3ac97a); color: #fff; padding: 14px 28px; border-radius: 14px; font-weight: 800; font-size: 15px; box-shadow: 0 8px 24px rgba(46,158,91,0.35); z-index: 1000; display: flex; align-items: center; gap: 8px; animation: slideDown 0.3s ease; }
        @keyframes slideDown { from { opacity: 0; transform: translateX(-50%) translateY(-12px); } to { opacity: 1; transform: translateX(-50%) translateY(0); } }
        .loading-spinner { width: 18px; height: 18px; border: 2.5px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @media (max-width: 900px) { .pay-layout { flex-direction: column; } .method-tabs { width: 100%; display: flex; flex-wrap: wrap; } .method-tab { flex: 1; justify-content: center; border-right: 1px solid #f5ece4; } .summary-box { width: 100%; position: static; } }
      `}</style>

      {showPopup && (
        <div className="coupon-popup">🎉 Coupon applied! You saved ₹{discount}</div>
      )}

      <div className="pay-root">
        <StepIndicator step={3} />
        <h2 className="pay-title">Select Payment Mode</h2>

        <div className="pay-layout">
          {/* LEFT: Method Tabs */}
          <div className="method-tabs">
            {payMethods.map((m) => (
              <div key={m.id} onClick={() => setMethod(m.id)} className={`method-tab ${method === m.id ? "active" : ""}`}>
                <span className="tab-icon">{m.icon}</span>
                {m.label}
              </div>
            ))}
          </div>

          {/* CENTER: Payment Panel */}
          <div className="pay-center">

            {/* CARD */}
            {method === "card" && (
              <div>
                <p className="panel-title">💳 Credit / Debit Card</p>
                <div className="card-preview">
                  <div className="card-chip" />
                  <div className="card-num">{cardNumber || "•••• •••• •••• ••••"}</div>
                  <div className="card-meta">
                    <div>
                      <div style={{ fontSize: 10, opacity: 0.7, marginBottom: 2 }}>CARD HOLDER</div>
                      <span>{cardName || "YOUR NAME"}</span>
                    </div>
                    <div>
                      <div style={{ fontSize: 10, opacity: 0.7, marginBottom: 2 }}>EXPIRES</div>
                      <span>{expiry || "MM/YY"}</span>
                    </div>
                  </div>
                </div>
                <label className="form-label">Card Number</label>
                <input className="form-input" placeholder="1234 5678 9012 3456" value={cardNumber} onChange={(e) => setCardNumber(formatCardNumber(e.target.value))} maxLength={19} />
                <label className="form-label">Name on Card</label>
                <input className="form-input" placeholder="John Doe" value={cardName} onChange={(e) => setCardName(e.target.value.toUpperCase())} />
                <div className="form-row">
                  <div style={{ flex: 1 }}>
                    <label className="form-label">Expiry Date</label>
                    <input className="form-input" placeholder="MM / YY" value={expiry} onChange={(e) => setExpiry(e.target.value)} maxLength={7} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <label className="form-label">CVV</label>
                    <input className="form-input" placeholder="•••" type="password" value={cvv} onChange={(e) => setCvv(e.target.value.slice(0, 3))} maxLength={3} />
                  </div>
                </div>
                <div className="save-card-row">
                  <input type="checkbox" checked={saveCard} onChange={(e) => setSaveCard(e.target.checked)} />
                  Save this card for future payments
                </div>
                <button onClick={handlePayment} className="btn-pay" disabled={loading}>
                  {loading ? <span className="loading-spinner" /> : null}
                  {loading ? "Processing..." : `PAY ₹${payAmount}`}
                </button>
                <p className="secure-note">🔒 256-bit SSL encrypted • 100% Secure</p>
              </div>
            )}

            {/* UPI */}
            {method === "upi" && (
              <div>
                <p className="panel-title">📱 UPI Payment</p>
                <div className="qr-box">
                  <p>Scan QR code to pay instantly</p>
                  <img src="http://localhost:5000/uploads/Qr.png" alt="QR Code" />
                </div>
                <div className="upi-divider">OR ENTER UPI ID</div>
                <label className="form-label">UPI ID</label>
                <input className="form-input" placeholder="yourname@upi" value={upiId} onChange={(e) => setUpiId(e.target.value)} />
                <button onClick={handlePayment} className="btn-pay" disabled={loading}>
                  {loading ? <span className="loading-spinner" /> : null}
                  {loading ? "Processing..." : `PAY ₹${payAmount}`}
                </button>
                <p className="secure-note">🔒 Payments powered by UPI</p>
              </div>
            )}

            {/* WALLET */}
            {method === "wallet" && (
              <div>
                <p className="panel-title">👛 Pay via Wallet</p>
                {[
                  { name: "Paytm", icon: "🔵", badge: "Fast" },
                  { name: "PhonePe", icon: "🟣", badge: "Recommended" },
                  { name: "Amazon Pay", icon: "🟡", badge: "Cashback" },
                  { name: "Mobikwik", icon: "🔴", badge: "" },
                ].map((w) => (
                  <div key={w.name} className={`wallet-option ${selectedWallet === w.name ? "selected" : ""}`} onClick={() => setSelectedWallet(w.name)}>
                    <div className="wallet-left">
                      <div className="wallet-icon">{w.icon}</div>
                      {w.name}
                    </div>
                    {w.badge && <span className="wallet-badge">{w.badge}</span>}
                  </div>
                ))}
                <button onClick={handlePayment} className="btn-pay" disabled={loading}>
                  {loading ? <span className="loading-spinner" /> : null}
                  {loading ? "Processing..." : `PAY ₹${payAmount}`}
                </button>
              </div>
            )}

            {/* EMI */}
            {method === "emi" && (
              <div>
                <p className="panel-title">🏦 EMI Options</p>
                <label className="form-label">Select Bank</label>
                <select className="bank-select" value={selectedBank} onChange={(e) => setSelectedBank(e.target.value)}>
                  <option value="">Choose your bank</option>
                  <option>HDFC Bank</option>
                  <option>SBI</option>
                  <option>Axis Bank</option>
                  <option>ICICI Bank</option>
                  <option>Kotak Bank</option>
                </select>
                <label className="form-label" style={{ marginBottom: 10 }}>Choose Tenure</label>
                <div className="emi-grid">
                  {[
                    { months: "3 Months", amount: Math.ceil(payAmount / 3) },
                    { months: "6 Months", amount: Math.ceil(payAmount / 6) },
                    { months: "9 Months", amount: Math.ceil(payAmount / 9) },
                    { months: "12 Months", amount: Math.ceil(payAmount / 12) },
                  ].map((e) => (
                    <div key={e.months} className={`emi-card ${selectedEmi === e.months ? "selected" : ""}`} onClick={() => setSelectedEmi(e.months)}>
                      <p className="emi-months">{e.months}</p>
                      <p className="emi-amount">₹{e.amount}/month</p>
                      {selectedEmi === e.months && <p className="emi-selected-badge">✔ Selected</p>}
                    </div>
                  ))}
                </div>
                <p className="emi-note">* Interest rates may vary based on your bank</p>
                <button onClick={handlePayment} className="btn-pay" disabled={loading}>
                  {loading ? <span className="loading-spinner" /> : null}
                  {loading ? "Processing..." : `PAY ₹${payAmount}`}
                </button>
              </div>
            )}

            {/* COD */}
            {method === "cod" && (
              <div>
                <p className="panel-title">💵 Cash on Delivery</p>
                <div className="cod-box">
                  <div className="cod-icon">🚚</div>
                  <h4>Pay when your order arrives</h4>
                  <p>No need to share any payment details.<br />Pay in cash when your order is delivered.</p>
                  <div className="cod-perks">
                    <span className="cod-perk">✔ No hidden charges</span>
                    <span className="cod-perk">✔ 100% Safe</span>
                    <span className="cod-perk">✔ Easy returns</span>
                  </div>
                </div>
                {deliveryDate && (
                  <div style={{ background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 12, padding: "12px 16px", marginBottom: 18, fontSize: 13.5, fontWeight: 700, color: "#ff6f00", display: "flex", alignItems: "center", gap: 8 }}>
                    🗓️ Expected delivery by {deliveryDate}
                  </div>
                )}
                <button onClick={handlePayment} className="btn-pay btn-pay-cod" disabled={loading}>
                  {loading ? <span className="loading-spinner" /> : null}
                  {loading ? "Placing Order..." : "PLACE ORDER →"}
                </button>
                <p className="secure-note">📦 Order will be confirmed immediately</p>
              </div>
            )}
          </div>

          {/* RIGHT: Order Summary */}
          <div className="summary-box">
            <h3>Order Summary</h3>
            <div className="summary-items">
              {cart.map((item) => (
                <div key={item._id} className="summary-item">
                  <img
                    src={
                      item.product?.images?.length > 0
                        ? item.product.images[0].startsWith("http") ? item.product.images[0] : `http://localhost:5000${item.product.images[0]}`
                        : item.product?.image
                        ? item.product.image.startsWith("http") ? item.product.image : `http://localhost:5000${item.product.image}`
                        : "/placeholder.png"
                    }
                    alt={item.product.name}
                    className="summary-img"
                  />
                  <div className="summary-item-info">
                    <p className="summary-item-name">{item.product.name}</p>
                    <p className="summary-item-qty">Qty: {item.qty}</p>
                  </div>
                  <span className="summary-item-price">₹{item.product.price * item.qty}</span>
                </div>
              ))}
            </div>

            {/* Coupon */}
            <div className="coupon-section">
              <div className="coupon-row">
                <span>🏷️ Coupon</span>
                <button className="coupon-btn" onClick={() => { if (!appliedCoupon) navigate("/coupons"); }}>
                  {appliedCoupon ? "Applied ✅" : "Apply →"}
                </button>
              </div>
              {appliedCoupon && (
                <div className="coupon-applied">
                  ✔ {appliedCoupon} — saved ₹{discount}
                  <button className="coupon-remove" onClick={() => {
                    sessionStorage.removeItem("appliedCoupon");
                    sessionStorage.removeItem("discountAmount");
                    sessionStorage.removeItem("finalTotal");
                    setAppliedCoupon(""); setDiscount(0); setFinalTotal(0);
                  }}>✕ Remove</button>
                </div>
              )}
            </div>

            {/* Price Breakdown */}
            <div style={{ marginBottom: 4 }}>
              <div className="price-line">
                <span>Cart Total</span>
                <span>₹{total}</span>
              </div>
              <div className="price-line">
                <span>Delivery</span>
                <span className="free">{deliveryFee === 0 ? "FREE" : `₹${deliveryFee}`}</span>
              </div>
              {discount > 0 && (
                <div className="price-line">
                  <span>Coupon Discount</span>
                  <span className="saving">−₹{discount}</span>
                </div>
              )}
              {/* ✅ Membership Discount Row */}
              {membershipDiscount > 0 && (
                <div className="price-line" style={{ background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 8, padding: "8px 10px", marginTop: 4 }}>
                  <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span>💳</span>
                    <span style={{ color: "#ff6f00", fontWeight: 700 }}>{membershipPlanName} Plan</span>
                  </span>
                  <span className="saving">−₹{membershipDiscount}</span>
                </div>
              )}
            </div>

            {/* ✅ Total with membership discount */}
            <div className="total-row">
              <span>Total Payable</span>
              <span>₹{payAmount}</span>
            </div>

            {/* ✅ Savings note */}
            {membershipDiscount > 0 && (
              <div style={{ marginTop: 10, background: "linear-gradient(135deg, #fff8f2, #fff3e6)", border: "1.5px solid #ffe0c2", borderRadius: 10, padding: "8px 12px", display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 700, color: "#ff6f00" }}>
                🎉 Saving ₹{membershipDiscount} with {membershipPlanName} membership!
              </div>
            )}

            <p style={{ marginTop: 12, textAlign: "center", fontSize: 12, color: "#bbb", fontWeight: 600 }}>
              🔒 Safe & Secure Payments
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Payment;