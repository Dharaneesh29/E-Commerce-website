// import React, { useState } from "react";
// import UserHeader from "../components/Header/UserHeader";
// import Banner from "../components/Home/Banner";
// import Categories from "../components/Home/categories";
// import Products from "../components/Home/Products";
// import Sidebar from "../components/Home/Sidebar";

// const Home = ({ cart, addToCart }) => {
//   const [selectedCategory, setSelectedCategory] = useState("");

//   return (
//     <div className="min-h-screen bg-gradient-to-b from-[#fffaf5] to-[#f3f4f6]">
//       {/* Header */}
//       {/* <UserHeader cart={cart} /> */}

//       {/* Main Layout */}
//       <div className="max-w-7xl mx-auto px-6 mt-4 grid grid-cols-12 gap-4">
        
//         {/* LEFT SIDEBAR */}
//         <div className="col-span-2">
//           <div className="bg-white p-4 rounded-xl shadow">
//             <Sidebar setSelectedCategory={setSelectedCategory} />
//           </div>
//         </div>

//         {/* RIGHT CONTENT */}
//         <div className="col-span-10 flex flex-col">
          
//           {/* Banner */}
//           <div className="mb-6 rounded-xl overflow-hidden shadow">
//             <Banner />
//           </div>

//           {/* Products */}
//           <Products
//             category={selectedCategory}
//             addToCart={addToCart}
//           />

//         </div>
//       </div>
//     </div>
//   );
// };

// export default Home;


import React, { useState } from "react";
import UserHeader from "../components/Header/UserHeader";
import Banner from "../components/Home/Banner";
import Categories from "../components/Home/categories";
import Products from "../components/Home/Products";
import Sidebar from "../components/Home/Sidebar";
import Deals from "../components/Home/Deals";
import CategoryCards from "../components/Home/categoryCards";
import LatestProducts from "../components/Home/LatestProducts";
import BrandSlider from "../components/Home/BrandSlider";
const Home = ({ cart, addToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState("");
 
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#fffaf5] to-[#f3f4f6]">
      {/* Header */}
      {/* <UserHeader cart={cart} /> */}
 
      {/* Main Layout */}
      <div className="max-w-7xl mx-auto px-6 mt-4 grid grid-cols-12 gap-4">
       
        {/* LEFT SIDEBAR */}
        <div className="col-span-3">
          <div className="bg-white p-4 rounded-xl shadow">
            <Sidebar setSelectedCategory={setSelectedCategory} />
          </div>

          <LatestProducts/>
          <BrandSlider/>
        </div>
 
        {/* RIGHT CONTENT */}
        <div className="col-span-9 flex flex-col">
         
          {/* Banner */}
          <div className="mb-6 rounded-xl overflow-hidden shadow">
            <Banner />
          </div>
 
          {/* Products */}
          <Products
            category={selectedCategory}
            addToCart={addToCart}
          />
          
           <Deals addToCart={addToCart} />
 
          {/* Category Cards */}
           <CategoryCards />

 
        </div>
      </div>
    </div>
  );
};
 
export default Home;
 