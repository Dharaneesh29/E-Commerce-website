import { useEffect, useState } from "react";
import axios from "axios";
import {
  Tag, Percent, IndianRupee, Calendar,
  ToggleLeft, ToggleRight, Trash2, Plus,
  Loader2, CheckCircle, XCircle, Copy,
  Check, Ticket, TrendingUp, AlertCircle,
  Search, BadgePercent, RefreshCw,
  ShieldCheck, Clock, Flame,
} from "lucide-react";

const BASE = "http://localhost:5000/api/coupon";

const EMPTY_FORM = {
  code: "",
  discountType: "percentage",
  discountValue: "",
  minAmount: "",
  maxDiscount: "",
  expiryDate: "",
  isActive: true,
};

export default function AdminCoupons() {
  const [coupons,  setCoupons]  = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [saving,   setSaving]   = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [form,     setForm]     = useState(EMPTY_FORM);
  const [errors,   setErrors]   = useState({});
  const [toast,    setToast]    = useState(null);
  const [copied,   setCopied]   = useState(null);
  const [search,   setSearch]   = useState("");

  const getToken    = () => sessionStorage.getItem("token");
  const authHeaders = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const isExpired = (date) => date && new Date(date) < new Date();

  // ✅ Auto delete expired coupons from DB
  const deleteExpiredCoupons = async (allCoupons) => {
    const expiredList = allCoupons.filter(c => isExpired(c.expiryDate));
    if (expiredList.length === 0) return allCoupons;
    try {
      await Promise.all(
        expiredList.map(c => axios.delete(`${BASE}/${c._id}`, authHeaders()))
      );
      showToast(`🗑 Auto-removed ${expiredList.length} expired coupon(s)`);
      // Return only non-expired
      return allCoupons.filter(c => !isExpired(c.expiryDate));
    } catch (err) {
      console.log("Failed to delete expired coupons", err);
      return allCoupons;
    }
  };

  const fetchCoupons = async () => {
    setLoading(true);
    try {
      const res = await axios.get(BASE, authHeaders());
      const allCoupons = res.data || [];

      // ✅ Auto delete expired and update state
      const cleaned = await deleteExpiredCoupons(allCoupons);
      setCoupons(cleaned);
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to fetch coupons", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchCoupons(); }, []);

  const validate = () => {
    const e = {};
    if (!form.code.trim()) e.code = "Coupon code is required";
    else if (!/^[A-Z0-9_]+$/.test(form.code.toUpperCase())) e.code = "Only letters, numbers and underscore";
    if (!form.discountValue || Number(form.discountValue) <= 0) e.discountValue = "Enter a valid discount value";
    else if (form.discountType === "percentage" && Number(form.discountValue) > 100) e.discountValue = "Percentage cannot exceed 100";
    if (form.minAmount === "" || Number(form.minAmount) < 0) e.minAmount = "Enter minimum order amount";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleCreate = async () => {
    if (!validate()) return;
    setSaving(true);
    try {
      await axios.post(`${BASE}/create`, {
        code:          form.code.toUpperCase().trim(),
        discountType:  form.discountType,
        discountValue: Number(form.discountValue),
        minAmount:     Number(form.minAmount),
        maxDiscount:   form.maxDiscount ? Number(form.maxDiscount) : null,
        expiryDate:    form.expiryDate || null,
        isActive:      form.isActive,
      }, authHeaders());
      setForm(EMPTY_FORM);
      setErrors({});
      showToast("Coupon created successfully! 🎉");
      fetchCoupons();
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to create coupon", "error");
    } finally {
      setSaving(false);
    }
  };

  const toggleStatus = async (coupon) => {
    try {
      await axios.put(`${BASE}/${coupon._id}`, { isActive: !coupon.isActive }, authHeaders());
      showToast(`Coupon ${coupon.isActive ? "deactivated" : "activated"}`);
      fetchCoupons();
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to update status", "error");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this coupon permanently?")) return;
    setDeleting(id);
    try {
      await axios.delete(`${BASE}/${id}`, authHeaders());
      showToast("Coupon deleted");
      fetchCoupons();
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to delete", "error");
    } finally {
      setDeleting(null);
    }
  };

  const copyCoupon = (code) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    setTimeout(() => setCopied(null), 2000);
  };

  const generateCode = () => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const code = Array.from({ length: 8 }, () =>
      chars[Math.floor(Math.random() * chars.length)]
    ).join("");
    setForm({ ...form, code });
    setErrors({ ...errors, code: "" });
  };

  const filtered = coupons.filter((c) =>
    c.code.toLowerCase().includes(search.toLowerCase())
  );

  const active   = coupons.filter((c) => c.isActive && !isExpired(c.expiryDate)).length;
  const inactive = coupons.filter((c) => !c.isActive).length;
  const expired  = coupons.filter((c) => isExpired(c.expiryDate)).length;

  const inputCls = (hasErr) =>
    `w-full h-9 px-3 rounded-lg border text-sm outline-none transition-all bg-white text-gray-800 placeholder-gray-400
    ${hasErr
      ? "border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-100"
      : "border-orange-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-100"}`;

  return (
    <div className="min-h-screen bg-orange-50/60 p-4 md:p-5">

      {/* Toast */}
      {toast && (
        <div className={`fixed top-16 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5
          px-4 py-2.5 rounded-xl shadow-xl text-sm font-semibold border
          ${toast.type === "success"
            ? "bg-white border-orange-200 text-gray-800 shadow-orange-200/60"
            : "bg-white border-red-200 text-gray-800 shadow-red-200/60"}`}>
          <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0
            ${toast.type === "success" ? "bg-orange-100" : "bg-red-100"}`}>
            {toast.type === "success"
              ? <CheckCircle className="w-3.5 h-3.5 text-orange-500" />
              : <XCircle     className="w-3.5 h-3.5 text-red-500" />}
          </div>
          {toast.msg}
        </div>
      )}

      {/* Page Header */}
      <div style={{
        background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
        borderRadius: 22, padding: "26px 32px", marginBottom: 20,
        position: "relative", overflow: "hidden",
        boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
      }}>
        <div style={{ position:"absolute", top:-40, right:-40, width:180, height:180, borderRadius:"50%", background:"rgba(255,255,255,0.08)" }} />
        <div style={{ position:"absolute", bottom:-50, left:"35%", width:220, height:220, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }} />
        <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
          <div>
            <h1 style={{ margin:0, fontSize:28, fontWeight:900, color:"#fff", letterSpacing:-0.5 }}>🎫 Coupon Management</h1>
            <p style={{ margin:"5px 0 0", fontSize:13, color:"rgba(255,255,255,0.8)", fontWeight:700 }}>
              {coupons.length} total coupon{coupons.length !== 1 ? "s" : ""}
            </p>
          </div>
          <div style={{ display:"flex", gap:10 }}>
            <button onClick={fetchCoupons} style={{
              display:"flex", alignItems:"center", gap:8,
              padding:"10px 20px",
              background:"rgba(255,255,255,0.2)",
              color:"#fff", border:"1.5px solid rgba(255,255,255,0.4)",
              borderRadius:12, fontSize:13, fontWeight:800,
              cursor:"pointer", fontFamily:"inherit",
              backdropFilter:"blur(8px)",
            }}>
              ↻ Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        {[
          { label: "Total Coupons", value: coupons.length, icon: Tag,         gradient: "from-orange-400 to-amber-500", shadow: "shadow-orange-200/50", badge: "bg-orange-100 text-orange-600" },
          { label: "Active",        value: active,         icon: ShieldCheck, gradient: "from-green-400 to-emerald-500", shadow: "shadow-green-200/50",  badge: "bg-green-100 text-green-600"  },
          { label: "Inactive",      value: inactive,       icon: XCircle,     gradient: "from-gray-400 to-gray-500",    shadow: "shadow-gray-200/50",   badge: "bg-gray-100 text-gray-500"    },
          { label: "Expired",       value: expired,        icon: Clock,       gradient: "from-red-400 to-rose-500",     shadow: "shadow-red-200/50",    badge: "bg-red-100 text-red-500"      },
        ].map(({ label, value, icon: Icon, gradient, shadow, badge }) => (
          <div key={label}
            className={`bg-white rounded-2xl p-4 border border-orange-100/80
              shadow-md ${shadow} hover:shadow-lg transition-all duration-200 group`}>
            <div className="flex items-center justify-between mb-3">
              <div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${gradient}
                flex items-center justify-center shadow-md`}>
                <Icon className="w-4 h-4 text-white" />
              </div>
              <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${badge}`}>
                {label}
              </span>
            </div>
            <p className="text-3xl font-black text-gray-900">{value}</p>
          </div>
        ))}
      </div>

      {/* Main Grid */}
      <div className="grid lg:grid-cols-5 gap-5">

        {/* CREATE FORM */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl border border-orange-100 shadow-lg shadow-orange-100/50 overflow-hidden">

            {/* Form header */}
            <div className="relative px-5 py-4 overflow-hidden bg-gradient-to-r from-orange-500 to-amber-500">
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-white/10 rounded-full" />
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-black/10 rounded-full" />
              <div className="relative flex items-center gap-2.5">
                <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
                  <Plus className="w-4 h-4 text-white" />
                </div>
                <div>
                  <h2 className="text-white font-black text-base">Create New Coupon</h2>
                  <p className="text-orange-100 text-xs">Fill in the details below</p>
                </div>
              </div>
            </div>

            <div className="p-5 space-y-3.5">

              {/* Coupon Code */}
              <div>
                <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1.5">
                  Coupon Code *
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-orange-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      placeholder="e.g. SAVE20"
                      value={form.code}
                      onChange={(e) => { setForm({ ...form, code: e.target.value.toUpperCase() }); setErrors({ ...errors, code: "" }); }}
                      className={`${inputCls(errors.code)} pl-8 font-mono font-bold tracking-widest`}
                    />
                  </div>
                  <button type="button" onClick={generateCode}
                    className="px-3 h-9 bg-orange-50 border border-orange-200 text-orange-600
                      rounded-lg text-xs font-bold hover:bg-orange-500 hover:text-white
                      hover:border-orange-500 transition-all whitespace-nowrap">
                    Auto
                  </button>
                </div>
                {errors.code && (
                  <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.code}
                  </p>
                )}
              </div>

              {/* Discount Type */}
              <div>
                <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1.5">
                  Discount Type *
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { value: "percentage", label: "% Percentage", icon: Percent },
                    { value: "flat",       label: "₹ Flat",       icon: IndianRupee },
                  ].map(({ value, label, icon: Icon }) => (
                    <button key={value} type="button"
                      onClick={() => setForm({ ...form, discountType: value })}
                      className={`h-9 rounded-lg border text-xs font-bold
                        flex items-center justify-center gap-1.5 transition-all duration-150
                        ${form.discountType === value
                          ? "bg-orange-500 border-orange-500 text-white shadow-md shadow-orange-200/60"
                          : "bg-orange-50 border-orange-200 text-orange-600 hover:border-orange-400"}`}>
                      <Icon className="w-3.5 h-3.5" /> {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Discount Value */}
              <div>
                <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1.5">
                  Discount Value *
                </label>
                <div className="relative">
                  {form.discountType === "percentage"
                    ? <Percent     className="w-3.5 h-3.5 text-orange-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    : <IndianRupee className="w-3.5 h-3.5 text-orange-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />}
                  <input type="number" min="0"
                    placeholder={form.discountType === "percentage" ? "e.g. 20" : "e.g. 100"}
                    value={form.discountValue}
                    onChange={(e) => { setForm({ ...form, discountValue: e.target.value }); setErrors({ ...errors, discountValue: "" }); }}
                    className={`${inputCls(errors.discountValue)} pl-8`} />
                </div>
                {errors.discountValue && (
                  <p className="text-xs text-red-500 mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.discountValue}
                  </p>
                )}
              </div>

              {/* Min + Max */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1.5">
                    Min Order (₹) *
                  </label>
                  <div className="relative">
                    <IndianRupee className="w-3.5 h-3.5 text-orange-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input type="number" min="0" placeholder="400"
                      value={form.minAmount}
                      onChange={(e) => { setForm({ ...form, minAmount: e.target.value }); setErrors({ ...errors, minAmount: "" }); }}
                      className={`${inputCls(errors.minAmount)} pl-8`} />
                  </div>
                  {errors.minAmount && <p className="text-xs text-red-500 mt-1">{errors.minAmount}</p>}
                </div>
                <div>
                  <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1.5">
                    Max Discount (₹)
                  </label>
                  <div className="relative">
                    <TrendingUp className="w-3.5 h-3.5 text-orange-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input type="number" min="0" placeholder="150"
                      value={form.maxDiscount}
                      onChange={(e) => setForm({ ...form, maxDiscount: e.target.value })}
                      className={`${inputCls(false)} pl-8`} />
                  </div>
                </div>
              </div>

              {/* Expiry */}
              <div>
                <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest block mb-1.5">
                  Expiry Date <span className="text-gray-400 font-normal normal-case">(optional)</span>
                </label>
                <div className="relative">
                  <Calendar className="w-3.5 h-3.5 text-orange-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input type="date"
                    min={new Date().toISOString().split("T")[0]}
                    value={form.expiryDate}
                    onChange={(e) => setForm({ ...form, expiryDate: e.target.value })}
                    className={`${inputCls(false)} pl-8`} />
                </div>
              </div>

              {/* Active Toggle */}
              <div className="flex items-center justify-between bg-orange-50 rounded-xl px-3 py-2.5 border border-orange-100">
                <div>
                  <p className="text-sm font-bold text-gray-800">Active on creation</p>
                  <p className="text-xs text-orange-400">Coupon usable immediately</p>
                </div>
                <button type="button" onClick={() => setForm({ ...form, isActive: !form.isActive })}>
                  {form.isActive
                    ? <ToggleRight className="w-9 h-9 text-orange-500" />
                    : <ToggleLeft  className="w-9 h-9 text-gray-300" />}
                </button>
              </div>

              {/* Live Preview */}
              {form.code && form.discountValue && (
                <div className="rounded-xl overflow-hidden border border-orange-200">
                  <div className="bg-gradient-to-r from-orange-500 to-amber-500 px-4 py-3">
                    <p className="text-[9px] text-orange-100 font-bold uppercase tracking-widest mb-2 flex items-center gap-1">
                      <Flame className="w-2.5 h-2.5" /> Preview
                    </p>
                    <div className="flex items-center gap-3">
                      <div className="flex flex-col items-center justify-center bg-white/20 border border-dashed border-white/40 rounded-xl px-3 py-2 min-w-[60px]">
                        <span className="text-white font-black text-lg leading-none">
                          {form.discountType === "percentage" ? `${form.discountValue}%` : `₹${form.discountValue}`}
                        </span>
                        <span className="text-orange-100 text-[9px] font-bold mt-0.5">OFF</span>
                      </div>
                      <div>
                        <p className="font-mono font-black text-white text-base tracking-widest">{form.code}</p>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {form.minAmount && (
                            <span className="text-[9px] bg-white/20 text-white px-1.5 py-0.5 rounded-full border border-white/30">
                              Min ₹{form.minAmount}
                            </span>
                          )}
                          {form.maxDiscount && (
                            <span className="text-[9px] bg-white/20 text-white px-1.5 py-0.5 rounded-full border border-white/30">
                              Max ₹{form.maxDiscount}
                            </span>
                          )}
                          {form.expiryDate && (
                            <span className="text-[9px] bg-white/20 text-white px-1.5 py-0.5 rounded-full border border-white/30">
                              Exp: {new Date(form.expiryDate).toLocaleDateString("en-IN")}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Submit */}
              <button onClick={handleCreate} disabled={saving}
                className="w-full h-10 rounded-xl font-black text-sm text-white
                  bg-gradient-to-r from-orange-500 to-amber-500
                  hover:from-orange-600 hover:to-amber-600
                  disabled:opacity-50 disabled:cursor-not-allowed
                  shadow-lg shadow-orange-300/50
                  hover:scale-[1.01] active:scale-[0.99]
                  transition-all duration-150 flex items-center justify-center gap-2">
                {saving
                  ? <><Loader2 className="w-4 h-4 animate-spin" /> Creating...</>
                  : <><BadgePercent className="w-4 h-4" /> Create Coupon</>}
              </button>
            </div>
          </div>
        </div>

        {/* COUPON LIST */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-2xl border border-orange-100 shadow-lg shadow-orange-100/50 overflow-hidden">

            {/* List header */}
            <div className="px-5 py-3.5 border-b border-orange-50 flex items-center justify-between gap-3 flex-wrap bg-gradient-to-r from-orange-50/80 to-amber-50/40">
              <div className="flex items-center gap-2">
                <Ticket className="w-4 h-4 text-orange-500" />
                <h2 className="font-black text-gray-900 text-sm">All Coupons</h2>
                <span className="text-xs bg-orange-500 text-white px-2 py-0.5 rounded-full font-black shadow-sm shadow-orange-300/50">
                  {filtered.length}
                </span>
              </div>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-orange-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  placeholder="Search by code..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-48 h-8 pl-8 pr-3 rounded-lg border border-orange-200
                    bg-white text-gray-800 text-xs placeholder-gray-400
                    focus:outline-none focus:border-orange-500 focus:ring-2
                    focus:ring-orange-100 transition-all"
                />
              </div>
            </div>

            {/* List body */}
            <div className="p-3 space-y-2 max-h-[560px] overflow-y-auto">
              {loading ? (
                <div className="flex items-center justify-center py-16 gap-2 text-orange-400">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span className="text-sm font-semibold">Loading coupons...</span>
                </div>
              ) : filtered.length === 0 ? (
                <div className="text-center py-16">
                  <div className="w-14 h-14 bg-orange-50 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-orange-100">
                    <Ticket className="w-7 h-7 text-orange-300" />
                  </div>
                  <p className="text-gray-600 font-bold text-sm">No coupons found</p>
                  <p className="text-gray-400 text-xs mt-1">Create your first coupon</p>
                </div>
              ) : (
                filtered.map((coupon) => {
                  const exp  = isExpired(coupon.expiryDate);
                  const live = coupon.isActive && !exp;
                  return (
                    <div key={coupon._id}
                      className={`relative rounded-xl border p-3 transition-all duration-150 group
                        ${live
                          ? "bg-gradient-to-r from-orange-50/70 to-amber-50/30 border-orange-200 hover:border-orange-400 hover:shadow-md hover:shadow-orange-100"
                          : "bg-gray-50/80 border-gray-200 opacity-60"}`}>

                      <div className="flex items-center gap-3">

                        {/* Discount badge */}
                        <div className={`flex-shrink-0 w-16 h-14 rounded-xl flex flex-col items-center justify-center border-2 border-dashed
                          ${live ? "border-orange-300 bg-white shadow-sm shadow-orange-100" : "border-gray-300 bg-gray-100"}`}>
                          <span className={`font-black text-base leading-none ${live ? "text-orange-500" : "text-gray-400"}`}>
                            {coupon.discountType === "flat" ? `₹${coupon.discountValue}` : `${coupon.discountValue}%`}
                          </span>
                          <span className={`text-[9px] font-black mt-0.5 tracking-wider ${live ? "text-orange-400" : "text-gray-400"}`}>OFF</span>
                        </div>

                        {/* Info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 flex-wrap mb-1">
                            <span className="font-mono font-bold text-gray-900 tracking-normal text-sm">{coupon.code}</span>
                            {live && (
                              <span className="text-[9px] bg-green-100 text-green-600 border border-green-200 px-1.5 py-0.5 rounded-full font-black uppercase tracking-wide flex items-center gap-0.5">
                                <span className="w-1 h-1 bg-green-500 rounded-full animate-pulse inline-block" />
                                Live
                              </span>
                            )}
                            {!coupon.isActive && !exp && (
                              <span className="text-[9px] bg-gray-200 text-gray-500 border border-gray-300 px-1.5 py-0.5 rounded-full font-black uppercase">
                                Inactive
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-xs text-gray-500 flex items-center gap-0.5">
                              <IndianRupee className="w-3 h-3 text-orange-400" /> Min ₹{coupon.minAmount}
                            </span>
                            {coupon.maxDiscount && (
                              <span className="text-xs text-gray-500 flex items-center gap-0.5">
                                · <TrendingUp className="w-3 h-3 text-orange-400" /> Max ₹{coupon.maxDiscount}
                              </span>
                            )}
                            {coupon.expiryDate && (
                              <span className="text-xs text-gray-400 flex items-center gap-0.5">
                                · <Calendar className="w-3 h-3" />
                                {new Date(coupon.expiryDate).toLocaleDateString("en-IN")}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <button onClick={() => copyCoupon(coupon.code)} title="Copy"
                            className="w-8 h-8 flex items-center justify-center rounded-lg bg-orange-50 border border-orange-200 text-orange-500 hover:bg-orange-500 hover:text-white hover:border-orange-500 transition-all duration-150">
                            {copied === coupon.code ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>

                          <button onClick={() => toggleStatus(coupon)} title={coupon.isActive ? "Deactivate" : "Activate"}
                            className={`w-8 h-8 flex items-center justify-center rounded-lg border transition-all duration-150
                              ${coupon.isActive
                                ? "bg-green-50 border-green-200 text-green-500 hover:bg-green-500 hover:text-white hover:border-green-500"
                                : "bg-gray-50 border-gray-200 text-gray-400 hover:bg-gray-200"}`}>
                            {coupon.isActive ? <ToggleRight className="w-3.5 h-3.5" /> : <ToggleLeft className="w-3.5 h-3.5" />}
                          </button>

                          <button onClick={() => handleDelete(coupon._id)} disabled={deleting === coupon._id} title="Delete"
                            className="w-8 h-8 flex items-center justify-center rounded-lg bg-red-50 border border-red-200 text-red-400 hover:bg-red-500 hover:text-white hover:border-red-500 transition-all duration-150 disabled:opacity-40">
                            {deleting === coupon._id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
