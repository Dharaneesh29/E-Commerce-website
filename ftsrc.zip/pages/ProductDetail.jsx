// // import { useParams , useNavigate } from "react-router-dom";

// // import React , { useState} from "react";
// // import { useContext} from "react";
// // import { ShopContext } from "../context/ShopContext";

// // const ProductDetails = () => {
// //   const { id } = useParams();
// //   const navigate=useNavigate();

// //   const {products,addToCart,buyNow}=useContext(ShopContext);
  

// //   const product = products.find(
// //     (item) => item.id === Number(id)
// //   );

// //   console.log("Current Product:",product);

// //    const [qty,setQty]=useState(1);

// //   if (!product) return <p className="p-5">Product not found</p>;

// //   return (
// //     <div className="p-6 bg-gray-100 min-h-screen">
// //       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-white p-6 rounded shadow">

// //         {/* LEFT - IMAGE */}
// //         <div>
// //           <img
// //             src={product.image}
// //             alt={product.name}
// //             className="w-full h-[400px] object-contain"
// //           />

// //           {/* Thumbnails */}
// //           <div className="flex gap-2 mt-3">
// //             {[1, 2, 3, 4].map((_, i) => (
// //               <img
// //                 key={i}
// //                 src={product.image}
// //                 className="w-16 h-16 border p-1 cursor-pointer"
// //               />
// //             ))}
// //           </div>
// //         </div>

// //         {/* CENTER - DETAILS */}
// //         <div>
// //           <h1 className="text-xl font-semibold">{product.name}</h1>
// //           <p className="text-blue-600 text-sm">Visit {product.brand} Store</p>

// //           {/* Rating */}
// //           <div className="flex items-center gap-2 mt-2">
// //             <span className="bg-green-600 text-white px-2 py-1 text-sm rounded">
// //               {product.rating} ★
// //             </span>
// //             <span className="text-sm text-gray-600">(12,345 reviews)</span>
// //           </div>

// //           {/* Price */}
// //           <div className="mt-3">
// //             <p className="text-red-600 text-lg font-semibold">
// //               -43% ₹{product.price}
// //             </p>
// //             <p className="text-gray-500 line-through text-sm">
// //               ₹{product.price + 2000}
// //             </p>
// //             <p className="text-sm">Inclusive of all taxes</p>
// //           </div>



// //           {/* Offers */}
// //           <div className="mt-4">
// //             <h3 className="font-semibold mb-2">Offers</h3>
// //             <div className="grid grid-cols-2 gap-2 text-sm">
// //               <div className="border p-2 rounded">
// //                 💳 Bank Offer: 10% Cashback
// //               </div>
// //               <div className="border p-2 rounded">
// //                 ⚡ No Cost EMI Available
// //               </div>
// //               <div className="border p-2 rounded">
// //                 💰 ₹500 Discount Coupon
// //               </div>
// //               <div className="border p-2 rounded">
// //                 🚚 Free Delivery
// //               </div>
// //             </div>
// //           </div>

// //           {/* Specs */}
// //           <div className="mt-5">
// //             <h3 className="font-semibold mb-2">Product Details</h3>
// //             <table className="text-sm">
// //               <tbody>
// //                 <tr>
// //                   <td className="pr-4 text-gray-500">Brand</td>
// //                   <td>{product.brand}</td>
// //                 </tr>
// //                 <tr>
// //                   <td className="pr-4 text-gray-500">Category</td>
// //                   <td>{product.category}</td>
// //                 </tr>
// //                 <tr>
// //                   <td className="pr-4 text-gray-500">Rating</td>
// //                   <td>{product.rating}</td>
// //                 </tr>
// //               </tbody>
// //             </table>
// //           </div>

// //           {/* About */}
// //           <div className="mt-5">
// //             <h3 className="font-semibold mb-2">About this item</h3>
// //             <ul className="list-disc ml-5 text-sm text-gray-700">
// //               <li>High quality product</li>
// //               <li>Best in class performance</li>
// //               <li>Durable and reliable</li>
// //               <li>Trusted brand product</li>
// //             </ul>
// //           </div>
// //         </div>

// //         {/* RIGHT - BUY BOX */}
// //         <div className="border p-4 rounded h-fit">
// //           <p className="text-2xl font-semibold">₹{product.price}</p>
// //          {/*<p className="text-green-600 text-sm">In stock</p>*/}

// //          <p className ="text-sm text-green-600">
// //             {product.stock > 0 ? "In Stock" : " Out of Stock"}
// //          </p>

// //          {product.stock>0 && product.stock<=5 && ( 
// //             <p className="text-red-500 text-sm">
// //                 Only {product.stock} left in stock!</p>
// //          )}

// //           <p className="text-sm mt-2">
// //             FREE delivery by tomorrow
// //           </p>

         

// //           <select value={qty} onChange={(e)=>
// //             setQty(Number(e.target.value))}
// //             className="border mt-3 p-2 w-full">
// //                 {[...Array(5)].map((_, i)=>
// //             (
// //                 <option key={i+1} value={i+1}>
// //                     Qty:{i+1}
// //                 </option>
// //             ))}
                
// //             </select>
          
// //           {/*Add to cart*/}
// //           <button onClick={()=>addToCart({...product,qty})}
// //         disabled={product.stock===0}
// //     className={`w-full py-2 mt-4 rounded font-semibold ${
// //         product.stock===0 ? "bg-gray-400 cursor-not-allowed" : "bg-yellow-400 hover:bg-yellow-500"
// //     }`}
// //     >
// //         Add to Cart</button>
    
// //     {/*buy now*/}
// //     <button onClick={()=>{
// //         buyNow(product.id,qty);
// //         navigate("/payment");
// //     }}

// //         disabled={product.stock===0}
// //     className={`w-full py-2 mt-4 rounded font-semibold ${
// //         product.stock===0 ? "bg-gray-400 cursor-not-allowed" : "bg-orange-500 text-white hover:bg-orange-600"
// //     }`}
// //     >
// //         Buy Now</button>

// //           {/* Services */}
// //           <div className="mt-4 text-sm text-gray-600 space-y-1">
// //             <p>🚚 Free Delivery</p>
// //             <p>🔄 7 Days Replacement</p>
// //             <p>🛡 1 Year Warranty</p>
// //             <p>💵 Pay on Delivery</p>
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default ProductDetails;


// import React, { useEffect, useState } from "react";
// import { useParams } from "react-router-dom";
// import axios from "axios";
 
// // import Header from "../components/Header";
// import ProductImages from "../components/Product/productImage";
//  import ProductInfo from "../components/Product/productInfo";
// import ProductTabs from "../components/Product/ProductTab";
// import ProductReviews from "../components/Product/productReviews";
// import SimilarProducts from "../components/Product/productSimilar";
 
// const ProductDetail = () => {
//   const { id } = useParams();
//   const [product, setProduct] = useState(null);
 
//   // 🔥 FETCH PRODUCT
//   useEffect(() => {
//     const fetchProduct = async () => {
//       try {
//         const { data } = await axios.get(
//           `http://localhost:5000/api/products/${id}`
//         );
//         setProduct(data);
//       } catch (err) {
//         console.log(err);
//       }
//     };
 
//     fetchProduct();
//   }, [id]);
 
//   if (!product) return <p className="p-5">Loading...</p>;
 
//   return (
//     <>
//       {/* 🔶 HEADER */}
//       {/* <Header /> */}
 
//       {/* 🔶 MAIN PAGE */}
//       <div className="bg-orange-50 min-h-screen">
//         <div className="max-w-6xl mx-auto p-5">
 
//           {/* 🔶 PRODUCT SECTION */}
//           <div className="grid grid-cols-1 md:grid-cols-2 gap-10 bg-white p-5 rounded-xl shadow-sm">
 
//             {/* LEFT */}
//             <ProductImages product={product} />
 
//             {/* RIGHT */}
//              <ProductInfo product={product} /> 

             
 
//           </div>

//           <ProductTabs product={product}/>
//           <ProductReviews product={product}/>
//           <SimilarProducts productId={product._id}/>
 
//         </div>
//       </div>
//     </>
//   );
// };
 
// export default ProductDetail;
 // import { useParams , useNavigate } from "react-router-dom";

// import React , { useState} from "react";
// import { useContext} from "react";
// import { ShopContext } from "../context/ShopContext";

// const ProductDetails = () => {
//   const { id } = useParams();
//   const navigate=useNavigate();

//   const {products,addToCart,buyNow}=useContext(ShopContext);
  

//   const product = products.find(
//     (item) => item.id === Number(id)
//   );

//   console.log("Current Product:",product);

//    const [qty,setQty]=useState(1);

//   if (!product) return <p className="p-5">Product not found</p>;

//   return (
//     <div className="p-6 bg-gray-100 min-h-screen">
//       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-white p-6 rounded shadow">

//         {/* LEFT - IMAGE */}
//         <div>
//           <img
//             src={product.image}
//             alt={product.name}
//             className="w-full h-[400px] object-contain"
//           />

//           {/* Thumbnails */}
//           <div className="flex gap-2 mt-3">
//             {[1, 2, 3, 4].map((_, i) => (
//               <img
//                 key={i}
//                 src={product.image}
//                 className="w-16 h-16 border p-1 cursor-pointer"
//               />
//             ))}
//           </div>
//         </div>

//         {/* CENTER - DETAILS */}
//         <div>
//           <h1 className="text-xl font-semibold">{product.name}</h1>
//           <p className="text-blue-600 text-sm">Visit {product.brand} Store</p>

//           {/* Rating */}
//           <div className="flex items-center gap-2 mt-2">
//             <span className="bg-green-600 text-white px-2 py-1 text-sm rounded">
//               {product.rating} ★
//             </span>
//             <span className="text-sm text-gray-600">(12,345 reviews)</span>
//           </div>

//           {/* Price */}
//           <div className="mt-3">
//             <p className="text-red-600 text-lg font-semibold">
//               -43% ₹{product.price}
//             </p>
//             <p className="text-gray-500 line-through text-sm">
//               ₹{product.price + 2000}
//             </p>
//             <p className="text-sm">Inclusive of all taxes</p>
//           </div>



//           {/* Offers */}
//           <div className="mt-4">
//             <h3 className="font-semibold mb-2">Offers</h3>
//             <div className="grid grid-cols-2 gap-2 text-sm">
//               <div className="border p-2 rounded">
//                 💳 Bank Offer: 10% Cashback
//               </div>
//               <div className="border p-2 rounded">
//                 ⚡ No Cost EMI Available
//               </div>
//               <div className="border p-2 rounded">
//                 💰 ₹500 Discount Coupon
//               </div>
//               <div className="border p-2 rounded">
//                 🚚 Free Delivery
//               </div>
//             </div>
//           </div>

//           {/* Specs */}
//           <div className="mt-5">
//             <h3 className="font-semibold mb-2">Product Details</h3>
//             <table className="text-sm">
//               <tbody>
//                 <tr>
//                   <td className="pr-4 text-gray-500">Brand</td>
//                   <td>{product.brand}</td>
//                 </tr>
//                 <tr>
//                   <td className="pr-4 text-gray-500">Category</td>
//                   <td>{product.category}</td>
//                 </tr>
//                 <tr>
//                   <td className="pr-4 text-gray-500">Rating</td>
//                   <td>{product.rating}</td>
//                 </tr>
//               </tbody>
//             </table>
//           </div>

//           {/* About */}
//           <div className="mt-5">
//             <h3 className="font-semibold mb-2">About this item</h3>
//             <ul className="list-disc ml-5 text-sm text-gray-700">
//               <li>High quality product</li>
//               <li>Best in class performance</li>
//               <li>Durable and reliable</li>
//               <li>Trusted brand product</li>
//             </ul>
//           </div>
//         </div>

//         {/* RIGHT - BUY BOX */}
//         <div className="border p-4 rounded h-fit">
//           <p className="text-2xl font-semibold">₹{product.price}</p>
//          {/*<p className="text-green-600 text-sm">In stock</p>*/}

//          <p className ="text-sm text-green-600">
//             {product.stock > 0 ? "In Stock" : " Out of Stock"}
//          </p>

//          {product.stock>0 && product.stock<=5 && ( 
//             <p className="text-red-500 text-sm">
//                 Only {product.stock} left in stock!</p>
//          )}

//           <p className="text-sm mt-2">
//             FREE delivery by tomorrow
//           </p>

         

//           <select value={qty} onChange={(e)=>
//             setQty(Number(e.target.value))}
//             className="border mt-3 p-2 w-full">
//                 {[...Array(5)].map((_, i)=>
//             (
//                 <option key={i+1} value={i+1}>
//                     Qty:{i+1}
//                 </option>
//             ))}
                
//             </select>
          
//           {/*Add to cart*/}
//           <button onClick={()=>addToCart({...product,qty})}
//         disabled={product.stock===0}
//     className={`w-full py-2 mt-4 rounded font-semibold ${
//         product.stock===0 ? "bg-gray-400 cursor-not-allowed" : "bg-yellow-400 hover:bg-yellow-500"
//     }`}
//     >
//         Add to Cart</button>
    
//     {/*buy now*/}
//     <button onClick={()=>{
//         buyNow(product.id,qty);
//         navigate("/payment");
//     }}

//         disabled={product.stock===0}
//     className={`w-full py-2 mt-4 rounded font-semibold ${
//         product.stock===0 ? "bg-gray-400 cursor-not-allowed" : "bg-orange-500 text-white hover:bg-orange-600"
//     }`}
//     >
//         Buy Now</button>

//           {/* Services */}
//           <div className="mt-4 text-sm text-gray-600 space-y-1">
//             <p>🚚 Free Delivery</p>
//             <p>🔄 7 Days Replacement</p>
//             <p>🛡 1 Year Warranty</p>
//             <p>💵 Pay on Delivery</p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ProductDetails;


import React, { useEffect, useState,useContext } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { WishlistContext } from "../context/WishlistContext";
 
// import Header from "../components/Header";
import ProductImages from "../components/Product/productImage";
 import ProductInfo from "../components/Product/productInfo";
import ProductTabs from "../components/Product/ProductTab";
import ProductReviews from "../components/Product/productReviews";
import SimilarProducts from "../components/Product/productSimilar";
 
const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
 
  // 🔥 FETCH PRODUCT
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const { data } = await axios.get(
          `http://localhost:5000/api/products/${id}`
        );
        setProduct(data);
      } catch (err) {
        console.log(err);
      }
    };
 
    fetchProduct();
  }, [id]);
 
  if (!product) return <p className="p-5">Loading...</p>;
 
  return (
    <>
      {/* 🔶 HEADER */}
      {/* <Header /> */}
 
      {/* 🔶 MAIN PAGE */}
      <div className="bg-orange-50 min-h-screen">
        <div className="max-w-6xl mx-auto p-5">
 
          {/* 🔶 PRODUCT SECTION */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 bg-white p-5 rounded-xl shadow-sm">
 
            {/* LEFT */}
            <ProductImages product={product} />
 
            {/* RIGHT */}
             <ProductInfo product={product} /> 

             
 
          </div>

          <ProductTabs product={product}/>
          <ProductReviews product={product}/>
          <SimilarProducts productId={product._id}/>
 
        </div>
      </div>
    </>
  );
};
 
export default ProductDetail;
 