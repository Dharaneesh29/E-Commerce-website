import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { WishlistContext } from "../context/WishlistContext";
import { ShopContext } from "../context/ShopContext";
import toast from "react-hot-toast";

const Wishlist = () => {
  const { wishlist, toggleWishlist, loading } = useContext(WishlistContext);
  const { addToCart } = useContext(ShopContext);
  const navigate = useNavigate();

  const [removingIds, setRemovingIds] = useState([]);

  // ── SKELETON LOADING ──
  if (loading) {
    return (
      <>
        <style>{`
          @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
          @keyframes shimmer {
            0% { background-position: -600px 0; }
            100% { background-position: 600px 0; }
          }
          .skeleton {
            font-family: 'Nunito', sans-serif;
            background: linear-gradient(90deg, #f5ece4 25%, #ffe8d0 50%, #f5ece4 75%);
            background-size: 600px 100%;
            animation: shimmer 1.4s infinite linear;
            border-radius: 18px;
          }
        `}</style>
        <div style={{ fontFamily: "'Nunito', sans-serif", background: "#fdf5ee", minHeight: "100vh", padding: "32px 24px" }}>
          <div style={{ maxWidth: 1180, margin: "0 auto" }}>
            <div className="skeleton" style={{ height: 38, width: 240, marginBottom: 32, borderRadius: 12 }} />
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
              {[...Array(8)].map((_, i) => (
                <div key={i}>
                  <div className="skeleton" style={{ height: 220, marginBottom: 12 }} />
                  <div className="skeleton" style={{ height: 16, width: "70%", marginBottom: 8 }} />
                  <div className="skeleton" style={{ height: 14, width: "40%" }} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </>
    );
  }

  // ── EMPTY STATE ──
  if (wishlist.length === 0) {
    return (
      <>
        <style>{`@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');`}</style>
        <div style={{
          fontFamily: "'Nunito', sans-serif",
          background: "#fdf5ee",
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: 24,
        }}>
          <div style={{
            background: "#fff",
            borderRadius: 24,
            border: "1.5px solid #ffe0c2",
            boxShadow: "0 12px 40px rgba(255,111,0,0.1)",
            padding: "56px 48px",
            textAlign: "center",
            maxWidth: 420,
            position: "relative",
            overflow: "hidden",
          }}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 4, background: "linear-gradient(90deg, #ff6f00, #ffaa5a)" }} />
            <div style={{ fontSize: 72, marginBottom: 20, lineHeight: 1 }}>💝</div>
            <h2 style={{ fontSize: 24, fontWeight: 900, color: "#1a1a1a", marginBottom: 10, letterSpacing: -0.4 }}>
              Your Wishlist is Empty
            </h2>
            <p style={{ fontSize: 14.5, color: "#aaa", fontWeight: 600, lineHeight: 1.6, marginBottom: 28 }}>
              Save the things you love.<br />Start adding products to your wishlist!
            </p>
            <button
              onClick={() => navigate("/home")}
              style={{
                padding: "13px 32px",
                background: "linear-gradient(135deg, #ff6f00, #ff9500)",
                color: "#fff",
                border: "none",
                borderRadius: 12,
                fontWeight: 800,
                fontSize: 14.5,
                cursor: "pointer",
                fontFamily: "inherit",
                boxShadow: "0 4px 16px rgba(255,111,0,0.32)",
                transition: "opacity 0.2s, transform 0.1s",
              }}
              onMouseOver={e => e.currentTarget.style.opacity = 0.9}
              onMouseOut={e => e.currentTarget.style.opacity = 1}
            >
              Explore Products →
            </button>
          </div>
        </div>
      </>
    );
  }

  const inStockCount = wishlist.filter(p => p.countInStock > 0).length;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }

        .wl-root {
          font-family: 'Nunito', sans-serif;
          background: #fdf5ee;
          min-height: 100vh;
          padding: 32px 24px 60px;
        }

        .wl-inner { max-width: 1180px; margin: 0 auto; }

        /* ── HEADER ── */
        .wl-header {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          margin-bottom: 28px;
          flex-wrap: wrap;
          gap: 16px;
        }
        .wl-title-wrap {}
        .wl-title {
          font-size: 30px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.5px;
          display: flex;
          align-items: center;
          gap: 10px;
          margin-bottom: 4px;
        }
        .wl-title-icon {
          width: 40px; height: 40px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-radius: 12px;
          display: flex; align-items: center; justify-content: center;
          font-size: 18px;
          box-shadow: 0 4px 12px rgba(255,111,0,0.3);
        }
        .wl-subtitle {
          font-size: 13.5px;
          color: #aaa;
          font-weight: 700;
        }
        .wl-subtitle span { color: #ff6f00; font-weight: 800; }

        .wl-actions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }

        .btn-move-all {
          padding: 11px 22px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          box-shadow: 0 4px 14px rgba(255,111,0,0.3);
          transition: opacity 0.2s, transform 0.1s;
          display: flex; align-items: center; gap: 7px;
        }
        .btn-move-all:hover { opacity: 0.9; transform: translateY(-1px); }

        /* ── STATS BAR ── */
        .wl-stats {
          display: flex;
          gap: 12px;
          margin-bottom: 24px;
          flex-wrap: wrap;
        }
        .wl-stat {
          background: #fff;
          border: 1.5px solid #ffe0c2;
          border-radius: 12px;
          padding: 12px 18px;
          display: flex;
          align-items: center;
          gap: 10px;
          box-shadow: 0 2px 8px rgba(255,111,0,0.05);
        }
        .wl-stat-icon {
          width: 34px; height: 34px;
          border-radius: 9px;
          background: #fff8f2;
          display: flex; align-items: center; justify-content: center;
          font-size: 16px;
        }
        .wl-stat-val { font-size: 18px; font-weight: 900; color: #ff6f00; line-height: 1; }
        .wl-stat-label { font-size: 11.5px; color: #aaa; font-weight: 700; }

        /* ── GRID ── */
        .wl-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 18px;
        }

        /* ── CARD ── */
        .wl-card {
          background: #fff;
          border-radius: 18px;
          border: 1.5px solid #f0e8e0;
          box-shadow: 0 3px 14px rgba(255,111,0,0.06);
          overflow: hidden;
          position: relative;
          transition: box-shadow 0.22s, border-color 0.22s, transform 0.2s, opacity 0.3s;
        }
        .wl-card:hover {
          box-shadow: 0 10px 32px rgba(255,111,0,0.14);
          border-color: #ffcc99;
          transform: translateY(-3px);
        }
        .wl-card.removing {
          opacity: 0;
          transform: scale(0.93) translateY(8px);
        }
        .wl-card.out-of-stock {
          opacity: 0.55;
          filter: grayscale(0.6);
        }

        /* Orange top accent on hover */
        .wl-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 3px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
          opacity: 0;
          transition: opacity 0.2s;
          z-index: 2;
        }
        .wl-card:hover::before { opacity: 1; }

        /* ── IMAGE WRAP ── */
        .wl-img-wrap {
          position: relative;
          height: 190px;
          overflow: hidden;
          background: #fff8f2;
          cursor: pointer;
        }
        .wl-img {
          width: 100%; height: 100%;
          object-fit: cover;
          transition: transform 0.4s ease;
        }
        .wl-card:hover .wl-img { transform: scale(1.05); }

        /* Out of stock overlay */
        .wl-oos-overlay {
          position: absolute;
          inset: 0;
          background: rgba(255,255,255,0.55);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 3;
        }
        .wl-oos-tag {
          background: #e53935;
          color: #fff;
          font-size: 11px;
          font-weight: 900;
          padding: 5px 12px;
          border-radius: 20px;
          letter-spacing: 0.5px;
        }

        /* Remove button */
        .wl-remove-btn {
          position: absolute;
          top: 10px; right: 10px;
          z-index: 10;
          width: 32px; height: 32px;
          background: rgba(255,255,255,0.92);
          border: 1.5px solid #f0e0d0;
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          cursor: pointer;
          font-size: 13px;
          color: #aaa;
          backdrop-filter: blur(4px);
          transition: background 0.15s, color 0.15s, border-color 0.15s, transform 0.1s;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .wl-remove-btn:hover {
          background: #e53935;
          color: #fff;
          border-color: #e53935;
          transform: scale(1.1);
        }

        /* Quick view badge */
        .wl-quick-view {
          position: absolute;
          bottom: 10px; left: 50%;
          transform: translateX(-50%) translateY(6px);
          background: rgba(26,26,26,0.82);
          color: #fff;
          font-size: 11.5px;
          font-weight: 800;
          padding: 5px 14px;
          border-radius: 20px;
          white-space: nowrap;
          opacity: 0;
          transition: opacity 0.2s, transform 0.2s;
          pointer-events: none;
          backdrop-filter: blur(4px);
          font-family: 'Nunito', sans-serif;
        }
        .wl-img-wrap:hover .wl-quick-view {
          opacity: 1;
          transform: translateX(-50%) translateY(0);
        }

        /* ── CARD BODY ── */
        .wl-card-body { padding: 14px 14px 16px; }

        .wl-product-name {
          font-size: 13.5px;
          font-weight: 800;
          color: #1a1a1a;
          line-height: 1.4;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
          margin-bottom: 8px;
          cursor: pointer;
          transition: color 0.15s;
        }
        .wl-product-name:hover { color: #ff6f00; }

        .wl-price-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 12px;
        }
        .wl-price {
          font-size: 17px;
          font-weight: 900;
          color: #ff6f00;
        }

        /* Move to cart button */
        .wl-cart-btn {
          width: 100%;
          padding: 10px;
          border-radius: 11px;
          font-weight: 800;
          font-size: 13px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          border: none;
          transition: opacity 0.2s, transform 0.1s, background 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
        }
        .wl-cart-btn.available {
          background: linear-gradient(135deg, #1a1a1a, #333);
          color: #fff;
          box-shadow: 0 3px 10px rgba(0,0,0,0.15);
        }
        .wl-cart-btn.available:hover {
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          transform: translateY(-1px);
          box-shadow: 0 4px 14px rgba(255,111,0,0.3);
        }
        .wl-cart-btn.unavailable {
          background: #f0ebe6;
          color: #bbb;
          cursor: not-allowed;
        }

        @media (max-width: 1024px) { .wl-grid { grid-template-columns: repeat(3, 1fr); } }
        @media (max-width: 768px)  { .wl-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 480px)  { .wl-grid { grid-template-columns: 1fr; } }
      `}</style>

      <div className="wl-root">
        <div className="wl-inner">

          {/* ── HEADER ── */}
          <div className="wl-header">
            <div className="wl-title-wrap">
              <h2 className="wl-title">
                <span className="wl-title-icon">❤️</span>
                My Wishlist
              </h2>
              <p className="wl-subtitle">
                <span>{wishlist.length}</span> saved item{wishlist.length !== 1 ? "s" : ""} ·{" "}
                <span>{inStockCount}</span> available to order
              </p>
            </div>

            <div className="wl-actions">
              <button
                className="btn-move-all"
                onClick={() => {
                  wishlist.forEach((p) => addToCart(p));
                  wishlist.forEach((p) => toggleWishlist(p._id));
                  toast.success("All items moved to cart 🛒");
                }}
              >
                🛒 Move All to Cart
              </button>
            </div>
          </div>

          {/* ── STATS ── */}
          <div className="wl-stats">
            <div className="wl-stat">
              <div className="wl-stat-icon">💝</div>
              <div>
                <p className="wl-stat-val">{wishlist.length}</p>
                <p className="wl-stat-label">Saved Items</p>
              </div>
            </div>
            <div className="wl-stat">
              <div className="wl-stat-icon">✅</div>
              <div>
                <p className="wl-stat-val">{inStockCount}</p>
                <p className="wl-stat-label">In Stock</p>
              </div>
            </div>
            <div className="wl-stat">
              <div className="wl-stat-icon">💰</div>
              <div>
                <p className="wl-stat-val">
                  ₹{wishlist.reduce((acc, p) => acc + (p.price || 0), 0).toLocaleString("en-IN")}
                </p>
                <p className="wl-stat-label">Total Value</p>
              </div>
            </div>
          </div>

          {/* ── GRID ── */}
          <div className="wl-grid">
            {wishlist.map((p) => {
              const outOfStock = p.countInStock === 0;
              const isRemoving = removingIds.includes(p._id);

              return (
                <div
                  key={p._id}
                  className={`wl-card ${isRemoving ? "removing" : ""} ${outOfStock ? "out-of-stock" : ""}`}
                >
                  {/* REMOVE BUTTON */}
                  <button
                    type="button"
                    className="wl-remove-btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      setRemovingIds((prev) => [...prev, p._id]);
                      setTimeout(() => toggleWishlist(p._id), 300);
                      toast.error("Removed from wishlist");
                    }}
                  >
                    ✕
                  </button>

                  {/* IMAGE */}
                  <div
                    className="wl-img-wrap"
                    onClick={() => navigate(`/product/${p._id}`)}
                  >
                    <img
                      src={
                        p.images && p.images.length > 0
                          ? p.images[0].startsWith("http")
                            ? p.images[0]
                            : `http://localhost:5000${p.images[0]}`
                          : "/placeholder.png"
                      }
                      className="wl-img"
                      alt={p.name}
                    />

                    {outOfStock && (
                      <div className="wl-oos-overlay">
                        <span className="wl-oos-tag">OUT OF STOCK</span>
                      </div>
                    )}

                    <div className="wl-quick-view">👁 Quick View</div>
                  </div>

                  {/* BODY */}
                  <div className="wl-card-body">
                    <p
                      className="wl-product-name"
                      onClick={() => navigate(`/product/${p._id}`)}
                    >
                      {p.name}
                    </p>

                    <div className="wl-price-row">
                      <span className="wl-price">₹{p.price?.toLocaleString("en-IN")}</span>
                    </div>

                    <button
                      className={`wl-cart-btn ${outOfStock ? "unavailable" : "available"}`}
                      disabled={outOfStock}
                      onClick={(e) => {
                        e.stopPropagation();
                        addToCart(p);
                        toggleWishlist(p._id);
                        toast.success("Moved to Cart 🛒");
                      }}
                    >
                      {outOfStock ? "Out of Stock" : <><span>🛒</span> Move to Cart</>}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      </div>
    </>
  );
};

export default Wishlist;
