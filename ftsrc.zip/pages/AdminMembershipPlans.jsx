// import { useEffect, useState } from "react";
// import axios from "axios";
// import { toast } from "react-toastify";

// const BASE = "http://localhost:5000/api";
// const getToken = () => sessionStorage.getItem("token");
// const authHeaders = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

// const emptyForm = {
//   name: "",
//   price: "",
//   duration: "",
//   discount: "",
//   benefits: "",
//   isActive: true,
// };

// const AdminMembershipPlans = () => {
//   const [plans, setPlans] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [showModal, setShowModal] = useState(false);
//   const [editPlan, setEditPlan] = useState(null);
//   const [form, setForm] = useState(emptyForm);
//   const [submitting, setSubmitting] = useState(false);

//   const fetchPlans = async () => {
//     try {
//       setLoading(true);
//       const res = await axios.get(`${BASE}/admin/membership/plans`, authHeaders());
//       setPlans(res.data);
//     } catch (err) {
//       toast.error("Failed to fetch plans");
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchPlans();
//   }, []);

//   const openAddModal = () => {
//     setEditPlan(null);
//     setForm(emptyForm);
//     setShowModal(true);
//   };

//   const openEditModal = (plan) => {
//     setEditPlan(plan);
//     setForm({
//       name: plan.name,
//       price: plan.price,
//       duration: plan.duration,
//       discount: plan.discount,
//       benefits: plan.benefits.join(", "),
//       isActive: plan.isActive,
//     });
//     setShowModal(true);
//   };

//   const handleSubmit = async () => {
//     if (!form.name || !form.price || !form.duration || !form.discount) {
//       toast.error("Please fill all required fields");
//       return;
//     }

//     const payload = {
//       name: form.name,
//       price: Number(form.price),
//       duration: Number(form.duration),
//       discount: Number(form.discount),
//       benefits: form.benefits
//         ? form.benefits.split(",").map((b) => b.trim()).filter(Boolean)
//         : [],
//       isActive: form.isActive,
//     };

//     try {
//       setSubmitting(true);
//       if (editPlan) {
//         await axios.put(
//           `${BASE}/admin/membership/plans/${editPlan._id}`,
//           payload,
//           authHeaders()
//         );
//         toast.success("Plan updated successfully");
//       } else {
//         await axios.post(
//           `${BASE}/admin/membership/plans`,
//           payload,
//           authHeaders()
//         );
//         toast.success("Plan created successfully");
//       }
//       setShowModal(false);
//       fetchPlans();
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Something went wrong");
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   const handleDelete = async (id) => {
//     if (!window.confirm("Are you sure you want to delete this plan?")) return;
//     try {
//       await axios.delete(`${BASE}/admin/membership/plans/${id}`, authHeaders());
//       toast.success("Plan deleted");
//       fetchPlans();
//     } catch (err) {
//       toast.error("Failed to delete plan");
//     }
//   };

//   const handleToggle = async (id) => {
//     try {
//       await axios.patch(
//         `${BASE}/admin/membership/plans/${id}/toggle`,
//         {},
//         authHeaders()
//       );
//       toast.success("Status updated");
//       fetchPlans();
//     } catch (err) {
//       toast.error("Failed to toggle status");
//     }
//   };

//   return (
//     <div className="p-6 min-h-screen bg-[#fdf5ee]">
//       {/* Header */}
//       <div className="flex items-center justify-between mb-6">
//         <div>
//           <h1 className="text-2xl font-bold text-[#7c3a00]">Membership Plans</h1>
//           <p className="text-sm text-gray-500 mt-1">Manage all subscription plans</p>
//         </div>
//         <button
//           onClick={openAddModal}
//           className="bg-[#f97316] hover:bg-[#ea6c0a] text-white px-5 py-2 rounded-lg font-semibold shadow transition"
//         >
//           + Add Plan
//         </button>
//       </div>

//       {/* Plans Table */}
//       {loading ? (
//         <div className="text-center py-20 text-gray-400 text-lg">Loading plans...</div>
//       ) : plans.length === 0 ? (
//         <div className="text-center py-20 text-gray-400 text-lg">No plans found. Add one!</div>
//       ) : (
//         <div className="bg-white rounded-2xl shadow overflow-hidden">
//           <table className="w-full text-sm">
//             <thead className="bg-[#f97316] text-white">
//               <tr>
//                 <th className="text-left px-5 py-3">Plan Name</th>
//                 <th className="text-left px-5 py-3">Price (₹)</th>
//                 <th className="text-left px-5 py-3">Duration (days)</th>
//                 <th className="text-left px-5 py-3">Discount (%)</th>
//                 <th className="text-left px-5 py-3">Benefits</th>
//                 <th className="text-left px-5 py-3">Status</th>
//                 <th className="text-left px-5 py-3">Actions</th>
//               </tr>
//             </thead>
//             <tbody>
//               {plans.map((plan, index) => (
//                 <tr
//                   key={plan._id}
//                   className={index % 2 === 0 ? "bg-white" : "bg-[#fff7f0]"}
//                 >
//                   <td className="px-5 py-3 font-semibold text-[#7c3a00]">{plan.name}</td>
//                   <td className="px-5 py-3">₹{plan.price}</td>
//                   <td className="px-5 py-3">{plan.duration} days</td>
//                   <td className="px-5 py-3">{plan.discount}%</td>
//                   <td className="px-5 py-3 text-gray-500 max-w-[200px]">
//                     {plan.benefits.length > 0 ? plan.benefits.join(", ") : "—"}
//                   </td>
//                   <td className="px-5 py-3">
//                     <button
//                       onClick={() => handleToggle(plan._id)}
//                       className={`px-3 py-1 rounded-full text-xs font-semibold ${
//                         plan.isActive
//                           ? "bg-green-100 text-green-700"
//                           : "bg-red-100 text-red-600"
//                       }`}
//                     >
//                       {plan.isActive ? "Active" : "Inactive"}
//                     </button>
//                   </td>
//                   <td className="px-5 py-3 flex gap-2">
//                     <button
//                       onClick={() => openEditModal(plan)}
//                       className="bg-[#f97316] hover:bg-[#ea6c0a] text-white px-3 py-1 rounded-lg text-xs font-semibold transition"
//                     >
//                       Edit
//                     </button>
//                     <button
//                       onClick={() => handleDelete(plan._id)}
//                       className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-lg text-xs font-semibold transition"
//                     >
//                       Delete
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}

//       {/* Modal */}
//       {showModal && (
//         <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
//           <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
//             <h2 className="text-xl font-bold text-[#7c3a00] mb-4">
//               {editPlan ? "Edit Plan" : "Add New Plan"}
//             </h2>

//             <div className="space-y-3">
//               <div>
//                 <label className="text-sm font-medium text-gray-600">Plan Name *</label>
//                 <input
//                   type="text"
//                   placeholder="e.g. Gold"
//                   value={form.name}
//                   onChange={(e) => setForm({ ...form, name: e.target.value })}
//                   className="w-full border border-gray-200 rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316]"
//                 />
//               </div>

//               <div className="grid grid-cols-2 gap-3">
//                 <div>
//                   <label className="text-sm font-medium text-gray-600">Price (₹) *</label>
//                   <input
//                     type="number"
//                     placeholder="e.g. 199"
//                     value={form.price}
//                     onChange={(e) => setForm({ ...form, price: e.target.value })}
//                     className="w-full border border-gray-200 rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316]"
//                   />
//                 </div>
//                 <div>
//                   <label className="text-sm font-medium text-gray-600">Duration (days) *</label>
//                   <input
//                     type="number"
//                     placeholder="e.g. 30"
//                     value={form.duration}
//                     onChange={(e) => setForm({ ...form, duration: e.target.value })}
//                     className="w-full border border-gray-200 rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316]"
//                   />
//                 </div>
//               </div>

//               <div>
//                 <label className="text-sm font-medium text-gray-600">Discount (%) *</label>
//                 <input
//                   type="number"
//                   placeholder="e.g. 10"
//                   value={form.discount}
//                   onChange={(e) => setForm({ ...form, discount: e.target.value })}
//                   className="w-full border border-gray-200 rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316]"
//                 />
//               </div>

//               <div>
//                 <label className="text-sm font-medium text-gray-600">
//                   Benefits{" "}
//                   <span className="text-gray-400 text-xs">(comma separated)</span>
//                 </label>
//                 <textarea
//                   placeholder="e.g. Free shipping, Early sale access, Priority support"
//                   value={form.benefits}
//                   onChange={(e) => setForm({ ...form, benefits: e.target.value })}
//                   rows={3}
//                   className="w-full border border-gray-200 rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316] resize-none"
//                 />
//               </div>

//               <div className="flex items-center gap-2">
//                 <input
//                   type="checkbox"
//                   id="isActive"
//                   checked={form.isActive}
//                   onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
//                   className="accent-[#f97316]"
//                 />
//                 <label htmlFor="isActive" className="text-sm text-gray-600">
//                   Active (visible to users)
//                 </label>
//               </div>
//             </div>

//             <div className="flex gap-3 mt-5">
//               <button
//                 onClick={() => setShowModal(false)}
//                 className="flex-1 border border-gray-300 text-gray-600 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 transition"
//               >
//                 Cancel
//               </button>
//               <button
//                 onClick={handleSubmit}
//                 disabled={submitting}
//                 className="flex-1 bg-[#f97316] hover:bg-[#ea6c0a] text-white py-2 rounded-lg text-sm font-semibold transition disabled:opacity-60"
//               >
//                 {submitting ? "Saving..." : editPlan ? "Update Plan" : "Create Plan"}
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default AdminMembershipPlans;

import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";

const BASE = "http://localhost:5000/api";
const getToken = () => sessionStorage.getItem("token");
const authHeaders = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

const emptyForm = {
  name: "",
  price: "",
  duration: "",
  discount: "",
  benefits: "",
  isActive: true,
};

const AdminMembershipPlans = () => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editPlan, setEditPlan] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [submitting, setSubmitting] = useState(false);

  const fetchPlans = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`${BASE}/admin/membership/plans`, authHeaders());
      setPlans(res.data);
    } catch (err) {
      toast.error("Failed to fetch plans");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchPlans(); }, []);

  const openAddModal = () => {
    setEditPlan(null);
    setForm(emptyForm);
    setShowModal(true);
  };

  const openEditModal = (plan) => {
    setEditPlan(plan);
    setForm({
      name: plan.name,
      price: plan.price,
      duration: plan.duration,
      discount: plan.discount,
      benefits: plan.benefits.join(", "),
      isActive: plan.isActive,
    });
    setShowModal(true);
  };

  const handleSubmit = async () => {
    if (!form.name || !form.price || !form.duration || !form.discount) {
      toast.error("Please fill all required fields");
      return;
    }
    const payload = {
      name: form.name,
      price: Number(form.price),
      duration: Number(form.duration),
      discount: Number(form.discount),
      benefits: form.benefits ? form.benefits.split(",").map((b) => b.trim()).filter(Boolean) : [],
      isActive: form.isActive,
    };
    try {
      setSubmitting(true);
      if (editPlan) {
        await axios.put(`${BASE}/admin/membership/plans/${editPlan._id}`, payload, authHeaders());
        toast.success("Plan updated successfully");
      } else {
        await axios.post(`${BASE}/admin/membership/plans`, payload, authHeaders());
        toast.success("Plan created successfully");
      }
      setShowModal(false);
      fetchPlans();
    } catch (err) {
      toast.error(err.response?.data?.message || "Something went wrong");
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this plan?")) return;
    try {
      await axios.delete(`${BASE}/admin/membership/plans/${id}`, authHeaders());
      toast.success("Plan deleted");
      fetchPlans();
    } catch (err) {
      toast.error("Failed to delete plan");
    }
  };

  const handleToggle = async (id) => {
    try {
      await axios.patch(`${BASE}/admin/membership/plans/${id}/toggle`, {}, authHeaders());
      toast.success("Status updated");
      fetchPlans();
    } catch (err) {
      toast.error("Failed to toggle status");
    }
  };

  const activePlans = plans.filter(p => p.isActive).length;
  const inactivePlans = plans.filter(p => !p.isActive).length;
  const avgDiscount = plans.length > 0
    ? Math.round(plans.reduce((a, p) => a + p.discount, 0) / plans.length)
    : 0;

  const planIcons = { Free: "🆓", Silver: "🥈", Gold: "🥇", Platinum: "💎" };

  return (
    <div style={{ fontFamily: "'Nunito', sans-serif", background: "#fdf8f3", minHeight: "100vh", padding: 24 }}>

      {/* ── HEADER BANNER ── */}
      <div style={{
        background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
        borderRadius: 22, padding: "26px 32px", marginBottom: 24,
        position: "relative", overflow: "hidden",
        boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
      }}>
        <div style={{ position: "absolute", top: -40, right: -40, width: 180, height: 180, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
        <div style={{ position: "absolute", bottom: -50, left: "35%", width: 220, height: 220, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
        <div style={{ position: "relative", zIndex: 1, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 14 }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 26, fontWeight: 900, color: "#fff", letterSpacing: -0.5 }}>
              💳 Membership Plans
            </h1>
            <p style={{ margin: "5px 0 0", fontSize: 13, color: "rgba(255,255,255,0.85)", fontWeight: 600 }}>
              {plans.length} total plan{plans.length !== 1 ? "s" : ""} · Manage subscription tiers
            </p>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={fetchPlans} style={{
              padding: "10px 18px", background: "rgba(255,255,255,0.2)",
              color: "#fff", border: "1.5px solid rgba(255,255,255,0.4)",
              borderRadius: 12, fontSize: 13, fontWeight: 800, cursor: "pointer",
              backdropFilter: "blur(8px)",
            }}>
              ↻ Refresh
            </button>
            <button onClick={openAddModal} style={{
              padding: "10px 20px", background: "#fff",
              color: "#ff6f00", border: "none",
              borderRadius: 12, fontSize: 13, fontWeight: 900, cursor: "pointer",
              boxShadow: "0 4px 14px rgba(0,0,0,0.15)",
            }}>
              + Add Plan
            </button>
          </div>
        </div>
      </div>

      {/* ── STAT CARDS ── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Plans", value: plans.length, icon: "📋", color: "#ff6f00", bg: "#fff3e8" },
          { label: "Active",      value: activePlans,   icon: "✅", color: "#16a34a", bg: "#f0fdf4" },
          { label: "Inactive",    value: inactivePlans, icon: "⛔", color: "#dc2626", bg: "#fef2f2" },
          { label: "Avg Discount",value: `${avgDiscount}%`, icon: "🏷️", color: "#7c3aed", bg: "#f5f3ff" },
        ].map((stat) => (
          <div key={stat.label} style={{
            background: "#fff", borderRadius: 16, padding: "18px 20px",
            border: "1.5px solid #f0e8e0",
            boxShadow: "0 4px 14px rgba(0,0,0,0.05)",
          }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: stat.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>
                {stat.icon}
              </div>
              <span style={{ fontSize: 10, fontWeight: 800, color: stat.color, background: stat.bg, padding: "3px 10px", borderRadius: 20, textTransform: "uppercase", letterSpacing: 0.5 }}>
                {stat.label}
              </span>
            </div>
            <div style={{ fontSize: 32, fontWeight: 900, color: "#1a1a1a" }}>{stat.value}</div>
          </div>
        ))}
      </div>

      {/* ── PLAN CARDS ── */}
      {loading ? (
        <div style={{ textAlign: "center", padding: "60px", color: "#aaa", fontSize: 15 }}>Loading plans...</div>
      ) : plans.length === 0 ? (
        <div style={{ textAlign: "center", padding: "60px", color: "#aaa", fontSize: 15 }}>No plans found. Add one!</div>
      ) : (
        <>
          {/* Plan Cards Grid */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 20, marginBottom: 28 }}>
            {plans.map((plan) => (
              <div key={plan._id} style={{
                background: "#fff", borderRadius: 20,
                border: `2px solid ${plan.isActive ? "#ffe0c2" : "#e8e8e8"}`,
                padding: 22, position: "relative",
                boxShadow: plan.isActive ? "0 6px 20px rgba(255,111,0,0.1)" : "0 4px 12px rgba(0,0,0,0.04)",
                transition: "transform 0.2s, box-shadow 0.2s",
              }}>
                {/* Plan header */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ fontSize: 28 }}>{planIcons[plan.name] || "💳"}</div>
                    <div>
                      <div style={{ fontSize: 17, fontWeight: 900, color: "#1a1a1a" }}>{plan.name}</div>
                      <div style={{ fontSize: 12, color: "#aaa", fontWeight: 600 }}>{plan.duration} days</div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleToggle(plan._id)}
                    style={{
                      padding: "4px 12px", borderRadius: 20, border: "none", cursor: "pointer",
                      fontSize: 11, fontWeight: 800,
                      background: plan.isActive ? "#dcfce7" : "#fee2e2",
                      color: plan.isActive ? "#16a34a" : "#dc2626",
                    }}
                  >
                    {plan.isActive ? "Active" : "Inactive"}
                  </button>
                </div>

                {/* Price */}
                <div style={{ marginBottom: 12 }}>
                  <span style={{ fontSize: 28, fontWeight: 900, color: "#ff6f00" }}>₹{plan.price}</span>
                  <span style={{ fontSize: 12, color: "#aaa", fontWeight: 600 }}>/month</span>
                </div>

                {/* Discount badge */}
                <div style={{
                  display: "inline-flex", alignItems: "center", gap: 5,
                  background: "#fff3e8", border: "1.5px solid #ffe0c2",
                  borderRadius: 8, padding: "5px 12px", marginBottom: 14,
                }}>
                  <span style={{ fontSize: 13 }}>🏷️</span>
                  <span style={{ fontSize: 13, fontWeight: 800, color: "#ff6f00" }}>{plan.discount}% discount</span>
                </div>

                {/* Benefits */}
                {plan.benefits.length > 0 && (
                  <div style={{ marginBottom: 16 }}>
                    {plan.benefits.slice(0, 3).map((b, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 5 }}>
                        <div style={{ width: 16, height: 16, borderRadius: "50%", background: "#ff6f00", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: "#fff", fontWeight: 900, flexShrink: 0 }}>✓</div>
                        <span style={{ fontSize: 12, color: "#555", fontWeight: 600 }}>{b}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Actions */}
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => openEditModal(plan)} style={{
                    flex: 1, padding: "9px", background: "linear-gradient(135deg, #ff6f00, #ff9500)",
                    color: "#fff", border: "none", borderRadius: 10,
                    fontSize: 13, fontWeight: 800, cursor: "pointer",
                  }}>
                    ✏️ Edit
                  </button>
                  <button onClick={() => handleDelete(plan._id)} style={{
                    flex: 1, padding: "9px", background: "#fff5f5",
                    color: "#dc2626", border: "1.5px solid #fecaca",
                    borderRadius: 10, fontSize: 13, fontWeight: 800, cursor: "pointer",
                  }}>
                    🗑️ Delete
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* ── TABLE VIEW ── */}
          <div style={{ background: "#fff", borderRadius: 18, overflow: "hidden", border: "1.5px solid #f0e8e0", boxShadow: "0 4px 16px rgba(0,0,0,0.05)" }}>
            <div style={{ padding: "16px 24px", borderBottom: "1.5px solid #f0e8e0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <h3 style={{ margin: 0, fontSize: 15, fontWeight: 800, color: "#1a1a1a" }}>📊 All Plans Overview</h3>
              <span style={{ fontSize: 12, color: "#aaa", fontWeight: 600 }}>{plans.length} plans total</span>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead style={{ background: "linear-gradient(135deg, #ff6f00, #ff9500)" }}>
                <tr>
                  {["Plan", "Price", "Duration", "Discount", "Benefits", "Status", "Actions"].map(h => (
                    <th key={h} style={{ textAlign: "left", padding: "12px 16px", color: "#fff", fontWeight: 800, fontSize: 12 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {plans.map((plan, index) => (
                  <tr key={plan._id} style={{ background: index % 2 === 0 ? "#fff" : "#fff8f2", borderBottom: "1px solid #f5ece4" }}>
                    <td style={{ padding: "12px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <span style={{ fontSize: 18 }}>{planIcons[plan.name] || "💳"}</span>
                        <span style={{ fontWeight: 800, color: "#1a1a1a" }}>{plan.name}</span>
                      </div>
                    </td>
                    <td style={{ padding: "12px 16px", fontWeight: 700, color: "#ff6f00" }}>₹{plan.price}</td>
                    <td style={{ padding: "12px 16px", color: "#555" }}>{plan.duration} days</td>
                    <td style={{ padding: "12px 16px" }}>
                      <span style={{ background: "#fff3e8", color: "#ff6f00", padding: "3px 10px", borderRadius: 8, fontWeight: 800, fontSize: 12 }}>
                        {plan.discount}%
                      </span>
                    </td>
                    <td style={{ padding: "12px 16px", color: "#888", maxWidth: 180 }}>
                      {plan.benefits.slice(0, 2).join(", ")}{plan.benefits.length > 2 ? "..." : ""}
                    </td>
                    <td style={{ padding: "12px 16px" }}>
                      <button onClick={() => handleToggle(plan._id)} style={{
                        padding: "4px 12px", borderRadius: 20, border: "none", cursor: "pointer",
                        fontSize: 11, fontWeight: 800,
                        background: plan.isActive ? "#dcfce7" : "#fee2e2",
                        color: plan.isActive ? "#16a34a" : "#dc2626",
                      }}>
                        {plan.isActive ? "✅ Active" : "⛔ Inactive"}
                      </button>
                    </td>
                    <td style={{ padding: "12px 16px" }}>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button onClick={() => openEditModal(plan)} style={{ padding: "6px 14px", background: "#ff6f00", color: "#fff", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 800, cursor: "pointer" }}>Edit</button>
                        <button onClick={() => handleDelete(plan._id)} style={{ padding: "6px 14px", background: "#fff5f5", color: "#dc2626", border: "1.5px solid #fecaca", borderRadius: 8, fontSize: 12, fontWeight: 800, cursor: "pointer" }}>Delete</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* ── MODAL ── */}
      {showModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50 }}>
          <div style={{ background: "#fff", borderRadius: 22, width: "100%", maxWidth: 460, padding: 28, boxShadow: "0 20px 60px rgba(0,0,0,0.2)" }}>

            {/* Modal header */}
            <div style={{ background: "linear-gradient(135deg, #ff6f00, #ff9500)", borderRadius: 14, padding: "16px 20px", marginBottom: 22 }}>
              <h2 style={{ margin: 0, fontSize: 18, fontWeight: 900, color: "#fff" }}>
                {editPlan ? "✏️ Edit Plan" : "➕ Add New Plan"}
              </h2>
              <p style={{ margin: "4px 0 0", fontSize: 12, color: "rgba(255,255,255,0.8)" }}>Fill in the plan details below</p>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 800, color: "#888", textTransform: "uppercase", letterSpacing: 0.5, display: "block", marginBottom: 6 }}>Plan Name *</label>
                <input
                  type="text" placeholder="e.g. Gold"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box" }}
                />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 800, color: "#888", textTransform: "uppercase", letterSpacing: 0.5, display: "block", marginBottom: 6 }}>Price (₹) *</label>
                  <input type="number" placeholder="e.g. 199" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })}
                    style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 800, color: "#888", textTransform: "uppercase", letterSpacing: 0.5, display: "block", marginBottom: 6 }}>Duration (days) *</label>
                  <input type="number" placeholder="e.g. 30" value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })}
                    style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
                </div>
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 800, color: "#888", textTransform: "uppercase", letterSpacing: 0.5, display: "block", marginBottom: 6 }}>Discount (%) *</label>
                <input type="number" placeholder="e.g. 10" value={form.discount} onChange={(e) => setForm({ ...form, discount: e.target.value })}
                  style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 800, color: "#888", textTransform: "uppercase", letterSpacing: 0.5, display: "block", marginBottom: 6 }}>
                  Benefits <span style={{ color: "#bbb", fontWeight: 600, textTransform: "none" }}>(comma separated)</span>
                </label>
                <textarea
                  placeholder="e.g. Free shipping, Early sale access"
                  value={form.benefits}
                  onChange={(e) => setForm({ ...form, benefits: e.target.value })}
                  rows={3}
                  style={{ width: "100%", padding: "11px 14px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 14, outline: "none", resize: "none", boxSizing: "border-box", fontFamily: "inherit" }}
                />
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <input type="checkbox" id="isActive" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} style={{ accentColor: "#ff6f00", width: 16, height: 16 }} />
                <label htmlFor="isActive" style={{ fontSize: 13, color: "#555", fontWeight: 600 }}>Active (visible to users)</label>
              </div>
            </div>

            <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
              <button onClick={() => setShowModal(false)} style={{ flex: 1, padding: "12px", border: "1.5px solid #e8e8e8", background: "#fff", borderRadius: 12, fontSize: 14, fontWeight: 800, cursor: "pointer", color: "#555" }}>
                Cancel
              </button>
              <button onClick={handleSubmit} disabled={submitting} style={{ flex: 1, padding: "12px", background: "linear-gradient(135deg, #ff6f00, #ff9500)", color: "#fff", border: "none", borderRadius: 12, fontSize: 14, fontWeight: 800, cursor: "pointer", opacity: submitting ? 0.6 : 1 }}>
                {submitting ? "Saving..." : editPlan ? "Update Plan" : "Create Plan"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminMembershipPlans;