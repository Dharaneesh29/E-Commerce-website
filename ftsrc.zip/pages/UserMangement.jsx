import { useEffect, useState } from "react";
import axios from "axios";

const AdminUsers = () => {
  const [users,     setUsers]     = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [search,    setSearch]    = useState("");
  const [exporting, setExporting] = useState(false);
  const [filter,    setFilter]    = useState("All");

  const getToken = () => JSON.parse(sessionStorage.getItem("userInfo"))?.token;

  const getUsers = async () => {
    try {
      setLoading(true);
      const res = await axios.get("http://localhost:5000/api/users/all", {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      setUsers(res.data);
    } catch (err) {
      console.log("Error fetching users:", err.response?.data);
    } finally {
      setLoading(false);
    }
  };

  const deleteUser = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;
    try {
      await axios.delete(`http://localhost:5000/api/users/${id}`, {
        headers: { Authorization: `Bearer ${getToken()}` },
      });
      getUsers();
    } catch { alert("Delete failed"); }
  };

  const toggleBlock = async (id) => {
    try {
      await axios.put(`http://localhost:5000/api/users/block/${id}`, {},
        { headers: { Authorization: `Bearer ${getToken()}` } }
      );
      getUsers();
    } catch { alert("Action failed"); }
  };

  const exportCSV = () => {
    setExporting(true);
    try {
      const data = filtered.length > 0 ? filtered : users;
      if (!data.length) { alert("No users to export"); return; }
      const headers = ["#","Name","Email","Phone","Role","Status","Joined"];
      const rows = data.map((u,i) => [
        i+1, u.name||"", u.email||"", u.phone||"", u.role||"",
        u.isBlocked?"Blocked":"Active",
        u.createdAt ? new Date(u.createdAt).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"}) : "",
      ]);
      const csv = [headers,...rows].map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
      const blob = new Blob([csv],{type:"text/csv;charset=utf-8;"});
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href=url; a.download=`users_${new Date().toISOString().split("T")[0]}.csv`; a.click();
      URL.revokeObjectURL(url);
    } finally { setTimeout(()=>setExporting(false),1000); }
  };

  useEffect(()=>{ getUsers(); },[]);

  const counts = {
    All:     users.length,
    Admins:  users.filter(u=>u.role==="admin").length,
    Blocked: users.filter(u=>u.isBlocked).length,
    Active:  users.filter(u=>!u.isBlocked).length,
  };

  const filtered = users.filter(u => {
    const matchSearch =
      u.name?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase()) ||
      u.phone?.includes(search);
    const matchFilter =
      filter==="All"     ? true :
      filter==="Admins"  ? u.role==="admin" :
      filter==="Blocked" ? u.isBlocked :
      filter==="Active"  ? !u.isBlocked : true;
    return matchSearch && matchFilter;
  });

  const STAT_CARDS = [
    { label:"Total Users", key:"All",     value:counts.All,     icon:"👥", accent:"#ff6f00", light:"#fff7ed", border:"#ffe0c2" },
    { label:"Admins",      key:"Admins",  value:counts.Admins,  icon:"⭐", accent:"#f97316", light:"#fff3e6", border:"#fed7aa" },
    { label:"Blocked",     key:"Blocked", value:counts.Blocked, icon:"🚫", accent:"#ef4444", light:"#fef2f2", border:"#fecaca" },
    { label:"Active",      key:"Active",  value:counts.Active,  icon:"✅", accent:"#10b981", light:"#ecfdf5", border:"#a7f3d0" },
  ];

  const timeStr = (d) => d
    ? new Date(d).toLocaleDateString("en-IN",{day:"numeric",month:"short",year:"numeric"})
    : "—";

  const COLS = [
    { label:"#",       width:50  },
    { label:"Name",    width:170 },
    { label:"Email",   width:210 },
    { label:"Phone",   width:130 },
    { label:"Role",    width:120 },
    { label:"Status",  width:130 },
    { label:"Joined",  width:110 },
    { label:"Actions", width:160 },
  ];

  return (
    <div style={{ padding:"28px 32px", background:"#fdf8f3", minHeight:"100vh", fontFamily:"'Nunito', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        @keyframes fadeUp { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
        @keyframes spin   { to{transform:rotate(360deg)} }
        .stat-c:hover  { transform:translateY(-4px) !important; box-shadow:0 12px 32px rgba(255,111,0,0.18) !important; }
        .exp-btn:hover { opacity:.88 !important; transform:translateY(-1px) !important; }
        .ref-btn:hover { background:#fff3e6 !important; border-color:#ff6f00 !important; color:#ff6f00 !important; }
        .blk-btn:hover  { background:#fee2e2 !important; }
        .ublk-btn:hover { background:#d1fae5 !important; }
        .del-btn:hover  { background:#fef2f2 !important; border-color:#fecaca !important; }
        tr.urow:hover td { background:#fff8f2 !important; }
        input:focus { border-color:#ff6f00 !important; box-shadow:0 0 0 3px rgba(255,111,0,0.12) !important; outline:none !important; }
      `}</style>

      {/* ── HERO HEADER ── */}
      <div style={{
        background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
        borderRadius: 22, padding: "26px 32px", marginBottom: 24,
        position: "relative", overflow: "hidden",
        boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
        animation: "fadeUp 0.4s ease both",
      }}>
        <div style={{ position:"absolute", top:-40, right:-40, width:180, height:180, borderRadius:"50%", background:"rgba(255,255,255,0.08)" }} />
        <div style={{ position:"absolute", bottom:-50, left:"35%", width:220, height:220, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }} />
        <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
          <div>
            <h1 style={{ margin:0, fontSize:28, fontWeight:900, color:"#fff", letterSpacing:-0.5 }}>👥 User Management</h1>
            <p style={{ margin:"5px 0 0", fontSize:13, color:"rgba(255,255,255,0.8)", fontWeight:700 }}>
              {users.length} total users
              {filter!=="All" && <span> · Filtered: {filter} ({filtered.length})</span>}
              {search && <span> · Search: "{search}"</span>}
            </p>
          </div>
          <div style={{ display:"flex", gap:10 }}>
            <button className="exp-btn" onClick={exportCSV} disabled={exporting||loading} style={{
              display:"flex", alignItems:"center", gap:8,
              padding:"10px 20px",
              background:"rgba(255,255,255,0.2)",
              color:"#fff", border:"1.5px solid rgba(255,255,255,0.4)",
              borderRadius:12, fontSize:13, fontWeight:800,
              cursor:"pointer", transition:"all .2s",
              backdropFilter:"blur(8px)", whiteSpace:"nowrap",
              fontFamily:"inherit",
            }}>
              {exporting ? "⏳ Exporting..." : "⬇️ Export CSV"}
            </button>
            <button className="ref-btn" onClick={getUsers} disabled={loading} style={{
              display:"flex", alignItems:"center", gap:6,
              padding:"10px 18px",
              background:"rgba(255,255,255,0.15)",
              color:"#fff", border:"1.5px solid rgba(255,255,255,0.3)",
              borderRadius:12, fontSize:13, fontWeight:800,
              cursor:"pointer", transition:"all .2s",
              fontFamily:"inherit", whiteSpace:"nowrap",
            }}>
              ↻ Refresh
            </button>
          </div>
        </div>
      </div>

      {/* ── STAT CARDS ── */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:16, marginBottom:22, animation:"fadeUp .4s ease .06s both" }}>
        {STAT_CARDS.map(s => {
          const isActive = filter===s.key;
          return (
            <div className="stat-c" key={s.key} onClick={()=>setFilter(isActive?"All":s.key)} style={{
              background: isActive ? s.light : "#fff",
              borderRadius:18, padding:"20px 22px",
              border: `1.5px solid ${isActive ? s.accent+"55" : "#ffe0c2"}`,
              boxShadow: isActive ? `0 0 0 2px ${s.accent}33, 0 6px 20px rgba(255,111,0,0.1)` : "0 2px 10px rgba(255,111,0,0.06)",
              position:"relative", overflow:"hidden", cursor:"pointer",
              transition:"all .22s",
            }}>
              <div style={{ position:"absolute", top:0, left:0, right:0, height:4, background:s.accent, borderRadius:"18px 18px 0 0" }} />
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginTop:4 }}>
                <div>
                  <div style={{ fontSize:11, color:"#aaa", fontWeight:800, textTransform:"uppercase", letterSpacing:0.8, marginBottom:8 }}>{s.label}</div>
                  <div style={{ fontSize:32, fontWeight:900, color:s.accent, lineHeight:1 }}>{s.value}</div>
                </div>
                <div style={{ width:46, height:46, borderRadius:14, background:s.light, border:`1.5px solid ${s.border}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:22 }}>{s.icon}</div>
              </div>
              <div style={{ marginTop:10, fontSize:11, fontWeight:800, color:isActive?s.accent:"#bbb" }}>
                {isActive ? "● Active filter — click to clear" : "Click to filter →"}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── SEARCH BAR ── */}
      <div style={{
        background:"#fff", borderRadius:14, padding:"14px 18px", marginBottom:18,
        border:"1.5px solid #ffe0c2", boxShadow:"0 2px 10px rgba(255,111,0,0.06)",
        display:"flex", alignItems:"center", gap:14, flexWrap:"wrap",
        animation:"fadeUp .4s ease .1s both",
      }}>
        <div style={{ position:"relative", flex:"0 0 300px" }}>
          <span style={{ position:"absolute", left:12, top:"50%", transform:"translateY(-50%)", fontSize:15 }}>🔍</span>
          <input
            placeholder="Search by name, email or phone..."
            value={search}
            onChange={e=>setSearch(e.target.value)}
            style={{
              width:"100%", padding:"9px 14px 9px 36px",
              borderRadius:10, border:"1.5px solid #ffe0c2",
              fontSize:13, color:"#1a1a1a", background:"#fff8f2",
              boxSizing:"border-box", fontFamily:"inherit", transition:"all .18s",
            }}
          />
        </div>
        {filter!=="All" && (
          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            <span style={{ fontSize:12, color:"#aaa", fontWeight:700 }}>Filter:</span>
            <span style={{
              fontSize:12, fontWeight:800, padding:"4px 12px", borderRadius:20, whiteSpace:"nowrap",
              background: filter==="Admins"?"#fff7ed":filter==="Blocked"?"#fef2f2":"#ecfdf5",
              color: filter==="Admins"?"#f97316":filter==="Blocked"?"#ef4444":"#10b981",
              border: `1.5px solid ${filter==="Admins"?"#fed7aa":filter==="Blocked"?"#fecaca":"#a7f3d0"}`,
            }}>{filter} ({counts[filter]})</span>
            <button onClick={()=>setFilter("All")} style={{ fontSize:11, fontWeight:800, padding:"3px 10px", borderRadius:20, border:"1.5px solid #ffe0c2", background:"#fff", color:"#ff6f00", cursor:"pointer", fontFamily:"inherit" }}>✕ Clear</button>
          </div>
        )}
        <div style={{ marginLeft:"auto", fontSize:12, color:"#aaa", fontWeight:700 }}>
          Showing <span style={{ color:"#ff6f00", fontWeight:900 }}>{filtered.length}</span> of {users.length} users
        </div>
      </div>

      {/* ── TABLE ── */}
      <div style={{
        background:"#fff", borderRadius:18,
        border:"1.5px solid #ffe0c2",
        boxShadow:"0 4px 18px rgba(255,111,0,0.07)",
        overflow:"hidden", animation:"fadeUp .4s ease .14s both",
        position:"relative",
      }}>
        <div style={{ height:4, background:"linear-gradient(90deg,#ff6f00,#ffaa44)" }} />

        {loading ? (
          <div style={{ padding:80, display:"flex", flexDirection:"column", alignItems:"center", gap:14 }}>
            <div style={{ width:44, height:44, borderRadius:"50%", border:"4px solid #ffe0c2", borderTop:"4px solid #ff6f00", animation:"spin .8s linear infinite" }} />
            <p style={{ margin:0, fontWeight:700, color:"#ffaa70" }}>Loading users…</p>
          </div>
        ) : filtered.length===0 ? (
          <div style={{ padding:80, display:"flex", flexDirection:"column", alignItems:"center", gap:12 }}>
            <span style={{ fontSize:52 }}>👤</span>
            <p style={{ margin:0, fontSize:16, fontWeight:800, color:"#1a1a1a" }}>No users found</p>
            <p style={{ margin:0, fontSize:13, color:"#aaa", fontWeight:600 }}>{filter!=="All"?`No ${filter.toLowerCase()} users`:"Try a different search"}</p>
            {filter!=="All" && (
              <button onClick={()=>setFilter("All")} style={{ marginTop:8, padding:"8px 18px", borderRadius:10, border:"1.5px solid #ffe0c2", background:"#fff8f2", color:"#ff6f00", fontWeight:800, fontSize:13, cursor:"pointer", fontFamily:"inherit" }}>Clear Filter</button>
            )}
          </div>
        ) : (
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse", tableLayout:"fixed" }}>
              <colgroup>
                {COLS.map(c=><col key={c.label} style={{ width:c.width }} />)}
              </colgroup>
              <thead>
                <tr style={{ background:"#fff8f2", borderBottom:"1.5px solid #ffe0c2" }}>
                  {COLS.map(c=>(
                    <th key={c.label} style={{
                      padding:"13px 16px", textAlign:"left",
                      fontSize:11, fontWeight:800, color:"#ffaa70",
                      textTransform:"uppercase", letterSpacing:0.8,
                      whiteSpace:"nowrap",
                    }}>
                      {c.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((u,i)=>(
                  <tr className="urow" key={u._id} style={{ borderBottom:"1px solid #fff3e6", opacity:u.isBlocked?0.75:1 }}>

                    {/* # */}
                    <td style={{ padding:"14px 16px", fontSize:13, color:"#aaa", fontWeight:700, verticalAlign:"middle", whiteSpace:"nowrap" }}>{i+1}</td>

                    {/* Name */}
                    <td style={{ padding:"14px 16px", verticalAlign:"middle" }}>
                      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                        <div style={{
                          width:38, height:38, borderRadius:"50%", flexShrink:0,
                          background: u.role==="admin"
                            ? "linear-gradient(135deg,#ff6f00,#ffaa44)"
                            : "linear-gradient(135deg,#ffaa44,#ffcc88)",
                          display:"flex", alignItems:"center", justifyContent:"center",
                          color:"#fff", fontWeight:900, fontSize:15,
                          boxShadow:"0 2px 8px rgba(255,111,0,0.25)",
                        }}>
                          {u.name?.charAt(0).toUpperCase()}
                        </div>
                        <div style={{ minWidth:0 }}>
                          <div style={{ fontSize:13, fontWeight:800, color:"#1a1a1a", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{u.name}</div>
                          {u.isBlocked && <div style={{ fontSize:10, color:"#ef4444", fontWeight:800 }}>Blocked</div>}
                        </div>
                      </div>
                    </td>

                    {/* Email */}
                    <td style={{ padding:"14px 16px", fontSize:13, color:"#555", verticalAlign:"middle", whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{u.email}</td>

                    {/* Phone */}
                    <td style={{ padding:"14px 16px", fontSize:13, color:"#888", fontWeight:600, verticalAlign:"middle", whiteSpace:"nowrap" }}>{u.phone||"—"}</td>

                    {/* Role */}
                    <td style={{ padding:"14px 16px", verticalAlign:"middle", whiteSpace:"nowrap" }}>
                      <span style={{
                        display:"inline-flex", alignItems:"center", gap:5,
                        fontSize:12, fontWeight:800, padding:"5px 12px", borderRadius:20,
                        background: u.role==="admin"?"#fff3e6":"#f8fafc",
                        color:      u.role==="admin"?"#ff6f00":"#888",
                        border:     `1.5px solid ${u.role==="admin"?"#ffe0c2":"#e8e8e8"}`,
                      }}>
                        {u.role==="admin"?"⭐ Admin":"👤 User"}
                      </span>
                    </td>

                    {/* Status */}
                    <td style={{ padding:"14px 16px", verticalAlign:"middle", whiteSpace:"nowrap" }}>
                      <span style={{
                        display:"inline-flex", alignItems:"center", gap:5,
                        fontSize:12, fontWeight:800, padding:"5px 12px", borderRadius:20,
                        background: u.isBlocked?"#fef2f2":"#ecfdf5",
                        color:      u.isBlocked?"#ef4444":"#10b981",
                        border:     `1.5px solid ${u.isBlocked?"#fecaca":"#a7f3d0"}`,
                      }}>
                        {u.isBlocked?"🚫 Blocked":"✅ Active"}
                      </span>
                    </td>

                    {/* Joined */}
                    <td style={{ padding:"14px 16px", fontSize:12, color:"#aaa", fontWeight:700, verticalAlign:"middle", whiteSpace:"nowrap" }}>{timeStr(u.createdAt)}</td>

                    {/* Actions */}
                    <td style={{ padding:"14px 16px", verticalAlign:"middle", whiteSpace:"nowrap" }}>
                      <div style={{ display:"flex", gap:7, alignItems:"center" }}>
                        {u.role!=="admin" && (
                          <button
                            className={u.isBlocked?"ublk-btn":"blk-btn"}
                            onClick={()=>toggleBlock(u._id)}
                            style={{
                              padding:"6px 14px", borderRadius:8,
                              border:`1.5px solid ${u.isBlocked?"#a7f3d0":"#fecaca"}`,
                              cursor:"pointer", fontSize:12, fontWeight:800,
                              transition:"background .18s", whiteSpace:"nowrap",
                              background: u.isBlocked?"#ecfdf5":"#fef2f2",
                              color:      u.isBlocked?"#10b981":"#ef4444",
                              fontFamily:"inherit",
                            }}>
                            {u.isBlocked?"✅ Unblock":"🚫 Block"}
                          </button>
                        )}
                        <button
                          className="del-btn"
                          onClick={()=>deleteUser(u._id)}
                          style={{
                            width:34, height:34, borderRadius:9,
                            border:"1.5px solid #ffe0c2", background:"#fff8f2",
                            cursor:"pointer", fontSize:15,
                            display:"flex", alignItems:"center", justifyContent:"center",
                            flexShrink:0, transition:"all .18s",
                          }}>
                          🗑
                        </button>
                      </div>
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Footer */}
        {!loading && filtered.length>0 && (
          <div style={{ padding:"12px 20px", borderTop:"1.5px solid #fff3e6", background:"#fff8f2", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontSize:12, color:"#ffaa70", fontWeight:700 }}>
              {filter!=="All" ? `Showing ${filtered.length} ${filter.toLowerCase()} users` : `${filtered.length} users total`}
              {search && ` matching "${search}"`}
            </span>
            <span style={{ fontSize:12, color:"#aaa", fontWeight:600 }}>
              Export will download {filtered.length} user{filtered.length!==1?"s":""}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminUsers;
