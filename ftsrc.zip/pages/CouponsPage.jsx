import React, { useEffect, useState, useContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { ShopContext } from "../context/ShopContext";
import Toast from "../components/Toast";
 
const CouponsPage = () => {
  const [coupons, setCoupons] = useState([]);
  const [search, setSearch] = useState("");
 
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState("");
 
  const navigate = useNavigate();
 
  // 🛒 CART FROM CONTEXT
  const { cart } = useContext(ShopContext);
 
  // 💰 TOTAL CALCULATION
  const total = (cart|| []).reduce(
    (acc, item) => acc + item.product.price * item.qty,
    0
  );
 
  // 📡 FETCH COUPONS
  useEffect(() => {
    const fetchCoupons = async () => {
      try {
        const token=sessionStorage.getItem("token")
        const res = await axios.get("http://localhost:5000/api/coupon",{
          headers:{
            Authorization:`Bearer ${token}`,
          },
        });
        setCoupons(res.data);
      } catch (err) {
        console.log(err);
      }
    };
 
    fetchCoupons();
  }, []);
 
  // 🔍 FILTER
  const filteredCoupons = coupons.filter((c) =>
    c.code.toLowerCase().includes(search.toLowerCase())
  );
 
  // 🔥 APPLY COUPON
  const handleApplyCoupon = async (coupon) => {
    try {
      const token=sessionStorage.getItem("token")
      const res = await axios.post(
        "http://localhost:5000/api/coupon/apply",
        {
          code: coupon.code,
          cartTotal: total,
        },
        {
          headers:{
            Authorization: `Bearer ${token}`,
          }
        }
      );
       
      const { discount, finalTotal } = res.data;
      console.log(res.data)
      console.log("toggle Triggered")
 
      // 💾 SAVE
      sessionStorage.setItem("appliedCoupon", coupon.code);
      sessionStorage.setItem("discountAmount", discount);
      sessionStorage.setItem("finalTotal", finalTotal);
 
      // 🎉 TOAST
      setToastMsg(`🎉 ${coupon.code} Applied! Saved ₹${discount}`);
      setShowToast(true);
 
      // 🔙 BACK AFTER ANIMATION
       setTimeout(() => {
         navigate(-1);
       }, 2500);
 
    } catch (err) {
  console.log("FULL ERROR:", err.response);
  console.log("MESSAGE:", err.response?.data);
 
  showToast(err.response?.data?.message || "Coupon failed ❌");
}
 
  };
 
  return (
    <>
    <div style={{ padding: "15px", background: "#f8f8f8", minHeight: "100vh" }}>
 
      {/* HEADER */}
      <div style={{ display: "flex", alignItems: "center", marginBottom: "15px" }}>
        <button onClick={() => navigate(-1)}>⬅</button>
        <h3 style={{ marginLeft: "10px" }}>Apply Coupon</h3>
      </div>
 
      {/* SEARCH */}
      <input
        type="text"
        placeholder="Enter coupon code"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{
          width: "100%",
          padding: "10px",
          borderRadius: "8px",
          border: "1px solid #ddd",
          marginBottom: "20px",
        }}
      />
 
      {/* BEST COUPON */}
      {filteredCoupons.length > 0 && (
        <>
          <h4>Best Coupon</h4>
 
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              border: "1px solid #eee",
              borderRadius: "12px",
              padding: "12px",
              background: "#fff",
              marginBottom: "15px",
            }}
          >
            <div style={{ display: "flex", gap: "10px" }}>
              <div
                style={{
                  background: "#ff6f00",
                  color: "#fff",
                  padding: "12px",
                  borderRadius: "10px",
                  fontWeight: "bold",
                  fontSize: "12px",
                }}
              >
                {filteredCoupons[0].discountValue}% OFF
              </div>
 
              <div>
                <p style={{ fontWeight: "600" }}>
                  {filteredCoupons[0].code}
                </p>
                <p style={{ color: "green", fontSize: "13px" }}>
                  Save up to ₹{filteredCoupons[0].maxDiscount}
                </p>
                <p style={{ fontSize: "12px", color: "gray" }}>
                  {filteredCoupons[0].discountValue}% off above ₹
                  {filteredCoupons[0].minAmount}
                </p>
              </div>
            </div>
 
            <button
              onClick={() => handleApplyCoupon(filteredCoupons[0])}
              style={{
                color: "#ff6f00",
                fontWeight: "bold",
                border: "none",
                background: "none",
                cursor: "pointer",
              }}
            >
              APPLY
            </button>
          </div>
        </>
      )}
 
      {/* MORE COUPONS */}
      <h4>More Offers</h4>
 
      {filteredCoupons.slice(1).map((c) => (
        <div
          key={c._id}
          style={{
            display: "flex",
            justifyContent: "space-between",
            border: "1px solid #eee",
            borderRadius: "12px",
            padding: "12px",
            background: "#fff",
            marginBottom: "10px",
          }}
        >
          <div style={{ display: "flex", gap: "10px" }}>
            <div
              style={{
                background: "#ff6f00",
                color: "#fff",
                padding: "12px",
                borderRadius: "10px",
                fontWeight: "bold",
                fontSize: "12px",
              }}
            >
              {c.discountValue}% OFF
            </div>
 
            <div>
              <p style={{ fontWeight: "600" }}>{c.code}</p>
              <p style={{ color: "green", fontSize: "13px" }}>
                Save up to ₹{c.maxDiscount}
              </p>
              <p style={{ fontSize: "12px", color: "gray" }}>
                {c.discountValue}% off above ₹{c.minAmount}
              </p>
            </div>
          </div>
 
          <button
            onClick={() => handleApplyCoupon(c)}
            style={{
              color: "#ff6f00",
              fontWeight: "bold",
              border: "none",
              background: "none",
              cursor: "pointer",
            }}
          >
            APPLY
          </button>
        </div>
      ))}
 
      {/* 🔥 TOAST */}
      {showToast &&(
        <Toast
        message={toastMsg}
        onClose={()=>setShowToast(false)}
        />
      )}
    </div>
    </>
  );
};
 
export default CouponsPage;
 