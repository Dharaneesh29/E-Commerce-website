
import React from "react";

const Orders = ({ orders }) => {
  return (
    <div className="bg-gray-100 min-h-screen p-4 md:p-6">
      <div className="max-w-5xl mx-auto bg-white rounded shadow p-4 md:p-6">

        {/* 🔍 HEADER */}
        <h1 className="text-xl font-bold mb-4">Your Orders</h1>

        {/* 🔎 SEARCH + FILTER */}
        <div className="flex justify-between items-center border p-2 rounded mb-6">
          <input
            type="text"
            placeholder="Search all orders"
            className="outline-none flex-1"
          />
          <button className="text-blue-600 font-medium">Filter</button>
        </div>

        {/* 🛍️ BUY AGAIN */}
        <div className="mb-6">
          <div className="flex justify-between mb-2">
            <h2 className="font-semibold">Buy again</h2>
            <button className="text-blue-600 text-sm">See more</button>
          </div>

          <div className="flex gap-4 overflow-x-auto">
            {orders.slice(0, 5).flatMap((order) =>
              order.items.map((item) => (
                <img
                  key={item.id}
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded border"
                />
              ))
            )}
          </div>
        </div>

        {/* 📦 PURCHASE HISTORY */}
        <div>
          <h2 className="font-semibold mb-2">Purchase history</h2>
          <p className="text-sm text-gray-500 mb-4">
            Past three months
          </p>

          {orders.length === 0 ? (
            <p className="text-gray-500">No orders yet</p>
          ) : (
            orders.map((order) => (
              <div
                key={order.id}
                className="border rounded p-4 mb-4 bg-white shadow-sm"
              >
                {/* STATUS */}
                <p
                  className={`font-semibold ${
                    order.status === "Cancelled"
                      ? "text-red-500"
                      : "text-green-600"
                  }`}
                >
                  {order.status}
                </p>

                <p className="text-sm text-gray-500 mb-2">
                  Ordered on {order.date}
                </p>

                {/* ITEMS */}
                {order.items.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center gap-4 mt-3"
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-16 h-16 object-cover rounded border"
                    />

                    <div className="flex-1">
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-gray-500">
                        ₹{item.price} × {item.qty || 1}
                      </p>
                    </div>
                  </div>
                ))}

                {/* TOTAL */}
                <div className="flex justify-between mt-4 font-semibold">
                  <span>Total</span>
                  <span>₹{order.total}</span>
                </div>

                {/* ACTION BUTTONS */}
                <div className="flex gap-3 mt-4">
                  <button className="border px-4 py-1 rounded text-sm hover:bg-gray-100">
                    Buy Again
                  </button>
                  <button className="border px-4 py-1 rounded text-sm hover:bg-gray-100">
                    View Details
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Orders;
