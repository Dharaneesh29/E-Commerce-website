// import React, { useContext } from "react";
// import { ShopContext } from "../context/ShopContext";
// import { useNavigate } from "react-router-dom";
// import StepIndicator from "../components/StepIndicator";
 
// const Cart = () => {
//   const { cart=[], updateQty, removeItem } = useContext(ShopContext);
//   const navigate = useNavigate();
 
//   const total = cart.reduce(
//     (acc, item) => acc + item.product.price * item.qty,
//     0
//   );

//   const handleProceed = () => {
//   const token = sessionStorage.getItem("token");
 
//   if (!token) {
//     alert("Please login to continue");
//     navigate("/users/login");
//     return;
//   }
 
//   navigate("/shipping");
// };
 
//   return (
//     <div style={{
//       padding: "20px",
//       background: "#f5f5f5",
//       minHeight: "100vh"
//     }}>
      
//       {/* 🔥 STEP INDICATOR */}
//       <StepIndicator step={0} />
 
//       <div style={{ display: "flex", gap: "20px" }}>
        
//         {/* LEFT SIDE */}
//         <div style={{ flex: 2 }}>
//           <h2 style={{ marginBottom: "20px" }}>
//             My Cart ({cart.length} items)
//           </h2>
 
//           {cart.length === 0 ? (
//             <h3>Cart is empty</h3>
//           ) : (
//             cart.map((item) => (
//               <div key={item._id} style={{
//                 display: "flex",
//                 gap: "20px",
//                 background: "#fff",
//                 padding: "20px",
//                 marginBottom: "15px",
//                 borderRadius: "12px",
//                 boxShadow: "0 2px 8px rgba(0,0,0,0.05)",
//                 alignItems: "center"
//               }}>
                
//                 {/* IMAGE */}
//                 <img
//                   src={
//                     item.product.image?.startsWith("http")
//                       ? item.product.image
//                       : `http://localhost:5000${item.product.image}`
//                   }
//                   alt={item.product.name}
//                   style={{
//                     width: "100px",
//                     height: "100px",
//                     objectFit: "contain",
//                   }}
//                 />
 
//                 {/* DETAILS */}
//                 <div style={{ flex: 1 }}>
//                   <h4>{item.product.name}</h4>
//                   <p style={{ color: "gray" }}>₹ {item.product.price}</p>
 
//                   {/* QTY */}
//                   <div style={{
//                     display: "flex",
//                     alignItems: "center",
//                     gap: "10px",
//                     marginTop: "10px"
//                   }}>
//                     <button
//                       onClick={() =>
//                         updateQty(item.product._id, item.qty - 1)
//                       }
//                       style={btnStyle}
//                     >
//                       -
//                     </button>
 
//                     <span>{item.qty}</span>
 
//                     <button
//                       onClick={() =>
//                         updateQty(item.product._id, item.qty + 1)
//                       }
//                       style={btnStyle}
//                     >
//                       +
//                     </button>
//                   </div>
 
//                   {/* REMOVE */}
//                   <p
//                     onClick={() => removeItem(item.product._id)}
//                     style={{
//                       color: "red",
//                       cursor: "pointer",
//                       marginTop: "10px"
//                     }}
//                   >
//                     ✖ Remove
//                   </p>
//                 </div>
 
//                 {/* ITEM TOTAL */}
//                 <h4>₹ {item.product.price * item.qty}</h4>
//               </div>
//             ))
//           )}
//         </div>
 
//         {/* RIGHT SIDE */}
//         <div style={{
//           flex: 1,
//           background: "#fff",
//           padding: "20px",
//           borderRadius: "12px",
//           height: "fit-content",
//           position: "sticky",
//           top: "20px",
//           boxShadow: "0 2px 8px rgba(0,0,0,0.05)"
//         }}>
//           <h3>Order Details</h3>
 
//           <div style={{ marginTop: "15px" }}>
//             <p>Bag Total: ₹{total}</p>
//             <p>Delivery: Free</p>
//             <hr />
//             <h3>Total: ₹{total}</h3>
//           </div>
 
//           <button
//             onClick={handleProceed}
//             style={{
//               marginTop: "20px",
//               width: "100%",
//               padding: "12px",
//               background: "#ff6f00",
//               color: "#fff",
//               border: "none",
//               borderRadius: "8px",
//               fontWeight: "bold",
//               cursor: "pointer"
//             }}
//           >
//             PROCEED TO SHIPPING
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// };
 
// const btnStyle = {
//   padding: "5px 12px",
//   border: "1px solid #ccc",
//   background: "#fff",
//   cursor: "pointer",
//   borderRadius: "4px"
// };
 
// export default Cart;


 
import React, { useContext } from "react";
import { ShopContext } from "../context/ShopContext";
import { useNavigate } from "react-router-dom";
import StepIndicator from "../components/StepIndicator";

const Cart = () => {
  const { cart = [], updateQty, removeItem } = useContext(ShopContext);
  const navigate = useNavigate();

  // ✅ FIXED TOTAL (HYBRID SAFE)
  const total = cart.reduce((acc, item) => {
    const product = item.product || item;
    return acc + (product.price || 0) * (item.qty || 1);
  }, 0);
 
  const deliveryFee = total < 500 ? Math.floor(total * 0.05) : 0;


  const handleProceed = () => {
    const token = sessionStorage.getItem("token");

    if (!token) {
      alert("Please login to continue");
      navigate("/users/login");
      return;
    }

    navigate("/shipping");
  };

  const savings = Math.round(total * 0.1); // show 10% savings badge

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        .cart-root {
          font-family: 'Nunito', sans-serif;
          background: #fdf5ee;
          min-height: 100vh;
          padding: 28px 20px 60px;
        }

        .cart-layout {
          display: flex;
          gap: 24px;
          margin-top: 28px;
          align-items: flex-start;
        }

        .cart-left { flex: 2; }

        /* ── Header ── */
        .cart-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 20px;
        }
        .cart-title {
          font-size: 28px;
          font-weight: 800;
          color: #1a1a1a;
          letter-spacing: -0.4px;
        }
        .cart-count-badge {
          background: #ff6f00;
          color: #fff;
          font-size: 13px;
          font-weight: 700;
          padding: 4px 12px;
          border-radius: 20px;
          margin-left: 10px;
        }

        /* ── Empty state ── */
        .empty-cart {
          text-align: center;
          padding: 60px 20px;
          background: #fff;
          border-radius: 18px;
          border: 1.5px dashed #ffcc99;
        }
        .empty-cart .empty-icon {
          font-size: 56px;
          margin-bottom: 16px;
        }
        .empty-cart h3 {
          font-size: 20px;
          font-weight: 800;
          color: #333;
          margin-bottom: 8px;
        }
        .empty-cart p {
          color: #999;
          font-size: 14px;
          margin-bottom: 20px;
        }
        .btn-shop {
          display: inline-block;
          padding: 12px 28px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 10px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          box-shadow: 0 4px 14px rgba(255,111,0,0.3);
        }

        /* ── Cart item card ── */
        .cart-item {
          display: flex;
          gap: 18px;
          background: #fff;
          padding: 18px 20px;
          margin-bottom: 14px;
          border-radius: 16px;
          border: 1.5px solid #f0e8e0;
          box-shadow: 0 2px 12px rgba(0,0,0,0.04);
          align-items: center;
          transition: box-shadow 0.2s, border-color 0.2s;
          position: relative;
          overflow: hidden;
        }
        .cart-item:hover {
          box-shadow: 0 6px 22px rgba(255,111,0,0.1);
          border-color: #ffcc99;
        }
        .cart-item::before {
          content: '';
          position: absolute;
          top: 0; left: 0;
          width: 3px;
          height: 100%;
          background: linear-gradient(180deg, #ff6f00, #ffaa5a);
          border-radius: 3px 0 0 3px;
        }

        /* IMAGE */
        .item-img-wrap {
          width: 90px;
          height: 90px;
          border-radius: 12px;
          background: #fff8f2;
          border: 1.5px solid #ffe5cc;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          overflow: hidden;
        }
        .item-img-wrap img {
          width: 78px;
          height: 78px;
          object-fit: contain;
        }

        /* DETAILS */
        .item-details { flex: 1; }
        .item-name {
          font-size: 15px;
          font-weight: 800;
          color: #1a1a1a;
          margin-bottom: 4px;
        }
        .item-price {
          font-size: 13.5px;
          color: #888;
          margin-bottom: 12px;
        }
        .item-price strong {
          color: #ff6f00;
          font-size: 15px;
          font-weight: 800;
        }

        /* QTY CONTROLS */
        .qty-row {
          display: flex;
          align-items: center;
          gap: 0;
          width: fit-content;
          border: 1.5px solid #ffe0c2;
          border-radius: 10px;
          overflow: hidden;
          background: #fff8f2;
        }
        .qty-btn {
          width: 34px;
          height: 34px;
          border: none;
          background: transparent;
          font-size: 18px;
          font-weight: 700;
          color: #ff6f00;
          cursor: pointer;
          font-family: 'Nunito', sans-serif;
          transition: background 0.15s;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .qty-btn:hover { background: #ffe0c2; }
        .qty-value {
          min-width: 36px;
          text-align: center;
          font-size: 14px;
          font-weight: 800;
          color: #1a1a1a;
          border-left: 1.5px solid #ffe0c2;
          border-right: 1.5px solid #ffe0c2;
          height: 34px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        /* REMOVE */
        .remove-btn {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          margin-top: 10px;
          font-size: 12.5px;
          font-weight: 700;
          color: #e53935;
          background: #fff5f5;
          border: 1px solid #ffc9c9;
          padding: 5px 11px;
          border-radius: 7px;
          cursor: pointer;
          transition: background 0.15s, color 0.15s;
        }
        .remove-btn:hover {
          background: #e53935;
          color: #fff;
        }

        /* ITEM TOTAL */
        .item-total {
          font-size: 17px;
          font-weight: 800;
          color: #1a1a1a;
          white-space: nowrap;
          padding-left: 10px;
        }

        /* ── Savings banner ── */
        .savings-banner {
          display: flex;
          align-items: center;
          gap: 10px;
          background: linear-gradient(135deg, #fff8f2, #fff3e6);
          border: 1.5px solid #ffe0c2;
          border-radius: 12px;
          padding: 12px 16px;
          margin-bottom: 16px;
          font-size: 13.5px;
          font-weight: 700;
          color: #ff6f00;
        }
        .savings-banner span.tag {
          background: #ff6f00;
          color: #fff;
          font-size: 11px;
          font-weight: 800;
          padding: 3px 8px;
          border-radius: 6px;
          letter-spacing: 0.3px;
        }

        /* ── RIGHT: Summary ── */
        .summary-box {
          flex: 1;
          background: #fff;
          border-radius: 18px;
          padding: 24px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 6px 24px rgba(255,111,0,0.09);
          position: sticky;
          top: 20px;
        }
        .summary-box h3 {
          font-size: 18px;
          font-weight: 800;
          color: #1a1a1a;
          border-bottom: 2px dashed #ffe0c2;
          padding-bottom: 14px;
          margin-bottom: 16px;
        }

        .summary-line {
          display: flex;
          justify-content: space-between;
          font-size: 13.5px;
          color: #555;
          margin-bottom: 10px;
        }
        .summary-line span:last-child { font-weight: 700; color: #222; }

        .summary-divider {
          border: none;
          border-top: 1.5px dashed #ffe0c2;
          margin: 14px 0;
        }

        .delivery-row {
          display: flex;
          justify-content: space-between;
          font-size: 13.5px;
          color: #555;
          margin-bottom: 6px;
        }
        .delivery-row span:last-child {
          color: #2e9e5b;
          font-weight: 800;
        }

        .you-save {
          display: flex;
          justify-content: space-between;
          font-size: 12.5px;
          color: #2e9e5b;
          background: #edfaf4;
          border: 1px solid #b6e9cf;
          border-radius: 8px;
          padding: 8px 12px;
          margin-bottom: 4px;
          font-weight: 700;
        }

        .total-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background: #fff8f2;
          border-radius: 10px;
          padding: 12px 14px;
          border: 1.5px solid #ffe0c2;
          margin-top: 12px;
        }
        .total-row span:first-child {
          font-size: 14px;
          font-weight: 700;
          color: #555;
        }
        .total-row span:last-child {
          font-size: 22px;
          font-weight: 800;
          color: #ff6f00;
        }

        .btn-primary {
          margin-top: 18px;
          width: 100%;
          padding: 14px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          letter-spacing: 0.5px;
          cursor: pointer;
          transition: opacity 0.2s, transform 0.1s;
          box-shadow: 0 4px 14px rgba(255,111,0,0.35);
          font-family: 'Nunito', sans-serif;
        }
        .btn-primary:hover { opacity: 0.92; transform: translateY(-1px); }
        .btn-primary:active { transform: translateY(0); }

        .secure-note {
          margin-top: 12px;
          text-align: center;
          font-size: 12px;
          color: #bbb;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 5px;
        }

        /* ── Item count summary ── */
        .item-count-line {
          font-size: 13px;
          color: #aaa;
          margin-bottom: 14px;
          font-weight: 600;
        }

        @media (max-width: 768px) {
          .cart-layout { flex-direction: column; }
          .summary-box { position: static; }
        }
      `}</style>

      <div className="cart-root">
        {/* STEP INDICATOR */}
        <StepIndicator step={0} />

        <div className="cart-layout">
          {/* LEFT SIDE */}
          <div className="cart-left">
            <div className="cart-header">
              <h2 className="cart-title">
                My Cart
                <span className="cart-count-badge">{cart.length} item{cart.length !== 1 ? "s" : ""}</span>
              </h2>
            </div>

            {cart.length === 0 ? (
              <div className="empty-cart">
                <div className="empty-icon">🛒</div>
                <h3>Your cart is empty</h3>
                <p>Looks like you haven't added anything yet. Start shopping!</p>
                <button className="btn-shop" onClick={() => navigate("/home")}>
                  Browse Products
                </button>
              </div>
            ) : (
              <>
                {/* Savings banner */}
                <div className="savings-banner">
                  <span>🎉</span>
                  <span>You're saving <strong>₹{savings}</strong> on this order!</span>
                  <span className="tag">DEAL</span>
                </div>

                {cart.map((item) => {
                  const product = item.product || item; // ✅ KEY FIX

                  return (
                    <div key={product._id} className="cart-item">
                      {/* IMAGE */}
                      <div className="item-img-wrap">
                        <img
                          src={
                            product?.images?.length > 0
                              ? product.images[0].startsWith("http")
                                ? product.images[0]
                                : `http://localhost:5000${product.images[0]}`
                              : product?.image
                              ? product.image.startsWith("http")
                                ? product.image
                                : `http://localhost:5000${product.image}`
                              : "/placeholder.png"
                          }
                          alt={product?.name}
                        />
                      </div>

                      {/* DETAILS */}
                      <div className="item-details">
                        <p className="item-name">{product.name}</p>
                        <p className="item-price">
                          Unit price: <strong>₹{product.price}</strong>
                        </p>

                        {/* QTY */}
                        <div className="qty-row">
                          <button
                            className="qty-btn"
                            onClick={() => updateQty(product._id, item.qty - 1)}
                          >
                            −
                          </button>
                          <span className="qty-value">{item.qty}</span>
                          <button
                            className="qty-btn"
                            onClick={() => updateQty(product._id, item.qty + 1)}
                          >
                            +
                          </button>
                        </div>

                        {/* REMOVE */}
                        <span
                          className="remove-btn"
                          onClick={() => removeItem(product._id)}
                        >
                          ✕ Remove
                        </span>
                      </div>

                      {/* ITEM TOTAL */}
                      <div className="item-total">
                        ₹{(product.price || 0) * (item.qty || 1)}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>

          {/* RIGHT SIDE */}
          <div className="summary-box">
            <h3>Order Details</h3>

            <p className="item-count-line">{cart.length} item{cart.length !== 1 ? "s" : ""} in your cart</p>

            {cart.map((item) => {
              const product = item.product || item;
              return (
                <div key={product._id} className="summary-line">
                  <span>{product.name} × {item.qty}</span>
                  <span>₹{(product.price || 0) * (item.qty || 1)}</span>
                </div>
              );
            })}

            <hr className="summary-divider" />

            <div className="delivery-row">
              <span>Delivery</span>
              <span>{deliveryFee === 0 ? "FREE" : `₹${deliveryFee}`}</span>
            </div>

            <div className="you-save">
              <span>🏷️ You save</span>
              <span>₹{savings}</span>
            </div>

            <div className="total-row">
              <span>Total Amount</span>
              <span>₹{total+deliveryFee}</span>
            </div>

            <button onClick={handleProceed} className="btn-primary">
              PROCEED TO SHIPPING →
            </button>

            <p className="secure-note">
              🔒 Secure & encrypted checkout
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Cart;
