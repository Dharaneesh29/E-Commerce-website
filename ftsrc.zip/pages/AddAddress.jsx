import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
 
const AddAddress = () => {
  const navigate = useNavigate();
 
  const [form, setForm] = useState({
    name: "",
    phone: "",
    pincode: "",
    city: "",
    state: "",
    address: "",
    landmark: "",
    type: "Home",
  });
 
  const token = sessionStorage.getItem("token");
 
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    try {
      await axios.post(
        "http://localhost:5000/api/address",
        form,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
 
      alert("Address Added Successfully ✅");
      navigate("/profile");
    } catch (err) {
      console.log(err);
    }
  };
 
  return (
    <div className="min-h-screen bg-gray-100 flex justify-center items-start py-10">
      
      <div className="w-full max-w-4xl bg-white rounded-2xl shadow-lg p-8">
 
        {/* 🔥 HEADER */}
        <h2 className="text-3xl font-bold mb-6 text-center">
          Add New Address
        </h2>
 
        <form onSubmit={handleSubmit} className="space-y-6">
 
          {/* 🔹 PERSONAL INFO */}
          <div>
            <h3 className="text-lg font-semibold mb-3 text-gray-700">
              Contact Details
            </h3>
 
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                name="name"
                placeholder="Full Name"
                onChange={handleChange}
                className="input-style"
                required
              />
 
              <input
                type="text"
                name="phone"
                placeholder="Phone Number"
                onChange={handleChange}
                className="input-style"
                required
              />
            </div>
          </div>
 
          {/* 🔹 ADDRESS INFO */}
          <div>
            <h3 className="text-lg font-semibold mb-3 text-gray-700">
              Address Details
            </h3>
 
            <div className="grid grid-cols-2 gap-4">
 
              <input
                type="text"
                name="pincode"
                placeholder="Pincode"
                onChange={handleChange}
                className="input-style"
                required
              />
 
              <input
                type="text"
                name="city"
                placeholder="City"
                onChange={handleChange}
                className="input-style"
                required
              />
 
              <input
                type="text"
                name="state"
                placeholder="State"
                onChange={handleChange}
                className="input-style"
                required
              />
 
              <input
                type="text"
                name="landmark"
                placeholder="Landmark (Optional)"
                onChange={handleChange}
                className="input-style"
              />
 
            </div>
 
            <textarea
              name="address"
              placeholder="Full Address"
              onChange={handleChange}
              className="input-style mt-4 w-full"
              rows="3"
              required
            />
          </div>
 
          {/* 🔹 TYPE */}
          <div>
            <h3 className="text-lg font-semibold mb-3 text-gray-700">
              Address Type
            </h3>
 
            <div className="flex gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="type"
                  value="Home"
                  checked={form.type === "Home"}
                  onChange={handleChange}
                />
                Home 
              </label>
 
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="type"
                  value="Work"
                  checked={form.type === "Work"}
                  onChange={handleChange}
                />
                Work 
              </label>
            </div>
          </div>
 
          {/* 🔹 BUTTONS */}
          <div className="flex justify-end gap-4 pt-4">
            <button
              type="button"
              onClick={() => navigate("/profile")}
              className="px-4 py-2 rounded-lg border"
            >
              Cancel
            </button>
 
            <button
              type="submit"
              className="px-6 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700"
            >
              Save Address
            </button>
          </div>
 
        </form>
      </div>
    </div>
  );
};
 
export default AddAddress;