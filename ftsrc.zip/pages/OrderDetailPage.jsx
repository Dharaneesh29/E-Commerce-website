

// import { useEffect, useState } from "react";
// import axios from "axios";
// import { useParams, useNavigate } from "react-router-dom";
// import { io } from "socket.io-client";
// import { motion, AnimatePresence } from "framer-motion";

// const socket = io("http://localhost:5000");

// const OrderDetailsPage = () => {
//   const { id } = useParams();
//   const navigate = useNavigate();

//   const [order, setOrder] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [showReturnModal, setShowReturnModal] = useState(false);
//   const [returnReason, setReturnReason] = useState("");
//   const [returnItems, setReturnItems] = useState([]);
//   const [returnSubmitted, setReturnSubmitted] = useState(false);
//   const [returnLoading, setReturnLoading] = useState(false);
//   const [cancelConfirm, setCancelConfirm] = useState(false);
//   const [showCancelModal, setShowCancelModal]=useState(false);
//   const [cancelReason,setCancelReason] = useState("");


//   const token = JSON.parse(sessionStorage.getItem("userInfo"))?.token;

//   const getDeliveryDate = () => {
//     const today = new Date();
//     today.setDate(today.getDate() + 4);
//     return today.toLocaleDateString("en-IN", { day: "numeric", month: "long" });
//   };
//   const deliveryDate = getDeliveryDate();

//   const fetchOrder = async () => {
//     try {
//       const { data } = await axios.get(`http://localhost:5000/api/orders/${id}`, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setOrder(data);
//       setLoading(false);
//     } catch (err) {
//       console.log(err);
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchOrder();
//     socket.on("orderUpdated", (updatedOrder) => {
//       if (updatedOrder._id === id) setOrder(updatedOrder);
//     });
//     return () => socket.off("orderUpdated");
//   }, []);

//   const handleCancel = async () => {
//     try {
//       await axios.put(`http://localhost:5000/api/orders/${id}/cancel`, {}, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setCancelConfirm(false);
//       fetchOrder();
//     } catch (err) {
//       console.log(err);
//     }
//   };

//   const handleInvoice = () => window.print();

//   const toggleReturnItem = (itemId) => {
//     setReturnItems((prev) =>
//       prev.includes(itemId) ? prev.filter((i) => i !== itemId) : [...prev, itemId]
//     );
//   };

//   const handleReturnSubmit = async () => {
//     if (!returnReason.trim()) return alert("Please select a return reason.");
//     if (returnItems.length === 0) return alert("Please select at least one item to return.");
//     setReturnLoading(true);
//     try {
//       await axios.post(
//         `http://localhost:5000/api/orders/${id}/return`,
//         { reason: returnReason, items: returnItems },
//         { headers: { Authorization: `Bearer ${token}` } }
//       );
//       setReturnSubmitted(true);
//       fetchOrder();
//     } catch (err) {
//       console.log(err);
//       // Even if API isn't ready, show success for UI demo
//       setReturnSubmitted(true);
//     } finally {
//       setReturnLoading(false);
//     }
//   };

//   const steps = ["pending", "confirmed", "shipped", "out_for_delivery", "delivered"];
//   const stepIcons = ["🕐", "✅", "📦", "🚚", "🏠"];
//   const stepLabels = ["Pending", "Confirmed", "Shipped", "Out for Delivery", "Delivered"];
//   const currentStep = steps.indexOf(order?.status);

//   const returnReasons = [
//     "Damaged / Defective product",
//     "Wrong item delivered",
//     "Item not as described",
//     "Changed my mind",
//     "Size / Fit issue",
//     "Better price available elsewhere",
//   ];

//   const cancelReasons = [
//   "Ordered by mistake",
//   "Found better price",
//   "Changed my mind",
//   "Delivery too slow",
//   "Duplicate order",
//   "Item no longer needed",
// ];
 

//   const statusColors = {
//     pending: { bg: "#fff8f2", text: "#ff6f00", border: "#ffe0c2" },
//     confirmed: { bg: "#edfaf4", text: "#2e9e5b", border: "#b6e9cf" },
//     shipped: { bg: "#eff6ff", text: "#3b82f6", border: "#bfdbfe" },
//     out_for_delivery: { bg: "#fdf4ff", text: "#9333ea", border: "#e9d5ff" },
//     delivered: { bg: "#edfaf4", text: "#2e9e5b", border: "#b6e9cf" },
//     cancelled: { bg: "#fff5f5", text: "#e53935", border: "#ffc9c9" },
//     return_requested: { bg: "#fff8f2", text: "#ff6f00", border: "#ffe0c2" },
//   };

//   const sc = statusColors[order?.status] || statusColors.pending;

//   if (loading)
//     return (
//       <div style={{ fontFamily: "'Nunito', sans-serif", display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh", flexDirection: "column", gap: 16 }}>
//         <div style={{ width: 44, height: 44, border: "4px solid #ffe0c2", borderTopColor: "#ff6f00", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
//         <p style={{ color: "#aaa", fontWeight: 700 }}>Loading order details...</p>
//         <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
//       </div>
//     );

//   if (!order)
//     return (
//       <div style={{ fontFamily: "'Nunito', sans-serif", textAlign: "center", padding: "60px 20px" }}>
//         <div style={{ fontSize: 48, marginBottom: 16 }}>📦</div>
//         <p style={{ fontWeight: 800, fontSize: 18, color: "#333" }}>Order not found</p>
//         <button onClick={() => navigate(-1)} style={{ marginTop: 16, padding: "10px 24px", background: "#ff6f00", color: "#fff", border: "none", borderRadius: 10, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>Go Back</button>
//       </div>
//     );

//   return (
//     <>
//       <style>{`
//         @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&display=swap');
//         * { box-sizing: border-box; margin: 0; padding: 0; }

//         .od-root {
//           font-family: 'Nunito', sans-serif;
//           background: #fdf5ee;
//           min-height: 100vh;
//           padding: 28px 20px 60px;
//           max-width: 860px;
//           margin: 0 auto;
//         }

//         /* Header */
//         .od-header {
//           display: flex;
//           align-items: center;
//           justify-content: space-between;
//           margin-bottom: 24px;
//           flex-wrap: wrap;
//           gap: 12px;
//         }
//         .od-back {
//           display: flex;
//           align-items: center;
//           gap: 6px;
//           font-size: 13.5px;
//           font-weight: 700;
//           color: #ff6f00;
//           cursor: pointer;
//           border: 1.5px solid #ff6f00;
//           padding: 6px 14px;
//           border-radius: 8px;
//           background: transparent;
//           transition: background 0.2s, color 0.2s;
//           font-family: inherit;
//         }
//         .od-back:hover { background: #ff6f00; color: #fff; }
//         .od-title {
//           font-size: 26px;
//           font-weight: 900;
//           color: #1a1a1a;
//           letter-spacing: -0.4px;
//         }
//         .od-title span { color: #ff6f00; }

//         /* Cards */
//         .od-card {
//           background: #fff;
//           border-radius: 18px;
//           border: 1.5px solid #ffe0c2;
//           box-shadow: 0 4px 18px rgba(255,111,0,0.07);
//           padding: 24px;
//           margin-bottom: 18px;
//           position: relative;
//           overflow: hidden;
//         }
//         .od-card::before {
//           content: '';
//           position: absolute;
//           top: 0; left: 0;
//           width: 100%; height: 4px;
//           background: linear-gradient(90deg, #ff6f00, #ffaa5a);
//         }
//         .od-card-title {
//           font-size: 16px;
//           font-weight: 800;
//           color: #1a1a1a;
//           margin-bottom: 18px;
//           display: flex;
//           align-items: center;
//           gap: 8px;
//         }

//         /* Tracking bar */
//         .track-wrap {
//           position: relative;
//           display: flex;
//           justify-content: space-between;
//           align-items: flex-start;
//           padding-top: 8px;
//         }
//         .track-line-bg {
//           position: absolute;
//           top: 20px; left: 5%; right: 5%;
//           height: 3px;
//           background: #f0e8e0;
//           border-radius: 3px;
//           z-index: 0;
//         }
//         .track-line-fill {
//           height: 3px;
//           background: linear-gradient(90deg, #ff6f00, #ffaa5a);
//           border-radius: 3px;
//           transition: width 0.8s ease;
//         }
//         .track-step {
//           display: flex;
//           flex-direction: column;
//           align-items: center;
//           gap: 8px;
//           z-index: 2;
//           flex: 1;
//         }
//         .track-dot {
//           width: 40px; height: 40px;
//           border-radius: 50%;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           font-size: 16px;
//           border: 2.5px solid #e8e8e8;
//           background: #fff;
//           color: #ccc;
//           transition: all 0.4s ease;
//         }
//         .track-dot.done {
//           background: linear-gradient(135deg, #ff6f00, #ff9500);
//           border-color: #ff6f00;
//           box-shadow: 0 3px 12px rgba(255,111,0,0.3);
//         }
//         .track-dot.current {
//           border-color: #ff6f00;
//           box-shadow: 0 0 0 5px rgba(255,111,0,0.12);
//           background: #fff8f2;
//         }
//         .track-label {
//           font-size: 10.5px;
//           font-weight: 700;
//           color: #bbb;
//           text-align: center;
//           line-height: 1.3;
//         }
//         .track-label.done { color: #ff6f00; }
//         .track-label.current { color: #555; }

//         .truck-row {
//           position: relative;
//           height: 36px;
//           margin-top: 12px;
//         }
//         .truck-emoji {
//           position: absolute;
//           font-size: 24px;
//           transition: left 0.8s ease;
//           transform: translateX(-50%);
//         }

//         .delivery-badge {
//           display: inline-flex;
//           align-items: center;
//           gap: 8px;
//           background: #fff8f2;
//           border: 1.5px solid #ffe0c2;
//           border-radius: 10px;
//           padding: 10px 16px;
//           font-size: 13.5px;
//           font-weight: 700;
//           color: #555;
//           margin-top: 16px;
//         }
//         .delivery-badge span { color: #ff6f00; font-weight: 900; }

//         /* Timeline */
//         .timeline-item {
//           display: flex;
//           gap: 14px;
//           align-items: flex-start;
//           padding-bottom: 16px;
//           position: relative;
//         }
//         .timeline-item:not(:last-child)::after {
//           content: '';
//           position: absolute;
//           left: 9px; top: 22px;
//           width: 2px;
//           height: calc(100% - 10px);
//           background: #ffe0c2;
//         }
//         .timeline-dot {
//           width: 20px; height: 20px;
//           border-radius: 50%;
//           background: linear-gradient(135deg, #ff6f00, #ff9500);
//           flex-shrink: 0;
//           box-shadow: 0 2px 8px rgba(255,111,0,0.25);
//           margin-top: 2px;
//         }
//         .timeline-text {
//           font-size: 13.5px;
//           font-weight: 700;
//           color: #333;
//           text-transform: capitalize;
//         }
//         .timeline-time {
//           font-size: 12px;
//           color: #aaa;
//           font-weight: 600;
//           margin-top: 2px;
//         }

//         /* Summary grid */
//         .summary-grid {
//           display: grid;
//           grid-template-columns: 1fr 1fr;
//           gap: 14px;
//         }
//         .summary-cell {
//           background: #fff8f2;
//           border: 1.5px solid #ffe0c2;
//           border-radius: 12px;
//           padding: 14px 16px;
//         }
//         .summary-cell .s-label {
//           font-size: 11px;
//           font-weight: 700;
//           color: #aaa;
//           text-transform: uppercase;
//           letter-spacing: 0.4px;
//           margin-bottom: 5px;
//         }
//         .summary-cell .s-value {
//           font-size: 18px;
//           font-weight: 900;
//           color: #ff6f00;
//         }
//         .summary-cell .s-value.dark { color: #1a1a1a; font-size: 15px; }

//         .status-pill {
//           display: inline-flex;
//           align-items: center;
//           gap: 5px;
//           padding: 5px 12px;
//           border-radius: 20px;
//           font-size: 12px;
//           font-weight: 800;
//           border: 1.5px solid;
//           margin-top: 4px;
//         }

//         /* Items */
//         .order-item {
//           display: flex;
//           gap: 14px;
//           align-items: center;
//           padding: 14px 0;
//           border-bottom: 1.5px solid #f5ece4;
//           position: relative;
//         }
//         .order-item:last-child { border-bottom: none; padding-bottom: 0; }
//         .order-item-img {
//           width: 70px; height: 70px;
//           border-radius: 12px;
//           object-fit: cover;
//           border: 1.5px solid #ffe0c2;
//           background: #fff8f2;
//           flex-shrink: 0;
//         }
//         .order-item-name {
//           font-size: 14px;
//           font-weight: 800;
//           color: #1a1a1a;
//           margin-bottom: 4px;
//         }
//         .order-item-qty {
//           font-size: 12.5px;
//           color: #aaa;
//           font-weight: 600;
//         }
//         .order-item-price {
//           font-size: 16px;
//           font-weight: 900;
//           color: #1a1a1a;
//           margin-left: auto;
//         }

//         /* Delivery partner */
//         .partner-card {
//           display: flex;
//           gap: 16px;
//           align-items: center;
//         }
//         .partner-avatar {
//           width: 52px; height: 52px;
//           background: linear-gradient(135deg, #ff6f00, #ff9500);
//           border-radius: 50%;
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           font-size: 20px;
//           font-weight: 900;
//           color: #fff;
//           flex-shrink: 0;
//           box-shadow: 0 4px 12px rgba(255,111,0,0.3);
//         }
//         .partner-name { font-size: 15px; font-weight: 800; color: #1a1a1a; margin-bottom: 4px; }
//         .partner-phone { font-size: 13.5px; color: #3b82f6; font-weight: 700; }

//         /* Action buttons */
//         .actions-row {
//           display: flex;
//           gap: 12px;
//           flex-wrap: wrap;
//           margin-top: 4px;
//         }
//         .btn-cancel {
//           flex: 1;
//           padding: 13px;
//           background: #fff5f5;
//           color: #e53935;
//           border: 2px solid #e53935;
//           border-radius: 12px;
//           font-weight: 800;
//           font-size: 14px;
//           cursor: pointer;
//           transition: background 0.2s, color 0.2s;
//           font-family: inherit;
//           min-width: 140px;
//         }
//         .btn-cancel:hover { background: #e53935; color: #fff; }

//         .btn-return {
//           flex: 1;
//           padding: 13px;
//           background: #fff8f2;
//           color: #ff6f00;
//           border: 2px solid #ff6f00;
//           border-radius: 12px;
//           font-weight: 800;
//           font-size: 14px;
//           cursor: pointer;
//           transition: background 0.2s, color 0.2s;
//           font-family: inherit;
//           min-width: 140px;
//         }
//         .btn-return:hover { background: #ff6f00; color: #fff; }

//         .btn-invoice {
//           flex: 1;
//           padding: 13px;
//           background: #1a1a1a;
//           color: #fff;
//           border: 2px solid #1a1a1a;
//           border-radius: 12px;
//           font-weight: 800;
//           font-size: 14px;
//           cursor: pointer;
//           transition: background 0.2s;
//           font-family: inherit;
//           min-width: 140px;
//         }
//         .btn-invoice:hover { background: #333; }

//         /* Cancel confirm */
//         .cancel-confirm-box {
//           background: #fff5f5;
//           border: 1.5px solid #ffc9c9;
//           border-radius: 14px;
//           padding: 18px 20px;
//           margin-bottom: 16px;
//           text-align: center;
//         }
//         .cancel-confirm-box p {
//           font-size: 14px;
//           font-weight: 700;
//           color: #333;
//           margin-bottom: 14px;
//         }
//         .cancel-confirm-btns { display: flex; gap: 10px; justify-content: center; }
//         .btn-yes {
//           padding: 9px 24px;
//           background: #e53935;
//           color: #fff;
//           border: none;
//           border-radius: 9px;
//           font-weight: 800;
//           font-size: 13px;
//           cursor: pointer;
//           font-family: inherit;
//         }
//         .btn-no {
//           padding: 9px 24px;
//           background: #f0f0f0;
//           color: #555;
//           border: none;
//           border-radius: 9px;
//           font-weight: 800;
//           font-size: 13px;
//           cursor: pointer;
//           font-family: inherit;
//         }

//         /* Return Modal Overlay */
//         .modal-overlay {
//           position: fixed;
//           inset: 0;
//           background: rgba(0,0,0,0.45);
//           display: flex;
//           align-items: center;
//           justify-content: center;
//           z-index: 1000;
//           padding: 20px;
//           backdrop-filter: blur(3px);
//         }
//         .modal-box {
//           background: #fff;
//           border-radius: 22px;
//           padding: 32px;
//           width: 100%;
//           max-width: 480px;
//           border: 1.5px solid #ffe0c2;
//           box-shadow: 0 20px 60px rgba(0,0,0,0.2);
//           position: relative;
//           overflow: hidden;
//         }
//         .modal-box::before {
//           content: '';
//           position: absolute;
//           top: 0; left: 0; right: 0;
//           height: 4px;
//           background: linear-gradient(90deg, #ff6f00, #ffaa5a);
//         }
//         .modal-title {
//           font-size: 20px;
//           font-weight: 900;
//           color: #1a1a1a;
//           margin-bottom: 6px;
//         }
//         .modal-sub {
//           font-size: 13px;
//           color: #aaa;
//           font-weight: 600;
//           margin-bottom: 22px;
//         }
//         .modal-section-label {
//           font-size: 12px;
//           font-weight: 700;
//           color: #aaa;
//           text-transform: uppercase;
//           letter-spacing: 0.4px;
//           margin-bottom: 10px;
//         }

//         /* Return item checkbox */
//         .return-item-row {
//           display: flex;
//           align-items: center;
//           gap: 12px;
//           padding: 10px 12px;
//           border: 1.5px solid #e8e8e8;
//           border-radius: 11px;
//           margin-bottom: 8px;
//           cursor: pointer;
//           transition: border-color 0.2s, background 0.15s;
//         }
//         .return-item-row:hover { border-color: #ffcc99; background: #fff8f2; }
//         .return-item-row.checked { border-color: #ff6f00; background: #fff8f2; }
//         .return-item-row input[type="checkbox"] {
//           accent-color: #ff6f00;
//           width: 17px; height: 17px;
//           cursor: pointer;
//           flex-shrink: 0;
//         }
//         .return-item-img {
//           width: 38px; height: 38px;
//           border-radius: 7px;
//           object-fit: cover;
//           border: 1px solid #ffe0c2;
//         }
//         .return-item-name {
//           font-size: 13px;
//           font-weight: 700;
//           color: #333;
//           flex: 1;
//         }

//         /* Reason pills */
//         .reason-grid {
//           display: grid;
//           grid-template-columns: 1fr 1fr;
//           gap: 8px;
//           margin-bottom: 20px;
//         }
//         .reason-pill {
//           padding: 9px 12px;
//           border: 1.5px solid #e8e8e8;
//           border-radius: 9px;
//           font-size: 12.5px;
//           font-weight: 700;
//           color: #555;
//           cursor: pointer;
//           transition: border-color 0.2s, background 0.15s, color 0.15s;
//           text-align: center;
//           line-height: 1.3;
//         }
//         .reason-pill:hover { border-color: #ffcc99; background: #fff8f2; }
//         .reason-pill.selected { border-color: #ff6f00; background: #fff8f2; color: #ff6f00; }

//         .modal-actions { display: flex; gap: 10px; margin-top: 6px; }
//         .btn-submit-return {
//           flex: 1;
//           padding: 13px;
//           background: linear-gradient(135deg, #ff6f00, #ff9500);
//           color: #fff;
//           border: none;
//           border-radius: 11px;
//           font-weight: 800;
//           font-size: 14px;
//           cursor: pointer;
//           font-family: inherit;
//           box-shadow: 0 4px 14px rgba(255,111,0,0.3);
//           transition: opacity 0.2s;
//         }
//         .btn-submit-return:disabled { opacity: 0.6; cursor: not-allowed; }
//         .btn-close-modal {
//           padding: 13px 20px;
//           background: #f0f0f0;
//           color: #555;
//           border: none;
//           border-radius: 11px;
//           font-weight: 800;
//           font-size: 14px;
//           cursor: pointer;
//           font-family: inherit;
//         }

//         /* Return success */
//         .return-success {
//           text-align: center;
//           padding: 20px 0;
//         }
//         .return-success .rs-icon { font-size: 52px; margin-bottom: 14px; }
//         .return-success h3 { font-size: 18px; font-weight: 900; color: #1a1a1a; margin-bottom: 6px; }
//         .return-success p { font-size: 13.5px; color: #888; font-weight: 600; line-height: 1.6; }

//         @keyframes spin { to { transform: rotate(360deg); } }
//         .spin { animation: spin 0.7s linear infinite; }
//       `}</style>

//       {/* RETURN MODAL */}
//       <AnimatePresence>
//         {showReturnModal && (
//           <motion.div
//             className="modal-overlay"
//             initial={{ opacity: 0 }}
//             animate={{ opacity: 1 }}
//             exit={{ opacity: 0 }}
//             onClick={(e) => { if (e.target === e.currentTarget) { setShowReturnModal(false); setReturnSubmitted(false); } }}
//           >
//             <motion.div
//               className="modal-box"
//               initial={{ scale: 0.85, opacity: 0, y: 30 }}
//               animate={{ scale: 1, opacity: 1, y: 0 }}
//               exit={{ scale: 0.85, opacity: 0, y: 30 }}
//               transition={{ type: "spring", stiffness: 300, damping: 25 }}
//             >
//               {returnSubmitted ? (
//                 <div className="return-success">
//                   <div className="rs-icon">📦</div>
//                   <h3>Return Requested!</h3>
//                   <p>
//                     Your return request has been submitted.<br />
//                     Our team will review it within 24–48 hours.<br />
//                     Refund will be processed after pickup.
//                   </p>
//                   <button
//                     className="btn-submit-return"
//                     style={{ marginTop: 24, width: "100%" }}
//                     onClick={() => { setShowReturnModal(false); setReturnSubmitted(false); }}
//                   >
//                     Done
//                   </button>
//                 </div>
//               ) : (
//                 <>
//                   <p className="modal-title">↩️ Return Order</p>
//                   <p className="modal-sub">Select items and reason for return</p>

//                   {/* Items to return */}
//                   <p className="modal-section-label">Select Items</p>
//                   <div style={{ marginBottom: 18 }}>
//                     {order.orderItems.map((item, i) => (
//                       <div
//                         key={i}
//                         className={`return-item-row ${returnItems.includes(item._id || i) ? "checked" : ""}`}
//                         onClick={() => toggleReturnItem(item._id || i)}
//                       >
//                         <input
//                           type="checkbox"
//                           checked={returnItems.includes(item._id || i)}
//                           onChange={() => {}}
//                         />
//                         <img
//                           src={
//                             item.product?.images?.length > 0
//                               ? item.product.images[0]
//                               : "https://via.placeholder.com/40"
//                           }
//                           className="return-item-img"
//                           alt={item.name}
//                         />
//                         <span className="return-item-name">{item.name}</span>
//                         <span style={{ fontSize: 13, fontWeight: 800, color: "#ff6f00" }}>₹{item.price}</span>
//                       </div>
//                     ))}
//                   </div>

//                   {/* Return reasons */}
//                   <p className="modal-section-label">Reason for Return</p>
//                   <div className="reason-grid">
//                     {returnReasons.map((r) => (
//                       <div
//                         key={r}
//                         className={`reason-pill ${returnReason === r ? "selected" : ""}`}
//                         onClick={() => setReturnReason(r)}
//                       >
//                         {r}
//                       </div>
//                     ))}
//                   </div>

//                   <div className="modal-actions">
//                     <button className="btn-close-modal" onClick={() => setShowReturnModal(false)}>
//                       Cancel
//                     </button>
//                     <button
//                       className="btn-submit-return"
//                       onClick={handleReturnSubmit}
//                       disabled={returnLoading}
//                     >
//                       {returnLoading ? (
//                         <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
//                           <span style={{ width: 16, height: 16, border: "2.5px solid rgba(255,255,255,0.4)", borderTopColor: "#fff", borderRadius: "50%" }} className="spin" />
//                           Submitting...
//                         </span>
//                       ) : "Submit Return →"}
//                     </button>
//                   </div>
//                 </>
//               )}
//             </motion.div>
//           </motion.div>
//         )}
//       </AnimatePresence>


//      <AnimatePresence>
//       {showCancelModal && (
//     <motion.div
//       className="modal-overlay"
//       initial={{ opacity: 0 }}
//       animate={{ opacity: 1 }}
//       exit={{ opacity: 0 }}
//       onClick={(e) => { if (e.target === e.currentTarget) { setShowCancelModal(false); setCancelReason(""); } }}
//     >
//       <motion.div
//         className="modal-box"
//         initial={{ scale: 0.85, opacity: 0, y: 30 }}
//         animate={{ scale: 1, opacity: 1, y: 0 }}
//         exit={{ scale: 0.85, opacity: 0, y: 30 }}
//         transition={{ type: "spring", stiffness: 300, damping: 25 }}
//       >
//         <div className="modal-title">Cancel Order</div>
//         <div className="modal-sub">Please tell us why you're cancelling</div>
 
//         <div className="modal-section-label">Select a reason</div>
//         <div className="reason-grid" style={{ marginBottom: 24 }}>
//           {cancelReasons.map((r) => (
//             <div
//               key={r}
//               className={`reason-pill${cancelReason === r ? " selected" : ""}`}
//               onClick={() => setCancelReason(r)}
//             >
//               {r}
//             </div>
//           ))}
//         </div>
 
//         <div className="modal-actions">
//           <button
//             className="btn-submit-return"
//             style={{ background: "linear-gradient(135deg, #e53935, #ef5350)" }}
//             disabled={!cancelReason}
//             onClick={handleCancel}
//           >
//             Confirm Cancel
//           </button>
//           <button
//             className="btn-close-modal"
//             onClick={() => { setShowCancelModal(false); setCancelReason(""); }}
//           >
//             Go Back
//           </button>
//         </div>
//       </motion.div>
//     </motion.div>
//   )}
// </AnimatePresence>
 


//       <div className="od-root">
//         {/* HEADER */}
//         <div className="od-header">
//           <button className="od-back" onClick={() => navigate(-1)}>← Back</button>
//           <div>
//             <h1 className="od-title">Order <span>#{order._id.slice(-6).toUpperCase()}</span></h1>
//           </div>
//           <div
//             className="status-pill"
//             style={{ background: sc.bg, color: sc.text, borderColor: sc.border }}
//           >
//             {order.status.replaceAll("_", " ").toUpperCase()}
//           </div>
//         </div>

//         {/* TRACKING */}
//         <motion.div
//           className="od-card"
//           initial={{ opacity: 0, y: 24 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ duration: 0.4 }}
//         >
//           <p className="od-card-title">🚚 Live Order Tracking</p>

//           <div className="track-wrap">
//             <div className="track-line-bg">
//               <motion.div
//                 className="track-line-fill"
//                 initial={{ width: 0 }}
//                 animate={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
//                 transition={{ duration: 0.9, delay: 0.2 }}
//               />
//             </div>

//             {steps.map((step, index) => {
//               const state = index < currentStep ? "done" : index === currentStep ? "current" : "";
//               return (
//                 <div key={index} className="track-step">
//                   <motion.div
//                     className={`track-dot ${state}`}
//                     initial={{ scale: 0 }}
//                     animate={{ scale: 1 }}
//                     transition={{ delay: index * 0.1 + 0.3 }}
//                   >
//                     {state === "done" ? "✔" : stepIcons[index]}
//                   </motion.div>
//                   <p className={`track-label ${state}`}>
//                     {stepLabels[index].split(" ").map((w, j) => (
//                       <span key={j} style={{ display: "block" }}>{w}</span>
//                     ))}
//                   </p>
//                 </div>
//               );
//             })}
//           </div>

//           <div className="truck-row">
//             <motion.div
//               className="truck-emoji"
//               animate={{ left: `${Math.min((currentStep / (steps.length - 1)) * 90 + 5, 95)}%` }}
//               transition={{ duration: 0.9, delay: 0.2 }}
//             >
//               🚚
//             </motion.div>
//           </div>

//           <div className="delivery-badge">
//             📅 Estimated Delivery: <span>{deliveryDate}</span>
//           </div>
//         </motion.div>

//         {/* DELIVERY PARTNER */}
//         {order.status === "out_for_delivery" && (
//           <motion.div
//             className="od-card"
//             initial={{ opacity: 0, y: 20 }}
//             animate={{ opacity: 1, y: 0 }}
//           >
//             <p className="od-card-title">🧑‍💼 Delivery Partner</p>
//             <div className="partner-card">
//               <div className="partner-avatar">
//                 {order.deliveryPartner?.name?.[0] || "D"}
//               </div>
//               <div>
//                 <p className="partner-name">{order.deliveryPartner?.name || "Assigned Soon"}</p>
//                 <p className="partner-phone">📞 {order.deliveryPartner?.phone || "Updating..."}</p>
//               </div>
//             </div>
//           </motion.div>
//         )}

//         {/* TIMELINE */}
//         <motion.div
//           className="od-card"
//           initial={{ opacity: 0, y: 24 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.15 }}
//         >
//           <p className="od-card-title">🕐 Order Timeline</p>
//           <div>
//             {steps.slice(0, currentStep + 1).map((step, i) => (
//               <motion.div
//                 key={i}
//                 className="timeline-item"
//                 initial={{ opacity: 0, x: -16 }}
//                 animate={{ opacity: 1, x: 0 }}
//                 transition={{ delay: i * 0.1 }}
//               >
//                 <div className="timeline-dot" />
//                 <div>
//                   <p className="timeline-text">{step.replaceAll("_", " ")}</p>
//                   <p className="timeline-time">Step {i + 1} of {steps.length}</p>
//                 </div>
//               </motion.div>
//             ))}
//           </div>
//         </motion.div>

//         {/* ORDER SUMMARY */}
//         <motion.div
//           className="od-card"
//           initial={{ opacity: 0, y: 24 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.2 }}
//         >
//           <p className="od-card-title">💳 Order Summary</p>
//           <div className="summary-grid">
//             <div className="summary-cell">
//               <p className="s-label">Total Amount</p>
//               <p className="s-value">₹{order.totalPrice}</p>
//             </div>
//             <div className="summary-cell">
//               <p className="s-label">Payment Method</p>
//               <p className="s-value dark">{order.paymentMethod}</p>
//             </div>
//             <div className="summary-cell">
//               <p className="s-label">Order Status</p>
//               <span
//                 className="status-pill"
//                 style={{ background: sc.bg, color: sc.text, borderColor: sc.border, marginTop: 0 }}
//               >
//                 {order.status.replaceAll("_", " ")}
//               </span>
//             </div>
//             <div className="summary-cell">
//               <p className="s-label">Items Count</p>
//               <p className="s-value dark">{order.orderItems.length} item{order.orderItems.length !== 1 ? "s" : ""}</p>
//             </div>
//           </div>
//         </motion.div>

//         {/* ITEMS */}
//         <motion.div
//           className="od-card"
//           initial={{ opacity: 0, y: 24 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.25 }}
//         >
//           <p className="od-card-title">🛍️ Order Items</p>
//           {order.orderItems.map((item, i) => (
//             <motion.div
//               key={i}
//               className="order-item"
//               initial={{ opacity: 0, x: -12 }}
//               animate={{ opacity: 1, x: 0 }}
//               transition={{ delay: i * 0.08 }}
//             >
//               <img
//                 src={
//                 item.product?.images && item.product.images.length > 0
//                   ? item.product?.images[0].startsWith("http")
//                     ? item.product?.images[0]
//                     : `http://localhost:5000${item.product.images[0]}`
//                   : "/placeholder.png"
//               }
//                 className="order-item-img"
//                 alt={item.name}
//               />
//               <div style={{ flex: 1 }}>
//                 <p className="order-item-name">{item.name}</p>
//                 <p className="order-item-qty">Qty: {item.qty}</p>
//               </div>
//               <p className="order-item-price">₹{item.price}</p>
//             </motion.div>
//           ))}
//         </motion.div>

//         {/* ACTIONS */}
//         <motion.div
//           initial={{ opacity: 0, y: 16 }}
//           animate={{ opacity: 1, y: 0 }}
//           transition={{ delay: 0.3 }}
//         >
//           {/* Cancel confirm inline */}
//             {cancelConfirm && (
//   <div className="cancel-confirm-box">
//     <p>Are you sure you want to cancel this order?</p>
//     <div className="cancel-confirm-btns">
//       <button className="btn-yes" onClick={() => { setShowCancelModal(true); setCancelConfirm(false); }}>
//         Yes, Cancel
//       </button>
//       <button className="btn-no" onClick={() => setCancelConfirm(false)}>
//         No, Keep
//       </button>
//     </div>
//   </div>
// )}
 

//           <div className="actions-row">
//             {order.status !== "delivered" &&
//               order.status !== "cancelled" &&
//               order.status !== "return_requested" && (
//                 <button className="btn-cancel" onClick={() => setCancelConfirm(true)}>
//                   ✕ Cancel Order
//                 </button>
//               )}

//             {order.status === "delivered" && (
//               <button
//                 className="btn-return"
//                 onClick={() => { setShowReturnModal(true); setReturnSubmitted(false); setReturnItems([]); setReturnReason(""); }}
//               >
//                 ↩️ Return Order
//               </button>
//             )}

//             {order.status === "return_requested" && (
//               <div style={{ flex: 1, padding: "13px", background: "#fff8f2", border: "2px solid #ffcc99", borderRadius: 12, textAlign: "center", fontWeight: 800, color: "#ff6f00", fontSize: 14 }}>
//                 🔄 Return Request Pending
//               </div>
//             )}

//             <button className="btn-invoice" onClick={handleInvoice}>
//               🧾 Download Invoice
//             </button>
//           </div>
//         </motion.div>
//       </div>
//     </>
//   );
// };

// export default OrderDetailsPage;





import { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import { io } from "socket.io-client";
import { motion, AnimatePresence } from "framer-motion";

const socket = io("http://localhost:5000");

const OrderDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [returnReason, setReturnReason] = useState("");
  const [returnItems, setReturnItems] = useState([]);
  const [returnSubmitted, setReturnSubmitted] = useState(false);
  const [returnLoading, setReturnLoading] = useState(false);
  const [cancelConfirm, setCancelConfirm] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [cancelReason, setCancelReason] = useState("");

  const token = JSON.parse(sessionStorage.getItem("userInfo"))?.token;

  const getDeliveryDate = () => {
    const today = new Date();
    today.setDate(today.getDate() + 4);
    return today.toLocaleDateString("en-IN", { day: "numeric", month: "long" });
  };
  const deliveryDate = getDeliveryDate();

  const fetchOrder = async () => {
    try {
      const { data } = await axios.get(`http://localhost:5000/api/orders/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setOrder(data);
      setLoading(false);
    } catch (err) {
      console.log(err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrder();
    socket.on("orderUpdated", (updatedOrder) => {
      if (updatedOrder._id === id) setOrder(updatedOrder);
    });
    return () => socket.off("orderUpdated");
  }, []);

  const handleCancel = async () => {
  if (!cancelReason.trim()) return alert("Please select a cancel reason.");
  try {
    await axios.put(
      `http://localhost:5000/api/orders/${id}/cancel`,
      { reason: cancelReason },                          // ← sends reason to DB
      { headers: { Authorization: `Bearer ${token}` } }
    );
    setShowCancelModal(false);
    setCancelReason("");
    fetchOrder();
  } catch (err) {
    console.log(err);
  }
};
const handleInvoice = () => {
  const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
  const userName = userInfo?.user?.name || "Customer";
  const userEmail = userInfo?.user?.email || "";
  const userPhone = userInfo?.user?.phone || "";
  const userCity = userInfo?.user?.city || "";

  const invoiceDate = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  const orderDate = new Date(order.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  const subtotal = order.orderItems.reduce((acc, item) => acc + item.price * item.qty, 0);
  const membershipDiscount = order.membershipDiscount || 0;
  const deliveryFee = order.deliveryFee || 0;
  const invoiceNum = `INV-${order._id.slice(-8).toUpperCase()}`;

  const invoiceHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>Invoice ${invoiceNum} - ShopEasy</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', Arial, sans-serif;
      background: #fff;
      color: #1a1a1a;
      font-size: 12px;
      line-height: 1.4;
    }
    .page {
      max-width: 780px;
      margin: 0 auto;
      padding: 0;
    }
    .top-stripe { height: 5px; background: linear-gradient(90deg, #ff6f00, #ff9500, #ffb347); }
    .bottom-stripe { height: 4px; background: linear-gradient(90deg, #ff6f00, #ff9500, #ffb347); }

    /* HEADER */
    .header {
      padding: 16px 28px 14px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      border-bottom: 1px solid #eee;
    }
    .brand-logo { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
    .brand-icon {
      width: 34px; height: 34px;
      background: linear-gradient(135deg, #ff6f00, #ff9500);
      border-radius: 8px;
      display: flex; align-items: center; justify-content: center;
      font-size: 18px;
    }
    .brand-name { font-size: 22px; font-weight: 900; color: #ff6f00; letter-spacing: -0.5px; }
    .brand-info { font-size: 10px; color: #888; line-height: 1.6; margin-left: 42px; }
    .invoice-right { text-align: right; }
    .invoice-label { font-size: 26px; font-weight: 900; color: #1a1a1a; letter-spacing: -1px; }
    .inv-num { font-size: 13px; font-weight: 700; color: #ff6f00; margin-top: 3px; }
    .inv-detail { font-size: 10px; color: #888; margin-top: 2px; }
    .status-chip {
      display: inline-block; margin-top: 5px;
      padding: 3px 10px; border-radius: 20px;
      font-size: 9px; font-weight: 700; letter-spacing: 0.8px; text-transform: uppercase;
      background: #fff8f2; color: #ff6f00; border: 1.5px solid #ffe0c2;
    }

    /* ADDRESSES */
    .addr-band {
      background: #f8f8f8;
      padding: 12px 28px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      border-bottom: 1px solid #eee;
    }
    .ab-title {
      font-size: 8px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 1px; color: #ff6f00; margin-bottom: 5px;
      padding-bottom: 4px; border-bottom: 1.5px solid #ff6f00;
      display: inline-block;
    }
    .ab-name { font-size: 12px; font-weight: 700; color: #1a1a1a; margin-bottom: 2px; }
    .addr-band p { font-size: 11px; color: #555; margin-bottom: 1px; }

    /* TABLE */
    .table-section { padding: 14px 28px 0; }
    .sec-title {
      font-size: 9px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.8px; color: #888; margin-bottom: 8px;
    }
    table { width: 100%; border-collapse: collapse; }
    thead tr { border-bottom: 2px solid #1a1a1a; }
    thead th {
      padding: 7px 6px; text-align: left;
      font-size: 9px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.6px; color: #888;
    }
    thead th:last-child, thead th.right { text-align: right; }
    thead th.center { text-align: center; }
    tbody tr { border-bottom: 1px solid #f0f0f0; }
    tbody tr:last-child { border-bottom: 2px solid #1a1a1a; }
    tbody td { padding: 9px 6px; font-size: 11.5px; color: #333; vertical-align: top; }
    tbody td:last-child { text-align: right; font-weight: 700; }
    tbody td.center { text-align: center; }
    .product-name { font-weight: 700; color: #1a1a1a; font-size: 12px; }
    .product-sku { font-size: 9px; color: #aaa; margin-top: 1px; }

    /* BOTTOM SECTION */
    .bottom-section {
      padding: 12px 28px 14px;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 20px;
    }

    /* PAYMENT */
    .payment-block { flex: 1; }
    .pay-title {
      font-size: 9px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.8px; color: #888; margin-bottom: 8px;
    }
    .pay-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 10px; }
    .pay-box {
      background: #f8f8f8; border: 1px solid #eee;
      border-radius: 7px; padding: 8px 10px;
    }
    .pay-box .pl { font-size: 8px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.6px; color: #aaa; margin-bottom: 3px; }
    .pay-box .pv { font-size: 12px; font-weight: 700; color: #1a1a1a; }
    .pay-box .pv.paid { color: #16a34a; }
    .pay-box .pv.pending { color: #ff6f00; }

    /* TERMS */
    .terms-box {
      background: #fafafa; border: 1px solid #eee;
      border-radius: 7px; padding: 8px 10px;
    }
    .terms-box .tt { font-size: 8px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.6px; color: #aaa; margin-bottom: 4px; }
    .terms-box p { font-size: 9.5px; color: #aaa; line-height: 1.6; }

    /* TOTALS */
    .totals-block { width: 240px; flex-shrink: 0; }
    .totals-row {
      display: flex; justify-content: space-between;
      padding: 5px 0; font-size: 11.5px; color: #555;
      border-bottom: 1px solid #f0f0f0;
    }
    .totals-row.saving { color: #16a34a; font-weight: 600; }
    .totals-row.free { color: #16a34a; font-weight: 600; }
    .totals-row.grand {
      margin-top: 6px; padding: 10px 12px;
      background: #1a1a1a; color: #fff;
      font-size: 13px; font-weight: 700;
      border-radius: 7px; border: none;
    }
    .totals-row.grand span:last-child { color: #ff9500; font-size: 15px; font-weight: 900; }

    /* FOOTER */
    .footer {
      background: #1a1a1a; padding: 12px 28px;
      display: flex; justify-content: space-between; align-items: center;
    }
    .footer .fl { font-size: 13px; font-weight: 900; color: #ff6f00; }
    .footer .fr { font-size: 10px; color: #888; text-align: right; line-height: 1.6; }

    /* WATERMARK */
    .watermark {
      position: fixed; top: 50%; left: 50%;
      transform: translate(-50%, -50%) rotate(-30deg);
      font-size: 90px; font-weight: 900;
      color: rgba(22,163,74,0.05);
      pointer-events: none; white-space: nowrap; z-index: 0;
    }

    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      @page { margin: 0.3cm; size: A4; }
    }
  </style>
</head>
<body>
<div class="page">

  ${order.paymentStatus === "paid" ? '<div class="watermark">PAID</div>' : ""}

  <div class="top-stripe"></div>

  <!-- HEADER -->
  <div class="header">
    <div>
      <div class="brand-logo">
        <div class="brand-icon">🛍️</div>
        <div class="brand-name">ShopEasy</div>
      </div>
      <div class="brand-info">
        Your Trusted Shopping Partner &nbsp;|&nbsp; support@shopeasy.com &nbsp;|&nbsp; www.shopeasy.com<br/>
        GSTIN: 33AABCS1429B1ZB
      </div>
    </div>
    <div class="invoice-right">
      <div class="invoice-label">INVOICE</div>
      <div class="inv-num">${invoiceNum}</div>
      <div class="inv-detail">Invoice Date: ${invoiceDate} &nbsp;|&nbsp; Order Date: ${orderDate}</div>
      <div class="inv-detail">Order ID: ${order._id}</div>
      <span class="status-chip">${order.status.replaceAll("_", " ")}</span>
    </div>
  </div>

  <!-- ADDRESSES -->
  <div class="addr-band">
    <div>
      <div class="ab-title">Bill To</div>
      <p class="ab-name">${userName}</p>
      ${userEmail ? `<p>✉ ${userEmail}</p>` : ""}
      ${userPhone ? `<p>☎ ${userPhone}</p>` : ""}
      ${userCity ? `<p>📍 ${userCity}</p>` : ""}
    </div>
    <div>
      <div class="ab-title">Ship To</div>
      <p class="ab-name">${order.shippingAddress?.fullName || userName}</p>
      <p>☎ ${order.shippingAddress?.phone || "—"}</p>
      <p>${order.shippingAddress?.address || "—"}</p>
      <p>${[order.shippingAddress?.city, order.shippingAddress?.state].filter(Boolean).join(", ")} ${order.shippingAddress?.pincode ? "· " + order.shippingAddress.pincode : ""}</p>
    </div>
  </div>

  <!-- ITEMS TABLE -->
  <div class="table-section">
    <div class="sec-title">Order Items</div>
    <table>
      <thead>
        <tr>
          <th style="width:24px">#</th>
          <th>Product Description</th>
          <th class="center" style="width:80px">Unit Price</th>
          <th class="center" style="width:40px">Qty</th>
          <th class="right" style="width:80px">Amount</th>
        </tr>
      </thead>
      <tbody>
        ${order.orderItems.map((item, i) => `
          <tr>
            <td style="color:#aaa;font-size:10px">${i + 1}</td>
            <td>
              <div class="product-name">${item.name}</div>
              <div class="product-sku">SKU: ${(item.product?._id || item._id || "N/A").toString().slice(-8).toUpperCase()}</div>
            </td>
            <td class="center">₹${item.price.toLocaleString("en-IN")}</td>
            <td class="center">${item.qty}</td>
            <td>₹${(item.price * item.qty).toLocaleString("en-IN")}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  </div>

  <!-- BOTTOM SECTION -->
  <div class="bottom-section">

    <!-- LEFT: PAYMENT + TERMS -->
    <div class="payment-block">
      <div class="pay-title">Payment Information</div>
      <div class="pay-grid">
        <div class="pay-box">
          <div class="pl">Method</div>
          <div class="pv">${order.paymentMethod}</div>
        </div>
        <div class="pay-box">
          <div class="pl">Status</div>
          <div class="pv ${order.paymentStatus === "paid" ? "paid" : "pending"}">
            ${order.paymentStatus === "paid" ? "✓ Paid" : "⏳ " + order.paymentStatus.charAt(0).toUpperCase() + order.paymentStatus.slice(1)}
          </div>
        </div>
        <div class="pay-box">
          <div class="pl">Items</div>
          <div class="pv">${order.orderItems.length} item${order.orderItems.length !== 1 ? "s" : ""}</div>
        </div>
        <div class="pay-box">
          <div class="pl">Order Date</div>
          <div class="pv" style="font-size:10px">${orderDate}</div>
        </div>
      </div>
      <div class="terms-box">
        <div class="tt">Terms & Conditions</div>
        <p>
          • Returns accepted within 7 days of delivery for eligible items.<br/>
          • Prices inclusive of all applicable taxes (GST).<br/>
          • Support: support@shopeasy.com | 1800-XXX-XXXX<br/>
          • Computer-generated invoice. No signature required.
        </p>
      </div>
    </div>

    <!-- RIGHT: TOTALS -->
    <div class="totals-block">
      <div class="totals-row">
        <span>Subtotal</span>
        <span>₹${subtotal.toLocaleString("en-IN")}</span>
      </div>
      <div class="totals-row free">
        <span>Shipping & Delivery</span>
        <span>${deliveryFee === 0 ? "FREE" : `₹${deliveryFee.toLocaleString("en-IN")}`}</span>
      </div>
      ${membershipDiscount > 0 ? `
      <div class="totals-row saving">
        <span>💳 Membership Discount</span>
        <span>−₹${membershipDiscount.toLocaleString("en-IN")}</span>
      </div>` : ""}
      <div class="totals-row" style="color:#999;border-bottom:none;padding-top:6px;font-size:10.5px;">
        <span>Tax (GST)</span>
        <span>Included</span>
      </div>
      <div class="totals-row grand">
        <span>Total Payable</span>
        <span>₹${order.totalPrice.toLocaleString("en-IN")}</span>
      </div>
    </div>
  </div>

  <!-- FOOTER -->
  <div class="footer">
    <div class="fl">🙏 Thank you for shopping with ShopEasy!</div>
    <div class="fr">www.shopeasy.com &nbsp;|&nbsp; support@shopeasy.com</div>
  </div>

  <div class="bottom-stripe"></div>

</div>
</body>
</html>`;

  const invoiceWindow = window.open("", "_blank", "width=900,height=750");
  invoiceWindow.document.write(invoiceHTML);
  invoiceWindow.document.close();
  invoiceWindow.focus();
  setTimeout(() => invoiceWindow.print(), 600);
};

  const toggleReturnItem = (itemId) => {
    setReturnItems((prev) =>
      prev.includes(itemId) ? prev.filter((i) => i !== itemId) : [...prev, itemId]
    );
  };

  const handleReturnSubmit = async () => {
    if (!returnReason.trim()) return alert("Please select a return reason.");
    if (returnItems.length === 0) return alert("Please select at least one item to return.");
    setReturnLoading(true);
    try {
      await axios.put(
        `http://localhost:5000/api/orders/${id}/return`,
        { reason: returnReason, items: returnItems },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setReturnSubmitted(true);
      fetchOrder();
    } catch (err) {
      console.log(err);
      // Even if API isn't ready, show success for UI demo
      setReturnSubmitted(true);
    } finally {
      setReturnLoading(false);
    }
  };

  const steps = ["pending", "confirmed", "shipped", "out_for_delivery", "delivered"];
  const stepIcons = ["🕐", "✅", "📦", "🚚", "🏠"];
  const stepLabels = ["Pending", "Confirmed", "Shipped", "Out for Delivery", "Delivered"];
  const currentStep = steps.indexOf(order?.status);

  const returnReasons = [
    "Damaged / Defective product",
    "Wrong item delivered",
    "Item not as described",
    "Changed my mind",
    "Size / Fit issue",
    "Better price available elsewhere",
  ];

  const cancelReasons = [
  "Ordered by mistake",
  "Found better price",
  "Changed my mind",
  "Delivery too slow",
  "Duplicate order",
  "Item no longer needed",
];
 

  const statusColors = {
    pending: { bg: "#fff8f2", text: "#ff6f00", border: "#ffe0c2" },
    confirmed: { bg: "#edfaf4", text: "#2e9e5b", border: "#b6e9cf" },
    shipped: { bg: "#eff6ff", text: "#3b82f6", border: "#bfdbfe" },
    out_for_delivery: { bg: "#fdf4ff", text: "#9333ea", border: "#e9d5ff" },
    delivered: { bg: "#edfaf4", text: "#2e9e5b", border: "#b6e9cf" },
    cancelled: { bg: "#fff5f5", text: "#e53935", border: "#ffc9c9" },
    return_requested: { bg: "#fff8f2", text: "#ff6f00", border: "#ffe0c2" },
  };

  const sc = statusColors[order?.status] || statusColors.pending;

  if (loading)
    return (
      <div style={{ fontFamily: "'Nunito', sans-serif", display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh", flexDirection: "column", gap: 16 }}>
        <div style={{ width: 44, height: 44, border: "4px solid #ffe0c2", borderTopColor: "#ff6f00", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
        <p style={{ color: "#aaa", fontWeight: 700 }}>Loading order details...</p>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );

  if (!order)
    return (
      <div style={{ fontFamily: "'Nunito', sans-serif", textAlign: "center", padding: "60px 20px" }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>📦</div>
        <p style={{ fontWeight: 800, fontSize: 18, color: "#333" }}>Order not found</p>
        <button onClick={() => navigate(-1)} style={{ marginTop: 16, padding: "10px 24px", background: "#ff6f00", color: "#fff", border: "none", borderRadius: 10, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>Go Back</button>
      </div>
    );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }

        .od-root {
          font-family: 'Nunito', sans-serif;
          background: #fdf5ee;
          min-height: 100vh;
          padding: 28px 20px 60px;
          max-width: 860px;
          margin: 0 auto;
        }

        /* Header */
        .od-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 24px;
          flex-wrap: wrap;
          gap: 12px;
        }
        .od-back {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 13.5px;
          font-weight: 700;
          color: #ff6f00;
          cursor: pointer;
          border: 1.5px solid #ff6f00;
          padding: 6px 14px;
          border-radius: 8px;
          background: transparent;
          transition: background 0.2s, color 0.2s;
          font-family: inherit;
        }
        .od-back:hover { background: #ff6f00; color: #fff; }
        .od-title {
          font-size: 26px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.4px;
        }
        .od-title span { color: #ff6f00; }

        /* Cards */
        .od-card {
          background: #fff;
          border-radius: 18px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 4px 18px rgba(255,111,0,0.07);
          padding: 24px;
          margin-bottom: 18px;
          position: relative;
          overflow: hidden;
        }
        .od-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0;
          width: 100%; height: 4px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
        }
        .od-card-title {
          font-size: 16px;
          font-weight: 800;
          color: #1a1a1a;
          margin-bottom: 18px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        /* Tracking bar */
        .track-wrap {
          position: relative;
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          padding-top: 8px;
        }
        .track-line-bg {
          position: absolute;
          top: 20px; left: 5%; right: 5%;
          height: 3px;
          background: #f0e8e0;
          border-radius: 3px;
          z-index: 0;
        }
        .track-line-fill {
          height: 3px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
          border-radius: 3px;
          transition: width 0.8s ease;
        }
        .track-step {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          z-index: 2;
          flex: 1;
        }
        .track-dot {
          width: 40px; height: 40px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 16px;
          border: 2.5px solid #e8e8e8;
          background: #fff;
          color: #ccc;
          transition: all 0.4s ease;
        }
        .track-dot.done {
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-color: #ff6f00;
          box-shadow: 0 3px 12px rgba(255,111,0,0.3);
        }
        .track-dot.current {
          border-color: #ff6f00;
          box-shadow: 0 0 0 5px rgba(255,111,0,0.12);
          background: #fff8f2;
        }
        .track-label {
          font-size: 10.5px;
          font-weight: 700;
          color: #bbb;
          text-align: center;
          line-height: 1.3;
        }
        .track-label.done { color: #ff6f00; }
        .track-label.current { color: #555; }

        .truck-row {
          position: relative;
          height: 36px;
          margin-top: 12px;
        }
        .truck-emoji {
          position: absolute;
          font-size: 24px;
          transition: left 0.8s ease;
          transform: translateX(-50%);
        }

        .delivery-badge {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #fff8f2;
          border: 1.5px solid #ffe0c2;
          border-radius: 10px;
          padding: 10px 16px;
          font-size: 13.5px;
          font-weight: 700;
          color: #555;
          margin-top: 16px;
        }
        .delivery-badge span { color: #ff6f00; font-weight: 900; }

        /* Timeline */
        .timeline-item {
          display: flex;
          gap: 14px;
          align-items: flex-start;
          padding-bottom: 16px;
          position: relative;
        }
        .timeline-item:not(:last-child)::after {
          content: '';
          position: absolute;
          left: 9px; top: 22px;
          width: 2px;
          height: calc(100% - 10px);
          background: #ffe0c2;
        }
        .timeline-dot {
          width: 20px; height: 20px;
          border-radius: 50%;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          flex-shrink: 0;
          box-shadow: 0 2px 8px rgba(255,111,0,0.25);
          margin-top: 2px;
        }
        .timeline-text {
          font-size: 13.5px;
          font-weight: 700;
          color: #333;
          text-transform: capitalize;
        }
        .timeline-time {
          font-size: 12px;
          color: #aaa;
          font-weight: 600;
          margin-top: 2px;
        }

        /* Summary grid */
        .summary-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 14px;
        }
        .summary-cell {
          background: #fff8f2;
          border: 1.5px solid #ffe0c2;
          border-radius: 12px;
          padding: 14px 16px;
        }
        .summary-cell .s-label {
          font-size: 11px;
          font-weight: 700;
          color: #aaa;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          margin-bottom: 5px;
        }
        .summary-cell .s-value {
          font-size: 18px;
          font-weight: 900;
          color: #ff6f00;
        }
        .summary-cell .s-value.dark { color: #1a1a1a; font-size: 15px; }

        .status-pill {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 5px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 800;
          border: 1.5px solid;
          margin-top: 4px;
        }

        /* Items */
        .order-item {
          display: flex;
          gap: 14px;
          align-items: center;
          padding: 14px 0;
          border-bottom: 1.5px solid #f5ece4;
          position: relative;
        }
        .order-item:last-child { border-bottom: none; padding-bottom: 0; }
        .order-item-img {
          width: 70px; height: 70px;
          border-radius: 12px;
          object-fit: cover;
          border: 1.5px solid #ffe0c2;
          background: #fff8f2;
          flex-shrink: 0;
        }
        .order-item-name {
          font-size: 14px;
          font-weight: 800;
          color: #1a1a1a;
          margin-bottom: 4px;
        }
        .order-item-qty {
          font-size: 12.5px;
          color: #aaa;
          font-weight: 600;
        }
        .order-item-price {
          font-size: 16px;
          font-weight: 900;
          color: #1a1a1a;
          margin-left: auto;
        }

        /* Delivery partner */
        .partner-card {
          display: flex;
          gap: 16px;
          align-items: center;
        }
        .partner-avatar {
          width: 52px; height: 52px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          font-weight: 900;
          color: #fff;
          flex-shrink: 0;
          box-shadow: 0 4px 12px rgba(255,111,0,0.3);
        }
        .partner-name { font-size: 15px; font-weight: 800; color: #1a1a1a; margin-bottom: 4px; }
        .partner-phone { font-size: 13.5px; color: #3b82f6; font-weight: 700; }

        /* Action buttons */
        .actions-row {
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
          margin-top: 4px;
        }
        .btn-cancel {
          flex: 1;
          padding: 13px;
          background: #fff5f5;
          color: #e53935;
          border: 2px solid #e53935;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          transition: background 0.2s, color 0.2s;
          font-family: inherit;
          min-width: 140px;
        }
        .btn-cancel:hover { background: #e53935; color: #fff; }

        .btn-return {
          flex: 1;
          padding: 13px;
          background: #fff8f2;
          color: #ff6f00;
          border: 2px solid #ff6f00;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          transition: background 0.2s, color 0.2s;
          font-family: inherit;
          min-width: 140px;
        }
        .btn-return:hover { background: #ff6f00; color: #fff; }

        .btn-invoice {
          flex: 1;
          padding: 13px;
          background: #1a1a1a;
          color: #fff;
          border: 2px solid #1a1a1a;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          transition: background 0.2s;
          font-family: inherit;
          min-width: 140px;
        }
        .btn-invoice:hover { background: #333; }

        /* Cancel confirm */
        .cancel-confirm-box {
          background: #fff5f5;
          border: 1.5px solid #ffc9c9;
          border-radius: 14px;
          padding: 18px 20px;
          margin-bottom: 16px;
          text-align: center;
        }
        .cancel-confirm-box p {
          font-size: 14px;
          font-weight: 700;
          color: #333;
          margin-bottom: 14px;
        }
        .cancel-confirm-btns { display: flex; gap: 10px; justify-content: center; }
        .btn-yes {
          padding: 9px 24px;
          background: #e53935;
          color: #fff;
          border: none;
          border-radius: 9px;
          font-weight: 800;
          font-size: 13px;
          cursor: pointer;
          font-family: inherit;
        }
        .btn-no {
          padding: 9px 24px;
          background: #f0f0f0;
          color: #555;
          border: none;
          border-radius: 9px;
          font-weight: 800;
          font-size: 13px;
          cursor: pointer;
          font-family: inherit;
        }

        /* Return Modal Overlay */
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.45);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 20px;
          backdrop-filter: blur(3px);
        }
        .modal-box {
          background: #fff;
          border-radius: 22px;
          padding: 32px;
          width: 100%;
          max-width: 480px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 20px 60px rgba(0,0,0,0.2);
          position: relative;
          overflow: hidden;
        }
        .modal-box::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 4px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
        }
        .modal-title {
          font-size: 20px;
          font-weight: 900;
          color: #1a1a1a;
          margin-bottom: 6px;
        }
        .modal-sub {
          font-size: 13px;
          color: #aaa;
          font-weight: 600;
          margin-bottom: 22px;
        }
        .modal-section-label {
          font-size: 12px;
          font-weight: 700;
          color: #aaa;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          margin-bottom: 10px;
        }

        /* Return item checkbox */
        .return-item-row {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 10px 12px;
          border: 1.5px solid #e8e8e8;
          border-radius: 11px;
          margin-bottom: 8px;
          cursor: pointer;
          transition: border-color 0.2s, background 0.15s;
        }
        .return-item-row:hover { border-color: #ffcc99; background: #fff8f2; }
        .return-item-row.checked { border-color: #ff6f00; background: #fff8f2; }
        .return-item-row input[type="checkbox"] {
          accent-color: #ff6f00;
          width: 17px; height: 17px;
          cursor: pointer;
          flex-shrink: 0;
        }
        .return-item-img {
          width: 38px; height: 38px;
          border-radius: 7px;
          object-fit: cover;
          border: 1px solid #ffe0c2;
        }
        .return-item-name {
          font-size: 13px;
          font-weight: 700;
          color: #333;
          flex: 1;
        }

        /* Reason pills */
        .reason-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 8px;
          margin-bottom: 20px;
        }
        .reason-pill {
          padding: 9px 12px;
          border: 1.5px solid #e8e8e8;
          border-radius: 9px;
          font-size: 12.5px;
          font-weight: 700;
          color: #555;
          cursor: pointer;
          transition: border-color 0.2s, background 0.15s, color 0.15s;
          text-align: center;
          line-height: 1.3;
        }
        .reason-pill:hover { border-color: #ffcc99; background: #fff8f2; }
        .reason-pill.selected { border-color: #ff6f00; background: #fff8f2; color: #ff6f00; }

        .modal-actions { display: flex; gap: 10px; margin-top: 6px; }
        .btn-submit-return {
          flex: 1;
          padding: 13px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 11px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          font-family: inherit;
          box-shadow: 0 4px 14px rgba(255,111,0,0.3);
          transition: opacity 0.2s;
        }
        .btn-submit-return:disabled { opacity: 0.6; cursor: not-allowed; }
        .btn-close-modal {
          padding: 13px 20px;
          background: #f0f0f0;
          color: #555;
          border: none;
          border-radius: 11px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          font-family: inherit;
        }

        /* Return success */
        .return-success {
          text-align: center;
          padding: 20px 0;
        }
        .return-success .rs-icon { font-size: 52px; margin-bottom: 14px; }
        .return-success h3 { font-size: 18px; font-weight: 900; color: #1a1a1a; margin-bottom: 6px; }
        .return-success p { font-size: 13.5px; color: #888; font-weight: 600; line-height: 1.6; }

        @keyframes spin { to { transform: rotate(360deg); } }
        .spin { animation: spin 0.7s linear infinite; }
      `}</style>

      {/* RETURN MODAL */}
      <AnimatePresence>
        {showReturnModal && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={(e) => { if (e.target === e.currentTarget) { setShowReturnModal(false); setReturnSubmitted(false); } }}
          >
            <motion.div
              className="modal-box"
              initial={{ scale: 0.85, opacity: 0, y: 30 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.85, opacity: 0, y: 30 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
            >
              {returnSubmitted ? (
                <div className="return-success">
                  <div className="rs-icon">📦</div>
                  <h3>Return Requested!</h3>
                  <p>
                    Your return request has been submitted.<br />
                    Our team will review it within 24–48 hours.<br />
                    Refund will be processed after pickup.
                  </p>
                  <button
                    className="btn-submit-return"
                    style={{ marginTop: 24, width: "100%" }}
                    onClick={() => { setShowReturnModal(false); setReturnSubmitted(false); }}
                  >
                    Done
                  </button>
                </div>
              ) : (
                <>
                  <p className="modal-title">↩️ Return Order</p>
                  <p className="modal-sub">Select items and reason for return</p>

                  {/* Items to return */}
                  <p className="modal-section-label">Select Items</p>
                  <div style={{ marginBottom: 18 }}>
                    {order.orderItems.map((item, i) => (
                      <div
                        key={i}
                        className={`return-item-row ${returnItems.includes(item._id || i) ? "checked" : ""}`}
                        onClick={() => toggleReturnItem(item._id || i)}
                      >
                        <input
                          type="checkbox"
                          checked={returnItems.includes(item._id || i)}
                          onChange={() => {}}
                        />
                        <img
                          src={
                            item.product?.images?.length > 0
                              ? item.product.images[0]
                              : "https://via.placeholder.com/40"
                          }
                          className="return-item-img"
                          alt={item.name}
                        />
                        <span className="return-item-name">{item.name}</span>
                        <span style={{ fontSize: 13, fontWeight: 800, color: "#ff6f00" }}>₹{item.price}</span>
                      </div>
                    ))}
                  </div>

                  {/* Return reasons */}
                  <p className="modal-section-label">Reason for Return</p>
                  <div className="reason-grid">
                    {returnReasons.map((r) => (
                      <div
                        key={r}
                        className={`reason-pill ${returnReason === r ? "selected" : ""}`}
                        onClick={() => setReturnReason(r)}
                      >
                        {r}
                      </div>
                    ))}
                  </div>

                  <div className="modal-actions">
                    <button className="btn-close-modal" onClick={() => setShowReturnModal(false)}>
                      Cancel
                    </button>
                    <button
                      className="btn-submit-return"
                      onClick={handleReturnSubmit}
                      disabled={returnLoading}
                    >
                      {returnLoading ? (
                        <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                          <span style={{ width: 16, height: 16, border: "2.5px solid rgba(255,255,255,0.4)", borderTopColor: "#fff", borderRadius: "50%" }} className="spin" />
                          Submitting...
                        </span>
                      ) : "Submit Return →"}
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
  {showCancelModal && (
    <motion.div
      className="modal-overlay"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={(e) => { if (e.target === e.currentTarget) { setShowCancelModal(false); setCancelReason(""); } }}
    >
      <motion.div
        className="modal-box"
        initial={{ scale: 0.85, opacity: 0, y: 30 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.85, opacity: 0, y: 30 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
      >
        <div className="modal-title">Cancel Order</div>
        <div className="modal-sub">Please tell us why you're cancelling</div>
 
        <div className="modal-section-label">Select a reason</div>
        <div className="reason-grid" style={{ marginBottom: 24 }}>
          {cancelReasons.map((r) => (
            <div
              key={r}
              className={`reason-pill${cancelReason === r ? " selected" : ""}`}
              onClick={() => setCancelReason(r)}
            >
              {r}
            </div>
          ))}
        </div>
 
        <div className="modal-actions">
          <button
            className="btn-submit-return"
            style={{ background: "linear-gradient(135deg, #e53935, #ef5350)" }}
            disabled={!cancelReason}
            onClick={handleCancel}
          >
            Confirm Cancel
          </button>
          <button
            className="btn-close-modal"
            onClick={() => { setShowCancelModal(false); setCancelReason(""); }}
          >
            Go Back
          </button>
        </div>
      </motion.div>
    </motion.div>
  )}
</AnimatePresence>
 

      <div className="od-root">
        {/* HEADER */}
        <div className="od-header">
          <button className="od-back" onClick={() => navigate(-1)}>← Back</button>
          <div>
            <h1 className="od-title">Order <span>#{order._id.slice(-6).toUpperCase()}</span></h1>
          </div>
          <div
            className="status-pill"
            style={{ background: sc.bg, color: sc.text, borderColor: sc.border }}
          >
            {order.status.replaceAll("_", " ").toUpperCase()}
          </div>
        </div>

        {/* TRACKING */}
        <motion.div
          className="od-card"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <p className="od-card-title">🚚 Live Order Tracking</p>

          <div className="track-wrap">
            <div className="track-line-bg">
              <motion.div
                className="track-line-fill"
                initial={{ width: 0 }}
                animate={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
                transition={{ duration: 0.9, delay: 0.2 }}
              />
            </div>

            {steps.map((step, index) => {
              const state = index < currentStep ? "done" : index === currentStep ? "current" : "";
              return (
                <div key={index} className="track-step">
                  <motion.div
                    className={`track-dot ${state}`}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.1 + 0.3 }}
                  >
                    {state === "done" ? "✔" : stepIcons[index]}
                  </motion.div>
                  <p className={`track-label ${state}`}>
                    {stepLabels[index].split(" ").map((w, j) => (
                      <span key={j} style={{ display: "block" }}>{w}</span>
                    ))}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="truck-row">
            <motion.div
              className="truck-emoji"
              animate={{ left: `${Math.min((currentStep / (steps.length - 1)) * 90 + 5, 95)}%` }}
              transition={{ duration: 0.9, delay: 0.2 }}
            >
              🚚
            </motion.div>
          </div>

          <div className="delivery-badge">
            📅 Estimated Delivery: <span>{deliveryDate}</span>
          </div>
        </motion.div>

        {/* DELIVERY PARTNER */}
        {order.status === "out_for_delivery" && (
          <motion.div
            className="od-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <p className="od-card-title">🧑‍💼 Delivery Partner</p>
            <div className="partner-card">
              <div className="partner-avatar">
                {order.deliveryPartner?.name?.[0] || "D"}
              </div>
              <div>
                <p className="partner-name">{order.deliveryPartner?.name || "Assigned Soon"}</p>
                <p className="partner-phone">📞 {order.deliveryPartner?.phone || "Updating..."}</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* TIMELINE */}
        <motion.div
          className="od-card"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <p className="od-card-title">🕐 Order Timeline</p>
          <div>
            {steps.slice(0, currentStep + 1).map((step, i) => (
              <motion.div
                key={i}
                className="timeline-item"
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
              >
                <div className="timeline-dot" />
                <div>
                  <p className="timeline-text">{step.replaceAll("_", " ")}</p>
                  <p className="timeline-time">Step {i + 1} of {steps.length}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* ORDER SUMMARY */}
        <motion.div
          className="od-card"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <p className="od-card-title">💳 Order Summary</p>
          <div className="summary-grid">
            <div className="summary-cell">
              <p className="s-label">Total Amount</p>
              <p className="s-value">₹{order.totalPrice}</p>
            </div>
            <div className="summary-cell">
              <p className="s-label">Payment Method</p>
              <p className="s-value dark">{order.paymentMethod}</p>
            </div>
            <div className="summary-cell">
              <p className="s-label">Order Status</p>
              <span
                className="status-pill"
                style={{ background: sc.bg, color: sc.text, borderColor: sc.border, marginTop: 0 }}
              >
                {order.status.replaceAll("_", " ")}
              </span>
            </div>
            <div className="summary-cell">
              <p className="s-label">Items Count</p>
              <p className="s-value dark">{order.orderItems.length} item{order.orderItems.length !== 1 ? "s" : ""}</p>
            </div>
          </div>
        </motion.div>

        {/* ITEMS */}
        <motion.div
          className="od-card"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <p className="od-card-title">🛍️ Order Items</p>
          {order.orderItems.map((item, i) => (
            <motion.div
              key={i}
              className="order-item"
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
            >
              <img
                src={
                item.product?.images && item.product.images.length > 0
                  ? item.product?.images[0].startsWith("http")
                    ? item.product?.images[0]
                    : `http://localhost:5000${item.product.images[0]}`
                  : "/placeholder.png"
              }
                className="order-item-img"
                alt={item.name}
              />
              <div style={{ flex: 1 }}>
                <p className="order-item-name">{item.name}</p>
                <p className="order-item-qty">Qty: {item.qty}</p>
              </div>
              <p className="order-item-price">₹{item.price}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* ACTIONS */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          {/* Cancel confirm inline */}
          {cancelConfirm && (
  <div className="cancel-confirm-box">
    <p>Are you sure you want to cancel this order?</p>
    <div className="cancel-confirm-btns">
      <button className="btn-yes" onClick={() => { setShowCancelModal(true); setCancelConfirm(false); }}>
        Yes, Cancel
      </button>
      <button className="btn-no" onClick={() => setCancelConfirm(false)}>
        No, Keep
      </button>
    </div>
  </div>
)}
 

          <div className="actions-row">
            {order.status !== "delivered" &&
              order.status !== "cancelled" &&
              order.status !== "return_requested" && (
                <button className="btn-cancel" onClick={() => setCancelConfirm(true)}>
                  ✕ Cancel Order
                </button>
              )}

            {order.status === "delivered" && (
              <button
                className="btn-return"
                onClick={() => { setShowReturnModal(true); setReturnSubmitted(false); setReturnItems([]); setReturnReason(""); }}
              >
                ↩️ Return Order
              </button>
            )}

            {order.status === "return_requested" && (
              <div style={{ flex: 1, padding: "13px", background: "#fff8f2", border: "2px solid #ffcc99", borderRadius: 12, textAlign: "center", fontWeight: 800, color: "#ff6f00", fontSize: 14 }}>
                🔄 Return Request Pending
              </div>
            )}

            <button className="btn-invoice" onClick={handleInvoice}>
              🧾 Download Invoice
            </button>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default OrderDetailsPage;

