// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
 
// const Success = () => {
//   const navigate = useNavigate();
//   const [show, setShow] = useState(false);
 
//   useEffect(() => {
//     setTimeout(() => setShow(true), 300);
//   }, []);
 
//   return (
//     <div style={container}>
//       <div style={card}>
        
//         {/* ✅ ANIMATED CHECK */}
//         <div style={{
//           ...circle,
//           transform: show ? "scale(1)" : "scale(0)",
//         }}>
//           ✔
//         </div>
 
//         {/* TEXT */}
//         <h1 style={{
//           opacity: show ? 1 : 0,
//           transition: "0.5s",
//         }}>
//           Order Placed Successfully!
//         </h1>
 
//         <p style={{ color: "gray" }}>
//           🎉 Thank you for your purchase
//         </p>
 
//         <p style={{ marginTop: "10px" }}>
//           Order ID: <b>#AFZ{Math.floor(Math.random()*10000)}</b>
//         </p>
 
//         <p style={{ marginTop: "10px", color: "gray" }}>
//           Your items will be delivered soon 🚚
//         </p>
 
//         {/* BUTTONS */}
//         <div style={{ marginTop: "25px", display: "flex", gap: "15px" }}>
//           <button style={btn} onClick={() => navigate("/home")}>
//             Continue Shopping
//           </button>
 
//           <button style={btnOutline}>
//             View Orders
//           </button>
//         </div>
 
//       </div>
//     </div>
//   );
// };
 
// export default Success;
 
// const container = {
//   height: "100vh",
//   display: "flex",
//   justifyContent: "center",
//   alignItems: "center",
//   background: "#f5f5f5",
// };
 
// const card = {
//   background: "#fff",
//   padding: "40px",
//   borderRadius: "16px",
//   textAlign: "center",
//   boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
//   width: "400px",
// };
 
// const circle = {
//   width: "80px",
//   height: "80px",
//   borderRadius: "50%",
//   background: "#4CAF50",
//   color: "#fff",
//   fontSize: "40px",
//   display: "flex",
//   justifyContent: "center",
//   alignItems: "center",
//   margin: "0 auto 20px",
//   transition: "0.4s ease",
// };
 
// const btn = {
//   padding: "12px 20px",
//   background: "#ff6f00",
//   color: "#fff",
//   border: "none",
//   borderRadius: "8px",
//   cursor: "pointer",
// };
 
// const btnOutline = {
//   padding: "12px 20px",
//   background: "#fff",
//   border: "2px solid #ff6f00",
//   color: "#ff6f00",
//   borderRadius: "8px",
//   cursor: "pointer",
// };
 

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Success = () => {
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [order, setOrder] = useState(null);
  const [confetti, setConfetti] = useState([]);

  useEffect(() => {
    setTimeout(() => setShow(true), 300);

    // ✅ get real order
    const savedOrder = JSON.parse(sessionStorage.getItem("orderSuccess"));
    console.log("Saved Order:",savedOrder)
    if (savedOrder) {
      setOrder(savedOrder);
    }


    // Generate confetti pieces
    const pieces = Array.from({ length: 32 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 1.2,
      duration: 1.8 + Math.random() * 1.2,
      color: ["#ff6f00", "#ffaa5a", "#ffe0c2", "#2e9e5b", "#ffd700", "#ff9500"][
        Math.floor(Math.random() * 6)
      ],
      size: 6 + Math.random() * 8,
      shape: Math.random() > 0.5 ? "circle" : "rect",
    }));
    setConfetti(pieces);
  }, []);

  const deliveryDate = sessionStorage.getItem("deliveryDate");

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        .success-root {
          font-family: 'Nunito', sans-serif;
          background: #fdf5ee;
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 40px 20px;
          position: relative;
          overflow: hidden;
        }

        /* Confetti */
        .confetti-piece {
          position: fixed;
          top: -20px;
          animation: fall linear forwards;
          pointer-events: none;
          z-index: 0;
          opacity: 0;
        }
        @keyframes fall {
          0%   { opacity: 1; transform: translateY(0) rotate(0deg); }
          100% { opacity: 0; transform: translateY(110vh) rotate(540deg); }
        }

        /* Background blobs */
        .bg-blob {
          position: fixed;
          border-radius: 50%;
          pointer-events: none;
          z-index: 0;
        }
        .blob-1 {
          width: 380px; height: 380px;
          background: radial-gradient(circle, rgba(255,111,0,0.08), transparent 70%);
          top: -80px; right: -80px;
        }
        .blob-2 {
          width: 300px; height: 300px;
          background: radial-gradient(circle, rgba(255,165,0,0.07), transparent 70%);
          bottom: -60px; left: -60px;
        }

        /* Main card */
        .success-card {
          background: #fff;
          border-radius: 24px;
          padding: 50px 44px 44px;
          max-width: 520px;
          width: 100%;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 20px 60px rgba(255,111,0,0.12);
          text-align: center;
          position: relative;
          z-index: 1;
          transition: opacity 0.6s ease, transform 0.6s ease;
        }

        /* Top orange bar */
        .success-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 5px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a, #ff9500);
          border-radius: 24px 24px 0 0;
        }

        /* Check circle */
        .check-circle {
          width: 90px; height: 90px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 24px;
          box-shadow: 0 8px 28px rgba(255,111,0,0.35), 0 0 0 12px rgba(255,111,0,0.1);
          font-size: 36px;
          color: #fff;
          transition: transform 0.5s cubic-bezier(0.34,1.56,0.64,1), opacity 0.5s;
        }

        /* Pulse ring */
        .check-circle-wrap {
          position: relative;
          width: 90px;
          margin: 0 auto 24px;
        }
        .pulse-ring {
          position: absolute;
          top: 0; left: 0;
          width: 90px; height: 90px;
          border-radius: 50%;
          border: 3px solid rgba(255,111,0,0.4);
          animation: pulse 1.8s ease-out infinite;
        }
        @keyframes pulse {
          0%   { transform: scale(1); opacity: 0.6; }
          100% { transform: scale(1.7); opacity: 0; }
        }

        /* Title */
        .success-title {
          font-size: 28px;
          font-weight: 900;
          color: #1a1a1a;
          letter-spacing: -0.5px;
          margin-bottom: 8px;
          transition: opacity 0.6s 0.2s, transform 0.6s 0.2s;
        }
        .success-sub {
          font-size: 14.5px;
          color: #999;
          font-weight: 600;
          margin-bottom: 24px;
          transition: opacity 0.6s 0.3s;
        }

        /* Order ID chip */
        .order-chip {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #fff8f2;
          border: 1.5px solid #ffe0c2;
          border-radius: 10px;
          padding: 10px 18px;
          font-size: 14px;
          font-weight: 700;
          color: #555;
          margin-bottom: 20px;
        }
        .order-chip span {
          color: #ff6f00;
          font-weight: 900;
          font-size: 15px;
        }

        /* Timeline / status steps */
        .status-track {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin: 24px 0;
          position: relative;
          padding: 0 8px;
        }
        .status-track::before {
          content: '';
          position: absolute;
          top: 16px;
          left: 8%; right: 8%;
          height: 2px;
          background: #ffe0c2;
          z-index: 0;
        }
        .status-track-fill {
          position: absolute;
          top: 16px;
          left: 8%;
          height: 2px;
          background: linear-gradient(90deg, #ff6f00, #ffaa5a);
          z-index: 1;
          transition: width 1.2s 0.6s ease;
        }

        .track-step {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          z-index: 2;
          flex: 1;
        }
        .track-dot {
          width: 32px; height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 14px;
          font-weight: 800;
          border: 2.5px solid #ffe0c2;
          background: #fff;
          color: #ccc;
          transition: all 0.4s ease;
        }
        .track-dot.done {
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          border-color: #ff6f00;
          color: #fff;
          box-shadow: 0 3px 10px rgba(255,111,0,0.3);
        }
        .track-dot.active {
          background: #fff;
          border-color: #ff6f00;
          color: #ff6f00;
          box-shadow: 0 0 0 4px rgba(255,111,0,0.12);
        }
        .track-label {
          font-size: 11px;
          font-weight: 700;
          color: #aaa;
          text-align: center;
          line-height: 1.3;
        }
        .track-label.done { color: #ff6f00; }
        .track-label.active { color: #555; }

        /* Delivery info */
        .delivery-banner {
          background: linear-gradient(135deg, #fff8f2, #fff3e6);
          border: 1.5px solid #ffe0c2;
          border-radius: 14px;
          padding: 14px 18px;
          margin-bottom: 24px;
          display: flex;
          align-items: center;
          gap: 12px;
          text-align: left;
        }
        .delivery-banner .del-icon {
          font-size: 28px;
          flex-shrink: 0;
        }
        .delivery-banner .del-text p:first-child {
          font-size: 12px;
          color: #aaa;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.4px;
          margin-bottom: 2px;
        }
        .delivery-banner .del-text p:last-child {
          font-size: 15px;
          font-weight: 800;
          color: #ff6f00;
        }

        /* Buttons */
        .btn-row {
          display: flex;
          gap: 12px;
          justify-content: center;
          margin-top: 4px;
        }

        .btn-primary {
          flex: 1;
          padding: 13px 20px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff;
          border: none;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          transition: opacity 0.2s, transform 0.1s;
          box-shadow: 0 4px 14px rgba(255,111,0,0.3);
          font-family: 'Nunito', sans-serif;
          letter-spacing: 0.3px;
        }
        .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }

        .btn-outline {
          flex: 1;
          padding: 13px 20px;
          background: transparent;
          color: #ff6f00;
          border: 2px solid #ff6f00;
          border-radius: 12px;
          font-weight: 800;
          font-size: 14px;
          cursor: pointer;
          transition: background 0.2s, color 0.2s, transform 0.1s;
          font-family: 'Nunito', sans-serif;
        }
        .btn-outline:hover {
          background: #ff6f00;
          color: #fff;
          transform: translateY(-1px);
        }

        /* Bottom reassurance strip */
        .reassurance {
          display: flex;
          justify-content: center;
          gap: 20px;
          margin-top: 24px;
          flex-wrap: wrap;
        }
        .reassurance-item {
          display: flex;
          align-items: center;
          gap: 5px;
          font-size: 12px;
          color: #bbb;
          font-weight: 700;
        }
      `}</style>

      {/* Background blobs */}
      <div className="bg-blob blob-1" />
      <div className="bg-blob blob-2" />

      {/* Confetti */}
      {show && confetti.map((c) => (
        <div
          key={c.id}
          className="confetti-piece"
          style={{
            left: `${c.left}%`,
            animationDelay: `${c.delay}s`,
            animationDuration: `${c.duration}s`,
            width: c.shape === "circle" ? c.size : c.size * 0.6,
            height: c.size,
            borderRadius: c.shape === "circle" ? "50%" : "2px",
            background: c.color,
          }}
        />
      ))}

      <div className="success-root">
        <div
          className="success-card"
          style={{
            opacity: show ? 1 : 0,
            transform: show ? "translateY(0)" : "translateY(24px)",
          }}
        >
          {/* Check circle with pulse */}
          <div className="check-circle-wrap">
            {show && <div className="pulse-ring" />}
            <div
              className="check-circle"
              style={{
                transform: show ? "scale(1)" : "scale(0)",
                opacity: show ? 1 : 0,
              }}
            >
              ✔
            </div>
          </div>

          {/* Title */}
          <h1
            className="success-title"
            style={{
              opacity: show ? 1 : 0,
              transform: show ? "translateY(0)" : "translateY(10px)",
            }}
          >
            Order Placed! 🎉
          </h1>
          <p
            className="success-sub"
            style={{ opacity: show ? 1 : 0 }}
          >
            Thank you for shopping with us
          </p>

          {/* Order ID */}
          <div className="order-chip">
            Order ID:&nbsp;
            <span>
              {order?._id
                ? `#${order?._id.slice(-6).toUpperCase()}`
                : "Loading..."}
            </span>
          </div>

          {/* Order tracking status */}
          <div className="status-track">
            <div
              className="status-track-fill"
              style={{ width: show ? "28%" : "0%" }}
            />
            {[
              { icon: "✔", label: "Order\nConfirmed", state: "done" },
              { icon: "📦", label: "Being\nPacked", state: "active" },
              { icon: "🚚", label: "Out for\nDelivery", state: "" },
              { icon: "🏠", label: "Delivered", state: "" },
            ].map((step, i) => (
              <div key={i} className="track-step">
                <div className={`track-dot ${step.state}`}>
                  {step.state === "done" ? "✔" : step.icon}
                </div>
                <p className={`track-label ${step.state}`}>
                  {step.label.split("\n").map((l, j) => (
                    <span key={j} style={{ display: "block" }}>{l}</span>
                  ))}
                </p>
              </div>
            ))}
          </div>

          {/* Delivery date */}
          {deliveryDate && (
            <div className="delivery-banner">
              <span className="del-icon">🚚</span>
              <div className="del-text">
                <p>Estimated Delivery</p>
                <p>{deliveryDate}</p>
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="btn-row">
            <button className="btn-primary" onClick={() => navigate("/home")}>
              Continue Shopping
            </button>
            <button className="btn-outline" onClick={() => navigate("/profile")}>
              View Orders
            </button>
          </div>

          {/* Reassurance strip */}
          <div className="reassurance">
            <span className="reassurance-item">🔒 Secure Order</span>
            <span className="reassurance-item">↩️ Easy Returns</span>
            <span className="reassurance-item">📧 Confirmation Sent</span>
          </div>
        </div>
      </div>
    </>
  );
};

export default Success;
