import React, { useContext, useEffect, useState } from "react";
import { ShopContext } from "../context/ShopContext";
import axios from "axios";
 
const Checkout = () => {
  const { cart } = useContext(ShopContext);
 
  const [addresses, setAddresses] = useState([]);
  const [selectedAddress, setSelectedAddress] = useState(null);
 
  const token = sessionStorage.getItem("token");
 
  // ✅ FETCH ADDRESSES
  useEffect(() => {
    const fetchAddresses = async () => {
      try {
        const res = await axios.get(
          "http://localhost:5000/api/address",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        setAddresses(res.data);
      } catch (err) {
        console.log(err);
      }
    };
 
    fetchAddresses();
  }, []);
 
  // ✅ TOTAL
  const totalAmount = cart.reduce(
    (acc, item) => acc + item.product.price * item.qty,
    0
  );
 
  // ✅ PLACE ORDER
  const placeOrder = async () => {
    if (!selectedAddress) {
      return alert("Please select address");
    }
 
    try {
      await axios.post(
        "http://localhost:5000/api/orders",
        {
          items: cart,
          address: selectedAddress,
          totalAmount,
        },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
 
      alert("Order Placed ✅");
      window.location.href = "/orders";
    } catch (err) {
      console.log(err);
      alert("Order failed ❌");
    }
  };
 
  return (
    <div style={{ padding: "20px" }}>
      <h2>Checkout</h2>
 
      <div style={{ display: "flex", gap: "40px" }}>
        
        {/* ADDRESS SELECT */}
        <div style={{ flex: 1 }}>
          <h3>Select Address</h3>
 
          {addresses.map((addr) => (
            <div
              key={addr._id}
              onClick={() => setSelectedAddress(addr)}
              style={{
                border:
                  selectedAddress?._id === addr._id
                    ? "2px solid green"
                    : "1px solid gray",
                padding: "10px",
                marginBottom: "10px",
                cursor: "pointer",
              }}
            >
              <p><b>{addr.name}</b></p>
              <p>{addr.phone}</p>
              <p>{addr.city} - {addr.pincode}</p>
              <p>{addr.addressLine}</p>
            </div>
          ))}
        </div>
 
        {/* SUMMARY */}
        <div style={{ flex: 1 }}>
          <h3>Order Summary</h3>
 
          {cart.map((item) => (
            <p key={item._id}>
              {item.product.name} × {item.qty} = ₹
              {item.product.price * item.qty}
            </p>
          ))}
 
          <h2>Total: ₹{totalAmount}</h2>
 
          <button onClick={placeOrder}>
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
};
 
export default Checkout;
 