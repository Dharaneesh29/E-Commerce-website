// import { useState, useRef } from "react";
// import API from "../api/axios";
// import Layout from "../components/AdminLayout";
// import { useNavigate } from "react-router-dom";

// const categories = ["Electronics", "Clothing", "Sports", "Home", "Books", "Other"];

// export default function AddProduct() {
//   const [form, setForm] = useState({
//     name: "", price: "", description: "",
//     image: null, brand: "", category: "", countInStock: "",
//   });
//   const [msg,     setMsg]     = useState({ text: "", type: "" });
//   const [loading, setLoading] = useState(false);
//   const [preview, setPreview] = useState(null);
//   const [dragOver, setDragOver] = useState(false);
//   const fileRef = useRef();
//   const navigate = useNavigate();

//   const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

//   const handleImage = (file) => {
//     if (!file) return;
//     setForm(f => ({ ...f, image: file }));
//     setPreview(URL.createObjectURL(file));
//   };

//   const validate = () => {
//     const { name, price, description, brand, category, countInStock, image } = form;
//     if (!name || !price || !description || !brand || !category || !countInStock || !image)
//       return setMsg({ text: "⚠️ All fields are required", type: "error" }), false;
//     if (isNaN(price) || Number(price) <= 0)
//       return setMsg({ text: "⚠️ Price must be a positive number", type: "error" }), false;
//     if (isNaN(countInStock) || Number(countInStock) < 0)
//       return setMsg({ text: "⚠️ Stock must be 0 or more", type: "error" }), false;
//     return true;
//   };

//   const handleSubmit = async () => {
//     if (!validate()) return;
//     setLoading(true);
//     setMsg({ text: "", type: "" });
//     try {
//       const fd = new FormData();
//       Object.entries(form).forEach(([k, v]) => fd.append(k, v));
//       await API.post("/products", fd);
//       setMsg({ text: "✅ Product added successfully!", type: "success" });
//       setForm({ name: "", price: "", description: "", image: null, brand: "", category: "", countInStock: "" });
//       setPreview(null);
//       setTimeout(() => navigate("/products"), 1200);
//     } catch (err) {
//       setMsg({ text: err.response?.data?.message || "❌ Error adding product", type: "error" });
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div style={{ minHeight: "100vh", background: "linear-gradient(160deg,#fff8f2,#fff3e8,#ffecd8)", padding: "32px 24px", fontFamily: "'Segoe UI', sans-serif" }}>
//       <style>{`
//         @keyframes fadeUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
//         @keyframes shake  { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-6px)} 75%{transform:translateX(6px)} }
//         .inp:focus { border-color:#ff6b00!important; box-shadow:0 0 0 3px rgba(255,107,0,0.15)!important; outline:none; }
//         .inp:hover { border-color:#ffb36b!important; }
//         .submit-btn:hover { background:linear-gradient(135deg,#e55a00,#ff7700)!important; transform:translateY(-2px)!important; box-shadow:0 8px 24px rgba(255,107,0,0.45)!important; }
//         .submit-btn:active { transform:translateY(0)!important; }
//         .back-btn:hover { background:#fff3e8!important; color:#ff6b00!important; }
//         .remove-btn:hover { background:#cc0000!important; }
//         .drop-zone:hover { border-color:#ff6b00!important; background:#fff3e8!important; }
//       `}</style>

//       <div style={{ maxWidth: 780, margin: "0 auto" }}>

//         {/* ── HEADER ── */}
//         <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 28, animation: "fadeUp 0.4s ease both" }}>
//           <button className="back-btn" onClick={() => navigate("/products")} style={{ background: "#fff", border: "2px solid #ffd4a3", borderRadius: 10, padding: "8px 16px", color: "#cc5500", fontWeight: 700, fontSize: 13, cursor: "pointer", transition: "all 0.2s" }}>
//             ← Back
//           </button>
//           <div>
//             <h1 style={{ margin: 0, fontSize: 26, fontWeight: 900, color: "#3d1a00", letterSpacing: -0.5 }}>
//               ➕ Add New Product
//             </h1>
//             <p style={{ margin: "3px 0 0", fontSize: 13, color: "#cc7a00", fontWeight: 500 }}>
//               Fill in the details below to list a new product
//             </p>
//           </div>
//         </div>

//         {/* ── ALERT MSG ── */}
//         {msg.text && (
//           <div style={{
//             padding: "13px 18px", borderRadius: 12, marginBottom: 20, fontWeight: 700, fontSize: 14,
//             animation: msg.type === "error" ? "shake 0.35s ease" : "fadeUp 0.3s ease",
//             background: msg.type === "success" ? "#d1fae5" : "#fee2e2",
//             color:      msg.type === "success" ? "#065f46"  : "#991b1b",
//             border:     `2px solid ${msg.type === "success" ? "#6ee7b7" : "#fca5a5"}`,
//           }}>{msg.text}</div>
//         )}

//         {/* ── FORM CARD ── */}
//         <div style={{ background: "#fff", borderRadius: 20, border: "2px solid #ffd4a3", boxShadow: "0 8px 32px rgba(255,107,0,0.1)", overflow: "hidden", animation: "fadeUp 0.4s ease 0.1s both" }}>

//           {/* Card top accent */}
//           <div style={{ height: 5, background: "linear-gradient(90deg,#ff6b00,#ff9500,#ffb300)" }} />

//           <div style={{ padding: "28px 32px" }}>

//             {/* ── ROW 1: Name + Brand ── */}
//             <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
//               <Field label="Product Name *" icon="🏷️">
//                 <input className="inp" name="name" value={form.name}
//                   placeholder="e.g. Nike Air Max"
//                   onChange={handleChange} style={INP} />
//               </Field>
//               <Field label="Brand *" icon="🏢">
//                 <input className="inp" name="brand" value={form.brand}
//                   placeholder="e.g. Nike"
//                   onChange={handleChange} style={INP} />
//               </Field>
//             </div>

//             {/* ── ROW 2: Price + Stock ── */}
//             <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
//               <Field label="Price (₹) *" icon="💰">
//                 <div style={{ position: "relative" }}>
//                   <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#ff6b00", fontWeight: 800, fontSize: 15 }}>₹</span>
//                   <input className="inp" name="price" value={form.price}
//                     placeholder="e.g. 2999" type="number" min="0"
//                     onChange={handleChange} style={{ ...INP, paddingLeft: 28 }} />
//                 </div>
//               </Field>
//               <Field label="Count In Stock *" icon="📦">
//                 <input className="inp" name="countInStock" value={form.countInStock}
//                   placeholder="e.g. 50" type="number" min="0"
//                   onChange={handleChange} style={INP} />
//               </Field>
//             </div>

//             {/* ── CATEGORY ── */}
//             <div style={{ marginBottom: 20 }}>
//               <Field label="Category *" icon="🗂️">
//                 <select className="inp" name="category" value={form.category}
//                   onChange={handleChange} style={{ ...INP, color: form.category ? "#3d1a00" : "#aaa" }}>
//                   <option value="">-- Select Category --</option>
//                   {categories.map(c => <option key={c} value={c}>{c}</option>)}
//                 </select>
//               </Field>
//             </div>

//             {/* ── DESCRIPTION ── */}
//             <div style={{ marginBottom: 20 }}>
//               <Field label="Description *" icon="📝">
//                 <textarea className="inp" name="description" value={form.description}
//                   placeholder="Write a detailed product description..."
//                   onChange={handleChange}
//                   style={{ ...INP, height: 100, resize: "vertical", lineHeight: 1.5 }} />
//               </Field>
//             </div>

//             {/* ── IMAGE UPLOAD ── */}
//             <div style={{ marginBottom: 28 }}>
//               <label style={{ fontSize: 13, fontWeight: 800, color: "#3d1a00", marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
//                 <span>🖼️</span> Product Image *
//               </label>

//               {/* Drop zone */}
//               {!preview ? (
//                 <div className="drop-zone"
//                   onClick={() => fileRef.current.click()}
//                   onDragOver={e => { e.preventDefault(); setDragOver(true); }}
//                   onDragLeave={() => setDragOver(false)}
//                   onDrop={e => { e.preventDefault(); setDragOver(false); handleImage(e.dataTransfer.files[0]); }}
//                   style={{
//                     border: `2px dashed ${dragOver ? "#ff6b00" : "#ffd4a3"}`,
//                     borderRadius: 14, padding: "36px 20px", textAlign: "center",
//                     cursor: "pointer", transition: "all 0.2s",
//                     background: dragOver ? "#fff3e8" : "#fffaf7",
//                   }}>
//                   <div style={{ fontSize: 40, marginBottom: 10 }}>📁</div>
//                   <p style={{ margin: 0, fontWeight: 700, color: "#cc5500", fontSize: 14 }}>Click or drag & drop image here</p>
//                   <p style={{ margin: "6px 0 0", fontSize: 12, color: "#cc8833" }}>Supports JPG, PNG, WEBP — max 5MB</p>
//                   <input ref={fileRef} type="file" accept="image/*"
//                     onChange={e => handleImage(e.target.files[0])}
//                     style={{ display: "none" }} />
//                 </div>
//               ) : (
//                 <div style={{ display: "flex", alignItems: "center", gap: 20, padding: "16px 20px", background: "#fff8f2", borderRadius: 14, border: "2px solid #ffd4a3" }}>
//                   <img src={preview} alt="Preview" style={{ width: 90, height: 90, objectFit: "cover", borderRadius: 12, border: "3px solid #ffd4a3", boxShadow: "0 4px 12px rgba(255,107,0,0.2)" }} />
//                   <div style={{ flex: 1 }}>
//                     <p style={{ margin: 0, fontWeight: 700, color: "#3d1a00", fontSize: 14 }}>{form.image?.name}</p>
//                     <p style={{ margin: "4px 0 0", fontSize: 12, color: "#cc7a00" }}>
//                       {form.image ? (form.image.size / 1024).toFixed(1) + " KB" : ""}
//                     </p>
//                     <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
//                       <button onClick={() => fileRef.current.click()} style={{ background: "#fff3e8", border: "2px solid #ffd4a3", borderRadius: 8, padding: "5px 12px", fontSize: 12, fontWeight: 700, color: "#cc5500", cursor: "pointer" }}>
//                         🔄 Change
//                       </button>
//                       <button className="remove-btn" onClick={() => { setPreview(null); setForm(f => ({ ...f, image: null })); }} style={{ background: "#ef4444", border: "none", borderRadius: 8, padding: "5px 12px", fontSize: 12, fontWeight: 700, color: "#fff", cursor: "pointer", transition: "background 0.2s" }}>
//                         ✕ Remove
//                       </button>
//                     </div>
//                   </div>
//                   <input ref={fileRef} type="file" accept="image/*"
//                     onChange={e => handleImage(e.target.files[0])}
//                     style={{ display: "none" }} />
//                 </div>
//               )}
//             </div>

//             {/* ── DIVIDER ── */}
//             <div style={{ height: 2, background: "linear-gradient(90deg,#ff6b00,#ffd4a3,transparent)", borderRadius: 2, marginBottom: 24 }} />

//             {/* ── SUBMIT ── */}
//             <button className="submit-btn" onClick={handleSubmit} disabled={loading} style={{
//               width: "100%", padding: "15px", border: "none", borderRadius: 14,
//               background: loading ? "#ffb36b" : "linear-gradient(135deg,#ff6b00,#ff9500)",
//               color: "#fff", fontWeight: 900, fontSize: 16, cursor: loading ? "not-allowed" : "pointer",
//               boxShadow: "0 4px 16px rgba(255,107,0,0.35)", transition: "all 0.25s",
//               display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
//               letterSpacing: 0.3
//             }}>
//               {loading
//                 ? <><Spinner /> Adding Product...</>
//                 : <><span style={{ fontSize: 20 }}>➕</span> Add Product</>
//               }
//             </button>

//             {/* helper */}
//             <p style={{ textAlign: "center", margin: "12px 0 0", fontSize: 12, color: "#cc8833" }}>
//               All fields marked with * are required
//             </p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// // ── Sub-components ────────────────────────────────────────────
// function Field({ label, icon, children }) {
//   return (
//     <div style={{ display: "flex", flexDirection: "column" }}>
//       <label style={{ fontSize: 13, fontWeight: 800, color: "#3d1a00", marginBottom: 7, display: "flex", alignItems: "center", gap: 6 }}>
//         <span>{icon}</span>{label}
//       </label>
//       {children}
//     </div>
//   );
// }

// function Spinner() {
//   return (
//     <span style={{ width: 18, height: 18, border: "3px solid rgba(255,255,255,0.4)", borderTop: "3px solid #fff", borderRadius: "50%", display: "inline-block", animation: "spin 0.7s linear infinite" }}>
//       <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
//     </span>
//   );
// }

// // ── Shared input style ────────────────────────────────────────
// const INP = {
//   padding: "11px 14px",
//   border: "2px solid #ffd4a3",
//   borderRadius: 10,
//   fontSize: 14,
//   width: "100%",
//   boxSizing: "border-box",
//   background: "#fffaf7",
//   color: "#3d1a00",
//   fontFamily: "'Segoe UI', sans-serif",
//   transition: "border-color 0.2s, box-shadow 0.2s",
// };

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../api/axios";

const CATEGORIES = [
  "Beauty", "Electronics", "Fashion", "Fragrances", "Furniture",
  "Groceries", "Home-decoration", "Kitchen-accessories", "Laptops",
  "Mens-shirts", "Mens-shoes", "Mobile-accessories", "Smartphones",
  "Skin-care", "Sports-accessories", "Tablets", "Tops", "Womens-dresses",
  "Womens-jewellery", "Womens-shoes", "Grocery", "Footwear", "Other"
];

export default function AddProduct() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "", price: "", description: "",
    brand: "", category: "", countInStock: "",
    discount: "", rating: "",
  });
  const [image, setImage]     = useState(null);
  const [preview, setPreview] = useState(null);
  const [msg, setMsg]         = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleImage = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImage(file);
    setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async () => {
    if (!form.name || !form.price || !form.brand || !form.category) {
      setMsg({ text: "Please fill all required fields", type: "error" });
      return;
    }
    setLoading(true);
    try {
      const formData = new FormData();
      Object.entries(form).forEach(([k, v]) => { if (v) formData.append(k, v); });
      if (image) formData.append("image", image);

      await API.post("/products", formData, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
          "Content-Type": "multipart/form-data",
        },
      });

      setMsg({ text: "✅ Product added successfully!", type: "success" });
      setTimeout(() => navigate("/products"), 1500);
    } catch {
      setMsg({ text: "❌ Error adding product. Please try again.", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: "28px", fontFamily: "'Nunito', sans-serif", background: "#fdf8f3", minHeight: "100vh" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        @keyframes fadeUp { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: translateY(0); } }
        .form-input:focus { border-color: #ff6f00 !important; box-shadow: 0 0 0 3px rgba(255,111,0,0.1) !important; outline: none !important; }
        .form-input:hover { border-color: #ffaa70 !important; }
        .submit-btn:hover { opacity: 0.88 !important; transform: translateY(-1px) !important; }
        .cancel-btn:hover { background: #ff6f00 !important; color: #fff !important; border-color: #ff6f00 !important; }
        .upload-area:hover { border-color: #ff6f00 !important; background: #fff3e6 !important; }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 28, animation: "fadeUp 0.4s ease" }}>
        <button
          className="cancel-btn"
          onClick={() => navigate("/products")}
          style={{
            width: 40, height: 40, borderRadius: 10,
            border: "1.5px solid #ffe0c2", background: "#fff",
            color: "#ff6f00", fontSize: 18, cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center",
            transition: "all 0.2s", fontFamily: "inherit",
          }}
        >←</button>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 900, color: "#1a1a1a", margin: 0, letterSpacing: -0.5 }}>Add Product</h1>
          <p style={{ fontSize: 13, color: "#ffaa70", margin: 0, fontWeight: 700 }}>Fill in the details to add a new product</p>
        </div>
      </div>

      {/* ── TOAST ── */}
      {msg && (
        <div style={{
          padding: "14px 18px", borderRadius: 12, marginBottom: 20,
          background: msg.type === "success" ? "#ecfdf5" : "#fef2f2",
          border: `1.5px solid ${msg.type === "success" ? "#6ee7b7" : "#fecaca"}`,
          color: msg.type === "success" ? "#065f46" : "#991b1b",
          fontWeight: 800, fontSize: 14,
          animation: "fadeUp 0.3s ease",
        }}>
          {msg.text}
        </div>
      )}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 340px", gap: 24, animation: "fadeUp 0.4s ease 0.1s both" }}>

        {/* ── LEFT: FORM ── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Basic Info */}
          <div style={card}>
            <div style={cardTopBar} />
            <h3 style={cardTitle}>📋 Basic Information</h3>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div style={{ gridColumn: "1 / -1" }}>
                <label style={label}>Product Name <span style={{ color: "#ef4444" }}>*</span></label>
                <input className="form-input" name="name" placeholder="Enter product name" onChange={handleChange} value={form.name} style={inputStyle} />
              </div>
              <div>
                <label style={label}>Brand <span style={{ color: "#ef4444" }}>*</span></label>
                <input className="form-input" name="brand" placeholder="Enter brand name" onChange={handleChange} value={form.brand} style={inputStyle} />
              </div>
              <div>
                <label style={label}>Category <span style={{ color: "#ef4444" }}>*</span></label>
                <select className="form-input" name="category" onChange={handleChange} value={form.category} style={{ ...inputStyle, cursor: "pointer" }}>
                  <option value="">Select category</option>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div style={{ gridColumn: "1 / -1" }}>
                <label style={label}>Description</label>
                <textarea
                  className="form-input"
                  name="description"
                  placeholder="Enter product description..."
                  onChange={handleChange}
                  value={form.description}
                  rows={4}
                  style={{ ...inputStyle, resize: "vertical", lineHeight: 1.6 }}
                />
              </div>
            </div>
          </div>

          {/* Pricing & Stock */}
          <div style={card}>
            <div style={cardTopBar} />
            <h3 style={cardTitle}>💰 Pricing & Stock</h3>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
              <div>
                <label style={label}>Price (₹) <span style={{ color: "#ef4444" }}>*</span></label>
                <div style={{ position: "relative" }}>
                  <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#ff6f00", fontWeight: 900, fontSize: 15 }}>₹</span>
                  <input className="form-input" name="price" type="number" placeholder="0" onChange={handleChange} value={form.price} style={{ ...inputStyle, paddingLeft: 28 }} />
                </div>
              </div>
              <div>
                <label style={label}>Stock Quantity <span style={{ color: "#ef4444" }}>*</span></label>
                <input className="form-input" name="countInStock" type="number" placeholder="0" onChange={handleChange} value={form.countInStock} style={inputStyle} />
              </div>
              <div>
                <label style={label}>Discount (%)</label>
                <input className="form-input" name="discount" type="number" placeholder="0" onChange={handleChange} value={form.discount} style={inputStyle} />
              </div>
            </div>
          </div>

        </div>

        {/* ── RIGHT: IMAGE + ACTIONS ── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

          {/* Image Upload */}
          <div style={card}>
            <div style={cardTopBar} />
            <h3 style={cardTitle}>🖼️ Product Image</h3>

            <label className="upload-area" htmlFor="img-upload" style={{
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
              border: "2px dashed #ffe0c2", borderRadius: 14, padding: "20px",
              cursor: "pointer", transition: "all 0.2s", background: "#fff8f2",
              minHeight: 160, marginBottom: 12,
            }}>
              {preview ? (
                <img src={preview} alt="preview" style={{ width: "100%", height: 160, objectFit: "cover", borderRadius: 10 }} />
              ) : (
                <>
                  <span style={{ fontSize: 36, marginBottom: 10 }}>📸</span>
                  <p style={{ fontSize: 13, fontWeight: 800, color: "#ff6f00", margin: 0 }}>Click to upload image</p>
                  <p style={{ fontSize: 11, color: "#aaa", fontWeight: 600, margin: "4px 0 0" }}>PNG, JPG up to 5MB</p>
                </>
              )}
            </label>
            <input id="img-upload" type="file" accept="image/*" onChange={handleImage} style={{ display: "none" }} />

            {preview && (
              <button
                onClick={() => { setImage(null); setPreview(null); }}
                style={{
                  width: "100%", padding: "8px", borderRadius: 8,
                  border: "1.5px solid #fecaca", background: "#fef2f2",
                  color: "#ef4444", fontWeight: 800, fontSize: 12,
                  cursor: "pointer", fontFamily: "inherit",
                }}
              >🗑 Remove Image</button>
            )}
          </div>

          {/* Actions */}
          <div style={card}>
            <div style={cardTopBar} />
            <h3 style={cardTitle}>⚡ Actions</h3>

            <button
              className="submit-btn"
              onClick={handleSubmit}
              disabled={loading}
              style={{
                width: "100%", padding: "14px",
                background: "linear-gradient(135deg, #ff6f00, #ff9500)",
                color: "#fff", border: "none", borderRadius: 12,
                fontWeight: 900, fontSize: 15, cursor: loading ? "not-allowed" : "pointer",
                fontFamily: "inherit",
                boxShadow: "0 4px 16px rgba(255,111,0,0.35)",
                transition: "all 0.2s",
                opacity: loading ? 0.7 : 1,
                marginBottom: 10,
                display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
              }}
            >
              {loading ? (
                <>
                  <span style={{ width: 16, height: 16, border: "2.5px solid rgba(255,255,255,0.4)", borderTopColor: "#fff", borderRadius: "50%", display: "inline-block", animation: "spin 0.7s linear infinite" }} />
                  Adding...
                </>
              ) : "＋ Add Product"}
            </button>

            <button
              className="cancel-btn"
              onClick={() => navigate("/products")}
              style={{
                width: "100%", padding: "12px",
                background: "#fff", color: "#ff6f00",
                border: "1.5px solid #ffe0c2", borderRadius: 12,
                fontWeight: 800, fontSize: 14, cursor: "pointer",
                fontFamily: "inherit", transition: "all 0.2s",
              }}
            >Cancel</button>

            <div style={{ marginTop: 14, padding: "12px", background: "#fff8f2", borderRadius: 10, border: "1px solid #ffe0c2" }}>
              <p style={{ fontSize: 11, color: "#ffaa70", fontWeight: 800, margin: "0 0 6px", textTransform: "uppercase", letterSpacing: 0.4 }}>Required fields</p>
              {["Name", "Brand", "Category", "Price", "Stock"].map(f => (
                <div key={f} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                  <span style={{ fontSize: 10, color: form[f.toLowerCase()] || (f === "Stock" && form.countInStock) ? "#10b981" : "#ddd" }}>●</span>
                  <span style={{ fontSize: 12, color: "#888", fontWeight: 600 }}>{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

const card = {
  background: "#fff", borderRadius: 18,
  border: "1.5px solid #ffe0c2",
  boxShadow: "0 4px 18px rgba(255,111,0,0.07)",
  padding: "22px", position: "relative", overflow: "hidden",
};
const cardTopBar = {
  position: "absolute", top: 0, left: 0, right: 0, height: 4,
  background: "linear-gradient(90deg, #ff6f00, #ffaa44)",
  borderRadius: "18px 18px 0 0",
};
const cardTitle = { fontSize: 16, fontWeight: 900, color: "#1a1a1a", margin: "0 0 18px" };
const label     = { fontSize: 12, fontWeight: 800, color: "#888", textTransform: "uppercase", letterSpacing: 0.4, display: "block", marginBottom: 6 };
const inputStyle = {
  width: "100%", padding: "11px 14px",
  border: "1.5px solid #ffe0c2", borderRadius: 10,
  fontSize: 14, fontFamily: "inherit", color: "#1a1a1a",
  background: "#fff8f2", transition: "all 0.2s",
  boxSizing: "border-box",
};
