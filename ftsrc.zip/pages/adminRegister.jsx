import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";

const BASE = "http://localhost:5000/api";

export default function AdminRegister() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name:           "",
    email:          "",
    phone:          "",
    password:       "",
    confirmPassword:"",
    adminSecret:    "", // secret key to prevent random admin registrations
  });
  const [loading,  setLoading]  = useState(false);
  const [showPwd,  setShowPwd]  = useState(false);
  const [errors,   setErrors]   = useState({});
  const [toast,    setToast]    = useState(null);

  const showMsg = (text, type = "error") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 4000);
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim())           e.name           = "Name is required";
    if (!form.email.trim())          e.email          = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Invalid email";
    if (!form.phone.trim())          e.phone          = "Phone is required";
    else if (form.phone.length < 10) e.phone          = "Enter valid phone number";
    if (!form.password)              e.password       = "Password is required";
    else if (form.password.length < 6) e.password     = "Min 6 characters";
    if (form.password !== form.confirmPassword)
                                     e.confirmPassword= "Passwords don't match";
    if (!form.adminSecret.trim())    e.adminSecret    = "Admin secret key is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await axios.post(`${BASE}/users/admin/register`, {
        name:        form.name,
        email:       form.email,
        phone:       form.phone,
        password:    form.password,
        adminSecret: form.adminSecret,
      });

      showMsg("Admin account created successfully! Redirecting to login...", "success");
      setTimeout(() => navigate("/users/login"), 2000);

    } catch (err) {
      showMsg(err.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
  };

  return (
    <div style={page}>

      {/* ── Toast ── */}
      {toast && (
        <div style={{
          ...toast_style,
          background:  toast.type === "success" ? "#ecfdf5" : "#fef2f2",
          borderColor: toast.type === "success" ? "#6ee7b7" : "#fca5a5",
          color:       toast.type === "success" ? "#065f46" : "#991b1b",
        }}>
          {toast.type === "success" ? "✅" : "❌"} {toast.text}
        </div>
      )}

      <div style={wrapper}>

        {/* ── Left panel ── */}
        <div style={leftPanel}>
          <div style={leftContent}>
            <div style={brandIcon}>🛍️</div>
            <h1 style={brandName}>ShopEasy</h1>
            <p style={brandTag}>Admin Portal</p>

            <div style={featureList}>
              {[
                { icon: "📊", text: "Full dashboard access"         },
                { icon: "📦", text: "Manage products & inventory"   },
                { icon: "👥", text: "User & order management"       },
                { icon: "🔔", text: "Real-time notifications"       },
                { icon: "📤", text: "Export data & reports"         },
              ].map(({ icon, text }) => (
                <div key={text} style={featureItem}>
                  <span style={featureIcon}>{icon}</span>
                  <span style={featureText}>{text}</span>
                </div>
              ))}
            </div>

            <div style={securityNote}>
              🔒 Admin registration requires a secret key. Contact your system administrator to get one.
            </div>
          </div>
        </div>

        {/* ── Right panel ── */}
        <div style={rightPanel}>
          <div style={formCard}>

            {/* Header */}
            <div style={formHeader}>
              <div style={formIconWrap}>
                <span style={{ fontSize: 28 }}>👤</span>
              </div>
              <h2 style={formTitle}>Create Admin Account</h2>
              <p style={formSub}>Register as an administrator</p>
            </div>

            {/* Fields */}
            <div style={fieldGrid}>

              {/* Name */}
              <div style={fieldWrap}>
                <label style={label}>Full Name *</label>
                <div style={inputWrap}>
                  <span style={inputIcon}>👤</span>
                  <input
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="Jane Smith"
                    style={{
                      ...input,
                      borderColor: errors.name ? "#ef4444" : "#e2e8f0",
                    }}
                  />
                </div>
                {errors.name && <p style={errText}>{errors.name}</p>}
              </div>

              {/* Email */}
              <div style={fieldWrap}>
                <label style={label}>Email Address *</label>
                <div style={inputWrap}>
                  <span style={inputIcon}>✉️</span>
                  <input
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="jane@shopeasy.com"
                    style={{
                      ...input,
                      borderColor: errors.email ? "#ef4444" : "#e2e8f0",
                    }}
                  />
                </div>
                {errors.email && <p style={errText}>{errors.email}</p>}
              </div>

              {/* Phone */}
              <div style={{ ...fieldWrap, gridColumn: "span 2" }}>
                <label style={label}>Phone Number *</label>
                <div style={inputWrap}>
                  <span style={inputIcon}>📱</span>
                  <input
                    name="phone"
                    type="tel"
                    value={form.phone}
                    onChange={handleChange}
                    placeholder="9876543210"
                    style={{
                      ...input,
                      borderColor: errors.phone ? "#ef4444" : "#e2e8f0",
                    }}
                  />
                </div>
                {errors.phone && <p style={errText}>{errors.phone}</p>}
              </div>

              {/* Password */}
              <div style={fieldWrap}>
                <label style={label}>Password *</label>
                <div style={inputWrap}>
                  <span style={inputIcon}>🔒</span>
                  <input
                    name="password"
                    type={showPwd ? "text" : "password"}
                    value={form.password}
                    onChange={handleChange}
                    placeholder="Min 6 characters"
                    style={{
                      ...input,
                      paddingRight: 40,
                      borderColor: errors.password ? "#ef4444" : "#e2e8f0",
                    }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPwd(!showPwd)}
                    style={eyeBtn}
                  >
                    {showPwd ? "🙈" : "👁"}
                  </button>
                </div>
                {errors.password && <p style={errText}>{errors.password}</p>}
              </div>

              {/* Confirm Password */}
              <div style={fieldWrap}>
                <label style={label}>Confirm Password *</label>
                <div style={inputWrap}>
                  <span style={inputIcon}>🔒</span>
                  <input
                    name="confirmPassword"
                    type="password"
                    value={form.confirmPassword}
                    onChange={handleChange}
                    placeholder="Repeat password"
                    style={{
                      ...input,
                      borderColor: errors.confirmPassword ? "#ef4444"
                        : form.confirmPassword && form.confirmPassword === form.password
                        ? "#10b981" : "#e2e8f0",
                    }}
                  />
                </div>
                {errors.confirmPassword && (
                  <p style={errText}>{errors.confirmPassword}</p>
                )}
                {form.confirmPassword && form.confirmPassword === form.password && (
                  <p style={{ ...errText, color: "#10b981" }}>✓ Passwords match</p>
                )}
              </div>

              {/* Admin Secret Key */}
              <div style={{ ...fieldWrap, gridColumn: "span 2" }}>
                <label style={label}>Admin Secret Key *</label>
                <div style={inputWrap}>
                  <span style={inputIcon}>🗝️</span>
                  <input
                    name="adminSecret"
                    type="password"
                    value={form.adminSecret}
                    onChange={handleChange}
                    placeholder="Enter admin secret key"
                    style={{
                      ...input,
                      borderColor: errors.adminSecret ? "#ef4444" : "#e2e8f0",
                      letterSpacing: form.adminSecret ? 3 : 0,
                    }}
                  />
                </div>
                {errors.adminSecret && <p style={errText}>{errors.adminSecret}</p>}
                <p style={hintText}>
                  🔐 This key is set in your backend .env file as <code style={code}>ADMIN_SECRET</code>
                </p>
              </div>

            </div>

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={loading}
              style={loading ? { ...submitBtn, opacity: 0.7 } : submitBtn}
            >
              {loading
                ? <><span style={loadingSpinner} /> Creating Admin Account...</>
                : <>⭐ Create Admin Account</>
              }
            </button>

            {/* Links */}
            <div style={linksRow}>
              <span style={linkText}>Already have an account?</span>
              <Link to="/users/login" style={linkBtn}>Login →</Link>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

/* ── STYLES ── */
const page         = { minHeight: "100vh", background: "#f8fafc", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'DM Sans',sans-serif", padding: 20 };
const toast_style  = { position: "fixed", top: 20, right: 20, zIndex: 9999, padding: "12px 20px", borderRadius: 12, border: "1px solid", fontSize: 13, fontWeight: 600, boxShadow: "0 8px 24px rgba(0,0,0,0.1)", maxWidth: 380 };
const wrapper      = { display: "flex", width: "100%", maxWidth: 1000, borderRadius: 24, overflow: "hidden", boxShadow: "0 24px 80px rgba(0,0,0,0.12)" };

/* Left panel */
const leftPanel    = { width: 340, background: "linear-gradient(160deg,#0f172a 0%,#1e3a5f 60%,#1e293b 100%)", padding: "48px 36px", display: "flex", flexDirection: "column", justifyContent: "center", flexShrink: 0, position: "relative", overflow: "hidden" };
const leftContent  = { position: "relative", zIndex: 1 };
const brandIcon    = { fontSize: 40, marginBottom: 12 };
const brandName    = { fontSize: 28, fontWeight: 900, color: "white", margin: "0 0 4px" };
const brandTag     = { fontSize: 14, color: "rgba(255,255,255,0.5)", margin: "0 0 40px", fontWeight: 500 };
const featureList  = { display: "flex", flexDirection: "column", gap: 16, marginBottom: 32 };
const featureItem  = { display: "flex", alignItems: "center", gap: 12 };
const featureIcon  = { width: 36, height: 36, background: "rgba(249,115,22,0.15)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 };
const featureText  = { fontSize: 14, color: "rgba(255,255,255,0.8)", fontWeight: 500 };
const securityNote = { background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, padding: "14px 16px", fontSize: 12, color: "rgba(255,255,255,0.6)", lineHeight: 1.6 };

/* Right panel */
const rightPanel   = { flex: 1, background: "white", padding: "40px 36px", overflowY: "auto" };
const formCard     = { maxWidth: 480, margin: "0 auto" };
const formHeader   = { textAlign: "center", marginBottom: 28 };
const formIconWrap = { width: 64, height: 64, background: "linear-gradient(135deg,#f97316,#ea580c)", borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", boxShadow: "0 8px 24px rgba(249,115,22,0.35)" };
const formTitle    = { fontSize: 22, fontWeight: 800, color: "#0f172a", margin: "0 0 6px" };
const formSub      = { fontSize: 14, color: "#94a3b8", margin: 0 };

/* Fields */
const fieldGrid    = { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px 14px", marginBottom: 20 };
const fieldWrap    = { display: "flex", flexDirection: "column" };
const label        = { fontSize: 12, fontWeight: 700, color: "#374151", marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.04em" };
const inputWrap    = { position: "relative", display: "flex", alignItems: "center" };
const inputIcon    = { position: "absolute", left: 12, fontSize: 14, pointerEvents: "none", zIndex: 1 };
const input        = { width: "100%", height: 44, paddingLeft: 36, paddingRight: 12, borderRadius: 10, border: "1.5px solid #e2e8f0", fontSize: 14, color: "#1e293b", outline: "none", background: "#f8fafc", boxSizing: "border-box", transition: "border-color 0.2s" };
const eyeBtn       = { position: "absolute", right: 10, background: "none", border: "none", cursor: "pointer", fontSize: 15, padding: 0 };
const errText      = { fontSize: 11, color: "#ef4444", margin: "4px 0 0", display: "flex", alignItems: "center", gap: 4 };
const hintText     = { fontSize: 11, color: "#94a3b8", margin: "6px 0 0", lineHeight: 1.5 };
const code         = { background: "#f1f5f9", padding: "1px 5px", borderRadius: 4, fontSize: 11, fontFamily: "monospace", color: "#f97316" };

/* Submit */
const submitBtn    = { width: "100%", height: 48, background: "linear-gradient(135deg,#f97316,#ea580c)", color: "white", border: "none", borderRadius: 12, fontSize: 15, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, boxShadow: "0 4px 14px rgba(249,115,22,0.35)", marginBottom: 16, transition: "opacity 0.2s" };
const loadingSpinner={ width: 16, height: 16, borderRadius: "50%", border: "2px solid rgba(255,255,255,0.3)", borderTopColor: "white", animation: "spin 0.8s linear infinite", display: "inline-block" };

/* Links */
const linksRow     = { display: "flex", alignItems: "center", justifyContent: "center", gap: 8 };
const linkText     = { fontSize: 13, color: "#94a3b8" };
const linkBtn      = { fontSize: 13, fontWeight: 700, color: "#f97316", textDecoration: "none" };
