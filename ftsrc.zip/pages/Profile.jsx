// import { useEffect, useState } from "react";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import { toast } from "react-hot-toast";
 
// const Profile = () => {
//   const [tab, setTab] = useState("profile");
//   const [addresses, setAddresses] = useState([]);
//   const [orders, setOrders] = useState([]);
//   const [wallet, setWallet] = useState({
//   balance: 0,
//   transactions: [],
// });
 
// const [addAmount, setAddAmount] = useState("");
// const [walletLoading, setWalletLoading] = useState(false);

// const [showWalletModal, setShowWalletModal] = useState(false);
 
// const [paymentType, setPaymentType] = useState("UPI");
 
// const [upiId, setUpiId] = useState("");
 
// const [cardNumber, setCardNumber] = useState("");
 
//   const [editMode, setEditMode] = useState(false);
//   const [saving, setSaving] = useState(false);
 
//   // Change password state
//   const [oldPassword, setOldPassword] = useState("");
//   const [newPassword, setNewPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");
//   const [showOld, setShowOld] = useState(false);
//   const [showNew, setShowNew] = useState(false);
//   const [showConfirm, setShowConfirm] = useState(false);
//   const [pwLoading, setPwLoading] = useState(false);
 
//   const navigate = useNavigate();
//   const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
//   const [user, setUser] = useState(userInfo?.user);
//   const token = userInfo?.token;
 
//   // Edit form state
//   const [form, setForm] = useState({
//     name: user?.name || "",
//     phone: user?.phone || "",
//     city: user?.city || "",
//     gender: user?.gender || "",
//     dob: user?.dob || "",
//   });
 
//   if (!user || !token) {
//     return (
//       <div style={{ fontFamily: "'Nunito', sans-serif", textAlign: "center", padding: "80px 20px" }}>
//         <div style={{ fontSize: 52, marginBottom: 16 }}>🔒</div>
//         <p style={{ fontWeight: 800, fontSize: 18, color: "#333", marginBottom: 16 }}>Please login first</p>
//         <button onClick={() => navigate("/users/login")} style={{ padding: "11px 28px", background: "#ff6f00", color: "#fff", border: "none", borderRadius: 10, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>
//           Login
//         </button>
//       </div>
//     );
//   }
 
//   const fetchAddresses = async () => {
//     try {
//       const { data } = await axios.get("http://localhost:5000/api/address", {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setAddresses(data);
//     } catch (err) { console.log(err); }
//   };
 
//   const fetchOrders = async () => {
//     try {
//       const { data } = await axios.get("http://localhost:5000/api/orders/my", {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setOrders(data);
//     } catch (err) { console.log(err); }
//   };

//   const fetchWallet = async () => {
//   try {
 
//     const { data } = await axios.get(
//       "http://localhost:5000/api/wallet",
//       {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       }
//     );
 
//     setWallet(data);
 
//   } catch (err) {
//     console.log(err);
//     toast.error("Failed to load wallet");
//   }
// };

// const handleAddMoney = async () => {
 
//   if (!addAmount || addAmount <= 0) {
//     return toast.error("Enter valid amount");
//   }
 
//   try {
 
//     setWalletLoading(true);
 
//     const { data } = await axios.post(
//       "http://localhost:5000/api/wallet/add",
//       {
//         amount: Number(addAmount),
//       },
//       {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       }
//     );
 
//     toast.success("Money added successfully");
 
//     setWallet(data);
 
//     await fetchWallet();
 
//     setAddAmount("");
 
//   } catch (err) {
 
//     toast.error(
//       err.response?.data?.message || "Failed to add money"
//     );
 
//   } finally {
 
//     setWalletLoading(false);
 
//   }
// };
 
 
 
//   const handleDelete = async (id) => {
//     try {
//       await axios.delete(`http://localhost:5000/api/address/${id}`, {
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       fetchAddresses();
//       toast.success("Address deleted");
//     } catch (err) { console.log(err); }
//   };
 
//   useEffect(() => {
//     if (tab === "address") fetchAddresses();
//     if (tab === "orders") fetchOrders();
//     if (tab==="wallet") fetchWallet();
//   }, [tab]);
 
//   useEffect(() => {
//   if (user) {
//     setForm({
//       name: user.name || "",
//       phone: user.phone || "",
//       city: user.city || "",
//       gender: user.gender || "",
//       dob: user.dob
//         ? new Date(user.dob).toISOString().split("T")[0]
//         : "",
//     });
//   }
// }, [user]);
 
//   // Save profile changes
//   const handleSaveProfile = async () => {
//     setSaving(true);
//     try {
//       const { data } = await axios.put(
//         "http://localhost:5000/api/users/profile",
//         form,
//         { headers: { Authorization: `Bearer ${token}` } }
//       );
//       const updated = { ...userInfo, user: { ...user, ...form } };
//       sessionStorage.setItem("userInfo", JSON.stringify(updated));
//       setUser({ ...user, ...form });
//       setEditMode(false);
//       toast.success("Profile updated successfully!");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Update failed");
//     } finally {
//       setSaving(false);
//     }
//   };
 
//   // Change password
//   const handleChangePassword = async () => {
//     if (!oldPassword || !newPassword || !confirmPassword) {
//       return toast.error("Please fill all fields");
//     }
//     if (newPassword !== confirmPassword) {
//       return toast.error("New passwords do not match");
//     }
//     if (newPassword.length < 6) {
//       return toast.error("Password must be at least 6 characters");
//     }
//     setPwLoading(true);
//     try {
//       await axios.put(
//         "http://localhost:5000/api/users/change-password",
//         { oldPassword, newPassword },
//         { headers: { Authorization: `Bearer ${token}` } }
//       );
//       toast.success("Password changed successfully! 🎉");
//       setOldPassword(""); setNewPassword(""); setConfirmPassword("");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to change password");
//     } finally {
//       setPwLoading(false);
//     }
//   };
 
//   const statusColors = {
//     delivered: { bg: "#edfaf4", text: "#2e9e5b", border: "#b6e9cf" },
//     shipped: { bg: "#eff6ff", text: "#3b82f6", border: "#bfdbfe" },
//     confirmed: { bg: "#fff8f2", text: "#ff6f00", border: "#ffe0c2" },
//     cancelled: { bg: "#fff5f5", text: "#e53935", border: "#ffc9c9" },
//     pending: { bg: "#fefce8", text: "#ca8a04", border: "#fde68a" },
//     out_for_delivery: { bg: "#fdf4ff", text: "#9333ea", border: "#e9d5ff" },
//   };
 
//   const tabs = [
//     { id: "profile", label: "My Profile", icon: "👤" },
//     { id: "orders", label: "My Orders", icon: "📦" },
//     { id: "address", label: "Addresses", icon: "📍" },
//     // { id: "wishlist", label: "Wishlist", icon: "❤️" },
//     { id: "wallet", label: "My Wallet", icon: "💰" },
//     { id: "password", label: "Change Password", icon: "🔒" },
//   ];
 
//   // Initials avatar
//   const initials = user.name?.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
 
//   const pwStrength = (pw) => {
//     if (!pw) return null;
//     if (pw.length < 6) return { label: "Weak", color: "#e53935", width: "30%" };
//     if (pw.length < 9) return { label: "Fair", color: "#ff9500", width: "60%" };
//     return { label: "Strong", color: "#2e9e5b", width: "100%" };
//   };
//   const strength = pwStrength(newPassword);
 
//   return (
//     <>
//       <style>{`
//         @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&display=swap');
//         * { box-sizing: border-box; margin: 0; padding: 0; }
 
//         .profile-root {
//           font-family: 'Nunito', sans-serif;
//           background: #fdf5ee;
//           min-height: 100vh;
//           padding: 28px 20px 60px;
//           max-width: 1100px;
//           margin: 0 auto;
//         }
 
//         /* ── HEADER BANNER ── */
//         .profile-banner {
//           background: linear-gradient(135deg, #ff6f00, #ff9500, #ffb347);
//           border-radius: 20px;
//           padding: 28px 32px;
//           display: flex;
//           align-items: center;
//           gap: 22px;
//           margin-bottom: 24px;
//           position: relative;
//           overflow: hidden;
//           box-shadow: 0 8px 28px rgba(255,111,0,0.25);
//         }
//         .profile-banner::before {
//           content: '';
//           position: absolute;
//           top: -40px; right: -40px;
//           width: 180px; height: 180px;
//           border-radius: 50%;
//           background: rgba(255,255,255,0.1);
//         }
//         .profile-banner::after {
//           content: '';
//           position: absolute;
//           bottom: -50px; left: 30%;
//           width: 220px; height: 220px;
//           border-radius: 50%;
//           background: rgba(255,255,255,0.06);
//         }
//         .avatar-circle {
//           width: 72px; height: 72px;
//           border-radius: 50%;
//           background: rgba(255,255,255,0.25);
//           border: 3px solid rgba(255,255,255,0.5);
//           display: flex; align-items: center; justify-content: center;
//           font-size: 26px; font-weight: 900; color: #fff;
//           flex-shrink: 0;
//           backdrop-filter: blur(4px);
//         }
//         .banner-name {
//           font-size: 22px; font-weight: 900; color: #fff;
//           letter-spacing: -0.3px; margin-bottom: 4px;
//         }
//         .banner-email {
//           font-size: 13.5px; color: rgba(255,255,255,0.8); font-weight: 600;
//         }
//         .banner-right {
//           margin-left: auto;
//           display: flex; flex-direction: column; align-items: flex-end; gap: 6px;
//           z-index: 1;
//         }
//         .banner-badge {
//           background: rgba(255,255,255,0.2);
//           border: 1px solid rgba(255,255,255,0.3);
//           color: #fff;
//           font-size: 12px; font-weight: 800;
//           padding: 4px 12px; border-radius: 20px;
//           backdrop-filter: blur(4px);
//         }
 
//         /* ── LAYOUT ── */
//         .profile-layout {
//           display: flex;
//           gap: 20px;
//           align-items: flex-start;
//         }
 
//         /* ── SIDEBAR ── */
//         .profile-sidebar {
//           width: 230px;
//           flex-shrink: 0;
//           background: #fff;
//           border-radius: 18px;
//           border: 1.5px solid #ffe0c2;
//           box-shadow: 0 4px 16px rgba(255,111,0,0.07);
//           overflow: hidden;
//           position: sticky;
//           top: 20px;
//         }
//         .sidebar-top {
//           background: linear-gradient(135deg, #fff8f2, #fff3e6);
//           padding: 18px 16px;
//           border-bottom: 1.5px solid #ffe0c2;
//         }
//         .sidebar-greeting {
//           font-size: 12px; font-weight: 700; color: #aaa;
//           text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 2px;
//         }
//         .sidebar-name {
//           font-size: 15px; font-weight: 800; color: #1a1a1a;
//         }
//         .sidebar-tab {
//           display: flex;
//           align-items: center;
//           gap: 10px;
//           padding: 13px 18px;
//           cursor: pointer;
//           font-size: 13.5px;
//           font-weight: 700;
//           color: #666;
//           border-bottom: 1px solid #f5ece4;
//           transition: background 0.15s, color 0.15s;
//           position: relative;
//         }
//         .sidebar-tab:last-child { border-bottom: none; }
//         .sidebar-tab:hover { background: #fff8f2; color: #ff6f00; }
//         .sidebar-tab.active {
//           background: #fff8f2;
//           color: #ff6f00;
//           font-weight: 800;
//         }
//         .sidebar-tab.active::before {
//           content: '';
//           position: absolute;
//           left: 0; top: 0;
//           width: 3px; height: 100%;
//           background: linear-gradient(180deg, #ff6f00, #ffaa5a);
//           border-radius: 0 2px 2px 0;
//         }
//         .sidebar-tab .tab-icon { font-size: 16px; }
//         .logout-tab {
//           display: flex;
//           align-items: center;
//           gap: 10px;
//           padding: 13px 18px;
//           cursor: pointer;
//           font-size: 13.5px;
//           font-weight: 700;
//           color: #e53935;
//           border-top: 1.5px solid #f5ece4;
//           transition: background 0.15s;
//           margin-top: 4px;
//         }
//         .logout-tab:hover { background: #fff5f5; }
 
//         /* ── CONTENT PANEL ── */
//         .profile-content {
//           flex: 1;
//           background: #fff;
//           border-radius: 18px;
//           border: 1.5px solid #ffe0c2;
//           box-shadow: 0 4px 18px rgba(255,111,0,0.07);
//           padding: 28px;
//           position: relative;
//           overflow: hidden;
//         }
//         .profile-content::before {
//           content: '';
//           position: absolute;
//           top: 0; left: 0; right: 0;
//           height: 4px;
//           background: linear-gradient(90deg, #ff6f00, #ffaa5a);
//         }
 
//         .content-title {
//           font-size: 22px; font-weight: 900; color: #1a1a1a;
//           letter-spacing: -0.3px; margin-bottom: 22px;
//           display: flex; align-items: center; justify-content: space-between;
//           flex-wrap: wrap; gap: 10px;
//         }
 
//         /* ── PROFILE INFO ── */
//         .info-grid {
//           display: grid;
//           grid-template-columns: 1fr 1fr;
//           gap: 14px;
//           margin-bottom: 24px;
//         }
//         .info-cell {
//           background: #fff8f2;
//           border: 1.5px solid #ffe0c2;
//           border-radius: 12px;
//           padding: 14px 16px;
//         }
//         .info-label {
//           font-size: 11px; font-weight: 700; color: #aaa;
//           text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 5px;
//         }
//         .info-value {
//           font-size: 15px; font-weight: 800; color: #1a1a1a;
//         }
//         .info-value.muted { color: #bbb; font-weight: 600; font-style: italic; }
 
//         /* Edit form */
//         .form-label {
//           font-size: 12px; font-weight: 700; color: #888;
//           text-transform: uppercase; letter-spacing: 0.4px;
//           display: block; margin-bottom: 6px;
//         }
//         .form-input {
//           width: 100%;
//           padding: 11px 14px;
//           border: 1.5px solid #e8e8e8;
//           border-radius: 10px;
//           font-size: 14px;
//           font-family: 'Nunito', sans-serif;
//           color: #1a1a1a;
//           background: #fafafa;
//           margin-bottom: 14px;
//           outline: none;
//           transition: border-color 0.2s, box-shadow 0.2s;
//         }
//         .form-input:focus {
//           border-color: #ff6f00;
//           box-shadow: 0 0 0 3px rgba(255,111,0,0.1);
//           background: #fff;
//         }
//         .form-select {
//           width: 100%;
//           padding: 11px 14px;
//           border: 1.5px solid #e8e8e8;
//           border-radius: 10px;
//           font-size: 14px;
//           font-family: 'Nunito', sans-serif;
//           color: #1a1a1a;
//           background: #fafafa;
//           margin-bottom: 14px;
//           outline: none;
//           cursor: pointer;
//         }
//         .form-select:focus { border-color: #ff6f00; }
//         .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
 
//         .btn-primary {
//           padding: 12px 22px;
//           background: linear-gradient(135deg, #ff6f00, #ff9500);
//           color: #fff;
//           border: none;
//           border-radius: 11px;
//           font-weight: 800;
//           font-size: 14px;
//           cursor: pointer;
//           font-family: 'Nunito', sans-serif;
//           box-shadow: 0 4px 14px rgba(255,111,0,0.3);
//           transition: opacity 0.2s, transform 0.1s;
//           display: inline-flex; align-items: center; gap: 6px;
//         }
//         .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
//         .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
 
//         .btn-outline {
//           padding: 12px 22px;
//           background: transparent;
//           color: #ff6f00;
//           border: 2px solid #ff6f00;
//           border-radius: 11px;
//           font-weight: 800;
//           font-size: 14px;
//           cursor: pointer;
//           font-family: 'Nunito', sans-serif;
//           transition: background 0.2s, color 0.2s;
//         }
//         .btn-outline:hover { background: #ff6f00; color: #fff; }
 
//         .btn-row { display: flex; gap: 10px; margin-top: 6px; }
 
//         /* ── ORDERS ── */
//         .order-card {
//           border: 1.5px solid #f0e8e0;
//           border-radius: 16px;
//           padding: 18px 20px;
//           margin-bottom: 14px;
//           cursor: pointer;
//           transition: box-shadow 0.2s, border-color 0.2s, transform 0.15s;
//           background: #fff;
//           position: relative;
//           overflow: hidden;
//         }
//         .order-card::before {
//           content: '';
//           position: absolute;
//           top: 0; left: 0;
//           width: 3px; height: 100%;
//           background: linear-gradient(180deg, #ff6f00, #ffaa5a);
//           border-radius: 3px 0 0 3px;
//         }
//         .order-card:hover {
//           box-shadow: 0 8px 24px rgba(255,111,0,0.12);
//           border-color: #ffcc99;
//           transform: translateY(-2px);
//         }
//         .order-top {
//           display: flex;
//           justify-content: space-between;
//           align-items: flex-start;
//           margin-bottom: 14px;
//         }
//         .order-id {
//           font-size: 12px; color: #aaa; font-weight: 700; margin-bottom: 3px;
//         }
//         .order-price {
//           font-size: 18px; font-weight: 900; color: #1a1a1a;
//         }
//         .order-status-pill {
//           padding: 5px 12px;
//           border-radius: 20px;
//           font-size: 11.5px;
//           font-weight: 800;
//           border: 1.5px solid;
//         }
//         .order-imgs {
//           display: flex; gap: 10px; flex-wrap: wrap;
//         }
//         .order-img {
//           width: 58px; height: 58px;
//           border-radius: 10px;
//           object-fit: cover;
//           border: 1.5px solid #ffe0c2;
//           background: #fff8f2;
//           transition: transform 0.15s;
//         }
//         .order-img:hover { transform: scale(1.06); }
//         .order-more {
//           width: 58px; height: 58px;
//           border-radius: 10px;
//           background: #fff8f2;
//           border: 1.5px solid #ffe0c2;
//           display: flex; align-items: center; justify-content: center;
//           font-size: 13px; font-weight: 800; color: #ff6f00;
//         }
//         .order-bottom {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           margin-top: 14px;
//           font-size: 13px;
//           color: #aaa; font-weight: 600;
//         }
//         .order-view-link {
//           color: #ff6f00; font-weight: 800; font-size: 13px;
//           display: flex; align-items: center; gap: 4px;
//         }
 
//         /* ── ADDRESSES ── */
//         .addr-card {
//           border: 1.5px solid #f0e8e0;
//           border-radius: 16px;
//           padding: 18px 20px;
//           margin-bottom: 14px;
//           display: flex;
//           justify-content: space-between;
//           align-items: flex-start;
//           gap: 12px;
//           transition: box-shadow 0.2s, border-color 0.2s;
//           position: relative; overflow: hidden;
//         }
//         .addr-card::before {
//           content: '';
//           position: absolute;
//           top: 0; left: 0;
//           width: 3px; height: 100%;
//           background: linear-gradient(180deg, #ff6f00, #ffaa5a);
//         }
//         .addr-card:hover {
//           box-shadow: 0 6px 20px rgba(255,111,0,0.09);
//           border-color: #ffcc99;
//         }
//         .addr-name { font-size: 15px; font-weight: 800; color: #1a1a1a; margin-bottom: 4px; }
//         .addr-line { font-size: 13.5px; color: #666; font-weight: 600; line-height: 1.6; }
//         .addr-type-pill {
//           display: inline-flex; align-items: center; gap: 4px;
//           padding: 3px 10px; border-radius: 20px;
//           font-size: 11px; font-weight: 800;
//           margin-top: 8px;
//         }
//         .addr-actions { display: flex; flex-direction: column; gap: 8px; align-items: flex-end; }
//         .btn-delete {
//           padding: 7px 14px;
//           background: #fff5f5;
//           color: #e53935;
//           border: 1.5px solid #ffc9c9;
//           border-radius: 8px;
//           font-size: 12.5px; font-weight: 800;
//           cursor: pointer; font-family: 'Nunito', sans-serif;
//           transition: background 0.15s, color 0.15s;
//         }
//         .btn-delete:hover { background: #e53935; color: #fff; border-color: #e53935; }
 
//         /* Empty states */
//         .empty-state {
//           text-align: center;
//           padding: 50px 20px;
//         }
//         .empty-state .e-icon { font-size: 52px; margin-bottom: 14px; }
//         .empty-state p { font-size: 16px; font-weight: 800; color: #333; margin-bottom: 6px; }
//         .empty-state span { font-size: 13.5px; color: #aaa; font-weight: 600; }
 
//         /* ── CHANGE PASSWORD ── */
//         .pw-card {
//           background: #fff8f2;
//           border: 1.5px solid #ffe0c2;
//           border-radius: 14px;
//           padding: 20px;
//           margin-bottom: 20px;
//         }
//         .pw-input-wrap {
//           position: relative;
//         }
//         .pw-input-wrap .form-input {
//           padding-right: 44px;
//           margin-bottom: 0;
//         }
//         .pw-eye {
//           position: absolute;
//           right: 14px; top: 50%;
//           transform: translateY(-50%);
//           cursor: pointer;
//           font-size: 16px;
//           color: #aaa;
//           user-select: none;
//           transition: color 0.15s;
//         }
//         .pw-eye:hover { color: #ff6f00; }
//         .pw-field-wrap { margin-bottom: 14px; }
 
//         .strength-bar-wrap { margin-top: 8px; margin-bottom: 4px; }
//         .strength-bg {
//           height: 5px; background: #e8e8e8;
//           border-radius: 5px; overflow: hidden;
//         }
//         .strength-fill {
//           height: 5px; border-radius: 5px;
//           transition: width 0.3s, background 0.3s;
//         }
//         /* ── WALLET ── */
 
// .wallet-card {
//   background: linear-gradient(135deg, #ff6f00, #ff9500);
//   border-radius: 20px;
//   padding: 28px;
//   color: white;
//   margin-bottom: 24px;
//   box-shadow: 0 10px 25px rgba(255,111,0,0.25);
// }
 
// .wallet-label {
//   font-size: 13px;
//   font-weight: 700;
//   opacity: 0.9;
//   margin-bottom: 8px;
// }
 
// .wallet-balance {
//   font-size: 38px;
//   font-weight: 900;
// }
 
// .wallet-sub {
//   margin-top: 6px;
//   font-size: 13px;
//   opacity: 0.85;
// }
 
// .wallet-add-box {
//   background: #fff8f2;
//   border: 1.5px solid #ffe0c2;
//   border-radius: 16px;
//   padding: 18px;
//   margin-bottom: 24px;
// }
 
// .wallet-row {
//   display: flex;
//   gap: 12px;
//   align-items: center;
// }
 
// .wallet-input {
//   flex: 1;
//   padding: 12px 14px;
//   border-radius: 10px;
//   border: 1.5px solid #e8e8e8;
//   font-family: 'Nunito', sans-serif;
//   font-size: 14px;
//   outline: none;
// }
 
// .wallet-input:focus {
//   border-color: #ff6f00;
// }
 
// .transaction-card {
//   border: 1.5px solid #f1e8df;
//   border-radius: 14px;
//   padding: 16px 18px;
//   margin-bottom: 14px;
//   display: flex;
//   justify-content: space-between;
//   align-items: center;
//   background: white;
// }
 
// .transaction-title {
//   font-size: 14px;
//   font-weight: 800;
//   color: #1a1a1a;
//   margin-bottom: 4px;
// }
 
// .transaction-date {
//   font-size: 12px;
//   color: #999;
//   font-weight: 700;
// }
 
// .transaction-amount {
//   font-size: 16px;
//   font-weight: 900;
// }
 
// .credit {
//   color: #16a34a;
// }
 
// .debit {
//   color: #e53935;
// }
 
//         .strength-label {
//           font-size: 11.5px; font-weight: 800; margin-top: 4px;
//         }

//         @keyframes popup {
//   from {
//     opacity: 0;
//     transform: scale(0.92);
//   }
//   to {
//     opacity: 1;
//     transform: scale(1);
//   }
// }
//       `}</style>
 
//       <div className="profile-root">
 
//         {/* ── BACK TO HOME BUTTON ── */}
//         <button
//           onClick={() => navigate("/home")}
//           style={{
//             display: "inline-flex",
//             alignItems: "center",
//             gap: "7px",
//             marginBottom: "16px",
//             padding: "9px 18px",
//             background: "#fff",
//             border: "1.5px solid #ffe0c2",
//             borderRadius: "11px",
//             fontFamily: "'Nunito', sans-serif",
//             fontWeight: 800,
//             fontSize: "14px",
//             color: "#ff6f00",
//             cursor: "pointer",
//             boxShadow: "0 2px 8px rgba(255,111,0,0.10)",
//             transition: "background 0.15s, box-shadow 0.15s, transform 0.1s",
//           }}
//           onMouseEnter={e => {
//             e.currentTarget.style.background = "#fff8f2";
//             e.currentTarget.style.transform = "translateY(-1px)";
//             e.currentTarget.style.boxShadow = "0 4px 14px rgba(255,111,0,0.18)";
//           }}
//           onMouseLeave={e => {
//             e.currentTarget.style.background = "#fff";
//             e.currentTarget.style.transform = "translateY(0)";
//             e.currentTarget.style.boxShadow = "0 2px 8px rgba(255,111,0,0.10)";
//           }}
//         >
//           ← Home
//         </button>
 
//         {/* ── BANNER ── */}
//         <div className="profile-banner">
//           <div className="avatar-circle">{initials}</div>
//           <div>
//             <div className="banner-name">{user.name}</div>
//             <div className="banner-email">{user.email}</div>
//           </div>
//           <div className="banner-right">
//             <span className="banner-badge">⭐ Member</span>
//           </div>
//         </div>
 
//         {/* ── LAYOUT ── */}
//         <div className="profile-layout">
 
//           {/* SIDEBAR */}
//           <div className="profile-sidebar">
//             <div className="sidebar-top">
//               <div className="sidebar-greeting">Hello,</div>
//               <div className="sidebar-name">{user.name?.split(" ")[0]}</div>
//             </div>
//             {tabs.map(t => (
//               <div
//                 key={t.id}
//                 className={`sidebar-tab${tab === t.id ? " active" : ""}`}
//                 onClick={() => setTab(t.id)}
//               >
//                 <span className="tab-icon">{t.icon}</span>
//                 {t.label}
//               </div>
//             ))}
//             <div
//               className="logout-tab"
//               onClick={() => {
//                 sessionStorage.removeItem("userInfo");
//                 navigate("/users/login");
//               }}
//             >
//               <span>🚪</span> Logout
//             </div>
//           </div>
 
//           {/* CONTENT */}
//           <div className="profile-content">
 
//             {/* ── MY PROFILE TAB ── */}
//             {tab === "profile" && (
//               <>
//                 <div className="content-title">
//                   My Profile
//                   {!editMode && (
//                     <button className="btn-outline" onClick={() => setEditMode(true)}>✏️ Edit Profile</button>
//                   )}
//                 </div>
 
//                 {!editMode ? (
//                   <div className="info-grid">
//                     {[
//                       { label: "Full Name", value: user.name },
//                       { label: "Email", value: user.email },
//                       { label: "Phone", value: user.phone },
//                       { label: "City", value: user.city },
//                       { label: "Gender", value: user.gender },
//                       { label: "Date of Birth", value: user.dob ? new Date(user.dob).toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" }) : null },
//                     ].map((item, i) => (
//                       <div className="info-cell" key={i}>
//                         <div className="info-label">{item.label}</div>
//                         <div className={`info-value${!item.value ? " muted" : ""}`}>
//                           {item.value || "Not provided"}
//                         </div>
//                       </div>
//                     ))}
//                   </div>
//                 ) : (
//                   <>
//                     <label className="form-label">Full Name</label>
//                     <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
 
//                     <label className="form-label">Phone</label>
//                     <input className="form-input" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Phone number" />
 
//                     <div className="form-grid">
//                       <div>
//                         <label className="form-label">City</label>
//                         <input className="form-input" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} placeholder="Your city" />
//                       </div>
//                       <div>
//                         <label className="form-label">Gender</label>
//                         <select className="form-select" value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}>
//                           <option value="">Select gender</option>
//                           <option value="Male">Male</option>
//                           <option value="Female">Female</option>
//                           <option value="Other">Other</option>
//                         </select>
//                       </div>
//                     </div>
 
//                     <label className="form-label">Date of Birth</label>
//                     <input className="form-input" type="date" value={form.dob} onChange={e => setForm({ ...form, dob: e.target.value })} />
 
//                     <div className="btn-row">
//                       <button className="btn-primary" onClick={handleSaveProfile} disabled={saving}>
//                         {saving ? "Saving..." : "💾 Save Changes"}
//                       </button>
//                       <button className="btn-outline" onClick={() => setEditMode(false)}>Cancel</button>
//                     </div>
//                   </>
//                 )}
//               </>
//             )}
 
//             {/* ── ORDERS TAB ── */}
// {tab === "orders" && (
//   <>
//     <div className="content-title">My Orders</div>

//     {orders.length === 0 ? (
//       <div className="empty-state">
//         <div className="e-icon">📦</div>
//         <p>No orders yet</p>
//         <span>Your placed orders will appear here</span>
//       </div>
//     ) : (
//       orders.map(order => {
//         const sc =
//           statusColors[order.status] || statusColors.pending;

//         return (
//           <div
//             className="order-card"
//             key={order._id}
//             onClick={() => navigate(`/orders/${order._id}`)}
//           >
//             {/* Top Section */}
//             <div className="order-top">
//               <div>
//                 <div className="order-id">
//                   #{order._id.slice(-8).toUpperCase()}
//                 </div>
//                 <div className="order-price">
//                   ₹{order.totalPrice?.toLocaleString("en-IN")}
//                 </div>
//               </div>

//               <span
//                 className="order-status-pill"
//                 style={{
//                   background: sc.bg,
//                   color: sc.text,
//                   borderColor: sc.border
//                 }}
//               >
//                 {order.status
//                   ?.replace(/_/g, " ")
//                   .replace(/\b\w/g, c => c.toUpperCase())}
//               </span>
//             </div>

//             {/* Images Section — UPDATED */}
//            <div className="order-imgs">
//   {order.orderItems?.slice(0, 3).map((item, i) => {
//     const imageSrc = item.image?.startsWith("http")
//       ? item.image
//       : `http://localhost:5000${item.image}`;

//     return (
//       <img
//       key={i}
//       src={imageSrc}
//       alt="product"
//       className="order-img"
//       onError={(e) => {
//         e.target.onerror = null
//         e.target.src = "/placeholder.png"
//       }}
//       />
//     );
//       })}

//   {order.orderItems?.length > 3 && (
//     <div className="order-more">
//       +{order.orderItems.length - 3}
//     </div>
//   )}
// </div>

//             {/* Bottom Section */}
//             <div className="order-bottom">
//               <span>
//                 {new Date(order.createdAt).toLocaleDateString(
//                   "en-IN",
//                   { day: "2-digit", month: "short", year: "numeric" }
//                 )}
//               </span>

//               <span className="order-view-link">
//                 View Details →
//               </span>
//             </div>
//           </div>
//         );
//       })
//     )}
//   </>
// )}
 
//             {/* ── ADDRESSES TAB ── */}
//             {tab === "address" && (
//               <>
//                 <div className="content-title">
//                   My Addresses
//                   <button className="btn-primary" onClick={() => navigate("/address/add")}>+ Add Address</button>
//                 </div>
//                 {addresses.length === 0 ? (
//                   <div className="empty-state">
//                     <div className="e-icon">📍</div>
//                     <p>No addresses saved</p>
//                     <span>Add a delivery address to get started</span>
//                   </div>
//                 ) : (
//                   addresses.map(addr => (
//                     <div className="addr-card" key={addr._id}>
//                       <div>
//                         <div className="addr-name">{addr.fullName}</div>
//                         <div className="addr-line">
//                           {addr.addressLine1}{addr.addressLine2 ? `, ${addr.addressLine2}` : ""}<br />
//                           {addr.city}, {addr.state} – {addr.pincode}<br />
//                           📞 {addr.phone}
//                         </div>
//                         <span
//                           className="addr-type-pill"
//                           style={{
//                             background: addr.addressType === "Home" ? "#eff6ff" : "#f0fdf4",
//                             color: addr.addressType === "Home" ? "#3b82f6" : "#16a34a",
//                             border: `1.5px solid ${addr.addressType === "Home" ? "#bfdbfe" : "#bbf7d0"}`,
//                           }}
//                         >
//                           {addr.addressType === "Home" ? "🏠" : "💼"} {addr.addressType}
//                         </span>
//                       </div>
//                       <div className="addr-actions">
//                         <button className="btn-delete" onClick={() => handleDelete(addr._id)}>🗑 Delete</button>
//                       </div>
//                     </div>
//                   ))
//                 )}
//               </>
//             )}

//             {/* ── WALLET TAB ── */}
// {tab === "wallet" && (
//   <>
//     <div className="content-title">
//       My Wallet
//     </div>
 
//     {/* Wallet Balance */}
//     <div className="wallet-card">
 
//       <div className="wallet-label">
//         Available Balance
//       </div>
 
//       <div className="wallet-balance">
//         ₹{wallet?.balance?.toLocaleString("en-IN") || "0"}
//       </div>
 
//       <div className="wallet-sub">
//         Use wallet balance for faster checkout ⚡
//       </div>
 
//     </div>
 
//     {/* Add Money */}
// <div className="wallet-add-box">
 
//   <div
//     style={{
//       display: "flex",
//       justifyContent: "space-between",
//       alignItems: "center",
//       marginBottom: 14,
//     }}
//   >
//     <div
//       style={{
//         fontWeight: 800,
//         fontSize: 16,
//         color: "#1a1a1a",
//       }}
//     >
//       Add Money to Wallet
//     </div>
 
//     <button
//       className="btn-primary"
//       onClick={() => setShowWalletModal(true)}
//     >
//       + Add Money
//     </button>
//   </div>
 
//   <div
//     style={{
//       fontSize: 13,
//       color: "#888",
//       fontWeight: 600,
//       lineHeight: 1.6,
//     }}
//   >
//     Add money instantly using UPI or Card payment
//   </div>
 
// </div>
 
 
//     {/* Transactions */}
//     <div className="content-title" style={{ fontSize: 20 }}>
//       Transaction History
//     </div>
 
//     {wallet?.transactions?.length === 0 ? (
 
//       <div className="empty-state">
//         <div className="e-icon">💳</div>
//         <p>No transactions yet</p>
//         <span>Your wallet history will appear here</span>
//       </div>
 
//     ) : (
 
//       wallet?.transactions
//         ?.slice()
//         ?.reverse()
//         ?.map((txn, index) => (
 
//           <div className="transaction-card" key={index}>
 
//             <div>
//               <div className="transaction-title">
//                 {txn.description || txn.type}
//               </div>
 
//               <div className="transaction-date">
//                 {new Date(txn.date).toLocaleString("en-IN")}
//               </div>
//             </div>
 
//             <div
//               className={`transaction-amount ${
//                 txn.type === "DEBIT" || txn.type === "PURCHASE"
//                   ? "debit"
//                   : "credit"
//               }`}
//             >
//               {txn.type === "DEBIT" || txn.type === "PURCHASE"
//                 ? "-"
//                 : "+"}
//               ₹{txn.amount}
//             </div>
 
//           </div>
 
//         ))
//     )}
//   </>
// )}
 
 
//             {/* ── CHANGE PASSWORD TAB ── */}
//             {tab === "password" && (
//               <>
//                 <div className="content-title">Change Password</div>
//                 <div className="pw-card">
 
//                   <div className="pw-field-wrap">
//                     <label className="form-label">Current Password</label>
//                     <div className="pw-input-wrap">
//                       <input
//                         className="form-input"
//                         type={showOld ? "text" : "password"}
//                         value={oldPassword}
//                         onChange={e => setOldPassword(e.target.value)}
//                         placeholder="Enter current password"
//                       />
//                       <span className="pw-eye" onClick={() => setShowOld(!showOld)}>{showOld ? "🙈" : "👁"}</span>
//                     </div>
//                   </div>
 
//                   <div className="pw-field-wrap" style={{ marginTop: 14 }}>
//                     <label className="form-label">New Password</label>
//                     <div className="pw-input-wrap">
//                       <input
//                         className="form-input"
//                         type={showNew ? "text" : "password"}
//                         value={newPassword}
//                         onChange={e => setNewPassword(e.target.value)}
//                         placeholder="Enter new password"
//                       />
//                       <span className="pw-eye" onClick={() => setShowNew(!showNew)}>{showNew ? "🙈" : "👁"}</span>
//                     </div>
//                     {strength && (
//                       <div className="strength-bar-wrap">
//                         <div className="strength-bg">
//                           <div className="strength-fill" style={{ width: strength.width, background: strength.color }} />
//                         </div>
//                         <div className="strength-label" style={{ color: strength.color }}>{strength.label}</div>
//                       </div>
//                     )}
//                   </div>
 
//                   <div className="pw-field-wrap" style={{ marginTop: 14 }}>
//                     <label className="form-label">Confirm New Password</label>
//                     <div className="pw-input-wrap">
//                       <input
//                         className="form-input"
//                         type={showConfirm ? "text" : "password"}
//                         value={confirmPassword}
//                         onChange={e => setConfirmPassword(e.target.value)}
//                         placeholder="Confirm new password"
//                       />
//                       <span className="pw-eye" onClick={() => setShowConfirm(!showConfirm)}>{showConfirm ? "🙈" : "👁"}</span>
//                     </div>
//                   </div>
 
//                 </div>
 
//                 <button className="btn-primary" onClick={handleChangePassword} disabled={pwLoading}>
//                   {pwLoading ? "Updating..." : "🔐 Update Password"}
//                 </button>
//               </>
//             )}
 
//           </div>
//         </div>
//       </div>

//       {/* WALLET ADD MODAL */}
// {showWalletModal && (
//   <div
//     style={{
//       position: "fixed",
//       inset: 0,
//       background: "rgba(0,0,0,0.45)",
//       display: "flex",
//       justifyContent: "center",
//       alignItems: "center",
//       zIndex: 9999,
//       backdropFilter: "blur(4px)",
//     }}
//   >
//     <div
//       style={{
//         width: "100%",
//         maxWidth: 430,
//         background: "#fff",
//         borderRadius: 22,
//         padding: 28,
//         position: "relative",
//         animation: "popup 0.25s ease",
//       }}
//     >
 
//       {/* CLOSE */}
//       <button
//         onClick={() => setShowWalletModal(false)}
//         style={{
//           position: "absolute",
//           top: 16,
//           right: 16,
//           border: "none",
//           background: "#fff5f5",
//           width: 34,
//           height: 34,
//           borderRadius: "50%",
//           cursor: "pointer",
//           fontSize: 16,
//           fontWeight: 800,
//         }}
//       >
//         ✕
//       </button>
 
//       <div
//         style={{
//           fontSize: 24,
//           fontWeight: 900,
//           marginBottom: 6,
//           color: "#1a1a1a",
//         }}
//       >
//         Add Money
//       </div>
 
//       <div
//         style={{
//           fontSize: 13,
//           color: "#888",
//           marginBottom: 22,
//           fontWeight: 600,
//         }}
//       >
//         Securely add money to your wallet
//       </div>
 
//       {/* AMOUNT */}
//       <label className="form-label">
//         Amount
//       </label>
 
//       <input
//         type="number"
//         className="form-input"
//         placeholder="Enter amount"
//         value={addAmount}
//         onChange={(e) => setAddAmount(e.target.value)}
//       />
 
//       {/* PAYMENT TYPE */}
//       <label className="form-label">
//         Payment Method
//       </label>
 
//       <div
//         style={{
//           display: "flex",
//           gap: 12,
//           marginBottom: 18,
//         }}
//       >
 
//         <div
//           onClick={() => setPaymentType("UPI")}
//           style={{
//             flex: 1,
//             padding: 14,
//             border:
//               paymentType === "UPI"
//                 ? "2px solid #ff6f00"
//                 : "1.5px solid #e8e8e8",
//             borderRadius: 12,
//             cursor: "pointer",
//             fontWeight: 800,
//             textAlign: "center",
//             background:
//               paymentType === "UPI"
//                 ? "#fff8f2"
//                 : "#fff",
//           }}
//         >
//           📱 UPI
//         </div>
 
//         <div
//           onClick={() => setPaymentType("CARD")}
//           style={{
//             flex: 1,
//             padding: 14,
//             border:
//               paymentType === "CARD"
//                 ? "2px solid #ff6f00"
//                 : "1.5px solid #e8e8e8",
//             borderRadius: 12,
//             cursor: "pointer",
//             fontWeight: 800,
//             textAlign: "center",
//             background:
//               paymentType === "CARD"
//                 ? "#fff8f2"
//                 : "#fff",
//           }}
//         >
//           💳 Card
//         </div>
 
//       </div>
 
//       {/* UPI INPUT */}
//       {paymentType === "UPI" && (
//         <>
//           <label className="form-label">
//             UPI ID
//           </label>
 
//           <input
//             className="form-input"
//             placeholder="example@upi"
//             value={upiId}
//             onChange={(e) => setUpiId(e.target.value)}
//           />
//         </>
//       )}
 
//       {/* CARD INPUT */}
//       {paymentType === "CARD" && (
//         <>
//           <label className="form-label">
//             Card Number
//           </label>
 
//           <input
//             className="form-input"
//             placeholder="1234 5678 9012 3456"
//             value={cardNumber}
//             onChange={(e) => setCardNumber(e.target.value)}
//             maxLength={19}
//           />
//         </>
//       )}
 
//       {/* BUTTON */}
//       <button
//         className="btn-primary"
//         style={{
//           width: "100%",
//           justifyContent: "center",
//           marginTop: 10,
//           padding: "14px",
//           fontSize: 15,
//         }}
//         onClick={async () => {
 
//           if (!addAmount || Number(addAmount) <= 0) {
//             return toast.error("Enter valid amount");
//           }
 
//           if (
//             paymentType === "UPI" &&
//             (!upiId || !upiId.includes("@"))
//           ) {
//             return toast.error("Enter valid UPI ID");
//           }
 
//           if (
//             paymentType === "CARD" &&
//             cardNumber.replace(/\s/g, "").length < 16
//           ) {
//             return toast.error("Enter valid card number");
//           }
 
//           await handleAddMoney();
 
//           setShowWalletModal(false);
 
//           setUpiId("");
//           setCardNumber("");
 
//           setTab("wallet");
//         }}
//         disabled={walletLoading}
//       >
//         {walletLoading
//           ? "Adding Money..."
//           : `Add ₹${addAmount || 0}`}
//       </button>
 
//     </div>
//   </div>
// )}
 
 
//     </>
//   );
// };
 
// export default Profile;



import React, { useEffect, useState, useContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";

const Profile = () => {
  const [tab, setTab] = useState("profile");
  const [addresses, setAddresses] = useState([]);
  const [orders, setOrders] = useState([]);
  const [wallet, setWallet] = useState({ balance: 0, transactions: [] });
  const [addAmount, setAddAmount] = useState("");
  const [walletLoading, setWalletLoading] = useState(false);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [paymentType, setPaymentType] = useState("UPI");
  const [upiId, setUpiId] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [saving, setSaving] = useState(false);

  // Membership state
  const [plans, setPlans] = useState([]);
  const [plansLoading, setPlansLoading] = useState(false);
  const [currentPlan,setCurrentPlan]=useState(null);

  // Change password state
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [pwLoading, setPwLoading] = useState(false);

  const navigate = useNavigate();
  const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
  const [user, setUser] = useState(userInfo?.user);
  const token = userInfo?.token;

  const [form, setForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    city: user?.city || "",
    gender: user?.gender || "",
    dob: user?.dob || "",
  });

  if (!user || !token) {
    return (
      <div style={{ fontFamily: "'Nunito', sans-serif", textAlign: "center", padding: "80px 20px" }}>
        <div style={{ fontSize: 52, marginBottom: 16 }}>🔒</div>
        <p style={{ fontWeight: 800, fontSize: 18, color: "#333", marginBottom: 16 }}>Please login first</p>
        <button onClick={() => navigate("/users/login")} style={{ padding: "11px 28px", background: "#ff6f00", color: "#fff", border: "none", borderRadius: 10, fontWeight: 800, cursor: "pointer", fontFamily: "inherit" }}>
          Login
        </button>
      </div>
    );
  }

  const fetchAddresses = async () => {
    try {
      const { data } = await axios.get("http://localhost:5000/api/address", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setAddresses(data);
    } catch (err) { console.log(err); }
  };

  const fetchOrders = async () => {
    try {
      const { data } = await axios.get("http://localhost:5000/api/orders/my", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setOrders(data);
    } catch (err) { console.log(err); }
  };

  const fetchWallet = async () => {
    try {
      const { data } = await axios.get("http://localhost:5000/api/wallet", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setWallet(data);
    } catch (err) {
      console.log(err);
      toast.error("Failed to load wallet");
    }
  };

const fetchPlans = async () => {
  setPlansLoading(true);
  try {
    const [plansRes, membershipRes] = await Promise.all([
      axios.get("http://localhost:5000/api/users/membership/plans-public"),
      axios.get("http://localhost:5000/api/users/my-membership", {
        headers: { Authorization: `Bearer ${token}` },
      }),
    ]);
    setPlans(plansRes.data);
    setCurrentPlan(membershipRes.data);
  } catch (err) {
    console.log(err);
  } finally {
    setPlansLoading(false);
  }
};

  const handleAddMoney = async () => {
    if (!addAmount || addAmount <= 0) return toast.error("Enter valid amount");
    try {
      setWalletLoading(true);
      const { data } = await axios.post(
        "http://localhost:5000/api/wallet/add",
        { amount: Number(addAmount) },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success("Money added successfully");
      setWallet(data);
      await fetchWallet();
      setAddAmount("");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to add money");
    } finally {
      setWalletLoading(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/address/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchAddresses();
      toast.success("Address deleted");
    } catch (err) { console.log(err); }
  };

  useEffect(() => {
    if (tab === "address") fetchAddresses();
    if (tab === "orders") fetchOrders();
    if (tab === "wallet") fetchWallet();
    if (tab === "membership") fetchPlans();
  }, [tab]);

  useEffect(() => {
    if (user) {
      setForm({
        name: user.name || "",
        phone: user.phone || "",
        city: user.city || "",
        gender: user.gender || "",
        dob: user.dob ? new Date(user.dob).toISOString().split("T")[0] : "",
      });
    }
  }, [user]);

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const { data } = await axios.put(
        "http://localhost:5000/api/users/profile",
        form,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const updated = { ...userInfo, user: { ...user, ...form } };
      sessionStorage.setItem("userInfo", JSON.stringify(updated));
      setUser({ ...user, ...form });
      setEditMode(false);
      toast.success("Profile updated successfully!");
    } catch (err) {
      toast.error(err.response?.data?.message || "Update failed");
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async () => {
    if (!oldPassword || !newPassword || !confirmPassword) return toast.error("Please fill all fields");
    if (newPassword !== confirmPassword) return toast.error("New passwords do not match");
    if (newPassword.length < 6) return toast.error("Password must be at least 6 characters");
    setPwLoading(true);
    try {
      await axios.put(
        "http://localhost:5000/api/users/change-password",
        { oldPassword, newPassword },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success("Password changed successfully! 🎉");
      setOldPassword(""); setNewPassword(""); setConfirmPassword("");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to change password");
    } finally {
      setPwLoading(false);
    }
  };

  const statusColors = {
    delivered:        { bg: "#edfaf4", text: "#2e9e5b", border: "#b6e9cf" },
    shipped:          { bg: "#eff6ff", text: "#3b82f6", border: "#bfdbfe" },
    confirmed:        { bg: "#fff8f2", text: "#ff6f00", border: "#ffe0c2" },
    cancelled:        { bg: "#fff5f5", text: "#e53935", border: "#ffc9c9" },
    pending:          { bg: "#fefce8", text: "#ca8a04", border: "#fde68a" },
    out_for_delivery: { bg: "#fdf4ff", text: "#9333ea", border: "#e9d5ff" },
  };

  const tabs = [
    { id: "profile",    label: "My Profile",    icon: "👤" },
    { id: "orders",     label: "My Orders",     icon: "📦" },
    { id: "address",    label: "Addresses",     icon: "📍" },
    { id: "wallet",     label: "My Wallet",     icon: "💰" },
    { id: "membership", label: "Membership",    icon: "💳" },
    { id: "password",   label: "Change Password", icon: "🔒" },
  ];

  const initials = user.name?.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);

  const pwStrength = (pw) => {
    if (!pw) return null;
    if (pw.length < 6) return { label: "Weak",   color: "#e53935", width: "30%" };
    if (pw.length < 9) return { label: "Fair",   color: "#ff9500", width: "60%" };
    return               { label: "Strong", color: "#2e9e5b", width: "100%" };
  };
  const strength = pwStrength(newPassword);

  const planIcons = { Free: "🆓", Silver: "🥈", Gold: "🥇", Platinum: "💎", platinum: "💎", gold: "🥇", silver: "🥈", free: "🆓" };

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }

        .profile-root {
          font-family: 'Nunito', sans-serif;
          background: #fdf5ee;
          min-height: 100vh;
          padding: 28px 20px 60px;
          max-width: 1100px;
          margin: 0 auto;
        }

        .profile-banner {
          background: linear-gradient(135deg, #ff6f00, #ff9500, #ffb347);
          border-radius: 20px;
          padding: 28px 32px;
          display: flex;
          align-items: center;
          gap: 22px;
          margin-bottom: 24px;
          position: relative;
          overflow: hidden;
          box-shadow: 0 8px 28px rgba(255,111,0,0.25);
        }
        .profile-banner::before {
          content: '';
          position: absolute;
          top: -40px; right: -40px;
          width: 180px; height: 180px;
          border-radius: 50%;
          background: rgba(255,255,255,0.1);
        }
        .profile-banner::after {
          content: '';
          position: absolute;
          bottom: -50px; left: 30%;
          width: 220px; height: 220px;
          border-radius: 50%;
          background: rgba(255,255,255,0.06);
        }
        .avatar-circle {
          width: 72px; height: 72px;
          border-radius: 50%;
          background: rgba(255,255,255,0.25);
          border: 3px solid rgba(255,255,255,0.5);
          display: flex; align-items: center; justify-content: center;
          font-size: 26px; font-weight: 900; color: #fff;
          flex-shrink: 0;
          backdrop-filter: blur(4px);
        }
        .banner-name { font-size: 22px; font-weight: 900; color: #fff; letter-spacing: -0.3px; margin-bottom: 4px; }
        .banner-email { font-size: 13.5px; color: rgba(255,255,255,0.8); font-weight: 600; }
        .banner-right { margin-left: auto; display: flex; flex-direction: column; align-items: flex-end; gap: 6px; z-index: 1; }
        .banner-badge { background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: #fff; font-size: 12px; font-weight: 800; padding: 4px 12px; border-radius: 20px; backdrop-filter: blur(4px); }

        .profile-layout { display: flex; gap: 20px; align-items: flex-start; }

        .profile-sidebar {
          width: 230px; flex-shrink: 0;
          background: #fff; border-radius: 18px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 4px 16px rgba(255,111,0,0.07);
          overflow: hidden; position: sticky; top: 20px;
        }
        .sidebar-top { background: linear-gradient(135deg, #fff8f2, #fff3e6); padding: 18px 16px; border-bottom: 1.5px solid #ffe0c2; }
        .sidebar-greeting { font-size: 12px; font-weight: 700; color: #aaa; text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 2px; }
        .sidebar-name { font-size: 15px; font-weight: 800; color: #1a1a1a; }
        .sidebar-tab {
          display: flex; align-items: center; gap: 10px;
          padding: 13px 18px; cursor: pointer;
          font-size: 13.5px; font-weight: 700; color: #666;
          border-bottom: 1px solid #f5ece4;
          transition: background 0.15s, color 0.15s;
          position: relative;
        }
        .sidebar-tab:last-child { border-bottom: none; }
        .sidebar-tab:hover { background: #fff8f2; color: #ff6f00; }
        .sidebar-tab.active { background: #fff8f2; color: #ff6f00; font-weight: 800; }
        .sidebar-tab.active::before {
          content: ''; position: absolute; left: 0; top: 0;
          width: 3px; height: 100%;
          background: linear-gradient(180deg, #ff6f00, #ffaa5a);
          border-radius: 0 2px 2px 0;
        }
        .sidebar-tab .tab-icon { font-size: 16px; }
        .logout-tab {
          display: flex; align-items: center; gap: 10px;
          padding: 13px 18px; cursor: pointer;
          font-size: 13.5px; font-weight: 700; color: #e53935;
          border-top: 1.5px solid #f5ece4;
          transition: background 0.15s; margin-top: 4px;
        }
        .logout-tab:hover { background: #fff5f5; }

        .profile-content {
          flex: 1; background: #fff; border-radius: 18px;
          border: 1.5px solid #ffe0c2;
          box-shadow: 0 4px 18px rgba(255,111,0,0.07);
          padding: 28px; position: relative; overflow: hidden;
        }
        .profile-content::before {
          content: ''; position: absolute; top: 0; left: 0; right: 0;
          height: 4px; background: linear-gradient(90deg, #ff6f00, #ffaa5a);
        }

        .content-title {
          font-size: 22px; font-weight: 900; color: #1a1a1a;
          letter-spacing: -0.3px; margin-bottom: 22px;
          display: flex; align-items: center; justify-content: space-between;
          flex-wrap: wrap; gap: 10px;
        }

        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 24px; }
        .info-cell { background: #fff8f2; border: 1.5px solid #ffe0c2; border-radius: 12px; padding: 14px 16px; }
        .info-label { font-size: 11px; font-weight: 700; color: #aaa; text-transform: uppercase; letter-spacing: 0.4px; margin-bottom: 5px; }
        .info-value { font-size: 15px; font-weight: 800; color: #1a1a1a; }
        .info-value.muted { color: #bbb; font-weight: 600; font-style: italic; }

        .form-label { font-size: 12px; font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.4px; display: block; margin-bottom: 6px; }
        .form-input { width: 100%; padding: 11px 14px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 14px; font-family: 'Nunito', sans-serif; color: #1a1a1a; background: #fafafa; margin-bottom: 14px; outline: none; transition: border-color 0.2s, box-shadow 0.2s; }
        .form-input:focus { border-color: #ff6f00; box-shadow: 0 0 0 3px rgba(255,111,0,0.1); background: #fff; }
        .form-select { width: 100%; padding: 11px 14px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 14px; font-family: 'Nunito', sans-serif; color: #1a1a1a; background: #fafafa; margin-bottom: 14px; outline: none; cursor: pointer; }
        .form-select:focus { border-color: #ff6f00; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }

        .btn-primary { padding: 12px 22px; background: linear-gradient(135deg, #ff6f00, #ff9500); color: #fff; border: none; border-radius: 11px; font-weight: 800; font-size: 14px; cursor: pointer; font-family: 'Nunito', sans-serif; box-shadow: 0 4px 14px rgba(255,111,0,0.3); transition: opacity 0.2s, transform 0.1s; display: inline-flex; align-items: center; gap: 6px; }
        .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }

        .btn-outline { padding: 12px 22px; background: transparent; color: #ff6f00; border: 2px solid #ff6f00; border-radius: 11px; font-weight: 800; font-size: 14px; cursor: pointer; font-family: 'Nunito', sans-serif; transition: background 0.2s, color 0.2s; }
        .btn-outline:hover { background: #ff6f00; color: #fff; }
        .btn-row { display: flex; gap: 10px; margin-top: 6px; }

        .order-card { border: 1.5px solid #f0e8e0; border-radius: 16px; padding: 18px 20px; margin-bottom: 14px; cursor: pointer; transition: box-shadow 0.2s, border-color 0.2s, transform 0.15s; background: #fff; position: relative; overflow: hidden; }
        .order-card::before { content: ''; position: absolute; top: 0; left: 0; width: 3px; height: 100%; background: linear-gradient(180deg, #ff6f00, #ffaa5a); border-radius: 3px 0 0 3px; }
        .order-card:hover { box-shadow: 0 8px 24px rgba(255,111,0,0.12); border-color: #ffcc99; transform: translateY(-2px); }
        .order-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 14px; }
        .order-id { font-size: 12px; color: #aaa; font-weight: 700; margin-bottom: 3px; }
        .order-price { font-size: 18px; font-weight: 900; color: #1a1a1a; }
        .order-status-pill { padding: 5px 12px; border-radius: 20px; font-size: 11.5px; font-weight: 800; border: 1.5px solid; }
        .order-imgs { display: flex; gap: 10px; flex-wrap: wrap; }
        .order-img { width: 58px; height: 58px; border-radius: 10px; object-fit: cover; border: 1.5px solid #ffe0c2; background: #fff8f2; transition: transform 0.15s; }
        .order-img:hover { transform: scale(1.06); }
        .order-more { width: 58px; height: 58px; border-radius: 10px; background: #fff8f2; border: 1.5px solid #ffe0c2; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800; color: #ff6f00; }
        .order-bottom { display: flex; justify-content: space-between; align-items: center; margin-top: 14px; font-size: 13px; color: #aaa; font-weight: 600; }
        .order-view-link { color: #ff6f00; font-weight: 800; font-size: 13px; display: flex; align-items: center; gap: 4px; }

        .addr-card { border: 1.5px solid #f0e8e0; border-radius: 16px; padding: 18px 20px; margin-bottom: 14px; display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; transition: box-shadow 0.2s, border-color 0.2s; position: relative; overflow: hidden; }
        .addr-card::before { content: ''; position: absolute; top: 0; left: 0; width: 3px; height: 100%; background: linear-gradient(180deg, #ff6f00, #ffaa5a); }
        .addr-card:hover { box-shadow: 0 6px 20px rgba(255,111,0,0.09); border-color: #ffcc99; }
        .addr-name { font-size: 15px; font-weight: 800; color: #1a1a1a; margin-bottom: 4px; }
        .addr-line { font-size: 13.5px; color: #666; font-weight: 600; line-height: 1.6; }
        .addr-type-pill { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 800; margin-top: 8px; }
        .addr-actions { display: flex; flex-direction: column; gap: 8px; align-items: flex-end; }
        .btn-delete { padding: 7px 14px; background: #fff5f5; color: #e53935; border: 1.5px solid #ffc9c9; border-radius: 8px; font-size: 12.5px; font-weight: 800; cursor: pointer; font-family: 'Nunito', sans-serif; transition: background 0.15s, color 0.15s; }
        .btn-delete:hover { background: #e53935; color: #fff; border-color: #e53935; }

        .empty-state { text-align: center; padding: 50px 20px; }
        .empty-state .e-icon { font-size: 52px; margin-bottom: 14px; }
        .empty-state p { font-size: 16px; font-weight: 800; color: #333; margin-bottom: 6px; }
        .empty-state span { font-size: 13.5px; color: #aaa; font-weight: 600; }

        .pw-card { background: #fff8f2; border: 1.5px solid #ffe0c2; border-radius: 14px; padding: 20px; margin-bottom: 20px; }
        .pw-input-wrap { position: relative; }
        .pw-input-wrap .form-input { padding-right: 44px; margin-bottom: 0; }
        .pw-eye { position: absolute; right: 14px; top: 50%; transform: translateY(-50%); cursor: pointer; font-size: 16px; color: #aaa; user-select: none; transition: color 0.15s; }
        .pw-eye:hover { color: #ff6f00; }
        .pw-field-wrap { margin-bottom: 14px; }
        .strength-bar-wrap { margin-top: 8px; margin-bottom: 4px; }
        .strength-bg { height: 5px; background: #e8e8e8; border-radius: 5px; overflow: hidden; }
        .strength-fill { height: 5px; border-radius: 5px; transition: width 0.3s, background 0.3s; }
        .strength-label { font-size: 11.5px; font-weight: 800; margin-top: 4px; }

        .wallet-card { background: linear-gradient(135deg, #ff6f00, #ff9500); border-radius: 20px; padding: 28px; color: white; margin-bottom: 24px; box-shadow: 0 10px 25px rgba(255,111,0,0.25); }
        .wallet-label { font-size: 13px; font-weight: 700; opacity: 0.9; margin-bottom: 8px; }
        .wallet-balance { font-size: 38px; font-weight: 900; }
        .wallet-sub { margin-top: 6px; font-size: 13px; opacity: 0.85; }
        .wallet-add-box { background: #fff8f2; border: 1.5px solid #ffe0c2; border-radius: 16px; padding: 18px; margin-bottom: 24px; }
        .transaction-card { border: 1.5px solid #f1e8df; border-radius: 14px; padding: 16px 18px; margin-bottom: 14px; display: flex; justify-content: space-between; align-items: center; background: white; }
        .transaction-title { font-size: 14px; font-weight: 800; color: #1a1a1a; margin-bottom: 4px; }
        .transaction-date { font-size: 12px; color: #999; font-weight: 700; }
        .transaction-amount { font-size: 16px; font-weight: 900; }
        .credit { color: #16a34a; }
        .debit { color: #e53935; }

        /* Membership plan cards */
        .plan-card {
          background: #fff;
          border: 2px solid #ffe0c2;
          border-radius: 20px;
          padding: 22px;
          display: flex;
          flex-direction: column;
          gap: 12px;
          transition: transform 0.2s, box-shadow 0.2s;
          position: relative;
          overflow: hidden;
        }
        .plan-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 4px;
          background: linear-gradient(90deg, #ff6f00, #ffaa44);
        }
        .plan-card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgba(255,111,0,0.15); }
        .plan-buy-btn {
          margin-top: auto;
          padding: 12px;
          background: linear-gradient(135deg, #ff6f00, #ff9500);
          color: #fff; border: none; border-radius: 12px;
          font-weight: 800; font-size: 14px; cursor: pointer;
          font-family: 'Nunito', sans-serif;
          box-shadow: 0 4px 14px rgba(255,111,0,0.3);
          transition: opacity 0.2s, transform 0.1s;
        }
        .plan-buy-btn:hover { opacity: 0.9; transform: translateY(-1px); }

        @keyframes popup { from { opacity: 0; transform: scale(0.92); } to { opacity: 1; transform: scale(1); } }

        @media (max-width: 768px) {
          .profile-layout { flex-direction: column; }
          .profile-sidebar { width: 100%; position: static; }
          .info-grid { grid-template-columns: 1fr; }
        }
      `}</style>

      <div className="profile-root">

        {/* BACK BUTTON */}
        <button
          onClick={() => navigate("/home")}
          style={{ display: "inline-flex", alignItems: "center", gap: "7px", marginBottom: "16px", padding: "9px 18px", background: "#fff", border: "1.5px solid #ffe0c2", borderRadius: "11px", fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: "14px", color: "#ff6f00", cursor: "pointer", boxShadow: "0 2px 8px rgba(255,111,0,0.10)", transition: "background 0.15s, box-shadow 0.15s, transform 0.1s" }}
          onMouseEnter={e => { e.currentTarget.style.background = "#fff8f2"; e.currentTarget.style.transform = "translateY(-1px)"; }}
          onMouseLeave={e => { e.currentTarget.style.background = "#fff"; e.currentTarget.style.transform = "translateY(0)"; }}
        >
          ← Home
        </button>

        {/* BANNER */}
        <div className="profile-banner">
          <div className="avatar-circle">{initials}</div>
          <div>
            <div className="banner-name">{user.name}</div>
            <div className="banner-email">{user.email}</div>
          </div>
          <div className="banner-right">
            <span className="banner-badge">⭐ Member</span>
          </div>
        </div>

        {/* LAYOUT */}
        <div className="profile-layout">

          {/* SIDEBAR */}
          <div className="profile-sidebar">
            <div className="sidebar-top">
              <div className="sidebar-greeting">Hello,</div>
              <div className="sidebar-name">{user.name?.split(" ")[0]}</div>
            </div>
            {tabs.map(t => (
              <div key={t.id} className={`sidebar-tab${tab === t.id ? " active" : ""}`} onClick={() => setTab(t.id)}>
                <span className="tab-icon">{t.icon}</span>
                {t.label}
              </div>
            ))}
            <div className="logout-tab" onClick={() => { sessionStorage.removeItem("userInfo"); navigate("/users/login"); }}>
              <span>🚪</span> Logout
            </div>
          </div>

          {/* CONTENT */}
          <div className="profile-content">

            {/* ── MY PROFILE TAB ── */}
            {tab === "profile" && (
              <>
                <div className="content-title">
                  My Profile
                  {!editMode && <button className="btn-outline" onClick={() => setEditMode(true)}>✏️ Edit Profile</button>}
                </div>
                {!editMode ? (
                  <div className="info-grid">
                    {[
                      { label: "Full Name", value: user.name },
                      { label: "Email",     value: user.email },
                      { label: "Phone",     value: user.phone },
                      { label: "City",      value: user.city },
                      { label: "Gender",    value: user.gender },
                      { label: "Date of Birth", value: user.dob ? new Date(user.dob).toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" }) : null },
                    ].map((item, i) => (
                      <div className="info-cell" key={i}>
                        <div className="info-label">{item.label}</div>
                        <div className={`info-value${!item.value ? " muted" : ""}`}>{item.value || "Not provided"}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <>
                    <label className="form-label">Full Name</label>
                    <input className="form-input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
                    <label className="form-label">Phone</label>
                    <input className="form-input" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="Phone number" />
                    <div className="form-grid">
                      <div>
                        <label className="form-label">City</label>
                        <input className="form-input" value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} placeholder="Your city" />
                      </div>
                      <div>
                        <label className="form-label">Gender</label>
                        <select className="form-select" value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })}>
                          <option value="">Select gender</option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                    </div>
                    <label className="form-label">Date of Birth</label>
                    <input className="form-input" type="date" value={form.dob} onChange={e => setForm({ ...form, dob: e.target.value })} />
                    <div className="btn-row">
                      <button className="btn-primary" onClick={handleSaveProfile} disabled={saving}>{saving ? "Saving..." : "💾 Save Changes"}</button>
                      <button className="btn-outline" onClick={() => setEditMode(false)}>Cancel</button>
                    </div>
                  </>
                )}
              </>
            )}

            {/* ── ORDERS TAB ── */}
            {tab === "orders" && (
              <>
                <div className="content-title">My Orders</div>
                {orders.length === 0 ? (
                  <div className="empty-state">
                    <div className="e-icon">📦</div>
                    <p>No orders yet</p>
                    <span>Your placed orders will appear here</span>
                  </div>
                ) : (
                  orders.map(order => {
                    const sc = statusColors[order.status] || statusColors.pending;
                    return (
                      <div className="order-card" key={order._id} onClick={() => navigate(`/orders/${order._id}`)}>
                        <div className="order-top">
                          <div>
                            <div className="order-id">#{order._id.slice(-8).toUpperCase()}</div>
                            <div className="order-price">₹{order.totalPrice?.toLocaleString("en-IN")}</div>
                          </div>
                          <span className="order-status-pill" style={{ background: sc.bg, color: sc.text, borderColor: sc.border }}>
                            {order.status?.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                          </span>
                        </div>
                        <div className="order-imgs">
                          {order.orderItems?.slice(0, 3).map((item, i) => {
                            const imageSrc = item.image?.startsWith("http") ? item.image : `http://localhost:5000${item.image}`;
                            return <img key={i} src={imageSrc} alt="product" className="order-img" onError={e => { e.target.onerror = null; e.target.src = "/placeholder.png"; }} />;
                          })}
                          {order.orderItems?.length > 3 && <div className="order-more">+{order.orderItems.length - 3}</div>}
                        </div>
                        <div className="order-bottom">
                          <span>{new Date(order.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</span>
                          <span className="order-view-link">View Details →</span>
                        </div>
                      </div>
                    );
                  })
                )}
              </>
            )}

            {/* ── ADDRESSES TAB ── */}
            {tab === "address" && (
              <>
                <div className="content-title">
                  My Addresses
                  <button className="btn-primary" onClick={() => navigate("/address/add")}>+ Add Address</button>
                </div>
                {addresses.length === 0 ? (
                  <div className="empty-state">
                    <div className="e-icon">📍</div>
                    <p>No addresses saved</p>
                    <span>Add a delivery address to get started</span>
                  </div>
                ) : (
                  addresses.map(addr => (
                    <div className="addr-card" key={addr._id}>
                      <div>
                        <div className="addr-name">{addr.fullName}</div>
                        <div className="addr-line">
                          {addr.addressLine1}{addr.addressLine2 ? `, ${addr.addressLine2}` : ""}<br />
                          {addr.city}, {addr.state} – {addr.pincode}<br />
                          📞 {addr.phone}
                        </div>
                        <span className="addr-type-pill" style={{ background: addr.addressType === "Home" ? "#eff6ff" : "#f0fdf4", color: addr.addressType === "Home" ? "#3b82f6" : "#16a34a", border: `1.5px solid ${addr.addressType === "Home" ? "#bfdbfe" : "#bbf7d0"}` }}>
                          {addr.addressType === "Home" ? "🏠" : "💼"} {addr.addressType}
                        </span>
                      </div>
                      <div className="addr-actions">
                        <button className="btn-delete" onClick={() => handleDelete(addr._id)}>🗑 Delete</button>
                      </div>
                    </div>
                  ))
                )}
              </>
            )}

            {/* ── WALLET TAB ── */}
            {tab === "wallet" && (
              <>
                <div className="content-title">My Wallet</div>
                <div className="wallet-card">
                  <div className="wallet-label">Available Balance</div>
                  <div className="wallet-balance">₹{wallet?.balance?.toLocaleString("en-IN") || "0"}</div>
                  <div className="wallet-sub">Use wallet balance for faster checkout ⚡</div>
                </div>
                <div className="wallet-add-box">
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                    <div style={{ fontWeight: 800, fontSize: 16, color: "#1a1a1a" }}>Add Money to Wallet</div>
                    <button className="btn-primary" onClick={() => setShowWalletModal(true)}>+ Add Money</button>
                  </div>
                  <div style={{ fontSize: 13, color: "#888", fontWeight: 600, lineHeight: 1.6 }}>Add money instantly using UPI or Card payment</div>
                </div>
                <div className="content-title" style={{ fontSize: 20 }}>Transaction History</div>
                {wallet?.transactions?.length === 0 ? (
                  <div className="empty-state">
                    <div className="e-icon">💳</div>
                    <p>No transactions yet</p>
                    <span>Your wallet history will appear here</span>
                  </div>
                ) : (
                  wallet?.transactions?.slice()?.reverse()?.map((txn, index) => (
                    <div className="transaction-card" key={index}>
                      <div>
                        <div className="transaction-title">{txn.description || txn.type}</div>
                        <div className="transaction-date">{new Date(txn.date).toLocaleString("en-IN")}</div>
                      </div>
                      <div className={`transaction-amount ${txn.type === "DEBIT" || txn.type === "PURCHASE" ? "debit" : "credit"}`}>
                        {txn.type === "DEBIT" || txn.type === "PURCHASE" ? "-" : "+"}₹{txn.amount}
                      </div>
                    </div>
                  ))
                )}
              </>
            )}

            {/* ── MEMBERSHIP TAB ── */}
            {tab === "membership" && (
              <>
                <div className="content-title">💳 Membership Plans</div>
                <p style={{ fontSize: 13, color: "#aaa", fontWeight: 600, marginBottom: 24, marginTop: -14 }}>
                  Choose a plan and enjoy exclusive discounts & benefits
                </p>

                {plansLoading ? (
                  <div style={{ textAlign: "center", padding: 60, color: "#aaa", fontSize: 15 }}>
                    <div style={{ fontSize: 40, marginBottom: 12 }}>⏳</div>
                    Loading plans...
                  </div>
                ) : plans.length === 0 ? (
                  <div className="empty-state">
                    <div className="e-icon">💳</div>
                    <p>No plans available</p>
                    <span>Check back later for membership offers</span>
                  </div>
                ) : (
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 18 }}>
                    {plans.map((plan) => (
                      <div key={plan._id} className="plan-card">

                        {/* Plan Header */}
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <span style={{ fontSize: 32 }}>{planIcons[plan.name] || "💳"}</span>
                          <div>
                            <div style={{ fontSize: 18, fontWeight: 900, color: "#1a1a1a" }}>{plan.name}</div>
                            <div style={{ fontSize: 12, color: "#aaa", fontWeight: 600 }}>{plan.duration} days</div>
                          </div>
                        </div>

                        {/* Price */}
                        <div>
                          <span style={{ fontSize: 28, fontWeight: 900, color: "#ff6f00" }}>₹{plan.price}</span>
                          <span style={{ fontSize: 12, color: "#aaa", fontWeight: 600 }}> /plan</span>
                        </div>

                        {/* Discount Badge */}
                        <div style={{ display: "inline-flex", alignItems: "center", gap: 5, background: "#fff3e8", border: "1.5px solid #ffe0c2", borderRadius: 8, padding: "5px 12px", width: "fit-content" }}>
                          <span>🏷️</span>
                          <span style={{ fontSize: 13, fontWeight: 800, color: "#ff6f00" }}>{plan.discount}% discount</span>
                        </div>

                        {/* Benefits */}
                        {plan.benefits?.length > 0 && (
                          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
                            {plan.benefits.map((b, i) => (
                              <div key={i} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                <div style={{ width: 17, height: 17, borderRadius: "50%", background: "#ff6f00", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: "#fff", fontWeight: 900, flexShrink: 0 }}>✓</div>
                                <span style={{ fontSize: 12.5, color: "#555", fontWeight: 600 }}>{b}</span>
                              </div>
                            ))}
                          </div>
                        )}

                      {/* Buy Button */}
<button
  className="plan-buy-btn"
  onClick={async () => {
    try {
      await axios.post(
        "http://localhost:5000/api/users/membership/subscribe",
        { planId: plan._id },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success(`${plan.name} plan activated! 🎉`);
      fetchPlans();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to subscribe");
    }
  }}
>
  Get {plan.name} Plan →
</button>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {/* ── CHANGE PASSWORD TAB ── */}
            {tab === "password" && (
              <>
                <div className="content-title">Change Password</div>
                <div className="pw-card">
                  <div className="pw-field-wrap">
                    <label className="form-label">Current Password</label>
                    <div className="pw-input-wrap">
                      <input className="form-input" type={showOld ? "text" : "password"} value={oldPassword} onChange={e => setOldPassword(e.target.value)} placeholder="Enter current password" />
                      <span className="pw-eye" onClick={() => setShowOld(!showOld)}>{showOld ? "🙈" : "👁"}</span>
                    </div>
                  </div>
                  <div className="pw-field-wrap" style={{ marginTop: 14 }}>
                    <label className="form-label">New Password</label>
                    <div className="pw-input-wrap">
                      <input className="form-input" type={showNew ? "text" : "password"} value={newPassword} onChange={e => setNewPassword(e.target.value)} placeholder="Enter new password" />
                      <span className="pw-eye" onClick={() => setShowNew(!showNew)}>{showNew ? "🙈" : "👁"}</span>
                    </div>
                    {strength && (
                      <div className="strength-bar-wrap">
                        <div className="strength-bg"><div className="strength-fill" style={{ width: strength.width, background: strength.color }} /></div>
                        <div className="strength-label" style={{ color: strength.color }}>{strength.label}</div>
                      </div>
                    )}
                  </div>
                  <div className="pw-field-wrap" style={{ marginTop: 14 }}>
                    <label className="form-label">Confirm New Password</label>
                    <div className="pw-input-wrap">
                      <input className="form-input" type={showConfirm ? "text" : "password"} value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} placeholder="Confirm new password" />
                      <span className="pw-eye" onClick={() => setShowConfirm(!showConfirm)}>{showConfirm ? "🙈" : "👁"}</span>
                    </div>
                  </div>
                </div>
                <button className="btn-primary" onClick={handleChangePassword} disabled={pwLoading}>
                  {pwLoading ? "Updating..." : "🔐 Update Password"}
                </button>
              </>
            )}

          </div>
        </div>
      </div>

      {/* WALLET ADD MODAL */}
      {showWalletModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", justifyContent: "center", alignItems: "center", zIndex: 9999, backdropFilter: "blur(4px)" }}>
          <div style={{ width: "100%", maxWidth: 430, background: "#fff", borderRadius: 22, padding: 28, position: "relative", animation: "popup 0.25s ease" }}>
            <button onClick={() => setShowWalletModal(false)} style={{ position: "absolute", top: 16, right: 16, border: "none", background: "#fff5f5", width: 34, height: 34, borderRadius: "50%", cursor: "pointer", fontSize: 16, fontWeight: 800 }}>✕</button>
            <div style={{ fontSize: 24, fontWeight: 900, marginBottom: 6, color: "#1a1a1a" }}>Add Money</div>
            <div style={{ fontSize: 13, color: "#888", marginBottom: 22, fontWeight: 600 }}>Securely add money to your wallet</div>
            <label className="form-label">Amount</label>
            <input type="number" className="form-input" placeholder="Enter amount" value={addAmount} onChange={e => setAddAmount(e.target.value)} />
            <label className="form-label">Payment Method</label>
            <div style={{ display: "flex", gap: 12, marginBottom: 18 }}>
              {["UPI", "CARD"].map(pt => (
                <div key={pt} onClick={() => setPaymentType(pt)} style={{ flex: 1, padding: 14, border: paymentType === pt ? "2px solid #ff6f00" : "1.5px solid #e8e8e8", borderRadius: 12, cursor: "pointer", fontWeight: 800, textAlign: "center", background: paymentType === pt ? "#fff8f2" : "#fff" }}>
                  {pt === "UPI" ? "📱 UPI" : "💳 Card"}
                </div>
              ))}
            </div>
            {paymentType === "UPI" && (
              <>
                <label className="form-label">UPI ID</label>
                <input className="form-input" placeholder="example@upi" value={upiId} onChange={e => setUpiId(e.target.value)} />
              </>
            )}
            {paymentType === "CARD" && (
              <>
                <label className="form-label">Card Number</label>
                <input className="form-input" placeholder="1234 5678 9012 3456" value={cardNumber} onChange={e => setCardNumber(e.target.value)} maxLength={19} />
              </>
            )}
            <button
              className="btn-primary"
              style={{ width: "100%", justifyContent: "center", marginTop: 10, padding: "14px", fontSize: 15 }}
              onClick={async () => {
                if (!addAmount || Number(addAmount) <= 0) return toast.error("Enter valid amount");
                if (paymentType === "UPI" && (!upiId || !upiId.includes("@"))) return toast.error("Enter valid UPI ID");
                if (paymentType === "CARD" && cardNumber.replace(/\s/g, "").length < 16) return toast.error("Enter valid card number");
                await handleAddMoney();
                setShowWalletModal(false);
                setUpiId(""); setCardNumber("");
                setTab("wallet");
              }}
              disabled={walletLoading}
            >
              {walletLoading ? "Adding Money..." : `Add ₹${addAmount || 0}`}
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default Profile;



