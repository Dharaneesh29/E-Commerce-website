// import { useParams, useNavigate } from "react-router-dom";
// import { useEffect, useState } from "react";
// import axios from "axios";
// import { Heart } from "lucide-react";
 
// const BrandPage = () => {
//   const { brand } = useParams();
//   const navigate = useNavigate();
 
//   const [products, setProducts] = useState([]);
//   const [wishlist, setWishlist] = useState([]);
 
//   useEffect(() => {
//     const fetchProducts = async () => {
//       const { data } = await axios.get(
//         `http://localhost:5000/api/products/brand/${brand}`
//       );
//       setProducts(data);
//     };
 
//     fetchProducts();
//   }, [brand]);
 
//   // 🔥 Top deals (based on discount)
//   const topDeals = [...products]
//     .sort((a, b) => b.discount - a.discount)
//     .slice(0, 5);
 
//   const otherProducts = products.filter(
//     (p) => !topDeals.includes(p)
//   );
 
//   // ❤️ Wishlist toggle
//   const toggleWishlist = (id) => {
//     setWishlist((prev) =>
//       prev.includes(id)
//         ? prev.filter((item) => item !== id)
//         : [...prev, id]
//     );
//   };
 
//   const ProductCard = ({ item }) => (
//     <div
//       className="bg-white rounded-xl shadow hover:shadow-lg transition p-3 relative cursor-pointer"
//       onClick={() => navigate(`/product/${item._id}`)}
//     >
//       {/* ❤️ Wishlist */}
//       <button
//         onClick={(e) => {
//           e.stopPropagation();
//           toggleWishlist(item._id);
//         }}
//         className="absolute top-2 right-2"
//       >
//         <Heart
//           size={20}
//           className={
//             wishlist.includes(item._id)
//               ? "text-red-500 fill-red-500"
//               : "text-gray-400"
//           }
//         />
//       </button>
 
//       <img
//         src={`http://localhost:5000${item.images[0]}`}
//         alt={item.name}
//         className="w-full h-40 object-cover rounded"
//       />
 
//       <h2 className="font-semibold mt-2 text-sm">{item.name}</h2>
 
//       <div className="flex items-center gap-2">
//         <p className="text-orange-600 font-bold">₹{item.price}</p>
//         <p className="text-xs text-gray-400 line-through">
//           ₹{item.originalPrice}
//         </p>
//       </div>
 
//       <p className="text-green-600 text-xs font-semibold">
//         {item.discount}% OFF
//       </p>
 
//       <p className="text-yellow-500 text-sm">⭐ {item.rating}</p>
//     </div>
//   );
 
//   return (
//     <div className="p-5 bg-orange-50 min-h-screen">
//       {/* 🔥 Title */}
//       <h1 className="text-3xl font-bold mb-6 capitalize text-orange-600">
//         {brand} Store
//       </h1>
 
//       {/* 🔥 TOP DEALS */}
//       <h2 className="text-xl font-semibold mb-3">🔥 Top Deals</h2>
 
//       <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
//         {topDeals.map((item) => (
//           <ProductCard key={item._id} item={item} />
//         ))}
//       </div>
 
//       {/* 🔥 ALL PRODUCTS */}
//       <h2 className="text-xl font-semibold mb-3">All Products</h2>
 
//       {products.length === 0 ? (
//         <p>No Products Found</p>
//       ) : (
//         <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
//           {otherProducts.map((item) => (
//             <ProductCard key={item._id} item={item} />
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };
 
// export default BrandPage;

import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useContext } from "react";
import axios from "axios";
import { Heart, Flame, ShoppingBag, Star, Tag } from "lucide-react";
import { useState } from "react";
import { WishlistContext } from "../context/WishlistContext"; // 🔥 adjust path if needed

const BrandPage = () => {
  const { brand } = useParams();
  const navigate = useNavigate();
  const { wishlist, toggleWishlist } = useContext(WishlistContext); // ✅ use context

  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data } = await axios.get(
        `http://localhost:5000/api/products/brand/${brand}`
      );
      setProducts(data);
    };
    fetchProducts();
  }, [brand]);

  const topDeals = [...products]
    .sort((a, b) => b.discount - a.discount)
    .slice(0, 5);

  const otherProducts = products.filter((p) => !topDeals.includes(p));

  // ✅ Check wishlist from context
  const isWishlisted = (id) => wishlist.some((p) => p._id === id);

  const ProductCard = ({ item, featured = false }) => (
    <div
      onClick={() => navigate(`/product/${item._id}`)}
      className={`group relative bg-white rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl shadow-md ${
        featured ? "border-2 border-orange-200" : ""
      }`}
    >
      {/* Discount Badge */}
      {item.discount > 0 && (
        <div className="absolute top-3 left-3 z-10 bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow">
          {item.discount}% OFF
        </div>
      )}

      {/* Wishlist Button */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          toggleWishlist(item._id); // ✅ calls context toggleWishlist
        }}
        className="absolute top-3 right-3 z-10 bg-white/80 backdrop-blur-sm p-1.5 rounded-full shadow transition hover:scale-110"
      >
        <Heart
          size={18}
          className={
            isWishlisted(item._id)
              ? "text-red-500 fill-red-500"
              : "text-gray-400"
          }
        />
      </button>

      {/* Image */}
      <div className="relative overflow-hidden bg-orange-50 h-44">
        <img
          src={
                item.images && item.images.length > 0
                  ? item.images[0].startsWith("http")
                    ? item.images[0]
                    : `http://localhost:5000${item.images[0]}`
                  : "/placeholder.png"
              }
          alt={item.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>

      {/* Info */}
      <div className="p-3">
        <h2 className="font-semibold text-gray-800 text-sm truncate mb-1">
          {item.name}
        </h2>

        <div className="flex items-center gap-2 mb-1">
          <span className="text-orange-600 font-bold text-base">
            ₹{item.price}
          </span>
          <span className="text-xs text-gray-400 line-through">
            ₹{item.originalPrice}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1 text-yellow-500 text-xs font-medium">
            <Star size={12} fill="currentColor" />
            {item.rating}
          </span>
          <span className="text-green-600 text-xs font-semibold">
            Save ₹{item.originalPrice 
  ? Math.round(item.originalPrice - item.price) 
  : 0}
 
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      {/* ===== HERO BANNER ===== */}
      <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-red-500 px-6 py-10 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <div className="bg-white/20 p-3 rounded-2xl">
            <ShoppingBag size={36} className="text-white" />
          </div>
          <div>
            <p className="text-orange-100 text-sm font-medium tracking-widest uppercase">
              Official Store
            </p>
            <h1 className="text-4xl font-extrabold text-white capitalize tracking-tight">
              {brand}
            </h1>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* ===== TOP DEALS ===== */}
        <div className="flex items-center gap-2 mb-4">
          <div className="bg-orange-100 p-2 rounded-xl">
            <Flame size={20} className="text-orange-500" />
          </div>
          <h2 className="text-xl font-bold text-gray-800">Top Deals</h2>
          <span className="ml-2 bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full">
            Hot
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
          {topDeals.map((item) => (
            <ProductCard key={item._id} item={item} featured />
          ))}
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 mb-6">
          <div className="flex-1 h-px bg-orange-100" />
          <div className="flex items-center gap-2">
            <Tag size={18} className="text-orange-400" />
            <span className="text-gray-500 text-sm font-medium">
              All Products
            </span>
          </div>
          <div className="flex-1 h-px bg-orange-100" />
        </div>

        {/* ===== ALL PRODUCTS ===== */}
        {products.length === 0 ? (
          <div className="text-center py-20">
            <ShoppingBag size={48} className="text-orange-200 mx-auto mb-4" />
            <p className="text-gray-400 text-lg">No Products Found</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {otherProducts.map((item) => (
              <ProductCard key={item._id} item={item} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BrandPage;