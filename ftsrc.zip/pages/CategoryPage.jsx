import React, { useEffect, useState, useMemo, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { categoryMap } from "../../utils/categoryMap";
import {
  Heart,
  Search,
  SlidersHorizontal,
  ChevronDown,
  Star,
  Sparkles,
  X,
  ArrowUpDown,
} from "lucide-react";
import { WishlistContext } from "../context/WishlistContext";
import toast from "react-hot-toast";

const CategoryPage = () => {
  const { name } = useParams();
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [selectedGroups, setSelectedGroups] = useState([]);
  const [selectedRatings, setSelectedRatings] = useState([]);
  const [priceRange, setPriceRange] = useState([0, 200000]);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sort, setSort] = useState("");
  const [loading, setLoading] = useState(true);
  const [visible, setVisible] = useState(8);
  const [animatingId, setAnimatingId] = useState(null);

  const { wishlist, toggleWishlist, fetchWishlist } = useContext(WishlistContext);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 400);
    return () => clearTimeout(timer);
  }, [search]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const res = await axios.get(`http://localhost:5000/api/products/group/${name}`);
        setProducts(res.data || []);
      } catch (err) {
        console.log(err);
      }
      setLoading(false);
    };
    fetchData();
    setVisible(8);
  }, [name]);

  useEffect(() => {
    setSelectedGroups(Object.keys(categoryMap[name] || {}));
  }, [name]);

  const toggle = (value, setter, list) => {
    setter(list.includes(value) ? list.filter((x) => x !== value) : [...list, value]);
  };

  const clearFilters = () => {
    setSelectedGroups(Object.keys(categoryMap[name] || {}));
    setSelectedRatings([]);
    setPriceRange([0, 200000]);
    setSearch("");
    setSort("");
  };

  const isInWishlist = (id) =>
    wishlist.some((item) => (item._id || item).toString() === id.toString());

  const filtered = useMemo(() => {
    let result = [...products];
    const groupMap = categoryMap[name] || {};
    let allowed = [];
    selectedGroups.forEach((g) => { allowed = [...allowed, ...(groupMap[g] || [])]; });
    result = result.filter((p) => {
      let ok = true;
      if (allowed.length) ok = allowed.includes(p.category);
      if (debouncedSearch) ok = ok && p.name.toLowerCase().includes(debouncedSearch.toLowerCase());
      ok = ok && p.price >= priceRange[0] && p.price <= priceRange[1];
      if (selectedRatings.length) ok = ok && selectedRatings.some((r) => p.rating >= r);
      return ok;
    });
    if (sort === "low") result.sort((a, b) => a.price - b.price);
    if (sort === "high") result.sort((a, b) => b.price - a.price);
    if (sort === "rating") result.sort((a, b) => b.rating - a.rating);
    if (sort === "discount") result.sort((a, b) => b.discount - a.discount);
    return result;
  }, [products, selectedGroups, selectedRatings, priceRange, debouncedSearch, sort, name]);

  const visibleProducts = filtered.slice(0, visible);

  // ── Skeleton Card ──────────────────────────────────────────────
  const SkeletonCard = () => (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm animate-pulse">
      <div className="h-48 bg-orange-100" />
      <div className="p-4 space-y-2">
        <div className="h-3 bg-gray-200 rounded-full w-3/4" />
        <div className="h-3 bg-gray-100 rounded-full w-1/2" />
        <div className="h-4 bg-orange-100 rounded-full w-1/3 mt-2" />
      </div>
    </div>
  );

  // ── Product Card ───────────────────────────────────────────────
  const ProductCard = ({ p }) => {
    const isWish = isInWishlist(p._id);
    const savings = p.originalPrice
  ? Math.round(p.originalPrice - p.price)
  : 0;

    return (
      <div
        className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 relative flex flex-col"
      >
        {/* Discount ribbon */}
        {p.discount > 0 && (
          <div className="absolute top-3 left-3 z-10">
            <span className="bg-gradient-to-r from-orange-500 to-red-500 text-white text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md tracking-wide">
              {p.discount}% OFF
            </span>
          </div>
        )}

        {/* Wishlist btn */}
        <button
          onClick={async (e) => {
            e.stopPropagation();
            setAnimatingId(p._id);
            const already = isInWishlist(p._id);
            await toggleWishlist(p._id);
            fetchWishlist();
            already ? toast.error("Removed 💔") : toast.success("Added ❤️");
            setTimeout(() => setAnimatingId(null), 300);
          }}
          className="absolute top-3 right-3 z-10 bg-white/80 backdrop-blur-sm p-1.5 rounded-full shadow-md hover:scale-110 transition-transform duration-200"
        >
          <Heart
            size={16}
            className={`transition-all duration-300 ${
              isWish ? "text-red-500 fill-red-500" : "text-gray-400"
            } ${animatingId === p._id ? "scale-125 rotate-12" : "scale-100"}`}
          />
        </button>

        {/* Image */}
        <div className="relative h-48 bg-orange-50 overflow-hidden cursor-pointer"
          onClick={() => navigate(`/product/${p._id}`)}>
          <img
            src={
              p.images && p.images.length > 0
                ? p.images[0].startsWith("http")
                  ? p.images[0]
                  : `http://localhost:5000${p.images[0]}`
                : "/placeholder.png"
            }
            alt={p.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>

        {/* Info */}
        <div className="p-3 flex flex-col gap-1 flex-1">
          <h3
            className="text-sm font-semibold text-gray-800 truncate cursor-pointer hover:text-orange-600 transition-colors"
            onClick={() => navigate(`/product/${p._id}`)}
          >
            {p.name}
          </h3>

          {/* Rating */}
          <div className="flex items-center gap-1.5">
            <span className="flex items-center gap-1 bg-green-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
              {p.rating?.toFixed(1) || "0.0"}
              <Star size={9} fill="white" />
            </span>
            <span className="text-[11px] text-gray-400">
              ({p.numReviews || p.reviews?.length || 0})
            </span>
          </div>

          {/* Price row */}
          <div className="flex items-center gap-2 mt-auto pt-1">
            <span className="text-orange-600 font-bold text-base">₹{p.price}</span>
            {p.originalPrice && (
              <span className="text-gray-400 text-xs line-through">₹{p.originalPrice}</span>
            )}
          </div>

          {savings > 0 && (
            <p className="text-green-600 text-[11px] font-medium">
              You save ₹{savings}
            </p>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">

      {/* ── HERO HEADER ───────────────────────────────────────── */}
      <div className="bg-gradient-to-r from-orange-600 via-orange-500 to-amber-500 py-8 px-6 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Sparkles size={16} className="text-orange-200" />
                <span className="text-orange-100 text-xs font-semibold tracking-[0.15em] uppercase">
                  Browse Collection
                </span>
              </div>
              <h1 className="text-3xl md:text-4xl font-extrabold text-white capitalize tracking-tight">
                {name}
              </h1>
              <p className="text-orange-100 text-sm mt-1">
                {filtered.length} products found
              </p>
            </div>

            {/* Search + Sort */}
            <div className="flex items-center gap-3">
              {/* Search */}
              <div className="relative">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-orange-300 pointer-events-none" />
                <input
                  placeholder="Search products..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 pr-10 py-2.5 rounded-xl bg-white/20 backdrop-blur-sm text-white placeholder-orange-200 text-sm border border-white/30 focus:outline-none focus:bg-white/30 w-56 transition-all"
                />
                {search && (
                  <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2">
                    <X size={13} className="text-orange-200 hover:text-white" />
                  </button>
                )}
              </div>

              {/* Sort */}
              <div className="relative">
                <ArrowUpDown size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-orange-300 pointer-events-none" />
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                  className="pl-8 pr-8 py-2.5 rounded-xl bg-white/20 backdrop-blur-sm text-white text-sm border border-white/30 focus:outline-none appearance-none cursor-pointer min-w-[130px]"
                >
                  <option value="" className="text-gray-800">Sort By</option>
                  <option value="low" className="text-gray-800">Price: Low → High</option>
                  <option value="high" className="text-gray-800">Price: High → Low</option>
                  <option value="rating" className="text-gray-800">Top Rated</option>
                  <option value="discount" className="text-gray-800">Best Offer</option>
                </select>
                <ChevronDown size={13} className="absolute right-3 top-1/2 -translate-y-1/2 text-orange-300 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── BODY ──────────────────────────────────────────────── */}
      <div className="max-w-7xl mx-auto px-4 py-8 flex gap-7">

        {/* ── FILTER SIDEBAR ──────────────────────────────────── */}
        <aside className="w-64 shrink-0 sticky top-24 h-fit">
          <div className="bg-white rounded-2xl shadow-md overflow-hidden">
            {/* Sidebar header */}
            <div className="bg-gradient-to-r from-orange-500 to-amber-500 px-5 py-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal size={16} className="text-white" />
                <span className="text-white font-bold text-sm tracking-wide">Filters</span>
              </div>
              <button
                onClick={clearFilters}
                className="text-orange-100 hover:text-white text-xs font-semibold border border-white/30 px-2.5 py-1 rounded-full transition hover:bg-white/20"
              >
                Clear All
              </button>
            </div>

            <div className="p-5 space-y-6">
              {/* Categories */}
              <div>
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">
                  Categories
                </h4>
                <div className="flex flex-wrap gap-2">
                  {Object.keys(categoryMap[name] || {}).map((g) => (
                    <button
                      key={g}
                      onClick={() => toggle(g, setSelectedGroups, selectedGroups)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all duration-200 ${
                        selectedGroups.includes(g)
                          ? "bg-orange-500 text-white border-orange-500 shadow-md shadow-orange-200"
                          : "bg-orange-50 text-orange-600 border-orange-100 hover:border-orange-300"
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-orange-50" />

              {/* Price */}
              <div>
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">
                  Max Price
                </h4>
                <input
                  type="range"
                  min="0"
                  max="200000"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([0, Number(e.target.value)])}
                  className="w-full accent-orange-500 cursor-pointer"
                />
                <div className="flex justify-between mt-2">
                  <span className="text-xs text-gray-400">₹0</span>
                  <span className="text-sm font-bold text-orange-600">
                    ₹{priceRange[1].toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Divider */}
              <div className="h-px bg-orange-50" />

              {/* Rating */}
              <div>
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">
                  Rating
                </h4>
                <div className="space-y-2">
                  {[4, 3, 2].map((r) => (
                    <button
                      key={r}
                      onClick={() => toggle(r, setSelectedRatings, selectedRatings)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm transition-all duration-200 ${
                        selectedRatings.includes(r)
                          ? "bg-orange-500 text-white shadow-md shadow-orange-200"
                          : "bg-orange-50 text-gray-600 hover:bg-orange-100"
                      }`}
                    >
                      <span className="flex items-center gap-1">
                        {Array.from({ length: r }).map((_, i) => (
                          <Star
                            key={i}
                            size={12}
                            className={selectedRatings.includes(r) ? "fill-white text-white" : "fill-yellow-400 text-yellow-400"}
                          />
                        ))}
                      </span>
                      <span className="text-xs font-semibold opacity-80">& above</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* ── PRODUCT GRID ────────────────────────────────────── */}
        <div className="flex-1 min-w-0">
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
            </div>
          ) : visibleProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-28 text-center">
              <div className="text-6xl mb-4">🛍️</div>
              <h3 className="text-xl font-bold text-gray-700 mb-2">No products found</h3>
              <p className="text-gray-400 text-sm mb-5">Try adjusting your filters or search term.</p>
              <button
                onClick={clearFilters}
                className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2.5 rounded-full text-sm font-semibold transition"
              >
                Clear Filters
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                {visibleProducts.map((p) => (
                  <ProductCard key={p._id} p={p} />
                ))}
              </div>

              {/* Load More */}
              {visible < filtered.length && (
                <div className="flex flex-col items-center mt-12 gap-2">
                  <p className="text-sm text-gray-400">
                    Showing {visibleProducts.length} of {filtered.length} products
                  </p>
                  <button
                    onClick={() => setVisible((prev) => prev + 8)}
                    className="group relative overflow-hidden bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white px-8 py-3 rounded-full font-semibold text-sm shadow-lg shadow-orange-200 hover:shadow-orange-300 transition-all duration-300 hover:-translate-y-0.5"
                  >
                    <span className="relative z-10">Load More Products</span>
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;