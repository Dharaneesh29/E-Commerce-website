
 

// import { useState, useRef, useEffect } from "react";
// import API from "../api/axios";
// import { Link } from "react-router-dom";
// import confetti from "canvas-confetti";
 
// const Register = () => {

//   const fireConfetti = () => {
//   confetti({
//     particleCount: 120,
//     spread: 70,
//     origin: { y: 0.6 },
//   });
// };
 
//   const [form, setForm] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     password: "",
//   });
 
//   const [msg, setMsg] = useState("");
//   const [loading, setLoading] = useState(false);
 
//   // EMAIL OTP
//   const [emailVerified, setEmailVerified] = useState(false);
//   const [showEmailOtp, setShowEmailOtp] = useState(false);
//   const [emailOtp, setEmailOtp] = useState(["", "", "", "", "", ""]);
//   const emailRef = useRef([]);
 
//   // PHONE OTP
//   const [phoneVerified, setPhoneVerified] = useState(false);
//   const [showPhoneOtp, setShowPhoneOtp] = useState(false);
//   const [phoneOtp, setPhoneOtp] = useState(["", "", "", "", "", ""]);
//   const phoneRef = useRef([]);
 
//   // TIMER (email)
//   const [timer, setTimer] = useState(30);
//   const [canResend, setCanResend] = useState(false);
 
//   const [showPassword, setShowPassword] = useState(false);
 
//   // INPUT
//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };
 
//   // ================= OTP HANDLER =================
//   const handleOtpChange = (value, index, type) => {
//     if (!/^[0-9]?$/.test(value)) return;
 
//     if (type === "email") {
//       const newOtp = [...emailOtp];
//       newOtp[index] = value;
//       setEmailOtp(newOtp);
//       if (value && index < 5) emailRef.current[index + 1].focus();
//     } else {
//       const newOtp = [...phoneOtp];
//       newOtp[index] = value;
//       setPhoneOtp(newOtp);
//       if (value && index < 5) phoneRef.current[index + 1].focus();
//     }
//   };
 
//   const handleKeyDown = (e, index, type) => {
//     const otpArr = type === "email" ? emailOtp : phoneOtp;
//     const refArr = type === "email" ? emailRef : phoneRef;
 
//     if (e.key === "Backspace" && !otpArr[index] && index > 0) {
//       refArr.current[index - 1].focus();
//     }
//   };
 
//   // ================= TIMER =================
//   useEffect(() => {
//     let interval;
//     if (showEmailOtp && timer > 0) {
//       interval = setInterval(() => setTimer((prev) => prev - 1), 1000);
//     } else if (timer === 0) {
//       setCanResend(true);
//     }
//     return () => clearInterval(interval);
//   }, [showEmailOtp, timer]);
 
//   // AUTO FOCUS
//   useEffect(() => {
//     if (showEmailOtp) emailRef.current[0]?.focus();
//   }, [showEmailOtp]);
 
//   useEffect(() => {
//     if (showPhoneOtp) phoneRef.current[0]?.focus();
//   }, [showPhoneOtp]);
 
//   // ================= EMAIL OTP =================
//   const sendEmailOtp = async () => {
//     try {
//       await API.post("/users/send-otp", { email: form.email });
//       setShowEmailOtp(true);
//       setTimer(30);
//       setCanResend(false);
//       setMsg("Email OTP Sent 📩");
//     } catch {
//       setMsg("Email OTP error");
//     }
//   };
 
//   const verifyEmailOtp = async () => {
//     const fullOtp = emailOtp.join("");
 
//     try {
//       await API.post("/users/verify-otp", {
//         email: form.email,
//         otp: fullOtp,
//       });
 
//       setEmailVerified(true);
//       setShowEmailOtp(false);
//       setMsg("Email Verified ✅");

//       fireConfetti();
//     } catch {
//       setMsg("Invalid Email OTP");
//     }
//   };
 
//   // ================= PHONE OTP =================
//   const sendPhoneOtp = async () => {
//     try {
//       await API.post("/users/send-phone-otp", { phone: form.phone });
//       setShowPhoneOtp(true);
//       setMsg("Phone OTP (check terminal)");
//     } catch {
//       setMsg("Phone OTP error");
//     }
//   };
 
//   const verifyPhoneOtp = async () => {
//     const fullOtp = phoneOtp.join("");
 
//     try {
//       await API.post("/users/verify-phone-otp", {
//         phone: form.phone,
//         otp: fullOtp,
//       });
 
//       setPhoneVerified(true);
//       setShowPhoneOtp(false);
//       setMsg("Phone Verified ✅");

//       fireConfetti()
//     } catch {
//       setMsg("Invalid Phone OTP");
//     }
//   };
 
//   // ================= REGISTER =================
//   const handleSubmit = async (e) => {
//     e.preventDefault();
 
//     if (!emailVerified || !phoneVerified) {
//       return setMsg("Verify Email & Phone first");
//     }
 
//     try {
//       setLoading(true);
//       const res = await API.post("/users/register", form);
//       setMsg(res.data.message);
//     } catch {
//       setMsg("Register failed");
//     } finally {
//       setLoading(false);
//     }
//   };
 
//   return (
//     <div className="min-h-screen flex justify-center items-center bg-orange-100">
//       <div className="bg-white p-6 rounded-xl w-[350px] shadow-lg">
 
//         <h2 className="text-xl font-bold text-center text-orange-600 mb-4">
//           Create Account 🔶
//         </h2>
 
//         <form onSubmit={handleSubmit} className="space-y-3">
 
//           <input name="name" placeholder="Name" className="input" onChange={handleChange} />
 
//           {/* EMAIL */}
//           <div className="relative">
//             <input name="email" placeholder="Email" className="input pr-24" onChange={handleChange} />
//             {!emailVerified ? (
//               <button type="button" onClick={sendEmailOtp} className="verify-btn">Verify</button>
//             ) : <span className="verified">✔</span>}
//           </div>
 
//           {/* EMAIL OTP */}
//           {showEmailOtp && !emailVerified && (
//             <div className="text-center">
//               <div className="flex justify-center gap-2">
//                 {emailOtp.map((d, i) => (
//                   <input key={i} maxLength="1"
//                     value={d}
//                     ref={(el) => emailRef.current[i] = el}
//                     onChange={(e) => handleOtpChange(e.target.value, i, "email")}
//                     onKeyDown={(e) => handleKeyDown(e, i, "email")}
//                     className="otp-box"
//                   />
//                 ))}
//               </div>
//               <button type="button" onClick={verifyEmailOtp} className="otp-btn">Verify Email OTP</button>
//               <p className="text-sm">{canResend ? <span onClick={sendEmailOtp}>Resend</span> : `Resend in ${timer}s`}</p>
//             </div>
//           )}
 
//           {/* PHONE */}
//           <div className="relative">
//             <input name="phone" placeholder="Phone" className="input pr-24" onChange={handleChange} />
//             {!phoneVerified ? (
//               <button type="button" onClick={sendPhoneOtp} className="verify-btn">Verify</button>
//             ) : <span className="verified">✔</span>}
//           </div>
 
//           {/* PHONE OTP */}
//           {showPhoneOtp && !phoneVerified && (
//             <div className="text-center">
//               <div className="flex justify-center gap-2">
//                 {phoneOtp.map((d, i) => (
//                   <input key={i} maxLength="1"
//                     value={d}
//                     ref={(el) => phoneRef.current[i] = el}
//                     onChange={(e) => handleOtpChange(e.target.value, i, "phone")}
//                     onKeyDown={(e) => handleKeyDown(e, i, "phone")}
//                     className="otp-box"
//                   />
//                 ))}
//               </div>
//               <button type="button" onClick={verifyPhoneOtp} className="otp-btn">Verify Phone OTP</button>
//             </div>
//           )}
 
//           {/* PASSWORD */}
//           <div className="relative">
//             <input
//               type={showPassword ? "text" : "password"}
//               name="password"
//               placeholder="Password"
//               className="input pr-10"
//               onChange={handleChange}
//             />
//             <span onClick={() => setShowPassword(!showPassword)} className="eye">👁</span>
//           </div>
 
//           <button disabled={!emailVerified || !phoneVerified || loading} className="submit-btn">
//             {loading ? "Creating..." : "Register"}
//           </button>
 
//           {msg && <p className="text-center text-sm">{msg}</p>}
//         </form>
 
//         <p className="text-center mt-2 text-sm">
//           Already have account? <Link to="/users/login" className="text-orange-500">Login</Link>
//         </p>
//       </div>
 
//       <style>{`
//         .input { width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; }
//         .verify-btn { position:absolute; right:5px; top:5px; background:orange; color:white; padding:5px 10px; border-radius:6px; }
//         .verified { position:absolute; right:10px; top:8px; color:green; }
//         .otp-box { width:40px; height:45px; text-align:center; border:1px solid #ccc; border-radius:6px; }
//         .otp-btn { width:100%; margin-top:5px; background:orange; color:white; padding:6px; border-radius:6px; }
//         .submit-btn { width:100%; padding:10px; background:linear-gradient(to right,#ff7e5f,#feb47b); color:white; border-radius:8px; }
//         .eye { position:absolute; right:10px; top:8px; cursor:pointer; }
//       `}</style>
//     </div>
//   );
// };
 
// export default Register;

// import { useState, useRef, useEffect } from "react";
// import API from "../api/axios";
// import { Link, useNavigate } from "react-router-dom";
// import confetti from "canvas-confetti";
// import toast from "react-hot-toast";
 
// const Register = () => {
//   const navigate = useNavigate();
 
//   const [form, setForm] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     password: "",
//   });
 
//   const [loading, setLoading] = useState(false);
 
//   // EMAIL OTP
//   const [emailVerified, setEmailVerified] = useState(false);
//   const [showEmailOtp, setShowEmailOtp] = useState(false);
//   const [emailOtp, setEmailOtp] = useState(["", "", "", "", "", ""]);
//   const emailRef = useRef([]);
 
//   // PHONE OTP
//   const [phoneVerified, setPhoneVerified] = useState(false);
//   const [showPhoneOtp, setShowPhoneOtp] = useState(false);
//   const [phoneOtp, setPhoneOtp] = useState(["", "", "", "", "", ""]);
//   const phoneRef = useRef([]);
 
//   // TIMER
//   const [emailTimer, setEmailTimer] = useState(0);
// const [phoneTimer, setPhoneTimer] = useState(0);
 
// const [canResendEmail, setCanResendEmail] = useState(true);
// const [canResendPhone, setCanResendPhone] = useState(true);
 
 
//   const [showPassword, setShowPassword] = useState(false);
 
//   // ================= INPUT =================
//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };
 
//   // ================= CONFETTI =================
//   const fireConfetti = () => {
//     confetti({
//       particleCount: 120,
//       spread: 80,
//       origin: { y: 0.6 },
//     });
//   };
 
//   // ================= OTP HANDLER =================
//   const handleOtpChange = (value, index, type) => {
//     if (!/^[0-9]?$/.test(value)) return;
 
//     if (type === "email") {
//       const newOtp = [...emailOtp];
//       newOtp[index] = value;
//       setEmailOtp(newOtp);
//       if (value && index < 5) emailRef.current[index + 1].focus();
//     } else {
//       const newOtp = [...phoneOtp];
//       newOtp[index] = value;
//       setPhoneOtp(newOtp);
//       if (value && index < 5) phoneRef.current[index + 1].focus();
//     }
//   };
 
//   const handleKeyDown = (e, index, type) => {
//     const otpArr = type === "email" ? emailOtp : phoneOtp;
//     const refArr = type === "email" ? emailRef : phoneRef;
 
//     if (e.key === "Backspace" && !otpArr[index] && index > 0) {
//       refArr.current[index - 1].focus();
//     }
//   };
 
//   // ================= AUTO VERIFY =================
//   useEffect(() => {
//     if (emailOtp.join("").length === 6) verifyEmailOtp();
//   }, [emailOtp]);
 
//   useEffect(() => {
//     if (phoneOtp.join("").length === 6) verifyPhoneOtp();
//   }, [phoneOtp]);
 
//   // ================= TIMER =================
//   useEffect(() => {
//   let emailInterval;
//   if (emailTimer > 0) {
//     emailInterval = setInterval(() => {
//       setEmailTimer((prev) => prev - 1);
//     }, 1000);
//   } else {
//     setCanResendEmail(true);
//   }
 
//   return () => clearInterval(emailInterval);
// }, [emailTimer]);
 
// useEffect(() => {
//   let phoneInterval;
//   if (phoneTimer > 0) {
//     phoneInterval = setInterval(() => {
//       setPhoneTimer((prev) => prev - 1);
//     }, 1000);
//   } else {
//     setCanResendPhone(true);
//   }
 
//   return () => clearInterval(phoneInterval);
// }, [phoneTimer]);
 
 
//   // ================= EMAIL OTP =================
//   const sendEmailOtp = async () => {
//     try {
//       await API.post("/users/send-otp", { email: form.email });
//       setShowEmailOtp(true);
//       setEmailTimer(30);
//       setCanResendEmail(false);
//       toast.success("OTP sent to email 📩");
//     } catch {
//       toast.error("Email OTP error");
//     }
//   };
 
//   const verifyEmailOtp = async () => {
//     const fullOtp = emailOtp.join("");
 
//     try {
//       await API.post("/users/verify-otp", {
//         email: form.email,
//         otp: fullOtp,
//       });
 
//       setEmailVerified(true);
//       setShowEmailOtp(false);
//       toast.success("Email Verified ✅");
//       fireConfetti();
//     } catch {
//       toast.error("Invalid Email OTP");
//     }
//   };
 
//   // ================= PHONE OTP =================
//   const sendPhoneOtp = async () => {
//     try {
//       await API.post("/users/send-phone-otp", { phone: form.phone });
//       setShowPhoneOtp(true);
//       setPhoneTimer(30);
//       setCanResendPhone(false)
//       toast.success("OTP printed in terminal 📱");
//     } catch {
//       toast.error("Phone OTP error");
//     }
//   };
 
//   const verifyPhoneOtp = async () => {
//     const fullOtp = phoneOtp.join("");
 
//     try {
//       await API.post("/users/verify-phone-otp", {
//         phone: form.phone,
//         otp: fullOtp,
//       });
 
//       setPhoneVerified(true);
//       setShowPhoneOtp(false);
//       toast.success("Phone Verified ✅");
//       fireConfetti();
//     } catch {
//       toast.error("Invalid Phone OTP");
//     }
//   };
 
//   // ================= PASSWORD STRENGTH =================
//   const getStrength = () => {
//     const pwd = form.password;
//     if (pwd.length < 6) return "Weak";
//     if (/[A-Z]/.test(pwd) && /[0-9]/.test(pwd)) return "Strong";
//     return "Medium";
//   };
 
//   // ================= REGISTER =================
//   const handleSubmit = async (e) => {
//   e.preventDefault();
 
//   if (!emailVerified || !phoneVerified) {
//     return toast.error("Verify Email & Phone first");
//   }
 
//   console.log("Register Data:", form);
 
//   try {
//     setLoading(true);
 
//     const res = await API.post("/users/register", {
//       ...form,
//       emailVerified,
//       phoneVerified,
//     });
 
//     toast.success("Registered Successfully 🎉");
//     fireConfetti();
 
//     setTimeout(() => navigate("/users/login"), 1500);
 
//   } catch (err) {
//     console.log("BACKEND ERROR:", err.response?.data);
//     toast.error(err.response?.data?.message || "Register failed");
//   } finally {
//     setLoading(false);
//   }
// };

 
//   return (
//     <div className="min-h-screen flex">
 
//       {/* LEFT SIDE */}
//       <div className="hidden md:flex w-1/2 bg-gradient-to-br from-orange-500 to-pink-500 text-white p-10 flex-col justify-center">
//         <h1 className="text-4xl font-bold mb-4">
//           Shop Smart.<br />Live Better.
//         </h1>
//         <p>Join ShopEasy and explore amazing deals.</p>
//       </div>
 
//       {/* RIGHT SIDE */}
//       <div className="flex w-full md:w-1/2 justify-center items-center bg-orange-50">
 
//         <div className="bg-white p-6 rounded-xl w-[350px] shadow-lg">
 
//           <h2 className="text-xl font-bold text-center text-orange-600 mb-4">
//             Create your account
//           </h2>
 
//           <form onSubmit={handleSubmit} className="space-y-3">
 
//             <input name="name" placeholder="Full Name" className="input" onChange={handleChange} />
 
//             {/* EMAIL */}
//             <div className="relative">
//               <input name="email" placeholder="Email" className="input pr-24" onChange={handleChange} />
//               {!emailVerified ? (
//                 <button type="button" onClick={sendEmailOtp} className="verify-btn">Verify Email</button>
//               ) : <span className="verified">✔</span>}
//             </div>
 
//             {/* EMAIL OTP */}
//             {showEmailOtp && !emailVerified && (
//   <>
//     <div className="flex justify-center gap-2">
//       {emailOtp.map((d, i) => (
//         <input
//           key={i}
//           maxLength="1"
//           value={d}
//           ref={(el) => (emailRef.current[i] = el)}
//           onChange={(e) => handleOtpChange(e.target.value, i, "email")}
//           onKeyDown={(e) => handleKeyDown(e, i, "email")}
//           className="otp-box"
//         />
//       ))}
//     </div>
 
//     {/* ✅ ADD TIMER HERE */}
//     <p className="text-center mt-2 text-sm text-gray-500">
//       {canResendEmail ? (
//         <span
//           className="text-orange-500 cursor-pointer"
//           onClick={sendEmailOtp}
//         >
//           Resend OTP
//         </span>
//       ) : (
//         `Resend OTP in ${emailTimer}s`
//       )}
//     </p>
//   </>
// )}
 
 
//             {/* PHONE */}
//             <div className="relative">
//               <input name="phone" placeholder="Phone Number" className="input pr-24" onChange={handleChange} />
//               {!phoneVerified ? (
//                 <button type="button" onClick={sendPhoneOtp} className="verify-btn">Verify Phone</button>
//               ) : <span className="verified">✔</span>}
//             </div>
 
//             {/* PHONE OTP */}
//             {showPhoneOtp && !phoneVerified && (
//   <>
//     <div className="flex justify-center gap-2">
//       {phoneOtp.map((d, i) => (
//         <input
//           key={i}
//           maxLength="1"
//           value={d}
//           ref={(el) => (phoneRef.current[i] = el)}
//           onChange={(e) => handleOtpChange(e.target.value, i, "phone")}
//           onKeyDown={(e) => handleKeyDown(e, i, "phone")}
//           className="otp-box"
//         />
//       ))}
//     </div>
 
//     {/* ✅ ADD TIMER HERE */}
//     <p className="text-center mt-2 text-sm text-gray-500">
//       {canResendPhone ? (
//         <span
//           className="text-orange-500 cursor-pointer"
//           onClick={sendPhoneOtp}
//         >
//           Resend OTP
//         </span>
//       ) : (
//         `Resend OTP in ${phoneTimer}s`
//       )}
//     </p>
//   </>
// )}
 
 
//             {/* PASSWORD */}
//             <div className="relative">
//               <input
//                 type={showPassword ? "text" : "password"}
//                 name="password"
//                 placeholder="Password"
//                 className="input pr-10"
//                 onChange={handleChange}
//               />
//               <span onClick={() => setShowPassword(!showPassword)} className="eye">👁</span>
//             </div>
 
//             <p className="text-sm">
//               Strength: <span className={
//                 getStrength() === "Strong" ? "text-green-600" :
//                 getStrength() === "Medium" ? "text-yellow-500" :
//                 "text-red-500"
//               }>
//                 {getStrength()}
//               </span>
//             </p>
 
//             <button disabled={!emailVerified || !phoneVerified || loading} className="submit-btn">
//               {loading ? "Creating..." : "Register"}
//             </button>
 
//           </form>
 
//           <p className="text-center mt-2 text-sm">
//             Already have account? <Link to="/users/login" className="text-orange-500">Login</Link>
//           </p>
 
//         </div>
//       </div>
 
//       <style>{`
//         .input { width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; }
//         .verify-btn { position:absolute; right:5px; top:5px; background:orange; color:white; padding:5px 10px; border-radius:6px; }
//         .verified { position:absolute; right:10px; top:8px; color:green; }
//         .otp-box { width:40px; height:45px; text-align:center; border:1px solid #ccc; border-radius:6px; }
//         .submit-btn { width:100%; padding:10px; background:linear-gradient(to right,#ff7e5f,#feb47b); color:white; border-radius:8px; }
//         .eye { position:absolute; right:10px; top:8px; cursor:pointer; }
//       `}</style>
 
//     </div>
//   );
// };
 
// export default Register;


import { useState, useRef, useEffect } from "react";
import API from "../api/axios";
import { Link, useNavigate } from "react-router-dom";
import confetti from "canvas-confetti";
import toast from "react-hot-toast";
 
import i1 from "../assets/register/i1.png";
import i2 from "../assets/register/i2.png";
import i3 from "../assets/register/i3.png";
 
const slides = [
  { img: i1 },
  { img: i2 },
  { img: i3 },
];
 
const Register = () => {
  const navigate = useNavigate();
 
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
  });
 
  const [loading, setLoading] = useState(false);
 
  const [currentSlide, setCurrentSlide] = useState(0);
 
  // OTP STATES (UNCHANGED)
  const [emailVerified, setEmailVerified] = useState(false);
  const [showEmailOtp, setShowEmailOtp] = useState(false);
  const [emailOtp, setEmailOtp] = useState(["", "", "", "", "", ""]);
  const emailRef = useRef([]);
 
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [showPhoneOtp, setShowPhoneOtp] = useState(false);
  const [phoneOtp, setPhoneOtp] = useState(["", "", "", "", "", ""]);
  const phoneRef = useRef([]);
 
  const [emailTimer, setEmailTimer] = useState(0);
  const [phoneTimer, setPhoneTimer] = useState(0);
 
  const [canResendEmail, setCanResendEmail] = useState(true);
  const [canResendPhone, setCanResendPhone] = useState(true);
 
  const [showPassword, setShowPassword] = useState(false);
 
  // 🔁 SLIDER
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);
 
  // INPUT
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
 
  const fireConfetti = () => {
    confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
  };
 
  // OTP HANDLER (same)
  const handleOtpChange = (value, index, type) => {
    if (!/^[0-9]?$/.test(value)) return;
 
    if (type === "email") {
      const newOtp = [...emailOtp];
      newOtp[index] = value;
      setEmailOtp(newOtp);
      if (value && index < 5) emailRef.current[index + 1].focus();
    } else {
      const newOtp = [...phoneOtp];
      newOtp[index] = value;
      setPhoneOtp(newOtp);
      if (value && index < 5) phoneRef.current[index + 1].focus();
    }
  };
 
  const handleKeyDown = (e, index, type) => {
    const otpArr = type === "email" ? emailOtp : phoneOtp;
    const refArr = type === "email" ? emailRef : phoneRef;
 
    if (e.key === "Backspace" && !otpArr[index] && index > 0) {
      refArr.current[index - 1].focus();
    }
  };
 
  // AUTO VERIFY
  useEffect(() => {
    if (emailOtp.join("").length === 6) verifyEmailOtp();
  }, [emailOtp]);
 
  useEffect(() => {
    if (phoneOtp.join("").length === 6) verifyPhoneOtp();
  }, [phoneOtp]);
 
  // TIMER
  useEffect(() => {
    let i;
    if (emailTimer > 0) {
      i = setInterval(() => setEmailTimer((p) => p - 1), 1000);
    } else setCanResendEmail(true);
    return () => clearInterval(i);
  }, [emailTimer]);
 
  useEffect(() => {
    let i;
    if (phoneTimer > 0) {
      i = setInterval(() => setPhoneTimer((p) => p - 1), 1000);
    } else setCanResendPhone(true);
    return () => clearInterval(i);
  }, [phoneTimer]);
 
  // EMAIL OTP
  const sendEmailOtp = async () => {
    await API.post("/users/send-otp", { email: form.email });
    setShowEmailOtp(true);
    setEmailTimer(30);
    setCanResendEmail(false);
    toast.success("OTP sent 📩");
  };
 
  const verifyEmailOtp = async () => {
    await API.post("/users/verify-otp", {
      email: form.email,
      otp: emailOtp.join(""),
    });
    setEmailVerified(true);
    setShowEmailOtp(false);
    toast.success("Email Verified ✅");
    fireConfetti();
  };
 
  // PHONE OTP
  const sendPhoneOtp = async () => {
    await API.post("/users/send-phone-otp", { phone: form.phone });
    setShowPhoneOtp(true);
    setPhoneTimer(30);
    setCanResendPhone(false);
    toast.success("OTP sent 📱");
  };
 
  const verifyPhoneOtp = async () => {
    await API.post("/users/verify-phone-otp", {
      phone: form.phone,
      otp: phoneOtp.join(""),
    });
    setPhoneVerified(true);
    setShowPhoneOtp(false);
    toast.success("Phone Verified ✅");
    fireConfetti();
  };
 
  const getStrength = () => {
    const p = form.password;
    if (p.length < 6) return "Weak";
    if (/[A-Z]/.test(p) && /[0-9]/.test(p)) return "Strong";
    return "Medium";
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!emailVerified || !phoneVerified)
      return toast.error("Verify first");
 
    await API.post("/users/register", {
      ...form,
      emailVerified,
      phoneVerified,
    });
 
    toast.success("Registered 🎉");
    fireConfetti();
    setTimeout(() => navigate("/users/login"), 1500);
  };
 
  return (
    <div className="min-h-screen flex items-center justify-center bg-[radial-gradient(circle_at_top,_#fff7ed,_#fed7aa,_#fdba74)]">
 
      <div className="w-full max-w-4xl mx-auto flex items-center justify-center gap-18 px-10">
 
        {/* LEFT IMAGE SLIDER */}
        <div className="relative w-[300px] md:w-[380px] h-[520px] rounded-3xl overflow-hidden shadow-[0_10px_40px_rgba(255,140,0,0.3)] animate float">
 
          {slides.map((s, i) => (
            <img
              key={i}
              src={s.img}
              className={`absolute w-full h-full object-cover transition-all duration-1000 ${
                i === currentSlide ? "opacity-100" : "opacity-0"
              }`}
            />
          ))}
 
          {/* DOTS */}
          <div className="absolute bottom-4 w-full flex justify-center gap-2">
            {slides.map((_, i) => (
              <div
                key={i}
                className={`h-2 rounded-full ${
                  i === currentSlide ? "w-6 bg-white" : "w-2 bg-white/50"
                }`}
              />
            ))}
          </div>
        </div>
 
        {/* RIGHT FORM */}
        <div className="backdrop-blur-xl bg-white/60 p-6 rounded-3xl w-[360px] md:w-[400px] shadow-[0_10px_40px_rgba(255,140,0,0.25)] animate-float">
 
          <h2 className="text-lg font-bold text-center text-orange-600 mb-4">
            Create your account
          </h2>
 
          <form onSubmit={handleSubmit} className="space-y-3">
 
            <input name="name" placeholder="Full Name" className="input" onChange={handleChange} />
 
            {/* EMAIL */}
            <div className="relative">
              <input name="email" placeholder="Email" className="input pr-24" onChange={handleChange} />
              {!emailVerified ? (
                <button type="button" onClick={sendEmailOtp} className="verify-btn">Verify</button>
              ) : <span className="verified">✔</span>}
            </div>
 
            {/* EMAIL OTP */}
            {showEmailOtp && !emailVerified && (
              <div className="flex justify-center gap-2">
                {emailOtp.map((d, i) => (
                  <input key={i} maxLength="1" value={d}
                    ref={(el) => (emailRef.current[i] = el)}
                    onChange={(e) => handleOtpChange(e.target.value, i, "email")}
                    onKeyDown={(e) => handleKeyDown(e, i, "email")}
                    className="otp-box" />
                ))}
              </div>
            )}
 
            {/* PHONE */}
            <div className="relative">
              <input name="phone" placeholder="Phone" className="input pr-24" onChange={handleChange} />
              {!phoneVerified ? (
                <button type="button" onClick={sendPhoneOtp} className="verify-btn">Verify</button>
              ) : <span className="verified">✔</span>}
            </div>
 
            {/* PHONE OTP */}
            {showPhoneOtp && !phoneVerified && (
              <div className="flex justify-center gap-2">
                {phoneOtp.map((d, i) => (
                  <input key={i} maxLength="1" value={d}
                    ref={(el) => (phoneRef.current[i] = el)}
                    onChange={(e) => handleOtpChange(e.target.value, i, "phone")}
                    onKeyDown={(e) => handleKeyDown(e, i, "phone")}
                    className="otp-box" />
                ))}
              </div>
            )}
 
            {/* PASSWORD */}
            <div className="relative">
              <input type={showPassword ? "text" : "password"} name="password"
                placeholder="Password" className="input pr-10" onChange={handleChange} />
              <span onClick={() => setShowPassword(!showPassword)} className="eye">👁</span>
            </div>
 
            <p className="text-sm">
              Strength: <span className={
                getStrength() === "Strong" ? "text-green-600" :
                getStrength() === "Medium" ? "text-yellow-500" :
                "text-red-500"
              }>
                {getStrength()}
              </span>
            </p>
 
            <button disabled={!emailVerified || !phoneVerified || loading} className="submit-btn shine">
              {loading ? "Creating..." : "Register"}
            </button>
          </form>
 
          <p className="text-center mt-2 text-sm">
            Already In ShopEasy? <Link to="/users/login" className="text-orange-500">Login</Link>
          </p>
        </div>
      </div>
 
      <style>{`
        .input { width:100%; padding:10px; border-radius:10px; border:1px solid #ddd; }
        .verify-btn { position:absolute; right:5px; top:5px; background:orange; color:white; padding:5px 10px; border-radius:6px; }
        .verified { position:absolute; right:10px; top:8px; color:green; }
        .otp-box { width:38px; height:42px; text-align:center; border:1px solid #ccc; border-radius:6px; }
        .submit-btn { width:100%; padding:10px; border-radius:10px; background:linear-gradient(to right,#ff7e5f,#feb47b); color:white; }
        .eye { position:absolute; right:10px; top:8px; cursor:pointer; }
        
        .submit-btn {
  width: 100%;
  padding: 10px;
  border-radius: 10px;
  background: linear-gradient(to right, #ff7e5f, #feb47b);
  color: white;
  position: relative;
  overflow: hidden;
  transition: 0.3s;
}
 
/* 🔥 SHINE EFFECT */
.submit-btn::before {
  content: "";
  position: absolute;
  top: 0;
  left: -75%;
  width: 50%;
  height: 100%;
  background: linear-gradient(
    120deg,
    transparent,
    rgba(255,255,255,0.6),
    transparent
  );
  transform: skewX(-25deg);
}
 
/* 👉 on hover shine moves */
.submit-btn:hover::before {
  left: 125%;
  transition: 0.7s;
}
 
/* slight scale effect */
.submit-btn:hover {
  transform: scale(1.03);
}


      `}</style>
    </div>
  );
};
 
export default Register;
 
 