import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const BASE = "http://localhost:5000/api";

export default function AdminProfile() {
  const navigate  = useNavigate();
  const [tab,     setTab]     = useState("profile");
  const [orders,  setOrders]  = useState([]);
  const [stats,   setStats]   = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving,  setSaving]  = useState(false);
  const [msg,     setMsg]     = useState(null);
  const [showPwd, setShowPwd] = useState(false);
  const [limit,   setLimit]   = useState(10); // ← dynamic order limit

  const userInfo   = JSON.parse(sessionStorage.getItem("userInfo")) || {};
  const token      = sessionStorage.getItem("token") || userInfo.token;
  const adminName  = userInfo.user?.name  || userInfo.name  || "Admin";
  const adminEmail = userInfo.user?.email || userInfo.email || "admin@shop.com";
  const adminRole  = userInfo.user?.role  || userInfo.role  || "admin";
  const AUTH = () => ({ headers: { Authorization: `Bearer ${token}` } });

  const [form, setForm] = useState({
    name: adminName, email: adminEmail,
    phone: userInfo.user?.phone || "", address: userInfo.user?.address || "",
    currentPassword: "", newPassword: "", confirmPassword: "",
  });

  useEffect(() => {
    axios.get(`${BASE}/dashboard`, AUTH()).then(r => setStats(r.data)).catch(() => {});
  }, []);

  // ← re-fetches whenever tab OR limit changes
  useEffect(() => {
    if (tab === "activity") {
      setLoading(true);
      axios.get(`${BASE}/orders/all`, AUTH())
        .then(r => setOrders((r.data || []).slice(0, limit)))
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  }, [tab, limit]);

  const showToast = (text, type = "success") => {
    setMsg({ text, type });
    setTimeout(() => setMsg(null), 3500);
  };

  const handleSaveProfile = async () => {
    const data = new FormData();
    data.append("name", form.name); data.append("email", form.email);
    data.append("phone", form.phone); data.append("address", form.address);
    try {
      const res = await axios.put(`${BASE}/users/profile`, data, { headers: { Authorization: `Bearer ${token}` } });
      const updated = { ...userInfo, user: res.data?.user || userInfo.user };
      sessionStorage.setItem("userInfo", JSON.stringify(updated));
      showToast("✅ Profile updated successfully!");
    } catch { showToast("Error updating profile", "error"); }
  };

  const handleChangePassword = async () => {
    if (!form.currentPassword) return showToast("Enter your current password", "error");
    if (!form.newPassword || form.newPassword.length < 6) return showToast("New password must be at least 6 characters", "error");
    if (form.newPassword !== form.confirmPassword) return showToast("Passwords don't match", "error");
    setSaving(true);
    try {
      await axios.put(`${BASE}/users/profile`, { currentPassword: form.currentPassword, newPassword: form.newPassword }, AUTH());
      setForm(f => ({ ...f, currentPassword: "", newPassword: "", confirmPassword: "" }));
      showToast("✅ Password changed successfully!");
    } catch (err) { showToast(err.response?.data?.message || "Failed to change password", "error"); }
    finally { setSaving(false); }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("userInfo"); sessionStorage.removeItem("token");
    navigate("/users/login");
  };

  const timeAgo = (date) => {
    const s = Math.floor((new Date() - new Date(date)) / 1000);
    if (s < 60) return "Just now"; if (s < 3600) return `${Math.floor(s/60)}m ago`;
    if (s < 86400) return `${Math.floor(s/3600)}h ago`;
    return new Date(date).toLocaleDateString("en-IN", { day:"numeric", month:"short", year:"numeric" });
  };

  const TABS = [
    { key:"profile",  label:"Profile Info",    icon:"👤" },
    { key:"stats",    label:"My Stats",         icon:"📊" },
    { key:"activity", label:"Recent Activity",  icon:"🕐" },
    { key:"security", label:"Security",         icon:"🔒" },
  ];

  const STATUS_MAP = {
    pending:   { bg:"#fffbeb", color:"#d97706", border:"#fde68a" },
    confirmed: { bg:"#eff6ff", color:"#3b82f6", border:"#bfdbfe" },
    shipped:   { bg:"#f0fdf4", color:"#10b981", border:"#a7f3d0" },
    delivered: { bg:"#ecfdf5", color:"#059669", border:"#6ee7b7" },
    cancelled: { bg:"#fef2f2", color:"#ef4444", border:"#fecaca" },
    returned:  { bg:"#fdf4ff", color:"#a855f7", border:"#e9d5ff" },
  };

  return (
    <div style={{ padding:"24px 28px", background:"#f1f5f9", minHeight:"100vh", fontFamily:"'Segoe UI',sans-serif" }}>
      <style>{`
        @keyframes fadeUp  { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
        @keyframes spin    { to{transform:rotate(360deg)} }
        @keyframes toastIn { from{opacity:0;transform:translateX(20px)} to{opacity:1;transform:translateX(0)} }
        .tab-b:hover   { background:#f8fafc!important; color:#0f172a!important; }
        .save-b:hover  { opacity:.88!important; transform:translateY(-1px)!important; }
        .inp:focus     { border-color:#f97316!important; box-shadow:0 0 0 3px rgba(249,115,22,.12)!important; outline:none!important; }
        .stat-c:hover  { transform:translateY(-3px)!important; box-shadow:0 10px 28px rgba(0,0,0,.1)!important; }
        .ord-r:hover   { background:#f8fafc!important; }
        .perm-i:hover  { background:#fff7ed!important; border-color:#fed7aa!important; }
        .lim-sel:focus { outline:none; border-color:#f97316!important; }
      `}</style>

      {/* ── TOAST ── */}
      {msg && (
        <div style={{
          position:"fixed", top:20, right:20, zIndex:9999,
          padding:"13px 20px", borderRadius:12, fontSize:13, fontWeight:700,
          boxShadow:"0 8px 24px rgba(0,0,0,.12)", animation:"toastIn .3s ease",
          background: msg.type==="success"?"#ecfdf5":"#fef2f2",
          border:     `1.5px solid ${msg.type==="success"?"#6ee7b7":"#fca5a5"}`,
          color:      msg.type==="success"?"#065f46":"#991b1b",
        }}>{msg.text}</div>
      )}

      {/* ══ HERO BANNER ══ */}
      <div style={{
        background:"linear-gradient(135deg,#0f172a 0%,#1e3a5f 55%,#1e293b 100%)",
        borderRadius:22, padding:"32px 36px", marginBottom:24,
        position:"relative", overflow:"hidden",
        boxShadow:"0 8px 32px rgba(0,0,0,.2)", animation:"fadeUp .4s ease both"
      }}>
        <div style={{ position:"absolute", inset:0, backgroundImage:"radial-gradient(circle at 15% 50%,rgba(249,115,22,.18) 0%,transparent 55%),radial-gradient(circle at 85% 20%,rgba(99,102,241,.15) 0%,transparent 50%)", pointerEvents:"none" }} />
        <div style={{ position:"relative", zIndex:1, display:"flex", alignItems:"center", gap:28, flexWrap:"wrap" }}>

          {/* Avatar */}
          <div style={{ width:88, height:88, borderRadius:"50%", background:"linear-gradient(135deg,#f97316,#ea580c)", display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, boxShadow:"0 8px 28px rgba(249,115,22,.45)", border:"3px solid rgba(255,255,255,.2)" }}>
            {userInfo.user?.profileImage
              ? <img src={`http://localhost:5000/${userInfo.user.profileImage}`} alt="profile" style={{ width:"100%", height:"100%", borderRadius:"50%", objectFit:"cover" }} />
              : <span style={{ fontSize:40, fontWeight:900, color:"#fff" }}>{adminName.charAt(0).toUpperCase()}</span>
            }
          </div>

          {/* Info */}
          <div style={{ flex:1, minWidth:180 }}>
            <h1 style={{ fontSize:26, fontWeight:900, color:"#fff", margin:"0 0 4px", letterSpacing:-.5 }}>{adminName}</h1>
            <p style={{ fontSize:13, color:"rgba(255,255,255,.6)", margin:"0 0 10px" }}>{adminEmail}</p>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              <span style={{ fontSize:11, fontWeight:800, padding:"4px 12px", borderRadius:20, background:"rgba(249,115,22,.2)", color:"#fb923c", border:"1px solid rgba(249,115,22,.3)" }}>⭐ {adminRole.toUpperCase()}</span>
              <span style={{ fontSize:11, fontWeight:800, padding:"4px 12px", borderRadius:20, background:"rgba(16,185,129,.2)", color:"#34d399", border:"1px solid rgba(16,185,129,.3)" }}>🟢 Active</span>
            </div>
          </div>

          {/* Stats */}
          {stats && (
            <div style={{ display:"flex", gap:2, background:"rgba(255,255,255,.06)", borderRadius:16, padding:"4px", border:"1px solid rgba(255,255,255,.1)" }}>
              {[
                { label:"Products", value:stats.totalProducts||0 },
                { label:"Orders",   value:stats.orders||0 },
                { label:"Users",    value:stats.totalUsers||0 },
                { label:"Revenue",  value:`₹${(stats.revenue||0).toLocaleString("en-IN")}` },
              ].map((s, i) => (
                <div key={s.label} style={{ padding:"12px 20px", textAlign:"center", borderRight:i<3?"1px solid rgba(255,255,255,.08)":"none" }}>
                  <div style={{ fontSize:20, fontWeight:900, color:"#fff", lineHeight:1 }}>{s.value}</div>
                  <div style={{ fontSize:10, color:"rgba(255,255,255,.45)", fontWeight:700, textTransform:"uppercase", letterSpacing:.8, marginTop:4 }}>{s.label}</div>
                </div>
              ))}
            </div>
          )}

          {/* Logout */}
          <button onClick={handleLogout} style={{ padding:"9px 20px", background:"rgba(239,68,68,.15)", border:"1.5px solid rgba(239,68,68,.3)", borderRadius:12, color:"#f87171", fontWeight:700, fontSize:13, cursor:"pointer", transition:"all .2s", whiteSpace:"nowrap" }}
            onMouseEnter={e=>e.currentTarget.style.background="rgba(239,68,68,.28)"}
            onMouseLeave={e=>e.currentTarget.style.background="rgba(239,68,68,.15)"}
          >⏻ Logout</button>
        </div>
      </div>

      {/* ══ TABS + CONTENT ══ */}
      <div style={{ display:"grid", gridTemplateColumns:"220px 1fr", gap:20, alignItems:"start" }}>

        {/* TAB SIDEBAR */}
        <div style={{ background:"#fff", borderRadius:18, padding:10, border:"1px solid #f1f5f9", boxShadow:"0 2px 12px rgba(0,0,0,.06)", position:"sticky", top:20, animation:"fadeUp .4s ease .1s both" }}>
          {TABS.map(t => (
            <button className="tab-b" key={t.key} onClick={() => setTab(t.key)} style={{
              display:"flex", alignItems:"center", gap:12, width:"100%",
              padding:"12px 14px", borderRadius:12, border:"none", cursor:"pointer",
              fontSize:14, textAlign:"left", transition:"all .18s", marginBottom:4,
              background: tab===t.key ? "linear-gradient(135deg,#f97316,#ea580c)" : "transparent",
              color:      tab===t.key ? "#fff" : "#64748b",
              fontWeight: tab===t.key ? 700 : 500,
              boxShadow:  tab===t.key ? "0 4px 14px rgba(249,115,22,.28)" : "none",
            }}>
              <div style={{ width:34, height:34, borderRadius:10, display:"flex", alignItems:"center", justifyContent:"center", fontSize:18,
                background: tab===t.key ? "rgba(255,255,255,.2)" : "#f8fafc",
                border:     tab===t.key ? "1px solid rgba(255,255,255,.3)" : "1px solid #f1f5f9"
              }}>{t.icon}</div>
              {t.label}
            </button>
          ))}
        </div>

        {/* CONTENT */}
        <div style={{ animation:"fadeUp .4s ease .15s both" }}>

          {/* ══ PROFILE INFO ══ */}
          {tab==="profile" && (
            <div style={CARD}>
              <div style={{ marginBottom:24 }}>
                <h2 style={TITLE}>👤 Profile Information</h2>
                <p style={SUB}>Changes are saved directly to the database</p>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:18, marginBottom:20 }}>
                {[
                  { label:"Full Name",     key:"name",    placeholder:"Your full name",    type:"text"  },
                  { label:"Email Address", key:"email",   placeholder:"your@email.com",    type:"email" },
                  { label:"Phone Number",  key:"phone",   placeholder:"Enter phone number", type:"text" },
                  { label:"Address",       key:"address", placeholder:"Enter address",      type:"text" },
                ].map(f => (
                  <div key={f.key}>
                    <label style={LBL}>{f.label}</label>
                    <input className="inp" type={f.type} value={form[f.key]}
                      onChange={e => setForm({...form, [f.key]:e.target.value})}
                      placeholder={f.placeholder}
                      style={{ width:"100%", padding:"11px 14px", border:"1.5px solid #e2e8f0", borderRadius:10, fontSize:13, color:"#1e293b", background:"#f8fafc", boxSizing:"border-box", transition:"all .18s", fontFamily:"inherit" }} />
                  </div>
                ))}
                <div>
                  <label style={LBL}>Role</label>
                  <input value={adminRole.charAt(0).toUpperCase()+adminRole.slice(1)} disabled
                    style={{ width:"100%", padding:"11px 14px", border:"1.5px solid #e2e8f0", borderRadius:10, fontSize:13, color:"#94a3b8", background:"#f8fafc", boxSizing:"border-box", fontFamily:"inherit" }} />
                </div>
                <div>
                  <label style={LBL}>Status</label>
                  <input value="Active" disabled
                    style={{ width:"100%", padding:"11px 14px", border:"1.5px solid #a7f3d0", borderRadius:10, fontSize:13, color:"#059669", background:"#ecfdf5", boxSizing:"border-box", fontWeight:700, fontFamily:"inherit" }} />
                </div>
              </div>

              {/* Info pills */}
              <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12, marginBottom:24 }}>
                {[
                  { icon:"📅", label:"Member Since", value:"April 2026" },
                  { icon:"🔑", label:"Last Login",   value:"Today"      },
                  { icon:"🛡️", label:"Access Level", value:"Full Admin" },
                ].map(p => (
                  <div key={p.label} style={{ display:"flex", alignItems:"center", gap:12, padding:"14px 16px", background:"#f8fafc", borderRadius:14, border:"1.5px solid #f1f5f9" }}>
                    <span style={{ fontSize:22, flexShrink:0 }}>{p.icon}</span>
                    <div>
                      <div style={{ fontSize:10, color:"#94a3b8", fontWeight:700, textTransform:"uppercase", letterSpacing:.8 }}>{p.label}</div>
                      <div style={{ fontSize:13, fontWeight:800, color:"#0f172a", marginTop:2 }}>{p.value}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ borderTop:"1px solid #f1f5f9", paddingTop:20 }}>
                <button className="save-b" onClick={handleSaveProfile} disabled={saving} style={{ padding:"12px 28px", background:"linear-gradient(135deg,#f97316,#ea580c)", color:"#fff", border:"none", borderRadius:12, fontWeight:800, fontSize:14, cursor:"pointer", boxShadow:"0 4px 16px rgba(249,115,22,.35)", transition:"all .2s" }}>
                  {saving ? "⏳ Saving..." : "💾 Save to Database"}
                </button>
              </div>
            </div>
          )}

          {/* ══ MY STATS ══ */}
          {tab==="stats" && (
            <div style={{ display:"flex", flexDirection:"column", gap:18 }}>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:16 }}>
                {stats ? [
                  { label:"Total Revenue",  value:`₹${(stats.revenue||0).toLocaleString("en-IN")}`, icon:"💰", color:"#f97316", light:"#fff7ed", border:"#fed7aa" },
                  { label:"Total Orders",   value:stats.orders||0,        icon:"📦", color:"#3b82f6", light:"#eff6ff", border:"#bfdbfe" },
                  { label:"Total Users",    value:stats.totalUsers||0,    icon:"👥", color:"#8b5cf6", light:"#f5f3ff", border:"#ddd6fe" },
                  { label:"Total Products", value:stats.totalProducts||0, icon:"🏪", color:"#10b981", light:"#ecfdf5", border:"#a7f3d0" },
                ].map(s => (
                  <div className="stat-c" key={s.label} style={{ background:"#fff", borderRadius:18, padding:"22px", border:"1.5px solid #f1f5f9", boxShadow:"0 2px 12px rgba(0,0,0,.05)", transition:"all .22s", position:"relative", overflow:"hidden" }}>
                    <div style={{ position:"absolute", top:0, left:0, right:0, height:4, background:s.color, borderRadius:"18px 18px 0 0" }} />
                    <div style={{ width:48, height:48, borderRadius:14, background:s.light, border:`1.5px solid ${s.border}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:24, marginBottom:16 }}>{s.icon}</div>
                    <div style={{ fontSize:11, color:"#94a3b8", fontWeight:700, textTransform:"uppercase", letterSpacing:1, marginBottom:6 }}>{s.label}</div>
                    <div style={{ fontSize:30, fontWeight:900, color:s.color, letterSpacing:-1 }}>{s.value}</div>
                  </div>
                )) : <p style={{ color:"#94a3b8", gridColumn:"span 2" }}>Loading stats...</p>}
              </div>

              <div style={CARD}>
                <h3 style={{ ...TITLE, marginBottom:6 }}>🛡️ Admin Permissions</h3>
                <p style={{ ...SUB, marginBottom:18 }}>Your access level grants the following permissions</p>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10 }}>
                  {["Manage Products","Manage Users","View Orders","Update Order Status","Manage Coupons","View Reports","Export Data","Manage Notifications"].map(p => (
                    <div className="perm-i" key={p} style={{ display:"flex", alignItems:"center", gap:10, padding:"12px 14px", background:"#f8fafc", borderRadius:12, border:"1.5px solid #f1f5f9", transition:"all .18s" }}>
                      <div style={{ width:24, height:24, borderRadius:"50%", background:"#ecfdf5", border:"1.5px solid #a7f3d0", display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, flexShrink:0 }}>✓</div>
                      <span style={{ fontSize:13, fontWeight:600, color:"#374151" }}>{p}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ══ RECENT ACTIVITY ══ */}
          {tab==="activity" && (
            <div style={CARD}>

              {/* ── Header with dynamic limit selector ── */}
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:20, flexWrap:"wrap", gap:12 }}>
                <div>
                  <h2 style={TITLE}>🕐 Recent Orders</h2>
                  <p style={SUB}>
                    Showing <span style={{ color:"#f97316", fontWeight:800 }}>{orders.length}</span> orders
                    {limit < 9999 ? ` (last ${limit})` : " (all)"}
                  </p>
                </div>

                {/* ── LIMIT SELECTOR ── */}
                <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                  <span style={{ fontSize:12, color:"#94a3b8", fontWeight:700 }}>Show:</span>
                  <div style={{ display:"flex", gap:6 }}>
                    {[5, 10, 20, 50].map(n => (
                      <button key={n} onClick={() => setLimit(n)} style={{
                        padding:"6px 14px", borderRadius:20, fontSize:12, fontWeight:700,
                        cursor:"pointer", border:"1.5px solid", transition:"all .18s",
                        background: limit===n ? "#f97316" : "#fff",
                        borderColor: limit===n ? "#f97316" : "#e2e8f0",
                        color: limit===n ? "#fff" : "#64748b",
                        boxShadow: limit===n ? "0 2px 8px rgba(249,115,22,.3)" : "none",
                      }}>{n}</button>
                    ))}
                    <button onClick={() => setLimit(9999)} style={{
                      padding:"6px 14px", borderRadius:20, fontSize:12, fontWeight:700,
                      cursor:"pointer", border:"1.5px solid", transition:"all .18s",
                      background: limit===9999 ? "#f97316" : "#fff",
                      borderColor: limit===9999 ? "#f97316" : "#e2e8f0",
                      color: limit===9999 ? "#fff" : "#64748b",
                      boxShadow: limit===9999 ? "0 2px 8px rgba(249,115,22,.3)" : "none",
                    }}>All</button>
                  </div>
                </div>
              </div>

              {loading ? (
                <div style={{ padding:60, display:"flex", flexDirection:"column", alignItems:"center", gap:14, color:"#94a3b8" }}>
                  <div style={{ width:40, height:40, borderRadius:"50%", border:"4px solid #f1f5f9", borderTop:"4px solid #f97316", animation:"spin .8s linear infinite" }} />
                  <p style={{ margin:0, fontWeight:600 }}>Loading orders…</p>
                </div>
              ) : orders.length===0 ? (
                <div style={{ padding:60, display:"flex", flexDirection:"column", alignItems:"center", gap:12, color:"#94a3b8" }}>
                  <span style={{ fontSize:48 }}>📭</span>
                  <p style={{ margin:0, fontWeight:600, fontSize:15 }}>No orders found</p>
                </div>
              ) : (
                <>
                  {/* Table header */}
                  <div style={{ display:"grid", gridTemplateColumns:"130px 1fr 130px 120px", gap:12, padding:"10px 14px", background:"linear-gradient(135deg,#f8fafc,#f1f5f9)", borderRadius:12, marginBottom:8, border:"1px solid #f1f5f9" }}>
                    {["Order ID","Customer","Amount","Status"].map(h => (
                      <div key={h} style={{ fontSize:11, fontWeight:800, color:"#64748b", textTransform:"uppercase", letterSpacing:.8 }}>{h}</div>
                    ))}
                  </div>

                  {orders.map((o, i) => {
                    const sc = STATUS_MAP[o.status] || STATUS_MAP.pending;
                    return (
                      <div className="ord-r" key={o._id} style={{ display:"grid", gridTemplateColumns:"130px 1fr 130px 120px", gap:12, padding:"12px 14px", borderRadius:12, transition:"background .15s", borderBottom:i<orders.length-1?"1px solid #f8fafc":"none", alignItems:"center" }}>
                        <div style={{ fontSize:12, fontWeight:800, color:"#f97316", fontFamily:"monospace", background:"#fff7ed", padding:"3px 8px", borderRadius:8, border:"1px solid #fed7aa", display:"inline-block" }}>
                          #{o._id?.slice(-6).toUpperCase()}
                        </div>
                        <div>
                          <div style={{ fontSize:13, fontWeight:700, color:"#1e293b" }}>{o.shippingAddress?.fullName || o.user?.name || "Unknown"}</div>
                          <div style={{ fontSize:11, color:"#94a3b8", marginTop:2 }}>
                            {o.orderItems?.length} item{o.orderItems?.length>1?"s":""} · {timeAgo(o.createdAt)}
                          </div>
                        </div>
                        <div style={{ fontSize:14, fontWeight:900, color:"#0f172a" }}>₹{o.totalPrice?.toLocaleString("en-IN")}</div>
                        <span style={{ fontSize:11, fontWeight:800, padding:"4px 12px", borderRadius:20, background:sc.bg, color:sc.color, border:`1.5px solid ${sc.border}`, display:"inline-block" }}>
                          {o.status}
                        </span>
                      </div>
                    );
                  })}

                  {/* Footer count */}
                  <div style={{ marginTop:14, paddingTop:14, borderTop:"1px solid #f1f5f9", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontSize:12, color:"#94a3b8", fontWeight:600 }}>
                      Showing {orders.length} order{orders.length!==1?"s":""}
                    </span>
                    <div style={{ display:"flex", gap:6, alignItems:"center" }}>
                      <span style={{ fontSize:12, color:"#94a3b8" }}>Quick select:</span>
                      {[5,10,20,50].map(n=>(
                        <button key={n} onClick={()=>setLimit(n)} style={{ fontSize:11, padding:"3px 10px", borderRadius:20, border:`1px solid ${limit===n?"#f97316":"#e2e8f0"}`, background:limit===n?"#fff7ed":"transparent", color:limit===n?"#f97316":"#94a3b8", cursor:"pointer", fontWeight:700, transition:"all .15s" }}>{n}</button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ══ SECURITY ══ */}
          {tab==="security" && (
            <div style={{ display:"flex", flexDirection:"column", gap:18 }}>

              <div style={CARD}>
                <div style={{ marginBottom:22 }}>
                  <h2 style={TITLE}>🔒 Change Password</h2>
                  <p style={SUB}>Password will be updated in the database</p>
                </div>

                <div style={{ display:"flex", flexDirection:"column", gap:16, maxWidth:440 }}>
                  <div>
                    <label style={LBL}>Current Password</label>
                    <div style={{ position:"relative" }}>
                      <input className="inp" type={showPwd?"text":"password"} value={form.currentPassword}
                        onChange={e=>setForm({...form, currentPassword:e.target.value})}
                        placeholder="Your current password"
                        style={{ width:"100%", padding:"11px 44px 11px 14px", border:"1.5px solid #e2e8f0", borderRadius:10, fontSize:13, color:"#1e293b", background:"#f8fafc", boxSizing:"border-box", transition:"all .18s", fontFamily:"inherit" }} />
                      <button onClick={()=>setShowPwd(p=>!p)} style={{ position:"absolute", right:12, top:"50%", transform:"translateY(-50%)", background:"none", border:"none", cursor:"pointer", fontSize:17, padding:2 }}>
                        {showPwd?"🙈":"👁"}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label style={LBL}>New Password</label>
                    <input className="inp" type="password" value={form.newPassword}
                      onChange={e=>setForm({...form, newPassword:e.target.value})}
                      placeholder="Min 6 characters"
                      style={{ width:"100%", padding:"11px 14px", border:"1.5px solid #e2e8f0", borderRadius:10, fontSize:13, color:"#1e293b", background:"#f8fafc", boxSizing:"border-box", transition:"all .18s", fontFamily:"inherit" }} />
                    {/* Password strength bar */}
                    {form.newPassword && (
                      <div style={{ marginTop:8, display:"flex", gap:4, alignItems:"center" }}>
                        {[1,2,3,4].map(n=>(
                          <div key={n} style={{ height:4, flex:1, borderRadius:2, transition:"background .3s",
                            background: form.newPassword.length>=n*2
                              ? form.newPassword.length>=8 ? "#10b981" : form.newPassword.length>=6 ? "#f59e0b" : "#ef4444"
                              : "#e2e8f0"
                          }} />
                        ))}
                        <span style={{ fontSize:10, color:"#94a3b8", marginLeft:6, whiteSpace:"nowrap" }}>
                          {form.newPassword.length<6?"Weak":form.newPassword.length<8?"Fair":"Strong"}
                        </span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label style={LBL}>Confirm New Password</label>
                    <input className="inp" type="password" value={form.confirmPassword}
                      onChange={e=>setForm({...form, confirmPassword:e.target.value})}
                      placeholder="Repeat new password"
                      style={{ width:"100%", padding:"11px 14px", borderRadius:10, fontSize:13, color:"#1e293b", background:"#f8fafc", boxSizing:"border-box", transition:"all .18s", fontFamily:"inherit",
                        border: form.confirmPassword && form.confirmPassword!==form.newPassword ? "1.5px solid #ef4444" : "1.5px solid #e2e8f0"
                      }} />
                    {form.confirmPassword && form.confirmPassword!==form.newPassword && (
                      <p style={{ fontSize:11, color:"#ef4444", marginTop:5, fontWeight:600 }}>⚠ Passwords don't match</p>
                    )}
                    {form.confirmPassword && form.confirmPassword===form.newPassword && form.newPassword && (
                      <p style={{ fontSize:11, color:"#10b981", marginTop:5, fontWeight:600 }}>✓ Passwords match</p>
                    )}
                  </div>
                </div>

                <div style={{ marginTop:22, paddingTop:18, borderTop:"1px solid #f1f5f9" }}>
                  <button className="save-b" onClick={handleChangePassword} disabled={saving} style={{ padding:"12px 28px", background:"linear-gradient(135deg,#f97316,#ea580c)", color:"#fff", border:"none", borderRadius:12, fontWeight:800, fontSize:14, cursor:"pointer", boxShadow:"0 4px 16px rgba(249,115,22,.35)", transition:"all .2s" }}>
                    {saving ? "⏳ Updating..." : "🔒 Update Password"}
                  </button>
                </div>
              </div>

              {/* Security tips */}
              <div style={{ ...CARD, background:"linear-gradient(135deg,#fffbeb,#fff7ed)" }}>
                <h4 style={{ fontSize:14, fontWeight:800, color:"#92400e", margin:"0 0 14px" }}>🛡️ Security Tips</h4>
                <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                  {["Use at least 8 characters with numbers and symbols","Don't reuse passwords from other accounts","Change your password every 3 months","Never share your admin credentials"].map(tip=>(
                    <div key={tip} style={{ display:"flex", alignItems:"flex-start", gap:10, padding:"10px 14px", background:"rgba(255,255,255,.6)", borderRadius:10, border:"1px solid #fde68a" }}>
                      <span style={{ color:"#f97316", fontWeight:900, fontSize:16, marginTop:1, flexShrink:0 }}>•</span>
                      <span style={{ fontSize:13, color:"#78350f", fontWeight:500, lineHeight:1.5 }}>{tip}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Danger zone */}
              <div style={{ ...CARD, border:"1.5px solid #fecaca" }}>
                <h4 style={{ fontSize:14, fontWeight:800, color:"#dc2626", margin:"0 0 6px" }}>⚠️ Danger Zone</h4>
                <p style={{ fontSize:13, color:"#64748b", marginBottom:16 }}>This will immediately log you out and clear your session.</p>
                <button onClick={handleLogout} style={{ padding:"11px 22px", background:"#fef2f2", border:"1.5px solid #fecaca", borderRadius:12, color:"#dc2626", fontWeight:800, fontSize:13, cursor:"pointer", transition:"all .2s" }}
                  onMouseEnter={e=>e.currentTarget.style.background="#fee2e2"}
                  onMouseLeave={e=>e.currentTarget.style.background="#fef2f2"}
                >⏻ Logout from All Sessions</button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

/* shared */
const CARD = { background:"#fff", borderRadius:18, padding:"24px 26px", border:"1px solid #f1f5f9", boxShadow:"0 2px 12px rgba(0,0,0,.06)" };
const TITLE = { fontSize:17, fontWeight:900, color:"#0f172a", margin:"0 0 4px" };
const SUB   = { fontSize:12, color:"#94a3b8", margin:0, fontWeight:500 };
const LBL   = { display:"block", fontSize:11, fontWeight:800, color:"#64748b", textTransform:"uppercase", letterSpacing:.8, marginBottom:7 };
