import { io } from "socket.io-client"
import { useEffect, useState } from "react";
import API from "../api/axios";
import { useNavigate } from "react-router-dom";

const IMG_BASE = "http://localhost:5000";

const getImageSrc = (p) => {
  if (!p || typeof p !== "object") return null;
  if (Array.isArray(p.images) && p.images.length > 0) {
    const img = p.images[0];
    if (typeof img === "string" && img.trim().length > 0)
      return img.startsWith("http") ? img : `${IMG_BASE}${img}`;
  }
  if (typeof p.image === "string" && p.image.trim().length > 0)
    return p.image.startsWith("http") ? p.image : `${IMG_BASE}${p.image}`;
  return null;
};

const FALLBACK = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48'%3E%3Crect width='48' height='48' fill='%23fff3e6'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' font-size='9' fill='%23ffaa70'%3ENo img%3C/text%3E%3C/svg%3E";
const STOCK_FILTERS = ["All", "In Stock", "Low Stock", "Out of Stock"];

export default function Products() {
  const [products,       setProducts]       = useState([]);
  const [selected,       setSelected]       = useState(null);
  const [search,         setSearch]         = useState("");
  const [filterCategory, setFilterCategory] = useState("All");
  const [filterStock,    setFilterStock]    = useState("All");
  const [loading,        setLoading]        = useState(true);
  const navigate = useNavigate();

  useEffect(() => { fetchProducts(); }, []);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const { data } = await API.get("/products");
      if (Array.isArray(data)) setProducts(data);
      else if (Array.isArray(data.products)) setProducts(data.products);
      else setProducts([]);
    } catch (err) {
      console.log(err);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
  socket.on("orderUpdated", () => {
    fetchProducts(); // ✅ refresh stock on cancel / order / return
  });

  return () => socket.off("orderUpdated");
}, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this product?")) return;
    try {
      await API.delete(`/products/${id}`);
      fetchProducts();
    } catch { alert("Delete failed"); }
  };

  const stockStatus = (count) => {
    if (count === 0)  return { label: "Out of Stock", color: "#ef4444", bg: "#fef2f2", border: "#fecaca" };
    if (count <= 10)  return { label: "Low Stock",    color: "#f59e0b", bg: "#fffbeb", border: "#fde68a" };
    return              { label: "In Stock",      color: "#10b981", bg: "#ecfdf5", border: "#6ee7b7" };
  };

  const categories = ["All", ...new Set(products.filter(p => p?.category).map(p => p.category))];

  const inStockCount  = products.filter(p => p.countInStock > 10).length;
  const lowStockCount = products.filter(p => p.countInStock > 0 && p.countInStock <= 10).length;
  const outCount      = products.filter(p => p.countInStock === 0).length;

  const stockFilterCount = {
    "All": products.length,
    "In Stock": inStockCount,
    "Low Stock": lowStockCount,
    "Out of Stock": outCount,
  };

  const filtered = products.filter(p => {
    const matchSearch = p.name?.toLowerCase().includes(search.toLowerCase()) || p.brand?.toLowerCase().includes(search.toLowerCase());
    const matchCat    = filterCategory === "All" || p.category === filterCategory;
    const matchStock  =
      filterStock === "All"          ? true :
      filterStock === "In Stock"     ? p.countInStock > 10 :
      filterStock === "Low Stock"    ? p.countInStock > 0 && p.countInStock <= 10 :
      filterStock === "Out of Stock" ? p.countInStock === 0 : true;
    return matchSearch && matchCat && matchStock;
  });

  return (
    <div style={{ padding: "28px", fontFamily: "'Nunito', sans-serif", background: "#fdf8f3", minHeight: "100vh" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        .prod-row:hover { background: #fff8f2 !important; }
        .prod-row:hover .prod-name { color: #ff6f00 !important; }
        .stat-c:hover { transform: translateY(-3px) !important; box-shadow: 0 8px 24px rgba(255,111,0,0.15) !important; }
        .act-btn:hover { transform: scale(1.1) !important; }
        .add-btn:hover { opacity: 0.88 !important; transform: translateY(-1px) !important; }
        .cat-btn:hover { border-color: #ffaa44 !important; color: #ff6f00 !important; }
        .modal-edit:hover { opacity: 0.9 !important; }
        .modal-del:hover { background: #ef4444 !important; color: #fff !important; }
        input:focus { border-color: #ff6f00 !important; box-shadow: 0 0 0 3px rgba(255,111,0,0.1) !important; outline: none !important; }
      `}</style>

      {/* ── HEADER ── */}
      <div style={{
  background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
  borderRadius: 22, padding: "26px 32px", marginBottom: 24,
  position: "relative", overflow: "hidden",
  boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
  animation: "fadeUp 0.4s ease both",
}}>
  <div style={{ position:"absolute", top:-40, right:-40, width:180, height:180, borderRadius:"50%", background:"rgba(255,255,255,0.08)" }} />
  <div style={{ position:"absolute", bottom:-50, left:"35%", width:220, height:220, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }} />
  <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
    <div>
      <h1 style={{ margin:0, fontSize:28, fontWeight:900, color:"#fff", letterSpacing:-0.5 }}>📦 Products</h1>
      <p style={{ margin:"5px 0 0", fontSize:13, color:"rgba(255,255,255,0.8)", fontWeight:700 }}>{products.length} total products</p>
    </div>
    <button className="add-btn" onClick={() => navigate("/add-product")} style={{
      background:"rgba(255,255,255,0.2)", color:"#fff",
      border:"1.5px solid rgba(255,255,255,0.4)",
      padding:"10px 22px", borderRadius:12,
      cursor:"pointer", fontWeight:800, fontSize:14,
      fontFamily:"inherit", transition:"all 0.2s",
      backdropFilter:"blur(8px)",
    }}>
      ＋ Add Product
    </button>
  </div>
</div>

      {/* ── STAT CARDS ── */}
      <div style={{ display: "flex", gap: 16, marginBottom: 20, animation: "fadeUp 0.4s ease 0.1s both" }}>
        {[
          { label: "Total",        value: products.length, accent: "#ff6f00", light: "#fff7ed", filter: "All" },
          { label: "In Stock",     value: inStockCount,    accent: "#10b981", light: "#ecfdf5", filter: "In Stock" },
          { label: "Low Stock",    value: lowStockCount,   accent: "#f59e0b", light: "#fffbeb", filter: "Low Stock" },
          { label: "Out of Stock", value: outCount,        accent: "#ef4444", light: "#fef2f2", filter: "Out of Stock" },
        ].map(s => (
          <div
            key={s.label}
            className="stat-c"
            onClick={() => setFilterStock(s.filter)}
            style={{
              flex: 1, background: filterStock === s.filter ? s.light : "#fff",
              borderRadius: 16, padding: "18px 20px",
              border: `1.5px solid ${filterStock === s.filter ? s.accent + "55" : "#ffe0c2"}`,
              cursor: "pointer", transition: "all 0.2s",
              boxShadow: filterStock === s.filter ? `0 0 0 2px ${s.accent}44, 0 4px 16px rgba(255,111,0,0.1)` : "0 2px 8px rgba(255,111,0,0.06)",
              position: "relative", overflow: "hidden",
            }}
          >
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: s.accent, borderRadius: "16px 16px 0 0" }} />
            <div style={{ fontSize: 30, fontWeight: 900, color: s.accent, lineHeight: 1 }}>{s.value}</div>
            <div style={{ fontSize: 12, color: "#aaa", marginTop: 5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>{s.label}</div>
            {filterStock === s.filter && (
              <div style={{ fontSize: 10, color: s.accent, fontWeight: 800, marginTop: 4 }}>● Active filter</div>
            )}
          </div>
        ))}
      </div>

      {/* ── STOCK FILTER TABS ── */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap", alignItems: "center", animation: "fadeUp 0.4s ease 0.15s both" }}>
        {STOCK_FILTERS.map(f => (
          <button key={f} onClick={() => setFilterStock(f)} style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "7px 14px", borderRadius: 10,
            border: filterStock === f ? "none" : "1.5px solid #ffe0c2",
            background: filterStock === f ? "#ff6f00" : "#fff",
            color: filterStock === f ? "#fff" : "#888",
            cursor: "pointer", fontSize: 13, fontWeight: 800,
            fontFamily: "inherit", transition: "all 0.15s",
            boxShadow: filterStock === f ? "0 3px 10px rgba(255,111,0,0.3)" : "none",
          }}>
            {f}
            <span style={{
              fontSize: 11, padding: "2px 7px", borderRadius: 99, fontWeight: 900,
              background: filterStock === f ? "rgba(255,255,255,0.25)" : "#fff3e6",
              color: filterStock === f ? "#fff" : "#ff6f00",
            }}>
              {stockFilterCount[f]}
            </span>
          </button>
        ))}
        {filterStock !== "All" && (
          <button onClick={() => setFilterStock("All")} style={{
            padding: "7px 12px", borderRadius: 10,
            border: "1.5px solid #fecaca", background: "#fef2f2",
            cursor: "pointer", fontSize: 12, color: "#ef4444",
            fontWeight: 800, fontFamily: "inherit",
          }}>✕ Clear</button>
        )}
      </div>

      {/* ── SEARCH + CATEGORY ── */}
      <div style={{ display: "flex", gap: 12, marginBottom: 10, flexWrap: "wrap", alignItems: "center", animation: "fadeUp 0.4s ease 0.2s both" }}>
        <div style={{ position: "relative" }}>
          <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 14, color: "#ffaa70" }}>🔍</span>
          <input
            placeholder="Search by name or brand..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{
              padding: "10px 14px 10px 36px",
              borderRadius: 10, border: "1.5px solid #ffe0c2",
              fontSize: 13, width: 280,
              fontFamily: "inherit", background: "#fff",
              transition: "all 0.2s", color: "#1a1a1a",
            }}
          />
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {categories.map(c => (
            <button
              key={c}
              className="cat-btn"
              onClick={() => setFilterCategory(c)}
              style={{
                padding: "6px 14px", borderRadius: 20,
                border: filterCategory === c ? "none" : "1.5px solid #ffe0c2",
                background: filterCategory === c ? "linear-gradient(135deg,#ff6f00,#ffaa44)" : "#fff",
                color: filterCategory === c ? "#fff" : "#888",
                cursor: "pointer", fontSize: 12, fontWeight: 800,
                fontFamily: "inherit", transition: "all 0.15s",
                boxShadow: filterCategory === c ? "0 3px 10px rgba(255,111,0,0.25)" : "none",
              }}
            >{c}</button>
          ))}
        </div>
      </div>

      {/* ── RESULTS NOTE ── */}
      {!loading && (
        <p style={{ fontSize: 12, color: "#ffaa70", marginBottom: 12, fontWeight: 700 }}>
          Showing {filtered.length} of {products.length} products
          {filterStock !== "All" && ` · ${filterStock}`}
          {filterCategory !== "All" && ` · ${filterCategory}`}
        </p>
      )}

      {/* ── TABLE ── */}
      <div style={{
        background: "#fff", borderRadius: 18,
        border: "1.5px solid #ffe0c2",
        boxShadow: "0 4px 18px rgba(255,111,0,0.07)",
        overflow: "hidden", position: "relative",
        animation: "fadeUp 0.4s ease 0.25s both",
      }}>
        {/* Top accent */}
        <div style={{ height: 4, background: "linear-gradient(90deg, #ff6f00, #ffaa44)" }} />

        {loading ? (
          <div style={{ padding: 60, textAlign: "center", color: "#ffaa70", fontSize: 15, fontWeight: 700 }}>
            <div style={{ width: 40, height: 40, border: "4px solid #ffe0c2", borderTopColor: "#ff6f00", borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 16px" }} />
            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
            Loading products...
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ padding: 60, textAlign: "center", color: "#ffaa70", display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
            <span style={{ fontSize: 48 }}>📦</span>
            <p style={{ fontWeight: 800, fontSize: 16, color: "#1a1a1a" }}>No products found</p>
            <p style={{ fontSize: 13, color: "#aaa" }}>Try adjusting your filters</p>
          </div>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#fff8f2", borderBottom: "1.5px solid #ffe0c2" }}>
                {["Product", "Brand", "Category", "Price", "Stock", "Status", "Actions"].map(h => (
                  <th key={h} style={{
                    padding: "13px 16px", textAlign: "left",
                    fontSize: 11, fontWeight: 800, color: "#ffaa70",
                    textTransform: "uppercase", letterSpacing: 0.6,
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.filter(p => p && typeof p === "object").map((p, idx) => {
                const stock  = stockStatus(p.countInStock);
                const imgSrc = getImageSrc(p);
                return (
                  <tr
                    key={p._id}
                    className="prod-row"
                    style={{
                      borderBottom: "1px solid #fff3e6",
                      transition: "background 0.15s",
                      animation: `fadeUp 0.3s ease ${idx * 0.03}s both`,
                    }}
                  >
                    <td style={{ padding: "14px 16px", verticalAlign: "middle" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <div style={{
                          width: 48, height: 48, borderRadius: 12,
                          overflow: "hidden", flexShrink: 0,
                          border: "1.5px solid #ffe0c2",
                          background: "#fff8f2",
                        }}>
                          <img
                            src={imgSrc || FALLBACK}
                            alt={p.name}
                            style={{ width: "100%", height: "100%", objectFit: "cover" }}
                            onError={e => { e.target.onerror = null; e.target.src = FALLBACK; }}
                          />
                        </div>
                        <div>
                          <div className="prod-name" style={{ fontWeight: 800, color: "#1a1a1a", fontSize: 14, transition: "color 0.15s" }}>{p.name}</div>
                          {p.isFeatured && (
                            <span style={{ background: "#fff3e6", color: "#ff6f00", fontSize: 10, padding: "2px 8px", borderRadius: 10, fontWeight: 800, border: "1px solid #ffe0c2" }}>⭐ Featured</span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: "14px 16px", verticalAlign: "middle" }}>
                      <span style={{ background: "#fff3e6", color: "#ff6f00", fontSize: 12, padding: "4px 10px", borderRadius: 8, fontWeight: 700, border: "1px solid #ffe0c2" }}>{p.brand}</span>
                    </td>
                    <td style={{ padding: "14px 16px", verticalAlign: "middle" }}>
                      <span style={{ background: "#fff8f2", color: "#ffaa44", fontSize: 12, padding: "4px 10px", borderRadius: 8, fontWeight: 700, border: "1px solid #ffe0c2" }}>{p.category}</span>
                    </td>
                    <td style={{ padding: "14px 16px", verticalAlign: "middle", fontWeight: 900, color: "#ff6f00", fontSize: 15 }}>
                      ₹{p.price?.toLocaleString()}
                    </td>
                    <td style={{ padding: "14px 16px", verticalAlign: "middle", fontWeight: 800, color: "#1a1a1a" }}>
                      {p.countInStock}
                    </td>
                    <td style={{ padding: "14px 16px", verticalAlign: "middle" }}>
                      <span style={{
                        fontSize: 12, padding: "4px 12px", borderRadius: 20,
                        fontWeight: 800, border: `1px solid ${stock.border}`,
                        color: stock.color, background: stock.bg,
                        whiteSpace:"nowrap",
                      }}>{stock.label}</span>
                    </td>
                    <td style={{ padding: "14px 16px", verticalAlign: "middle",whiteSpace:"nowrap" }}>
                      <div style={{ display: "flex", gap: 6 }}>
                        {[
                          { icon: "👁", bg: "#fff3e6", title: "View",   fn: () => setSelected(p) },
                          { icon: "✏️", bg: "#fff8f2", title: "Edit",   fn: () => navigate(`/edit-product/${p._id}`) },
                          { icon: "🗑", bg: "#fef2f2", title: "Delete", fn: () => handleDelete(p._id) },
                        ].map(a => (
                          <button
                            key={a.title}
                            className="act-btn"
                            onClick={a.fn}
                            title={a.title}
                            style={{
                              width: 32, height: 32, borderRadius: 8,
                              border: "1.5px solid #ffe0c2",
                              background: a.bg, cursor: "pointer",
                              fontSize: 14, transition: "all 0.15s",
                              display: "flex", alignItems: "center", justifyContent: "center",
                            }}
                          >{a.icon}</button>
                        ))}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* ── MODAL ── */}
      {selected && (
        <div
          onClick={() => setSelected(null)}
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, backdropFilter: "blur(4px)" }}
        >
          <div
            onClick={e => e.stopPropagation()}
            style={{
              background: "#fff", borderRadius: 22, width: 520,
              maxWidth: "92vw", overflow: "hidden",
              boxShadow: "0 24px 60px rgba(255,111,0,0.2)",
              border: "1.5px solid #ffe0c2",
            }}
          >
            {/* Modal top bar */}
            <div style={{ height: 5, background: "linear-gradient(90deg,#ff6f00,#ffaa44)" }} />

            {/* Modal header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 24px", borderBottom: "1.5px solid #fff3e6" }}>
              <h3 style={{ fontSize: 18, fontWeight: 900, color: "#1a1a1a", margin: 0 }}>{selected.name}</h3>
              <button onClick={() => setSelected(null)} style={{ background: "#fff3e6", border: "none", borderRadius: 8, width: 32, height: 32, cursor: "pointer", fontSize: 14, color: "#ff6f00", fontWeight: 900 }}>✕</button>
            </div>

            {/* Modal body */}
            <div style={{ padding: 24, display: "flex", gap: 20 }}>
              <div style={{ width: 140, height: 140, borderRadius: 16, overflow: "hidden", border: "1.5px solid #ffe0c2", background: "#fff8f2", flexShrink: 0 }}>
                <img
                  src={getImageSrc(selected) || FALLBACK}
                  alt={selected.name}
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                  onError={e => { e.target.onerror = null; e.target.src = FALLBACK; }}
                />
              </div>
              <div style={{ flex: 1 }}>
                {[
                  ["Brand",    selected.brand],
                  ["Category", selected.category],
                  ["Price",    `₹${selected.price?.toLocaleString()}`],
                  ["Stock",    selected.countInStock],
                  ["Rating",   `${selected.rating ?? "N/A"} ⭐`],
                  ["Discount", selected.discount ? `${selected.discount}%` : "None"],
                ].map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", marginBottom: 10, paddingBottom: 10, borderBottom: "1px solid #fff3e6" }}>
                    <span style={{ fontSize: 11, color: "#ffaa70", fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.5 }}>{k}</span>
                    <span style={{ fontSize: 13, color: "#1a1a1a", fontWeight: 800 }}>{v}</span>
                  </div>
                ))}
                {selected.description && (
                  <div style={{ marginTop: 6 }}>
                    <div style={{ fontSize: 11, color: "#ffaa70", fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 }}>Description</div>
                    <p style={{ fontSize: 12, color: "#888", lineHeight: 1.6, margin: 0 }}>{selected.description}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Modal footer */}
            <div style={{ padding: "16px 24px", borderTop: "1.5px solid #fff3e6", display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button
                className="modal-edit"
                onClick={() => navigate(`/edit-product/${selected._id}`)}
                style={{
                  background: "linear-gradient(135deg,#ff6f00,#ff9500)",
                  color: "#fff", border: "none",
                  padding: "10px 20px", borderRadius: 10,
                  cursor: "pointer", fontWeight: 800, fontSize: 13,
                  fontFamily: "inherit", transition: "opacity 0.2s",
                  boxShadow: "0 4px 12px rgba(255,111,0,0.3)",
                }}
              >✏️ Edit Product</button>
              <button
                className="modal-del"
                onClick={() => { handleDelete(selected._id); setSelected(null); }}
                style={{
                  background: "#fef2f2", color: "#ef4444",
                  border: "1.5px solid #fecaca",
                  padding: "10px 20px", borderRadius: 10,
                  cursor: "pointer", fontWeight: 800, fontSize: 13,
                  fontFamily: "inherit", transition: "all 0.15s",
                }}
              >🗑 Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const socket = io("http://localhost:5000", {
  transports: ["websocket"],
});
