import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import API from "../api/axios";

const FIELDS = [
  { key: "name",          label: "Product Name",      icon: "🏷️",  type: "text",     placeholder: "e.g. Nike Air Max",          span: 2 },
  { key: "brand",         label: "Brand",             icon: "🏢",  type: "text",     placeholder: "e.g. Nike",                  span: 1 },
  { key: "category",      label: "Category",          icon: "🗂️",  type: "text",     placeholder: "e.g. Sports",                span: 1 },
  { key: "price",         label: "Price (₹)",         icon: "💰",  type: "number",   placeholder: "e.g. 2999",                  span: 1 },
  { key: "originalPrice", label: "Original Price (₹)",icon: "🏷️",  type: "number",   placeholder: "e.g. 3499",                  span: 1 },
  { key: "discount",      label: "Discount (%)",      icon: "🎟️",  type: "number",   placeholder: "e.g. 10",                    span: 1 },
  { key: "countInStock",  label: "Count In Stock",    icon: "📦",  type: "number",   placeholder: "e.g. 50",                    span: 1 },
  { key: "rating",        label: "Rating",            icon: "⭐",  type: "number",   placeholder: "e.g. 4.5",                   span: 1 },
  { key: "delivery",      label: "Delivery Time",     icon: "🚚",  type: "text",     placeholder: "e.g. 3-5 Days",              span: 1 },
  { key: "returnPolicy",  label: "Return Policy",     icon: "↩️",  type: "text",     placeholder: "e.g. 7 Days Return",         span: 2 },
  { key: "description",   label: "Description",       icon: "📝",  type: "textarea", placeholder: "Product description...",     span: 2 },
];

export default function EditProduct() {
  const { id }   = useParams();
  const navigate = useNavigate();
  const fileRef  = useRef();

  const [form,     setForm]     = useState({});
  const [original, setOriginal] = useState({});
  const [loading,  setLoading]  = useState(true);
  const [saving,   setSaving]   = useState(false);
  const [msg,      setMsg]      = useState(null);
  const [preview,  setPreview]  = useState(null);
  const [dragOver, setDragOver] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const { data } = await API.get(`/products/${id}`);
        setForm(data);
        setOriginal(data);
        if (data.images?.[0])    setPreview(data.images[0]);
        else if (data.image)     setPreview(data.image);
      } catch {
        setMsg({ text: "❌ Error loading product", type: "error" });
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleImage = (file) => {
    if (!file) return;
    setForm(f => ({ ...f, newImage: file }));
    setPreview(URL.createObjectURL(file));
  };

  const handleUpdate = async () => {
    if (!form.name?.trim())
      return setMsg({ text: "⚠️ Product name is required", type: "error" });
    setSaving(true);
    try {
      await API.put(`/products/${id}`, form, {
        headers: { Authorization: `Bearer ${sessionStorage.getItem("token")}` },
      });
      setMsg({ text: "✅ Product updated successfully!", type: "success" });
      setTimeout(() => navigate("/products"), 1400);
    } catch {
      setMsg({ text: "❌ Error updating product", type: "error" });
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm("Reset all changes to original values?")) return;
    setLoading(true);
    try {
      const { data } = await API.get(`/products/${id}`);
      setForm(data); setOriginal(data);
      if (data.images?.[0]) setPreview(data.images[0]);
      else if (data.image)  setPreview(data.image);
      setMsg({ text: "🔄 Changes reset to original", type: "info" });
    } catch {
      setMsg({ text: "❌ Error resetting", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  const imgSrc = preview
    ? preview.startsWith("blob:") || preview.startsWith("http")
      ? preview
      : `http://localhost:5000${preview}`
    : null;

  // ── Loading ───────────────────────────────────────────────
  if (loading) return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg,#fff8f2,#fff3e8,#ffecd8)", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{ width: 48, height: 48, borderRadius: "50%", border: "5px solid #ffd4a3", borderTop: "5px solid #ff6b00", animation: "spin 0.9s linear infinite" }} />
      <p style={{ color: "#ff6b00", marginTop: 16, fontWeight: 800 }}>Loading product...</p>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(160deg,#fff8f2,#fff3e8,#ffecd8)", padding: "28px 24px", fontFamily: "'Segoe UI', sans-serif" }}>
      <style>{`
        @keyframes fadeUp  { from{opacity:0;transform:translateY(14px)} to{opacity:1;transform:translateY(0)} }
        @keyframes spin    { to{transform:rotate(360deg)} }
        @keyframes shake   { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-5px)} 75%{transform:translateX(5px)} }
        .inp:focus  { border-color:#ff6b00!important; box-shadow:0 0 0 3px rgba(255,107,0,0.15)!important; outline:none; background:#fffaf7!important; }
        .inp:hover  { border-color:#ffb36b!important; }
        .save-btn:hover  { background:linear-gradient(135deg,#e55a00,#ff7700)!important; transform:translateY(-2px)!important; box-shadow:0 8px 24px rgba(255,107,0,0.45)!important; }
        .reset-btn:hover { background:#fff3e8!important; color:#ff6b00!important; border-color:#ff6b00!important; }
        .back-btn:hover  { background:#fff3e8!important; color:#ff6b00!important; }
        .drop-zone:hover { border-color:#ff6b00!important; background:#fff3e8!important; }
        .stat-card:hover { transform:scale(1.03); border-color:#ffb36b!important; }
      `}</style>

      <div style={{ maxWidth: 1100, margin: "0 auto" }}>

        {/* ── TOPBAR ── */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24, flexWrap: "wrap", gap: 12, animation: "fadeUp 0.35s ease both" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <button className="back-btn" onClick={() => navigate("/products")} style={{ background: "#fff", border: "2px solid #ffd4a3", borderRadius: 10, padding: "8px 16px", color: "#cc5500", fontWeight: 700, fontSize: 13, cursor: "pointer", transition: "all 0.2s" }}>← Back</button>
            <div>
              <h1 style={{ margin: 0, fontSize: 24, fontWeight: 900, color: "#3d1a00", letterSpacing: -0.5 }}>✏️ Edit Product</h1>
              <p style={{ margin: "3px 0 0", fontSize: 12, color: "#cc7a00", fontWeight: 600 }}>
                ID: <span style={{ fontFamily: "monospace", background: "#fff3e8", padding: "1px 8px", borderRadius: 6, border: "1px solid #ffd4a3", color: "#ff6b00" }}>{id?.slice(-8).toUpperCase()}</span>
              </p>
            </div>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button className="reset-btn" onClick={handleReset} style={{ padding: "9px 18px", background: "#fff", border: "2px solid #ffd4a3", borderRadius: 10, fontSize: 13, fontWeight: 700, color: "#cc5500", cursor: "pointer", transition: "all 0.2s" }}>↺ Reset</button>
            <button className="save-btn" onClick={handleUpdate} disabled={saving} style={{ padding: "9px 22px", background: saving ? "#ffb36b" : "linear-gradient(135deg,#ff6b00,#ff9500)", color: "#fff", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 800, cursor: saving ? "not-allowed" : "pointer", boxShadow: "0 4px 14px rgba(255,107,0,0.35)", transition: "all 0.22s", display: "flex", alignItems: "center", gap: 8 }}>
              {saving ? <><Spinner /> Saving...</> : "💾 Save Changes"}
            </button>
          </div>
        </div>

        {/* ── MSG ── */}
        {msg && (
          <div style={{
            padding: "13px 18px", borderRadius: 12, marginBottom: 20, fontWeight: 700, fontSize: 14,
            animation: msg.type === "error" ? "shake 0.35s ease" : "fadeUp 0.3s ease",
            background: msg.type === "success" ? "#d1fae5" : msg.type === "error" ? "#fee2e2" : "#fff3e8",
            color:      msg.type === "success" ? "#065f46"  : msg.type === "error" ? "#991b1b" : "#cc5500",
            border:     `2px solid ${msg.type === "success" ? "#6ee7b7" : msg.type === "error" ? "#fca5a5" : "#ffd4a3"}`,
          }}>{msg.text}</div>
        )}

        {/* ── MAIN LAYOUT ── */}
        <div style={{ display: "grid", gridTemplateColumns: "290px 1fr", gap: 20, alignItems: "start" }}>

          {/* ── LEFT PANEL ── */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16, animation: "fadeUp 0.4s ease 0.1s both" }}>

            {/* Image Card */}
            <div style={{ background: "#fff", borderRadius: 20, border: "2px solid #ffd4a3", overflow: "hidden", boxShadow: "0 4px 20px rgba(255,107,0,0.1)" }}>
              <div style={{ height: 4, background: "linear-gradient(90deg,#ff6b00,#ff9500,#ffb300)" }} />
              <div style={{ padding: 20 }}>
                <p style={SEC}>🖼️ Product Image</p>

                {/* Image box */}
                <div style={{ width: "100%", aspectRatio: "1", borderRadius: 14, overflow: "hidden", background: "#fff8f2", border: "2px solid #ffd4a3", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14, position: "relative" }}>
                  {imgSrc ? (
                    <img src={imgSrc} alt={form.name} style={{ width: "100%", height: "100%", objectFit: "contain" }} onError={e => e.target.style.display = "none"} />
                  ) : (
                    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", color: "#ffb36b" }}>
                      <span style={{ fontSize: 48 }}>📦</span>
                      <p style={{ fontSize: 12, marginTop: 8, fontWeight: 600 }}>No image</p>
                    </div>
                  )}
                </div>

                {/* Drop zone / change */}
                <div className="drop-zone" onClick={() => fileRef.current.click()}
                  onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={e => { e.preventDefault(); setDragOver(false); handleImage(e.dataTransfer.files[0]); }}
                  style={{ border: `2px dashed ${dragOver ? "#ff6b00" : "#ffd4a3"}`, borderRadius: 12, padding: "14px", textAlign: "center", cursor: "pointer", transition: "all 0.2s", background: dragOver ? "#fff3e8" : "#fffaf7" }}>
                  <p style={{ margin: 0, fontSize: 12, fontWeight: 700, color: "#cc5500" }}>📁 Click or drag to change image</p>
                  <input ref={fileRef} type="file" accept="image/*" onChange={e => handleImage(e.target.files[0])} style={{ display: "none" }} />
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div style={{ background: "#fff", borderRadius: 20, border: "2px solid #ffd4a3", overflow: "hidden", boxShadow: "0 4px 20px rgba(255,107,0,0.1)" }}>
              <div style={{ height: 4, background: "linear-gradient(90deg,#ff6b00,#ff9500,#ffb300)" }} />
              <div style={{ padding: 20 }}>
                <p style={SEC}>📊 Quick Stats</p>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  {[
                    { label: "Price",    value: form.price        ? `₹${Number(form.price).toLocaleString("en-IN")}` : "—", color: "#ff6b00" },
                    { label: "Stock",    value: form.countInStock ?? "—",    color: "#e07000" },
                    { label: "Rating",   value: form.rating       ? `${form.rating} ⭐` : "—", color: "#cc5500" },
                    { label: "Category", value: form.category     || "—",    color: "#b34700" },
                    { label: "Discount", value: form.discount     ? `${form.discount}%` : "0%", color: "#cc3300" },
                    { label: "Delivery", value: form.delivery     || "—",    color: "#cc5500" },
                  ].map(s => (
                    <div className="stat-card" key={s.label} style={{ background: "#fff8f2", borderRadius: 10, padding: "10px 12px", border: "2px solid #ffecd8", transition: "all 0.2s", cursor: "default" }}>
                      <div style={{ fontSize: 10, color: "#cc8833", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.8 }}>{s.label}</div>
                      <div style={{ fontSize: 14, fontWeight: 900, color: s.color, marginTop: 3 }}>{s.value}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Featured Toggle */}
            <div style={{ background: "#fff", borderRadius: 20, border: "2px solid #ffd4a3", overflow: "hidden", boxShadow: "0 4px 20px rgba(255,107,0,0.1)" }}>
              <div style={{ height: 4, background: "linear-gradient(90deg,#ff6b00,#ff9500,#ffb300)" }} />
              <div style={{ padding: 20 }}>
                <p style={SEC}>⭐ Visibility</p>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "#fff8f2", borderRadius: 12, padding: "14px 16px", border: "2px solid #ffecd8" }}>
                  <div>
                    <p style={{ fontWeight: 800, fontSize: 13, color: "#3d1a00", margin: 0 }}>Featured Product</p>
                    <p style={{ fontSize: 11, color: "#cc8833", margin: "3px 0 0" }}>Show on homepage</p>
                  </div>
                  <button onClick={() => setForm({ ...form, isFeatured: !form.isFeatured })} style={{ width: 46, height: 26, borderRadius: 99, border: "none", cursor: "pointer", position: "relative", transition: "background 0.25s", background: form.isFeatured ? "linear-gradient(135deg,#ff6b00,#ff9500)" : "#ffd4a3", boxShadow: form.isFeatured ? "0 3px 10px rgba(255,107,0,0.4)" : "none", flexShrink: 0 }}>
                    <div style={{ width: 20, height: 20, background: "#fff", borderRadius: "50%", position: "absolute", top: 3, left: 3, transition: "transform 0.25s", transform: form.isFeatured ? "translateX(20px)" : "translateX(0)", boxShadow: "0 1px 4px rgba(0,0,0,0.2)" }} />
                  </button>
                </div>

                {/* Last updated */}
                <p style={{ fontSize: 11, color: "#cc8833", marginTop: 12, textAlign: "center", fontWeight: 600 }}>
                  🕐 Last updated: {form.updatedAt ? new Date(form.updatedAt).toLocaleString("en-IN") : "—"}
                </p>
              </div>
            </div>
          </div>

          {/* ── RIGHT: FORM ── */}
          <div style={{ background: "#fff", borderRadius: 20, border: "2px solid #ffd4a3", overflow: "hidden", boxShadow: "0 4px 20px rgba(255,107,0,0.1)", animation: "fadeUp 0.4s ease 0.15s both" }}>
            <div style={{ height: 5, background: "linear-gradient(90deg,#ff6b00,#ff9500,#ffb300,#ffcc44)" }} />
            <div style={{ padding: "24px 28px" }}>
              <p style={{ ...SEC, marginBottom: 20 }}>📋 Product Details</p>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px 20px" }}>
                {FIELDS.map(({ key, label, icon, type, placeholder, span }) => {
                  const value = form[key] ?? "";
                  const displayVal = typeof value === "object" ? JSON.stringify(value) : value;
                  return (
                    <div key={key} style={{ gridColumn: `span ${span}` }}>
                      <label style={{ fontSize: 12, fontWeight: 800, color: "#3d1a00", marginBottom: 7, display: "flex", alignItems: "center", gap: 5 }}>
                        <span>{icon}</span>{label}
                      </label>
                      {type === "textarea" ? (
                        <textarea className="inp" name={key} value={displayVal} onChange={handleChange} placeholder={placeholder} rows={4}
                          style={{ ...INP, height: 100, resize: "vertical", lineHeight: 1.6 }} />
                      ) : (
                        <div style={{ position: "relative" }}>
                          {(key === "price" || key === "originalPrice") && (
                            <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "#ff6b00", fontWeight: 900, fontSize: 14, pointerEvents: "none" }}>₹</span>
                          )}
                          <input className="inp" name={key} type={type} value={displayVal} onChange={handleChange} placeholder={placeholder}
                            style={{ ...INP, paddingLeft: (key === "price" || key === "originalPrice") ? 26 : 14 }} />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Bottom bar */}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderTop: "2px dashed #ffd4a3", paddingTop: 18, marginTop: 24, flexWrap: "wrap", gap: 12 }}>
                <p style={{ fontSize: 12, color: "#cc8833", margin: 0, fontWeight: 600 }}>
                  🕐 Last updated: {form.updatedAt ? new Date(form.updatedAt).toLocaleString("en-IN") : "—"}
                </p>
                <div style={{ display: "flex", gap: 10 }}>
                  <button className="reset-btn" onClick={handleReset} style={{ padding: "9px 18px", background: "#fff", border: "2px solid #ffd4a3", borderRadius: 10, fontSize: 13, fontWeight: 700, color: "#cc5500", cursor: "pointer", transition: "all 0.2s" }}>↺ Reset</button>
                  <button className="save-btn" onClick={handleUpdate} disabled={saving} style={{ padding: "9px 22px", background: saving ? "#ffb36b" : "linear-gradient(135deg,#ff6b00,#ff9500)", color: "#fff", border: "none", borderRadius: 10, fontSize: 13, fontWeight: 800, cursor: saving ? "not-allowed" : "pointer", boxShadow: "0 4px 14px rgba(255,107,0,0.35)", transition: "all 0.22s", display: "flex", alignItems: "center", gap: 8 }}>
                    {saving ? <><Spinner /> Saving...</> : "💾 Save Changes"}
                  </button>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

// ── Sub-components ────────────────────────────────────────────
function Spinner() {
  return (
    <>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <span style={{ width: 16, height: 16, border: "3px solid rgba(255,255,255,0.4)", borderTop: "3px solid #fff", borderRadius: "50%", display: "inline-block", animation: "spin 0.7s linear infinite" }} />
    </>
  );
}

// ── Shared styles ─────────────────────────────────────────────
const SEC = {
  fontSize: 11, fontWeight: 800, color: "#cc7a00",
  textTransform: "uppercase", letterSpacing: 1.2,
  margin: "0 0 14px",
};

const INP = {
  width: "100%", padding: "11px 14px",
  border: "2px solid #ffd4a3", borderRadius: 10,
  fontSize: 13, color: "#3d1a00",
  background: "#fffaf7", boxSizing: "border-box",
  fontFamily: "'Segoe UI', sans-serif",
  transition: "border-color 0.2s, box-shadow 0.2s, background 0.2s",
};
