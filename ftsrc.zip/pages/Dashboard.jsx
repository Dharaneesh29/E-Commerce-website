import { useEffect, useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  LineChart, Line, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, Legend,
  BarChart, Bar,
} from "recharts";

const TOKEN = () => sessionStorage.getItem("token");
const AUTH  = () => ({ headers: { Authorization: `Bearer ${TOKEN()}` } });
const BASE  = "http://localhost:5000/api";

const CHART_FILTERS = ["Today", "This Week", "This Month"];
const CHART_TYPES   = ["Line", "Bar"];

const buildChartData = (orders, filter) => {
  const now    = new Date();
  const result = {};

  if (filter === "Today") {
    for (let h = 0; h < 24; h++) {
      const label = `${h}:00`;
      result[label] = { name: label, sales: 0, orders: 0 };
    }
    orders.forEach(o => {
      const d = new Date(o.createdAt);
      const isToday =
        d.getDate() === now.getDate() &&
        d.getMonth() === now.getMonth() &&
        d.getFullYear() === now.getFullYear();
      if (!isToday) return;
      const label = `${d.getHours()}:00`;
      if (result[label]) {
        result[label].sales  += o.totalPrice || 0;
        result[label].orders += 1;
      }
    });
    const currentHour = now.getHours();
    return Object.values(result).filter((_, i) => i <= currentHour);
  }

  if (filter === "This Week") {
    const days    = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const weekAgo = new Date(now);
    weekAgo.setDate(now.getDate() - 6);
    weekAgo.setHours(0, 0, 0, 0);
    for (let i = 6; i >= 0; i--) {
      const d     = new Date(now);
      d.setDate(now.getDate() - i);
      const label = `${days[d.getDay()]} ${d.getDate()}`;
      result[label] = { name: label, sales: 0, orders: 0 };
    }
    orders.forEach(o => {
      const d     = new Date(o.createdAt);
      const days2 = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      const label = `${days2[d.getDay()]} ${d.getDate()}`;
      if (result[label] && d >= weekAgo) {
        result[label].sales  += o.totalPrice || 0;
        result[label].orders += 1;
      }
    });
    return Object.values(result);
  }

  const year  = now.getFullYear();
  const month = now.getMonth();
  const days  = new Date(year, month + 1, 0).getDate();
  for (let d = 1; d <= days; d++) {
    result[`${d}`] = { name: `${d}`, sales: 0, orders: 0 };
  }
  orders.forEach(o => {
    const d = new Date(o.createdAt);
    if (d.getMonth() === month && d.getFullYear() === year) {
      const label = `${d.getDate()}`;
      if (result[label]) {
        result[label].sales  += o.totalPrice || 0;
        result[label].orders += 1;
      }
    }
  });
  return Object.values(result);
};

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "#fff",
      border: "1.5px solid #ffe0c2",
      borderRadius: 14,
      padding: "12px 16px",
      boxShadow: "0 8px 24px rgba(255,111,0,0.15)",
      fontFamily: "'Nunito', sans-serif",
    }}>
      <p style={{ fontSize: 12, fontWeight: 800, color: "#ff6f00", marginBottom: 6 }}>{label}</p>
      {payload.map(p => (
        <p key={p.name} style={{ fontSize: 13, fontWeight: 700, color: p.color, margin: "2px 0" }}>
          {p.name === "Revenue" ? `₹${Number(p.value).toLocaleString()}` : `${p.value} orders`}
        </p>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats,         setStats]         = useState(null);
  const [products,      setProducts]      = useState([]);
  const [orders,        setOrders]        = useState([]);
  const [users,         setUsers]         = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [chartFilter,   setChartFilter]   = useState("This Month");
  const [chartType,     setChartType]     = useState("Line");
  const [loading,       setLoading]       = useState(true);
  const [refreshing,    setRefreshing]    = useState(false);

  useEffect(() => { fetchAll(); }, []);

  const fetchAll = async () => {
    setRefreshing(true);
    setLoading(true);
    try {
      const [statsRes, productsRes, ordersRes, usersRes, notifRes] =
        await Promise.all([
          axios.get(`${BASE}/dashboard`,     AUTH()),
          axios.get(`${BASE}/products`,      AUTH()),
          axios.get(`${BASE}/orders/all`,    AUTH()),
          axios.get(`${BASE}/users/all`,     AUTH()),
          axios.get(`${BASE}/notifications`, AUTH()),
        ]);
      setStats(statsRes.data);
      setProducts(productsRes.data   || []);
      setOrders(ordersRes.data       || []);
      setUsers(usersRes.data         || []);
      setNotifications(notifRes.data || []);
    } catch (err) {
      console.log("Dashboard error:", err.response?.data);
    } finally {
      setLoading(false);
      setTimeout(() => setRefreshing(false), 600);
    }
  };

  const chartData = useMemo(() => buildChartData(orders, chartFilter), [orders, chartFilter]);

  const chartSummary = useMemo(() => ({
    totalSales:  chartData.reduce((s, d) => s + d.sales, 0),
    totalOrders: chartData.reduce((s, d) => s + d.orders, 0),
  }), [chartData]);

  const isCompleted = (o) => o.status === "delivered" || o.paymentStatus === "paid";
  const now = new Date();
  const thisMonth = orders.filter(o => {
    const d = new Date(o.createdAt);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear() && isCompleted(o);
  });
  const lastMonth = orders.filter(o => {
    const d  = new Date(o.createdAt);
    const lm = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
    return d.getMonth() === lm && isCompleted(o);
  });

  const calcGrowth = (cur, prev) => {
    if (!prev) return null;
    return Number(((cur - prev) / prev * 100).toFixed(1));
  };

  const revenueGrowth = calcGrowth(
    thisMonth.reduce((s, o) => s + (o.totalPrice || 0), 0),
    lastMonth.reduce((s, o) => s + (o.totalPrice || 0), 0)
  );
  const ordersGrowth = calcGrowth(thisMonth.length, lastMonth.length);

  const topProducts = useMemo(() => {
    const map = {};
    orders.forEach(o => {
      (o.orderItems || []).forEach(item => {
        const n = item.name || "Unknown";
        map[n] = (map[n] || 0) + (item.qty || 1);
      });
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, count]) => ({ name, count }));
  }, [orders]);

  const lowStock    = products.filter(p => p.countInStock > 0 && p.countInStock <= 10);
  const outOfStock  = products.filter(p => p.countInStock === 0);
  const pendingOrds = orders.filter(o => o.status === "pending");
  const recentAct   = notifications.slice(0, 8);

  const timeAgo = (date) => {
    const s = Math.floor((new Date() - new Date(date)) / 1000);
    if (s < 60)    return "Just now";
    if (s < 3600)  return `${Math.floor(s / 60)}m ago`;
    if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
    return `${Math.floor(s / 86400)}d ago`;
  };

  const TYPE_ICON = { order: "🛒", user: "👤", stock: "⚠️" };

  const KPI = [
    { label: "Total Revenue",  value: `₹${(stats?.revenue || 0).toLocaleString()}`, icon: "💰", accent: "#ff6f00", light: "#fff7ed", growth: revenueGrowth },
    { label: "Total Orders",   value: stats?.orders || 0,        icon: "🛍️", accent: "#f97316", light: "#fff3e6", growth: ordersGrowth },
    { label: "Total Users",    value: stats?.totalUsers || 0,    icon: "👥", accent: "#fb923c", light: "#fff0e0", growth: null },
    { label: "Total Products", value: stats?.totalProducts || 0, icon: "📦", accent: "#ea580c", light: "#ffeee0", growth: null },
  ];

  if (loading || !stats) {
    return (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: "80vh", fontFamily: "'Nunito', sans-serif", background: "#fdf8f3" }}>
        <div style={{ width: 48, height: 48, border: "4px solid #ffe0c2", borderTopColor: "#ff6f00", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
        <p style={{ color: "#ffaa70", marginTop: 16, fontWeight: 700, fontSize: 14 }}>Loading dashboard...</p>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  const hasChartData = chartData.some(d => d.sales > 0 || d.orders > 0);

  return (
    <div style={{ background: "#fdf8f3", minHeight: "100vh", padding: "24px 28px 48px", fontFamily: "'Nunito', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
        .kpi-card:hover { transform: translateY(-4px) !important; box-shadow: 0 16px 40px rgba(255,111,0,0.18) !important; }
        .alert-card:hover { transform: translateX(4px) !important; }
        .top-row:hover { background: #fff3e6 !important; }
        .act-row:hover { background: #fff8f2 !important; }
        .nav-btn:hover { background: #ff6f00 !important; color: #fff !important; }
        .refresh-btn:hover { background: #ff6f00 !important; color: #fff !important; border-color: #ff6f00 !important; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #fff3e6; border-radius: 6px; }
        ::-webkit-scrollbar-thumb { background: #ffcc99; border-radius: 6px; }
      `}</style>

      {/* ── HERO HEADER ── */}
      <div style={{
        background: "linear-gradient(135deg, #ff6f00 0%, #ff8c00 40%, #ffaa44 100%)",
        borderRadius: 24,
        padding: "28px 36px",
        marginBottom: 28,
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 12px 40px rgba(255,111,0,0.3)",
        animation: "fadeUp 0.5s ease",
      }}>
        {/* Decorative circles */}
        <div style={{ position: "absolute", top: -40, right: -40, width: 200, height: 200, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
        <div style={{ position: "absolute", bottom: -60, left: "30%", width: 240, height: 240, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
        <div style={{ position: "absolute", top: 20, right: 180, width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />

        <div style={{ position: "relative", zIndex: 1, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <span style={{ fontSize: 28 }}>🏪</span>
              <h1 style={{ fontSize: 30, fontWeight: 900, color: "#fff", margin: 0, letterSpacing: -0.5 }}>Dashboard</h1>
            </div>
            <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 14, fontWeight: 600, margin: 0 }}>
              Welcome back! Here's what's happening today — {new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}
            </p>
          </div>
          <button
            className="refresh-btn"
            onClick={fetchAll}
            style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "10px 22px",
              background: "rgba(255,255,255,0.15)",
              border: "1.5px solid rgba(255,255,255,0.4)",
              borderRadius: 12,
              color: "#fff",
              fontWeight: 800,
              fontSize: 13,
              cursor: "pointer",
              fontFamily: "inherit",
              transition: "all 0.2s",
              backdropFilter: "blur(8px)",
            }}
          >
            <span style={{ display: "inline-block", animation: refreshing ? "spin 0.8s linear infinite" : "none" }}>↻</span>
            Refresh
          </button>
        </div>
      </div>

      {/* ── KPI CARDS ── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 18, marginBottom: 24 }}>
        {KPI.map((k, idx) => (
          <div
            key={k.label}
            className="kpi-card"
            style={{
              background: "#fff",
              borderRadius: 20,
              padding: "22px 20px",
              border: `1.5px solid #ffe0c2`,
              boxShadow: "0 4px 18px rgba(255,111,0,0.08)",
              transition: "all 0.25s ease",
              position: "relative",
              overflow: "hidden",
              animation: `fadeUp 0.5s ease ${idx * 0.08}s both`,
            }}
          >
            {/* Top accent bar */}
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 4, background: `linear-gradient(90deg, ${k.accent}, ${k.accent}99)`, borderRadius: "20px 20px 0 0" }} />

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <p style={{ fontSize: 11, fontWeight: 800, color: "#aaa", textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 8 }}>{k.label}</p>
                <h2 style={{ fontSize: 28, fontWeight: 900, color: k.accent, margin: 0, letterSpacing: -0.5 }}>{k.value}</h2>
              </div>
              <div style={{
                width: 48, height: 48,
                borderRadius: 14,
                background: k.light,
                border: `1.5px solid ${k.accent}33`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 22,
              }}>
                {k.icon}
              </div>
            </div>

            {k.growth !== null && (
              <div style={{ marginTop: 12, display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{
                  fontSize: 11, fontWeight: 800,
                  color: k.growth >= 0 ? "#10b981" : "#ef4444",
                  background: k.growth >= 0 ? "#ecfdf5" : "#fef2f2",
                  padding: "3px 8px", borderRadius: 99,
                }}>
                  {k.growth >= 0 ? "▲" : "▼"} {Math.abs(k.growth)}%
                </span>
                <span style={{ fontSize: 11, color: "#bbb", fontWeight: 600 }}>vs last month</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ── CHART + TOP PRODUCTS ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 20, marginBottom: 20 }}>

        {/* Sales Chart */}
        <div style={{ background: "#fff", borderRadius: 20, padding: "24px", border: "1.5px solid #ffe0c2", boxShadow: "0 4px 18px rgba(255,111,0,0.07)", animation: "fadeUp 0.5s ease 0.3s both" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
            <h3 style={{ fontSize: 17, fontWeight: 900, color: "#1a1a1a", margin: 0 }}>📈 Sales Overview</h3>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {/* Chart type */}
              <div style={{ display: "flex", background: "#fff3e6", borderRadius: 10, padding: 3 }}>
                {CHART_TYPES.map(t => (
                  <button key={t} onClick={() => setChartType(t)} style={{
                    padding: "5px 12px", borderRadius: 8, border: "none",
                    background: chartType === t ? "#ff6f00" : "transparent",
                    color: chartType === t ? "#fff" : "#ff6f00",
                    fontWeight: 800, fontSize: 12, cursor: "pointer",
                    fontFamily: "inherit", transition: "all 0.15s",
                  }}>{t}</button>
                ))}
              </div>
              {/* Date filter */}
              {CHART_FILTERS.map(f => (
                <button key={f} onClick={() => setChartFilter(f)} style={{
                  padding: "5px 12px", borderRadius: 8,
                  border: chartFilter === f ? "none" : "1.5px solid #ffe0c2",
                  background: chartFilter === f ? "#ff6f00" : "#fff",
                  color: chartFilter === f ? "#fff" : "#888",
                  fontWeight: 800, fontSize: 12, cursor: "pointer",
                  fontFamily: "inherit", transition: "all 0.15s",
                }}>{f}</button>
              ))}
            </div>
          </div>

          {/* Mini stats */}
          <div style={{ display: "flex", gap: 0, background: "#fff8f2", borderRadius: 14, padding: "14px 0", marginBottom: 20, border: "1.5px solid #ffe0c2" }}>
            {[
              { label: "Revenue", value: `₹${chartSummary.totalSales.toLocaleString()}`, color: "#ff6f00" },
              { label: "Orders", value: chartSummary.totalOrders, color: "#f97316" },
              { label: "Avg Value", value: chartSummary.totalOrders > 0 ? `₹${Math.round(chartSummary.totalSales / chartSummary.totalOrders).toLocaleString()}` : "—", color: "#ea580c" },
            ].map((s, i) => (
              <div key={s.label} style={{ flex: 1, textAlign: "center", borderRight: i < 2 ? "1.5px solid #ffe0c2" : "none", padding: "0 16px" }}>
                <p style={{ fontSize: 11, color: "#bbb", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5, margin: "0 0 4px" }}>{s.label}</p>
                <p style={{ fontSize: 20, fontWeight: 900, color: s.color, margin: 0 }}>{s.value}</p>
              </div>
            ))}
          </div>

          {!hasChartData ? (
            <div style={{ textAlign: "center", padding: "40px 20px" }}>
              <span style={{ fontSize: 40 }}>📊</span>
              <p style={{ color: "#ccc", marginTop: 10, fontWeight: 700 }}>No orders for {chartFilter.toLowerCase()}</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={210}>
              {chartType === "Line" ? (
                <LineChart data={chartData} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#bbb" }} interval={chartFilter === "This Month" ? 4 : 0} />
                  <YAxis tick={{ fontSize: 10, fill: "#bbb" }} width={48} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Line type="monotone" dataKey="sales" stroke="#ff6f00" strokeWidth={2.5} dot={{ r: 3, fill: "#ff6f00" }} name="Revenue" activeDot={{ r: 6 }} />
                  <Line type="monotone" dataKey="orders" stroke="#ffaa44" strokeWidth={2.5} dot={{ r: 3, fill: "#ffaa44" }} name="Orders" activeDot={{ r: 6 }} />
                </LineChart>
              ) : (
                <BarChart data={chartData} margin={{ top: 5, right: 10, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#fff3e6" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#bbb" }} interval={chartFilter === "This Month" ? 4 : 0} />
                  <YAxis tick={{ fontSize: 10, fill: "#bbb" }} width={48} />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar dataKey="sales" fill="#ff6f00" name="Revenue" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="orders" fill="#ffaa44" name="Orders" radius={[6, 6, 0, 0]} />
                </BarChart>
              )}
            </ResponsiveContainer>
          )}
        </div>

        {/* Top Products */}
        <div style={{ background: "#fff", borderRadius: 20, padding: "24px", border: "1.5px solid #ffe0c2", boxShadow: "0 4px 18px rgba(255,111,0,0.07)", animation: "fadeUp 0.5s ease 0.4s both" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <h3 style={{ fontSize: 17, fontWeight: 900, color: "#1a1a1a", margin: 0 }}>🏆 Top Products</h3>
            <span style={{ fontSize: 11, fontWeight: 800, color: "#ff6f00", background: "#fff3e6", padding: "4px 10px", borderRadius: 20, border: "1px solid #ffe0c2" }}>
              {orders.length} orders
            </span>
          </div>

          {topProducts.length === 0 ? (
            <div style={{ textAlign: "center", padding: "40px 20px" }}>
              <span style={{ fontSize: 40 }}>📦</span>
              <p style={{ color: "#ccc", marginTop: 10, fontWeight: 700 }}>No sales data yet</p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {topProducts.map((p, i) => (
                <div key={p.name} className="top-row" style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 12px", borderRadius: 12, transition: "background 0.15s", cursor: "default" }}>
                  <div style={{
                    width: 34, height: 34, borderRadius: 10,
                    background: i === 0 ? "linear-gradient(135deg,#ff6f00,#ffaa44)" : i === 1 ? "#fff3e6" : "#fdf8f3",
                    border: i === 0 ? "none" : "1.5px solid #ffe0c2",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 15, fontWeight: 900,
                    color: i === 0 ? "#fff" : "#ff6f00",
                    flexShrink: 0,
                    boxShadow: i === 0 ? "0 4px 12px rgba(255,111,0,0.3)" : "none",
                  }}>
                    {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i+1}`}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 13, fontWeight: 800, color: "#1a1a1a", margin: "0 0 5px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{p.name}</p>
                    <div style={{ height: 5, background: "#fff3e6", borderRadius: 5, overflow: "hidden" }}>
                      <div style={{
                        height: 5,
                        width: `${Math.min((p.count / topProducts[0].count) * 100, 100)}%`,
                        background: i === 0 ? "linear-gradient(90deg,#ff6f00,#ffaa44)" : "linear-gradient(90deg,#ffaa44,#ffcc88)",
                        borderRadius: 5,
                        transition: "width 0.6s ease",
                      }} />
                    </div>
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 900, color: "#ff6f00", background: "#fff3e6", padding: "3px 10px", borderRadius: 20, flexShrink: 0 }}>
                    {p.count} sold
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── ACTIVITY + ALERTS ── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>

        {/* Recent Activity */}
        <div style={{ background: "#fff", borderRadius: 20, padding: "24px", border: "1.5px solid #ffe0c2", boxShadow: "0 4px 18px rgba(255,111,0,0.07)", animation: "fadeUp 0.5s ease 0.5s both" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <h3 style={{ fontSize: 17, fontWeight: 900, color: "#1a1a1a", margin: 0 }}>🕐 Recent Activity</h3>
            <button
              className="nav-btn"
              onClick={() => navigate("/notifications")}
              style={{ fontSize: 12, fontWeight: 800, color: "#ff6f00", background: "#fff3e6", border: "1.5px solid #ffe0c2", padding: "5px 12px", borderRadius: 8, cursor: "pointer", fontFamily: "inherit", transition: "all 0.15s" }}
            >
              View All →
            </button>
          </div>

          {recentAct.length === 0 ? (
            <div style={{ textAlign: "center", padding: "32px 20px" }}>
              <span style={{ fontSize: 36 }}>🔕</span>
              <p style={{ color: "#ccc", marginTop: 10, fontWeight: 700 }}>No recent activity</p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", maxHeight: 340, overflowY: "auto" }}>
              {recentAct.map((n, i) => (
                <div key={n._id} className="act-row" style={{
                  display: "flex", gap: 12, alignItems: "flex-start",
                  padding: "11px 10px", borderRadius: 12,
                  borderBottom: i < recentAct.length - 1 ? "1px solid #fff3e6" : "none",
                  transition: "background 0.15s",
                }}>
                  <div style={{
                    width: 36, height: 36, borderRadius: 10, flexShrink: 0,
                    background: n.type === "order" ? "#fff3e6" : n.type === "user" ? "#fdf0ff" : "#fff8e0",
                    border: "1.5px solid #ffe0c2",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 16,
                  }}>
                    {TYPE_ICON[n.type] || "📌"}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 13, fontWeight: n.isRead ? 600 : 800, color: n.isRead ? "#888" : "#1a1a1a", margin: "0 0 3px", lineHeight: 1.4 }}>
                      {n.message}
                    </p>
                    <span style={{ fontSize: 11, color: "#ffaa70", fontWeight: 700 }}>{timeAgo(n.createdAt)}</span>
                  </div>
                  {!n.isRead && (
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#ff6f00", flexShrink: 0, marginTop: 4 }} />
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Alerts */}
        <div style={{ background: "#fff", borderRadius: 20, padding: "24px", border: "1.5px solid #ffe0c2", boxShadow: "0 4px 18px rgba(255,111,0,0.07)", animation: "fadeUp 0.5s ease 0.6s both" }}>
          <h3 style={{ fontSize: 17, fontWeight: 900, color: "#1a1a1a", margin: "0 0 18px" }}>🚨 Alerts</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              {
                icon: "🕐", title: "Pending Orders",
                desc: pendingOrds.length > 0 ? `${pendingOrds.length} order${pendingOrds.length > 1 ? "s" : ""} waiting for action` : "All caught up! No pending orders",
                count: pendingOrds.length, path: "/orders",
                accent: "#f59e0b", bg: "#fffbeb", border: "#fde68a",
              },
              {
                icon: "⚠️", title: "Low Stock",
                desc: lowStock.length > 0 ? `${lowStock.length} product${lowStock.length > 1 ? "s" : ""} with ≤10 units left` : "All products well stocked",
                count: lowStock.length, path: "/products",
                accent: "#f97316", bg: "#fff7ed", border: "#fed7aa",
              },
              {
                icon: "🚫", title: "Out of Stock",
                desc: outOfStock.length > 0 ? `${outOfStock.length} product${outOfStock.length > 1 ? "s" : ""} need restocking` : "No out-of-stock products",
                count: outOfStock.length, path: "/products",
                accent: "#ef4444", bg: "#fef2f2", border: "#fecaca",
              },
            ].map(a => (
              <div
                key={a.title}
                className="alert-card"
                onClick={() => navigate(a.path)}
                style={{
                  display: "flex", alignItems: "center", gap: 14,
                  padding: "14px 16px", borderRadius: 14,
                  background: a.bg, border: `1.5px solid ${a.border}`,
                  cursor: "pointer", transition: "all 0.2s",
                }}
              >
                <div style={{
                  width: 42, height: 42, borderRadius: 12,
                  background: "#fff",
                  border: `1.5px solid ${a.border}`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 20, flexShrink: 0,
                }}>
                  {a.icon}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 13, fontWeight: 800, color: "#1a1a1a", margin: "0 0 3px" }}>{a.title}</p>
                  <p style={{ fontSize: 12, color: "#888", fontWeight: 600, margin: 0 }}>{a.desc}</p>
                </div>
                {a.count > 0 && (
                  <span style={{
                    fontSize: 15, fontWeight: 900,
                    color: a.accent,
                    background: "#fff",
                    border: `1.5px solid ${a.border}`,
                    width: 36, height: 36, borderRadius: 10,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    flexShrink: 0,
                  }}>
                    {a.count}
                  </span>
                )}
              </div>
            ))}
          </div>

          {/* Quick nav */}
          <div style={{ marginTop: 18, paddingTop: 16, borderTop: "1.5px dashed #ffe0c2" }}>
            <p style={{ fontSize: 11, fontWeight: 800, color: "#bbb", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 10 }}>Quick Navigation</p>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {[
                { label: "📦 Products", path: "/products" },
                { label: "🛍️ Orders", path: "/orders" },
                { label: "👥 Users", path: "/user-management" },
                { label: "🎫 Coupons", path: "/admin/coupons" },
              ].map(n => (
                <button
                  key={n.label}
                  className="nav-btn"
                  onClick={() => navigate(n.path)}
                  style={{
                    padding: "6px 14px", borderRadius: 8,
                    border: "1.5px solid #ffe0c2",
                    background: "#fff8f2", color: "#ff6f00",
                    fontSize: 12, fontWeight: 800,
                    cursor: "pointer", fontFamily: "inherit",
                    transition: "all 0.15s",
                  }}
                >
                  {n.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
