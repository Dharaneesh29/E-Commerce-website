import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import {
  Bell, ShoppingCart, User, Package, RefreshCw,
  CheckCheck, Trash2, Check, Eye,
  BellOff, Loader2, CheckCircle, XCircle, Zap,
} from "lucide-react";

const BASE = "http://localhost:5000/api/notifications";

const TYPE_CONFIG = {
  order: {
    icon: ShoppingCart,
    color: "text-blue-600",
    bg: "bg-blue-50",
    border: "border-blue-200",
    gradient: "from-blue-500 to-blue-600",
    glow: "shadow-blue-200/60",
    label: "Order",
    path: "/orders",
    leftBar: "bg-blue-500",
  },
  user: {
    icon: User,
    color: "text-purple-600",
    bg: "bg-purple-50",
    border: "border-purple-200",
    gradient: "from-purple-500 to-purple-600",
    glow: "shadow-purple-200/60",
    label: "User",
    path: "/user-management",
    leftBar: "bg-purple-500",
  },
  stock: {
    icon: Package,
    color: "text-orange-600",
    bg: "bg-orange-50",
    border: "border-orange-200",
    gradient: "from-orange-500 to-amber-500",
    glow: "shadow-orange-200/60",
    label: "Inventory",
    path: "/products",
    leftBar: "bg-orange-500",
  },
};

const TABS = [
  { key: "all",    label: "All"       },
  { key: "unread", label: "Unread"    },
  { key: "order",  label: "Orders"    },
  { key: "user",   label: "Users"     },
  { key: "stock",  label: "Stock"     },
];

export default function NotificationsPage() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [refreshing,    setRefreshing]    = useState(false);
  const [filter,        setFilter]        = useState("all");
  const [deleting,      setDeleting]      = useState(null);
  const [actionMsg,     setActionMsg]     = useState(null);

  const getToken = () =>
    JSON.parse(sessionStorage.getItem("userInfo"))?.token ||
    sessionStorage.getItem("token");

  const AUTH = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

  const showMsg = (text, type = "success") => {
    setActionMsg({ text, type });
    setTimeout(() => setActionMsg(null), 3000);
  };

  const fetchNotifications = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else           setLoading(true);
    try {
      const res = await axios.get(BASE, AUTH());
      setNotifications(res.data || []);
    } catch {
      showMsg("Failed to load notifications", "error");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(() => fetchNotifications(true), 30000);
    return () => clearInterval(interval);
  }, [fetchNotifications]);

  const markAsRead = async (n) => {
    try {
      if (!n.isRead) {
        await axios.put(`${BASE}/${n._id}/read`, {}, AUTH());
        setNotifications(prev =>
          prev.map(x => x._id === n._id ? { ...x, isRead: true } : x)
        );
      }
      const config = TYPE_CONFIG[n.type];
      if (config?.path) navigate(config.path);
    } catch {
      showMsg("Failed to mark as read", "error");
    }
  };

  const markAllAsRead = async () => {
    try {
      await axios.put(`${BASE}/mark-all-read`, {}, AUTH());
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      showMsg("All notifications marked as read");
    } catch {
      showMsg("Failed to mark all as read", "error");
    }
  };

  const deleteOne = async (e, id) => {
    e.stopPropagation();
    setDeleting(id);
    try {
      await axios.delete(`${BASE}/${id}`, AUTH());
      setNotifications(prev => prev.filter(n => n._id !== id));
      showMsg("Notification deleted");
    } catch {
      showMsg("Failed to delete", "error");
    } finally {
      setDeleting(null);
    }
  };

  const clearAllRead = async () => {
    if (!window.confirm("Delete all read notifications?")) return;
    const readIds = notifications.filter(n => n.isRead).map(n => n._id);
    try {
      await Promise.all(readIds.map(id => axios.delete(`${BASE}/${id}`, AUTH())));
      setNotifications(prev => prev.filter(n => !n.isRead));
      showMsg(`Cleared ${readIds.length} read notifications`);
    } catch {
      showMsg("Failed to clear", "error");
    }
  };

  const timeAgo = (date) => {
    const s = Math.floor((new Date() - new Date(date)) / 1000);
    if (s < 60)    return "Just now";
    if (s < 3600)  return `${Math.floor(s / 60)}m ago`;
    if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
    return new Date(date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  };

  const filtered = notifications.filter(n => {
    if (filter === "unread") return !n.isRead;
    if (filter === "order")  return n.type === "order";
    if (filter === "user")   return n.type === "user";
    if (filter === "stock")  return n.type === "stock";
    return true;
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const tabCount = (key) => {
    if (key === "all")    return notifications.length;
    if (key === "unread") return unreadCount;
    return notifications.filter(n => n.type === key).length;
  };

  return (
    <div className="min-h-screen bg-orange-50/60 p-5 md:p-6">

      {/* Toast */}
      {actionMsg && (
        <div className={`fixed top-16 left-1/2 -translate -x-1/2 z-50 
          px-4 py-2.5 rounded-xl shadow-xl text-sm font-semibold border
          ${actionMsg.type === "success"
            ? "bg-white border-orange-200 text-gray-800 shadow-orange-100"
            : "bg-white border-red-200 text-gray-800 shadow-red-100"}`}>
          <div className={`w-7 h-7 rounded-lg flex items-center justify-center
            ${actionMsg.type === "success" ? "bg-orange-100" : "bg-red-100"}`}>
            {actionMsg.type === "success"
              ? <CheckCircle className="w-3.5 h-3.5 text-orange-500" />
              : <XCircle     className="w-3.5 h-3.5 text-red-500" />}
          </div>
          {actionMsg.text}
        </div>
      )}

      {/* Page Header */}
      {/* Page Header */}
<div style={{
  background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
  borderRadius: 22, padding: "26px 20px", marginBottom: 20,
  position: "relative", overflow: "hidden",
  boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
}}>
  <div style={{ position:"absolute", top:-40, right:-40, width:180, height:180, borderRadius:"50%", background:"rgba(255,255,255,0.08)" }} />
  <div style={{ position:"absolute", bottom:-50, left:"35%", width:220, height:220, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }} />
  <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
    <div>
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:4 }}>
        <h1 style={{ margin:0, fontSize:28, fontWeight:900, color:"#fff", letterSpacing:-0.5 }}>🔔 All Notifications</h1>
        {unreadCount > 0 && (
          <span style={{ fontSize:12, fontWeight:900, background:"rgba(255,255,255,0.25)", color:"#fff", padding:"3px 10px", borderRadius:20, border:"1px solid rgba(255,255,255,0.3)" }}>
            {unreadCount} new
          </span>
        )}
      </div>
      <p style={{ margin:0, fontSize:13, color:"rgba(255,255,255,0.8)", fontWeight:700 }}>
        {notifications.length} total notifications
      </p>
    </div>
    <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
      <button onClick={() => fetchNotifications(true)} disabled={refreshing} style={{
        display:"flex", alignItems:"center", gap:6,
        padding:"9px 18px", background:"rgba(255,255,255,0.2)",
        color:"#fff", border:"1.5px solid rgba(255,255,255,0.4)",
        borderRadius:12, fontSize:13, fontWeight:800,
        cursor:"pointer", fontFamily:"inherit", backdropFilter:"blur(8px)",
      }}>
        ↻ {refreshing ? "Refreshing..." : "Refresh"}
      </button>
      {unreadCount > 0 && (
        <button onClick={markAllAsRead} style={{
          display:"flex", alignItems:"center", gap:6,
          padding:"9px 18px", background:"rgba(255,255,255,0.2)",
          color:"#fff", border:"1.5px solid rgba(255,255,255,0.4)",
          borderRadius:12, fontSize:13, fontWeight:800,
          cursor:"pointer", fontFamily:"inherit", backdropFilter:"blur(8px)",
        }}>
          ✓ Mark All Read
        </button>
      )}
      {notifications.some(n => n.isRead) && (
        <button onClick={clearAllRead} style={{
          display:"flex", alignItems:"center", gap:6,
          padding:"9px 18px", background:"rgba(239,68,68,0.3)",
          color:"#fff", border:"1.5px solid rgba(255,255,255,0.3)",
          borderRadius:12, fontSize:13, fontWeight:800,
          cursor:"pointer", fontFamily:"inherit",
        }}>
          🗑 Clear Read
        </button>
      )}
    </div>
  </div>
</div>


      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
        {[
          { label: "Total",     value: notifications.length,                               gradient: "from-orange-400 to-amber-500",  badge: "bg-orange-100 text-orange-600"  },
          { label: "Unread",    value: unreadCount,                                        gradient: "from-red-400 to-rose-500",      badge: "bg-red-100 text-red-500"        },
          { label: "Orders",    value: notifications.filter(n => n.type==="order").length, gradient: "from-blue-400 to-blue-500",     badge: "bg-blue-100 text-blue-600"      },
          { label: "Users",     value: notifications.filter(n => n.type==="user").length,  gradient: "from-purple-400 to-purple-500", badge: "bg-purple-100 text-purple-600"  },
          { label: "Inventory", value: notifications.filter(n => n.type==="stock").length, gradient: "from-green-400 to-emerald-500", badge: "bg-green-100 text-green-600"    },
        ].map(({ label, value, gradient, badge }) => (
          <div key={label}
            className="bg-white rounded-2xl p-4 border border-orange-100 shadow-md hover:shadow-lg transition-all duration-200">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${gradient}
                flex items-center justify-center shadow-sm`}>
                <Bell className="w-3.5 h-3.5 text-white" />
              </div>
              <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${badge}`}>
                {label}
              </span>
            </div>
            <p className="text-3xl font-black text-gray-900">{value}</p>
          </div>
        ))}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4 flex-wrap">
        {TABS.map(({ key, label }) => (
          <button key={key} onClick={() => setFilter(key)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-bold
              transition-all duration-150 border
              ${filter === key
                ? "bg-orange-500 border-orange-500 text-white shadow-md shadow-orange-200/60"
                : "bg-white border-orange-200 text-gray-600 hover:border-orange-400 hover:text-orange-600"}`}>
            {label}
            <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black
              ${filter === key ? "bg-white/25 text-white" : "bg-orange-100 text-orange-600"}`}>
              {tabCount(key)}
            </span>
          </button>
        ))}
      </div>

      {/* Notification Cards */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          <p className="text-sm font-semibold text-gray-400">Loading notifications...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-orange-100 shadow-md p-16
          flex flex-col items-center justify-center gap-3">
          <div className="w-16 h-16 bg-orange-50 rounded-2xl flex items-center justify-center border border-orange-100">
            <BellOff className="w-8 h-8 text-orange-300" />
          </div>
          <p className="text-gray-700 font-bold text-sm">No notifications found</p>
          <p className="text-gray-400 text-xs">
            {filter !== "all" ? `No ${filter} notifications yet` : "You're all caught up!"}
          </p>
          <button onClick={() => fetchNotifications(true)}
            className="flex items-center gap-1.5 px-4 py-2 bg-orange-50 border border-orange-200
              text-orange-600 rounded-xl text-sm font-semibold hover:bg-orange-500
              hover:text-white hover:border-orange-500 transition-all mt-1">
            <RefreshCw className="w-3.5 h-3.5" /> Check for new
          </button>
        </div>
      ) : (
        <div className="space-y-3">

          {/* Count bar */}
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">
              {filtered.length} notification{filtered.length !== 1 ? "s" : ""}
            </span>
            {refreshing && (
              <span className="text-xs text-orange-500 font-semibold flex items-center gap-1">
                <RefreshCw className="w-3 h-3 animate-spin" /> Refreshing...
              </span>
            )}
          </div>

          {filtered.map((n) => {
            const config = TYPE_CONFIG[n.type] || TYPE_CONFIG.stock;
            const Icon   = config.icon;
            return (
              <div key={n._id}
                onClick={() => markAsRead(n)}
                className={`group relative bg-white rounded-2xl border overflow-hidden
                  cursor-pointer transition-all duration-200 hover:shadow-lg
                  ${n.isRead
                    ? "border-gray-100 hover:border-orange-200 hover:shadow-orange-100/50"
                    : `border-orange-200 shadow-md ${config.glow}`}`}>

                {/* Unread left accent bar */}
                {!n.isRead && (
                  <div className={`absolute left-0 top-0 bottom-0 w-1 ${config.leftBar}`} />
                )}

                <div className="flex items-start gap-4 p-4 pl-5">

                  {/* Icon badge */}
                  <div className={`relative flex-shrink-0 w-11 h-11 rounded-xl
                    bg-gradient-to-br ${config.gradient} flex items-center justify-center
                    shadow-md mt-0.5`}>
                    <Icon className="w-5 h-5 text-white" />
                    {!n.isRead && (
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-orange-500
                        rounded-full border-2 border-white animate-pulse" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">

                    {/* Top row */}
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-black uppercase tracking-widest
                          px-2 py-0.5 rounded-lg border ${config.bg} ${config.color} ${config.border}`}>
                          {config.label}
                        </span>
                        {!n.isRead && (
                          <span className="text-[10px] font-black uppercase tracking-widest
                            px-2 py-0.5 rounded-lg bg-orange-100 text-orange-600 border border-orange-200">
                            New
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-gray-400 font-medium flex-shrink-0">
                        {timeAgo(n.createdAt)}
                      </span>
                    </div>

                    {/* Message */}
                    <p className={`text-sm leading-relaxed mb-3
                      ${n.isRead ? "text-gray-500 font-normal" : "text-gray-900 font-semibold"}`}>
                      {n.message}
                    </p>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2">
                      {!n.isRead && (
                        <button
                          onClick={(e) => { e.stopPropagation(); markAsRead(n); }}
                          className="flex items-center gap-1 text-xs font-bold text-green-600
                            bg-green-50 border border-green-200 px-2.5 py-1.5 rounded-lg
                            hover:bg-green-500 hover:text-white hover:border-green-500
                            transition-all duration-150">
                          <Check className="w-3 h-3" /> Mark Read
                        </button>
                      )}
                      <button
                        onClick={(e) => { e.stopPropagation(); navigate(config.path); }}
                        className="flex items-center gap-1 text-xs font-bold text-orange-600
                          bg-orange-50 border border-orange-200 px-2.5 py-1.5 rounded-lg
                          hover:bg-orange-500 hover:text-white hover:border-orange-500
                          transition-all duration-150">
                        <Eye className="w-3 h-3" /> View
                      </button>
                    </div>
                  </div>

                  {/* Delete button */}
                  <button
                    onClick={(e) => deleteOne(e, n._id)}
                    disabled={deleting === n._id}
                    className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-xl
                      bg-gray-50 border border-gray-200 text-gray-400
                      hover:bg-red-500 hover:text-white hover:border-red-500
                      transition-all duration-150 disabled:opacity-40 mt-0.5
                      opacity-0 group-hover:opacity-100">
                    {deleting === n._id
                      ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      : <Trash2  className="w-3.5 h-3.5" />}
                  </button>

                </div>

                {/* Bottom shimmer for unread */}
                {!n.isRead && (
                  <div className={`h-0.5 bg-gradient-to-r ${config.gradient} opacity-30`} />
                )}

              </div>
            );
          })}
        </div>
      )}

      {/* Footer */}
      <p className="text-xs text-gray-400 text-center mt-5 flex items-center justify-center gap-1">
        <RefreshCw className="w-3 h-3" /> Auto-refreshes every 30 seconds
      </p>

    </div>
  );
}
