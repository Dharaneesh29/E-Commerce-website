import Layout from "../components/UserLayout";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import API from "../api/axios";

export default function ProductManagement() {
  const navigate = useNavigate();

  const [id, setId] = useState("");
  const [message, setMessage] = useState("");

  // DELETE
  const handleDelete = async () => {
    try {
      await API.delete(`/products/${id}`, {
        headers: {
          Authorization: `Bearer ${sessionStorage.getItem("token")}`,
        },
      });

      setMessage("Product deleted successfully");
      setId("");
    } catch (err) {
      setMessage("Error deleting product");
    }
  };

  // UPDATE NAVIGATION
  const handleUpdate = () => {
    if (!id) return setMessage("Enter product ID");
    navigate(`/edit-product/${id}`);
  };

  return (
    <>
      <h2 style={{ marginBottom: "20px" }}>Product Management</h2>

      {message && <p style={msg}>{message}</p>}

      <div style={grid}>
        {/* VIEW */}
        <div style={card} onClick={() => navigate("/products")}>
          <h3>View Products</h3>
          <p>See all products</p>
        </div>

        {/* ADD */}
        <div style={card} onClick={() => navigate("/add-product")}>
          <h3>Add Product</h3>
          <p>Create new product</p>
        </div>

        {/* UPDATE */}
        <div style={card}>
          <h3>Update Product</h3>
          <input
            placeholder="Enter Product ID"
            value={id}
            onChange={(e) => setId(e.target.value)}
            style={input}
          />
          <button onClick={handleUpdate} style={btn}>
            Update
          </button>
        </div>

        {/* DELETE */}
        <div style={card}>
          <h3>Delete Product</h3>
          <input
            placeholder="Enter Product ID"
            value={id}
            onChange={(e) => setId(e.target.value)}
            style={input}
          />
          <button onClick={handleDelete} style={deleteBtn}>
            Delete
          </button>
        </div>
      </div>
    </>
  );
}

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
  gap: "20px",
};

const card = {
  background: "white",
  padding: "25px",
  borderRadius: "12px",
  boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
  cursor: "pointer",
  transition: "all 0.3s ease",
};

const input = {
  width: "100%",
  padding: "8px",
  marginTop: "10px",
  border: "1px solid #ccc",
  borderRadius: "6px",
};

const btn = {
  marginTop: "10px",
  background: "#f59e0b",
  color: "white",
  border: "none",
  padding: "8px",
  width: "100%",
  cursor: "pointer",
};

const deleteBtn = {
  ...btn,
  background: "#ef4444",
};

const msg = {
  background: "#d1fae5",
  padding: "10px",
  marginBottom: "15px",
  borderRadius: "6px",
};
