// import { useEffect, useState } from "react";
// import axios from "axios";
// import { toast } from "react-toastify";

// const BASE = "http://localhost:5000/api";
// const getToken = () => sessionStorage.getItem("token");
// const authHeaders = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

// const AdminMembers = () => {
//   const [members, setMembers] = useState([]);
//   const [plans, setPlans] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [search, setSearch] = useState("");
//   const [filterStatus, setFilterStatus] = useState("all");
//   const [showAssignModal, setShowAssignModal] = useState(false);
//   const [selectedUser, setSelectedUser] = useState(null);
//   const [selectedPlanId, setSelectedPlanId] = useState("");
//   const [submitting, setSubmitting] = useState(false);

//   const fetchMembers = async () => {
//     try {
//       setLoading(true);
//       const res = await axios.get(
//         `${BASE}/admin/membership/members`,
//         authHeaders()
//       );
//       setMembers(res.data);
//     } catch (err) {
//       toast.error("Failed to fetch members");
//     } finally {
//       setLoading(false);
//     }
//   };

//   const fetchPlans = async () => {
//     try {
//       const res = await axios.get(
//         `${BASE}/admin/membership/plans`,
//         authHeaders()
//       );
//       setPlans(res.data.filter((p) => p.isActive));
//     } catch (err) {
//       console.error("Failed to fetch plans");
//     }
//   };

//   useEffect(() => {
//     fetchMembers();
//     fetchPlans();
//   }, []);

//   const openAssignModal = (user) => {
//     setSelectedUser(user);
//     setSelectedPlanId("");
//     setShowAssignModal(true);
//   };

//   const handleAssign = async () => {
//     if (!selectedPlanId) {
//       toast.error("Please select a plan");
//       return;
//     }
//     try {
//       setSubmitting(true);
//       await axios.patch(
//         `${BASE}/admin/membership/members/${selectedUser._id}/assign`,
//         { planId: selectedPlanId },
//         authHeaders()
//       );
//       toast.success("Plan assigned successfully");
//       setShowAssignModal(false);
//       fetchMembers();
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to assign plan");
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   const handleRevoke = async (userId, userName) => {
//     if (!window.confirm(`Revoke membership for ${userName}?`)) return;
//     try {
//       await axios.patch(
//         `${BASE}/admin/membership/members/${userId}/revoke`,
//         {},
//         authHeaders()
//       );
//       toast.success("Membership revoked");
//       fetchMembers();
//     } catch (err) {
//       toast.error("Failed to revoke membership");
//     }
//   };

//   const getExpiryStatus = (expiryDate, isActive) => {
//     if (!isActive) return { label: "Revoked", color: "bg-gray-100 text-gray-500" };
//     const today = new Date();
//     const expiry = new Date(expiryDate);
//     const daysLeft = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
//     if (daysLeft < 0) return { label: "Expired", color: "bg-red-100 text-red-600" };
//     if (daysLeft <= 7) return { label: `Expires in ${daysLeft}d`, color: "bg-yellow-100 text-yellow-700" };
//     return { label: "Active", color: "bg-green-100 text-green-700" };
//   };

//   const filtered = members.filter((m) => {
//     const matchSearch =
//       m.name?.toLowerCase().includes(search.toLowerCase()) ||
//       m.email?.toLowerCase().includes(search.toLowerCase());
//     const status = getExpiryStatus(
//       m.membership?.expiryDate,
//       m.membership?.isActive
//     ).label;
//     if (filterStatus === "active") return matchSearch && status === "Active";
//     if (filterStatus === "expired") return matchSearch && status === "Expired";
//     if (filterStatus === "revoked") return matchSearch && status === "Revoked";
//     return matchSearch;
//   });

//   return (
//     <div className="p-6 min-h-screen bg-[#fdf5ee]">
//       {/* Header */}
//       <div className="mb-6">
//         <h1 className="text-2xl font-bold text-[#7c3a00]">Members</h1>
//         <p className="text-sm text-gray-500 mt-1">
//           All users with membership plans
//         </p>
//       </div>

//       {/* Search & Filter */}
//       <div className="flex flex-col sm:flex-row gap-3 mb-5">
//         <input
//           type="text"
//           placeholder="Search by name or email..."
//           value={search}
//           onChange={(e) => setSearch(e.target.value)}
//           className="flex-1 border border-gray-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316] bg-white"
//         />
//         <select
//           value={filterStatus}
//           onChange={(e) => setFilterStatus(e.target.value)}
//           className="border border-gray-200 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316] bg-white"
//         >
//           <option value="all">All Status</option>
//           <option value="active">Active</option>
//           <option value="expired">Expired</option>
//           <option value="revoked">Revoked</option>
//         </select>
//       </div>

//       {/* Table */}
//       {loading ? (
//         <div className="text-center py-20 text-gray-400 text-lg">
//           Loading members...
//         </div>
//       ) : filtered.length === 0 ? (
//         <div className="text-center py-20 text-gray-400 text-lg">
//           No members found.
//         </div>
//       ) : (
//         <div className="bg-white rounded-2xl shadow overflow-hidden">
//           <table className="w-full text-sm">
//             <thead className="bg-[#f97316] text-white">
//               <tr>
//                 <th className="text-left px-5 py-3">User</th>
//                 <th className="text-left px-5 py-3">Plan</th>
//                 <th className="text-left px-5 py-3">Discount</th>
//                 <th className="text-left px-5 py-3">Start Date</th>
//                 <th className="text-left px-5 py-3">Expiry Date</th>
//                 <th className="text-left px-5 py-3">Status</th>
//                 <th className="text-left px-5 py-3">Actions</th>
//               </tr>
//             </thead>
//             <tbody>
//               {filtered.map((member, index) => {
//                 const status = getExpiryStatus(
//                   member.membership?.expiryDate,
//                   member.membership?.isActive
//                 );
//                 return (
//                   <tr
//                     key={member._id}
//                     className={index % 2 === 0 ? "bg-white" : "bg-[#fff7f0]"}
//                   >
//                     <td className="px-5 py-3">
//                       <p className="font-semibold text-[#7c3a00]">{member.name}</p>
//                       <p className="text-xs text-gray-400">{member.email}</p>
//                     </td>
//                     <td className="px-5 py-3 font-medium">
//                       {member.membership?.planId?.name || "—"}
//                     </td>
//                     <td className="px-5 py-3">
//                       {member.membership?.planId?.discount ?? "—"}%
//                     </td>
//                     <td className="px-5 py-3 text-gray-500">
//                       {member.membership?.startDate
//                         ? new Date(member.membership.startDate).toLocaleDateString()
//                         : "—"}
//                     </td>
//                     <td className="px-5 py-3 text-gray-500">
//                       {member.membership?.expiryDate
//                         ? new Date(member.membership.expiryDate).toLocaleDateString()
//                         : "—"}
//                     </td>
//                     <td className="px-5 py-3">
//                       <span
//                         className={`px-3 py-1 rounded-full text-xs font-semibold ${status.color}`}
//                       >
//                         {status.label}
//                       </span>
//                     </td>
//                     <td className="px-5 py-3">
//                       <div className="flex gap-2">
//                         <button
//                           onClick={() => openAssignModal(member)}
//                           className="bg-[#f97316] hover:bg-[#ea6c0a] text-white px-3 py-1 rounded-lg text-xs font-semibold transition"
//                         >
//                           Assign
//                         </button>
//                         {member.membership?.isActive && (
//                           <button
//                             onClick={() => handleRevoke(member._id, member.name)}
//                             className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-lg text-xs font-semibold transition"
//                           >
//                             Revoke
//                           </button>
//                         )}
//                       </div>
//                     </td>
//                   </tr>
//                 );
//               })}
//             </tbody>
//           </table>
//         </div>
//       )}

//       {/* Assign Modal */}
//       {showAssignModal && (
//         <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
//           <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
//             <h2 className="text-xl font-bold text-[#7c3a00] mb-1">
//               Assign Plan
//             </h2>
//             <p className="text-sm text-gray-400 mb-4">
//               For:{" "}
//               <span className="font-medium text-gray-600">
//                 {selectedUser?.name}
//               </span>
//             </p>

//             <label className="text-sm font-medium text-gray-600">
//               Select Plan
//             </label>
//             <select
//               value={selectedPlanId}
//               onChange={(e) => setSelectedPlanId(e.target.value)}
//               className="w-full border border-gray-200 rounded-lg px-3 py-2 mt-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#f97316]"
//             >
//               <option value="">-- Choose a plan --</option>
//               {plans.map((plan) => (
//                 <option key={plan._id} value={plan._id}>
//                   {plan.name} — ₹{plan.price} / {plan.duration} days
//                 </option>
//               ))}
//             </select>

//             <div className="flex gap-3 mt-5">
//               <button
//                 onClick={() => setShowAssignModal(false)}
//                 className="flex-1 border border-gray-300 text-gray-600 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 transition"
//               >
//                 Cancel
//               </button>
//               <button
//                 onClick={handleAssign}
//                 disabled={submitting}
//                 className="flex-1 bg-[#f97316] hover:bg-[#ea6c0a] text-white py-2 rounded-lg text-sm font-semibold transition disabled:opacity-60"
//               >
//                 {submitting ? "Assigning..." : "Assign Plan"}
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default AdminMembers;


import { useEffect, useState } from "react";
import axios from "axios";
import { toast } from "react-toastify";

const BASE = "http://localhost:5000/api";
const getToken = () => sessionStorage.getItem("token");
const authHeaders = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

const AdminMembers = () => {
  const [members, setMembers] = useState([]);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedPlanId, setSelectedPlanId] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const fetchMembers = async () => {
    try {
      setLoading(true);
      const res = await axios.get(`${BASE}/admin/membership/members`, authHeaders());
      setMembers(res.data);
    } catch (err) {
      toast.error("Failed to fetch members");
    } finally {
      setLoading(false);
    }
  };

  const fetchPlans = async () => {
    try {
      const res = await axios.get(`${BASE}/admin/membership/plans`, authHeaders());
      setPlans(res.data.filter((p) => p.isActive));
    } catch (err) {
      console.error("Failed to fetch plans");
    }
  };

  useEffect(() => {
    fetchMembers();
    fetchPlans();
  }, []);

  const openAssignModal = (user) => {
    setSelectedUser(user);
    setSelectedPlanId("");
    setShowAssignModal(true);
  };

  const handleAssign = async () => {
    if (!selectedPlanId) { toast.error("Please select a plan"); return; }
    try {
      setSubmitting(true);
      await axios.patch(`${BASE}/admin/membership/members/${selectedUser._id}/assign`, { planId: selectedPlanId }, authHeaders());
      toast.success("Plan assigned successfully");
      setShowAssignModal(false);
      fetchMembers();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to assign plan");
    } finally {
      setSubmitting(false);
    }
  };

  const handleRevoke = async (userId, userName) => {
    if (!window.confirm(`Revoke membership for ${userName}?`)) return;
    try {
      await axios.patch(`${BASE}/admin/membership/members/${userId}/revoke`, {}, authHeaders());
      toast.success("Membership revoked");
      fetchMembers();
    } catch (err) {
      toast.error("Failed to revoke membership");
    }
  };

  const getExpiryStatus = (expiryDate, isActive) => {
    if (!isActive) return { label: "Revoked", color: "#6b7280", bg: "#f3f4f6" };
    const today = new Date();
    const expiry = new Date(expiryDate);
    const daysLeft = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    if (daysLeft < 0) return { label: "Expired", color: "#dc2626", bg: "#fee2e2" };
    if (daysLeft <= 7) return { label: `${daysLeft}d left`, color: "#d97706", bg: "#fef3c7" };
    return { label: "Active", color: "#16a34a", bg: "#dcfce7" };
  };

  const filtered = members.filter((m) => {
    const matchSearch =
      m.name?.toLowerCase().includes(search.toLowerCase()) ||
      m.email?.toLowerCase().includes(search.toLowerCase());
    const status = getExpiryStatus(m.membership?.expiryDate, m.membership?.isActive).label;
    if (filterStatus === "active") return matchSearch && status === "Active";
    if (filterStatus === "expired") return matchSearch && status === "Expired";
    if (filterStatus === "revoked") return matchSearch && status === "Revoked";
    return matchSearch;
  });

  const activeCount = members.filter(m => getExpiryStatus(m.membership?.expiryDate, m.membership?.isActive).label === "Active").length;
  const expiredCount = members.filter(m => getExpiryStatus(m.membership?.expiryDate, m.membership?.isActive).label === "Expired").length;
  const revokedCount = members.filter(m => getExpiryStatus(m.membership?.expiryDate, m.membership?.isActive).label === "Revoked").length;

  const planIcons = { Free: "🆓", Silver: "🥈", Gold: "🥇", Platinum: "💎" };

  return (
    <div style={{ fontFamily: "'Nunito', sans-serif", background: "#fdf8f3", minHeight: "100vh", padding: 24 }}>

      {/* ── HEADER BANNER ── */}
      <div style={{
        background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
        borderRadius: 22, padding: "26px 32px", marginBottom: 24,
        position: "relative", overflow: "hidden",
        boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
      }}>
        <div style={{ position: "absolute", top: -40, right: -40, width: 180, height: 180, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
        <div style={{ position: "absolute", bottom: -50, left: "35%", width: 220, height: 220, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
        <div style={{ position: "relative", zIndex: 1, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 14 }}>
          <div>
            <h1 style={{ margin: 0, fontSize: 26, fontWeight: 900, color: "#fff", letterSpacing: -0.5 }}>
              👥 Members
            </h1>
            <p style={{ margin: "5px 0 0", fontSize: 13, color: "rgba(255,255,255,0.85)", fontWeight: 600 }}>
              {members.length} total member{members.length !== 1 ? "s" : ""} · All users with membership plans
            </p>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => { fetchMembers(); fetchPlans(); }} style={{
              padding: "10px 18px", background: "rgba(255,255,255,0.2)",
              color: "#fff", border: "1.5px solid rgba(255,255,255,0.4)",
              borderRadius: 12, fontSize: 13, fontWeight: 800, cursor: "pointer",
              backdropFilter: "blur(8px)",
            }}>
              ↻ Refresh
            </button>
          </div>
        </div>
      </div>

      {/* ── STAT CARDS ── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16, marginBottom: 24 }}>
        {[
          { label: "Total Members", value: members.length, icon: "👥", color: "#ff6f00", bg: "#fff3e8",
            onClick: () => setFilterStatus("all") },
          { label: "Active",        value: activeCount,    icon: "✅", color: "#16a34a", bg: "#f0fdf4",
            onClick: () => setFilterStatus("active") },
          { label: "Expired",       value: expiredCount,   icon: "⏰", color: "#dc2626", bg: "#fef2f2",
            onClick: () => setFilterStatus("expired") },
          { label: "Revoked",       value: revokedCount,   icon: "⛔", color: "#6b7280", bg: "#f3f4f6",
            onClick: () => setFilterStatus("revoked") },
        ].map((stat) => (
          <div key={stat.label} onClick={stat.onClick} style={{
            background: "#fff", borderRadius: 16, padding: "18px 20px",
            border: filterStatus === stat.label.toLowerCase()
              ? "2px solid #ff6f00"
              : "1.5px solid #f0e8e0",
            boxShadow: "0 4px 14px rgba(0,0,0,0.05)",
            cursor: "pointer", transition: "all 0.2s",
          }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: stat.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>
                {stat.icon}
              </div>
              <span style={{ fontSize: 10, fontWeight: 800, color: stat.color, background: stat.bg, padding: "3px 10px", borderRadius: 20, textTransform: "uppercase", letterSpacing: 0.5 }}>
                {stat.label}
              </span>
            </div>
            <div style={{ fontSize: 32, fontWeight: 900, color: "#1a1a1a" }}>{stat.value}</div>
            <div style={{ fontSize: 11, color: "#aaa", fontWeight: 600, marginTop: 4 }}>Click to filter →</div>
          </div>
        ))}
      </div>

      {/* ── SEARCH & FILTER ── */}
      <div style={{ background: "#fff", borderRadius: 16, padding: "16px 20px", marginBottom: 20, border: "1.5px solid #f0e8e0", display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ flex: 1, position: "relative", minWidth: 200 }}>
          <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>🔍</span>
          <input
            type="text"
            placeholder="Search by name or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ width: "100%", padding: "10px 12px 10px 36px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 13, outline: "none", fontFamily: "inherit", boxSizing: "border-box" }}
          />
        </div>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          style={{ padding: "10px 14px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 13, outline: "none", fontFamily: "inherit", cursor: "pointer", background: "#fff" }}
        >
          <option value="all">All Status</option>
          <option value="active">Active</option>
          <option value="expired">Expired</option>
          <option value="revoked">Revoked</option>
        </select>
        <span style={{ fontSize: 13, color: "#aaa", fontWeight: 600 }}>
          Showing {filtered.length} of {members.length} members
        </span>
      </div>

      {/* ── TABLE ── */}
      {loading ? (
        <div style={{ textAlign: "center", padding: "60px", color: "#aaa", fontSize: 15 }}>Loading members...</div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: "60px", background: "#fff", borderRadius: 18, border: "1.5px solid #f0e8e0" }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>👥</div>
          <div style={{ fontSize: 16, fontWeight: 800, color: "#1a1a1a", marginBottom: 6 }}>No members found</div>
          <div style={{ fontSize: 13, color: "#aaa" }}>Try adjusting your search or filter</div>
        </div>
      ) : (
        <div style={{ background: "#fff", borderRadius: 18, overflow: "hidden", border: "1.5px solid #f0e8e0", boxShadow: "0 4px 16px rgba(0,0,0,0.05)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead style={{ background: "linear-gradient(135deg, #ff6f00, #ff9500)" }}>
              <tr>
                {["#", "Member", "Plan", "Discount", "Start Date", "Expiry Date", "Status", "Actions"].map(h => (
                  <th key={h} style={{ textAlign: "left", padding: "13px 16px", color: "#fff", fontWeight: 800, fontSize: 12 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((member, index) => {
                const status = getExpiryStatus(member.membership?.expiryDate, member.membership?.isActive);
                const planName = member.membership?.planId?.name || "—";
                return (
                  <tr key={member._id} style={{
                    background: index % 2 === 0 ? "#fff" : "#fff8f2",
                    borderBottom: "1px solid #f5ece4",
                    transition: "background 0.15s",
                  }}>
                    <td style={{ padding: "14px 16px", color: "#aaa", fontWeight: 700 }}>{index + 1}</td>

                    {/* Member info */}
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{
                          width: 38, height: 38, borderRadius: "50%",
                          background: "linear-gradient(135deg, #ff6f00, #ff9500)",
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 15, fontWeight: 900, color: "#fff", flexShrink: 0,
                        }}>
                          {member.name?.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div style={{ fontWeight: 800, color: "#1a1a1a", fontSize: 13 }}>{member.name}</div>
                          <div style={{ fontSize: 11, color: "#aaa", fontWeight: 600 }}>{member.email}</div>
                        </div>
                      </div>
                    </td>

                    {/* Plan */}
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ fontSize: 16 }}>{planIcons[planName] || "💳"}</span>
                        <span style={{ fontWeight: 800, color: "#1a1a1a" }}>{planName}</span>
                      </div>
                    </td>

                    {/* Discount */}
                    <td style={{ padding: "14px 16px" }}>
                      <span style={{ background: "#fff3e8", color: "#ff6f00", padding: "4px 10px", borderRadius: 8, fontWeight: 800, fontSize: 12 }}>
                        {member.membership?.planId?.discount ?? "—"}%
                      </span>
                    </td>

                    {/* Start Date */}
                    <td style={{ padding: "14px 16px", color: "#555", fontWeight: 600 }}>
                      {member.membership?.startDate
                        ? new Date(member.membership.startDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                        : "—"}
                    </td>

                    {/* Expiry Date */}
                    <td style={{ padding: "14px 16px", color: "#555", fontWeight: 600 }}>
                      {member.membership?.expiryDate
                        ? new Date(member.membership.expiryDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })
                        : "—"}
                    </td>

                    {/* Status */}
                    <td style={{ padding: "14px 16px" }}>
                      <span style={{
                        padding: "5px 12px", borderRadius: 20,
                        fontSize: 11, fontWeight: 800,
                        color: status.color, background: status.bg,
                      }}>
                        {status.label === "Active" ? "✅ " : status.label === "Expired" ? "⏰ " : "⛔ "}
                        {status.label}
                      </span>
                    </td>

                    {/* Actions */}
                    <td style={{ padding: "14px 16px" }}>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button
                          onClick={() => openAssignModal(member)}
                          style={{ padding: "7px 14px", background: "linear-gradient(135deg, #ff6f00, #ff9500)", color: "#fff", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 800, cursor: "pointer" }}
                        >
                          Assign
                        </button>
                        {member.membership?.isActive && (
                          <button
                            onClick={() => handleRevoke(member._id, member.name)}
                            style={{ padding: "7px 14px", background: "#fff5f5", color: "#dc2626", border: "1.5px solid #fecaca", borderRadius: 8, fontSize: 12, fontWeight: 800, cursor: "pointer" }}
                          >
                            Revoke
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* ── ASSIGN MODAL ── */}
      {showAssignModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50 }}>
          <div style={{ background: "#fff", borderRadius: 22, width: "100%", maxWidth: 420, padding: 28, boxShadow: "0 20px 60px rgba(0,0,0,0.2)" }}>

            {/* Modal header */}
            <div style={{ background: "linear-gradient(135deg, #ff6f00, #ff9500)", borderRadius: 14, padding: "16px 20px", marginBottom: 22 }}>
              <h2 style={{ margin: 0, fontSize: 18, fontWeight: 900, color: "#fff" }}>📋 Assign Plan</h2>
              <p style={{ margin: "4px 0 0", fontSize: 12, color: "rgba(255,255,255,0.85)" }}>
                Assigning to: <strong>{selectedUser?.name}</strong>
              </p>
            </div>

            {/* User info card */}
            <div style={{ background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 12, padding: "14px 16px", marginBottom: 18, display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: "50%", background: "linear-gradient(135deg, #ff6f00, #ff9500)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: "#fff", flexShrink: 0 }}>
                {selectedUser?.name?.charAt(0).toUpperCase()}
              </div>
              <div>
                <div style={{ fontWeight: 800, color: "#1a1a1a", fontSize: 14 }}>{selectedUser?.name}</div>
                <div style={{ fontSize: 12, color: "#aaa" }}>{selectedUser?.email}</div>
                <div style={{ fontSize: 11, marginTop: 3 }}>
                  Current:{" "}
                  <span style={{ fontWeight: 800, color: "#ff6f00" }}>
                    {selectedUser?.membership?.planId?.name || "No Plan"}
                  </span>
                </div>
              </div>
            </div>

            <label style={{ fontSize: 11, fontWeight: 800, color: "#888", textTransform: "uppercase", letterSpacing: 0.5, display: "block", marginBottom: 8 }}>
              Select New Plan
            </label>
            <select
              value={selectedPlanId}
              onChange={(e) => setSelectedPlanId(e.target.value)}
              style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #e8e8e8", borderRadius: 10, fontSize: 14, outline: "none", fontFamily: "inherit", cursor: "pointer", marginBottom: 6, boxSizing: "border-box" }}
            >
              <option value="">-- Choose a plan --</option>
              {plans.map((plan) => (
                <option key={plan._id} value={plan._id}>
                  {planIcons[plan.name] || "💳"} {plan.name} — ₹{plan.price} / {plan.duration} days ({plan.discount}% off)
                </option>
              ))}
            </select>

            <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
              <button onClick={() => setShowAssignModal(false)} style={{ flex: 1, padding: "12px", border: "1.5px solid #e8e8e8", background: "#fff", borderRadius: 12, fontSize: 14, fontWeight: 800, cursor: "pointer", color: "#555" }}>
                Cancel
              </button>
              <button onClick={handleAssign} disabled={submitting} style={{ flex: 1, padding: "12px", background: "linear-gradient(135deg, #ff6f00, #ff9500)", color: "#fff", border: "none", borderRadius: 12, fontSize: 14, fontWeight: 800, cursor: "pointer", opacity: submitting ? 0.6 : 1 }}>
                {submitting ? "Assigning..." : "✅ Assign Plan"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminMembers;


