// import { useEffect, useState } from "react";
// import axios from "axios";

// const P = "#ff6f00";

// const STATUS_FLOW = ["pending", "confirmed", "shipped", "delivered"];
// const ALL_STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled", "returned"];

// const STATUS_COLORS = {
//   pending:   { bg: "#fffbeb", color: "#f59e0b", border: "#fde68a" },
//   confirmed: { bg: "#eff6ff", color: "#3b82f6", border: "#bfdbfe" },
//   shipped:   { bg: "#f0fdf4", color: "#10b981", border: "#a7f3d0" },
//   delivered: { bg: "#ecfdf5", color: "#059669", border: "#6ee7b7" },
//   cancelled: { bg: "#fef2f2", color: "#ef4444", border: "#fca5a5" },
//   returned:  { bg: "#f5f3ff", color: "#8b5cf6", border: "#c4b5fd" },
// };
// const PAYMENT_COLORS = {
//   pending:  { bg: "#fffbeb", color: "#f59e0b", border: "#fde68a" },
//   paid:     { bg: "#ecfdf5", color: "#10b981", border: "#6ee7b7" },
//   refunded: { bg: "#f5f3ff", color: "#8b5cf6", border: "#c4b5fd" },
// };
// const REFUND_COLORS = {
//   none:      { bg: "#f8fafc", color: "#94a3b8", border: "#e2e8f0" },
//   pending:   { bg: "#fffbeb", color: "#f59e0b", border: "#fde68a" },
//   refunded: { bg: "#ecfdf5", color: "#10b981", border: "#6ee7b7" },
//   failed:    { bg: "#fef2f2", color: "#ef4444", border: "#fca5a5" },
// };

// const BASE = "http://localhost:5000/api/orders";

// export default function OrderManagement() {
//   const [orders,       setOrders]       = useState([]);
//   const [loading,      setLoading]      = useState(true);
//   const [selected,     setSelected]     = useState(null);
//   const [search,       setSearch]       = useState("");
//   const [filterStatus, setFilterStatus] = useState("all");
//   const [updating,     setUpdating]     = useState(null);
//   const [exporting,    setExporting]    = useState(false);
//   const [cancelModal,  setCancelModal]  = useState(null);
//   const [cancelReason, setCancelReason] = useState("");
//   const [returnModal,  setReturnModal]  = useState(null);
//   const [returnReason, setReturnReason] = useState("");
//   const [refundModal,  setRefundModal]  = useState(null);
//   const [refundAmount, setRefundAmount] = useState("");
//   const [toast,        setToast]        = useState(null);

//   const getToken = () =>
//     JSON.parse(sessionStorage.getItem("userInfo"))?.token ||
//     sessionStorage.getItem("token");
//   const AUTH = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

//   const showToast = (msg, type = "success") => {
//     setToast({ msg, type });
//     setTimeout(() => setToast(null), 3000);
//   };

//   const fetchOrders = async () => {
//     setLoading(true);
//     try {
//       const res = await axios.get(`${BASE}/all`, AUTH());
//       setOrders(res.data || []);
//     } catch (e) {
//       console.log("Orders error:", e.response?.data);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const updateStatus = async (id, newStatus) => {
//     setUpdating(id);
//     try {
//       await axios.put(`${BASE}/${id}/status`, { status: newStatus }, AUTH());
//       fetchOrders();
//       if (selected?._id === id) setSelected(p => ({ ...p, status: newStatus }));
//     } catch {
//       showToast("Failed to update status", "error");
//     } finally {
//       setUpdating(null);
//     }
//   };

//   const handleCancel = async () => {
//     if (!cancelReason.trim()) { showToast("Please enter a cancel reason", "error"); return; }
//     try {
//       await axios.put(`${BASE}/${cancelModal._id}/cancel`, { reason: cancelReason }, AUTH());
//       showToast("Order cancelled successfully");
//       setCancelModal(null); setCancelReason(""); fetchOrders();
//       if (selected?._id === cancelModal._id) setSelected(null);
//     } catch (e) {
//       showToast(e.response?.data?.message || "Cancel failed", "error");
//     }
//   };

//   const handleReturn = async (action, order) => {
//     try {
//       const body = action === "request"
//         ? { action: "request", reason: returnReason || "Return requested" }
//         : { action };
//       await axios.put(`${BASE}/${order._id}/return`, body, AUTH());
//       showToast(`Return ${action}d successfully`);
//       setReturnModal(null); setReturnReason(""); fetchOrders();
//       if (selected?._id === order._id) setSelected(null);
//     } catch (e) {
//       showToast(e.response?.data?.message || "Action failed", "error");
//     }
//   };

//   const handleRefund = async (status) => {
//     try {
//       await axios.put(
//         `${BASE}/${refundModal._id}/refund`,
//         { status, amount: Number(refundAmount) || refundModal.totalPrice },
//         AUTH()
//       );
//       showToast(`Refund ${status} successfully`);
//       setRefundModal(null); setRefundAmount(""); fetchOrders();
//       if (selected?._id === refundModal._id) setSelected(null);
//     } catch (e) {
//       showToast(e.response?.data?.message || "Refund failed", "error");
//     }
//   };

//   const exportCSV = () => {
//     setExporting(true);
//     try {
//       const data = filtered.length > 0 ? filtered : orders;
//       if (data.length === 0) { showToast("No orders to export", "error"); return; }
//       const headers = ["Order ID","Customer","Phone","Items","Total (₹)","Payment","Method","Status","Refund","Date"];
//       const rows = data.map(o => [
//         "#" + o._id.toString().slice(-6).toUpperCase(),
//         o.shippingAddress?.fullName || "",
//         o.shippingAddress?.phone    || "",
//         o.orderItems?.map(i => `${i.name}(x${i.qty})`).join(" | ") || "",
//         o.totalPrice || 0,
//         o.paymentStatus || "",
//         o.paymentMethod || "",
//         o.status        || "",
//         o.refundStatus  || "none",
//         o.createdAt ? new Date(o.createdAt).toLocaleDateString("en-IN") : "",
//       ]);
//       const csv  = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
//       const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
//       const url  = URL.createObjectURL(blob);
//       const a    = document.createElement("a");
//       a.href = url; a.download = `orders_${new Date().toISOString().split("T")[0]}.csv`; a.click();
//       URL.revokeObjectURL(url);
//     } finally {
//       setTimeout(() => setExporting(false), 1000);
//     }
//   };

//   useEffect(() => { fetchOrders(); }, []);

//   const filtered = orders.filter(o => {
//     const matchSearch =
//       o._id.toString().slice(-6).toLowerCase().includes(search.toLowerCase()) ||
//       o.shippingAddress?.fullName?.toLowerCase().includes(search.toLowerCase()) ||
//       o.shippingAddress?.phone?.includes(search);
//     const matchStatus = filterStatus === "all" || o.status === filterStatus;
//     return matchSearch && matchStatus;
//   });

//   const statusCounts = ALL_STATUSES.reduce((acc, s) => {
//     acc[s] = orders.filter(o => o.status === s).length;
//     return acc;
//   }, {});

//   const totalRevenue  = orders.filter(o => o.paymentStatus === "paid").reduce((s, o) => s + o.totalPrice, 0);
//   const cancelledCount = orders.filter(o => o.status === "cancelled").length;
//   const returnCount        = orders.filter(o => o.status === "returned").length;
//   const returnRequestCount = orders.filter(o => o.returnRequest?.requested && o.returnRequest?.status === "pending").length;
//   const refundPending  = orders.filter(o => o.refundStatus === "pending" || (o.status === "cancelled" && o.paymentStatus === "paid" && o.refundStatus !== "processed")).length;

//   const canCancel = (o) => !["delivered","cancelled","returned"].includes(o.status);
//   const canReturn = (o) => o.status === "delivered" && !o.returnRequest?.requested;
//   const canRefund = (o) => (["cancelled","returned"].includes(o.status) || o.refundStatus === "pending") && !["processed","refunded"].includes(o.refundStatus);

//   const STAT_CARDS = [
//     { label: "Revenue",        value: `₹${totalRevenue.toLocaleString()}`, color: P,         bg: "#fff8f2", icon: "💰" },
//     { label: "Pending",        value: statusCounts.pending   || 0,         color: "#f59e0b",  bg: "#fffbeb", icon: "🕐" },
//     { label: "Confirmed",      value: statusCounts.confirmed || 0,         color: "#3b82f6",  bg: "#eff6ff", icon: "✅" },
//     { label: "Shipped",        value: statusCounts.shipped   || 0,         color: "#10b981",  bg: "#f0fdf4", icon: "📦" },
//     { label: "Delivered",      value: statusCounts.delivered || 0,         color: "#059669",  bg: "#ecfdf5", icon: "🏠" },
//     { label: "Cancelled",      value: cancelledCount,                      color: "#ef4444",  bg: "#fef2f2", icon: "✕" },
//     { label: "Returned",       value: returnCount,                         color: "#8b5cf6",  bg: "#f5f3ff", icon: "↩" },
//     { label: "Return Req.",    value: returnRequestCount,                  color: "#f97316",  bg: "#fff8f2", icon: "🔄" },
//     { label: "Refund Pending", value: refundPending,                       color: "#f59e0b",  bg: "#fffbeb", icon: "💸" },
//   ];

//   const TAB_LABELS = ["all","pending","confirmed","shipped","delivered","cancelled","returned"];

//   return (
//     <>
//       <style>{`
//         @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
//         * { box-sizing: border-box; }

//         .om-root {
//           font-family: 'Nunito', sans-serif;
//           background: #fdf5ee;
//           min-height: 100vh;
//           padding: 18px 20px 40px;
//         }

//         /* ── HEADER ── */
//         .om-header {
//           display: flex;
//           align-items: center;
//           justify-content: space-between;
//           margin-bottom: 22px;
//           flex-wrap: wrap;
//           gap: 12px;
//         }
//         .om-page-title {
//           font-size: 26px;
//           font-weight: 900;
//           color: #1a1a1a;
//           letter-spacing: -0.5px;
//           margin-bottom: 2px;
//         }
//         .om-subtitle { font-size: 13px; color: #aaa; font-weight: 700; }
//         .om-header-btns { display: flex; gap: 10px; align-items: center; }

//         .btn-export {
//           display: flex; align-items: center; gap: 7px;
//           padding: 9px 18px;
//           background: linear-gradient(135deg, #ff6f00, #ff9500);
//           color: #fff;
//           border: none;
//           border-radius: 10px;
//           font-weight: 800;
//           font-size: 13px;
//           cursor: pointer;
//           font-family: 'Nunito', sans-serif;
//           box-shadow: 0 3px 12px rgba(255,111,0,0.3);
//           transition: opacity 0.2s;
//         }
//         .btn-export:hover { opacity: 0.88; }
//         .btn-export:disabled { opacity: 0.55; cursor: not-allowed; }

//         .btn-refresh {
//           display: flex; align-items: center; gap: 6px;
//           padding: 9px 16px;
//           background: #fff;
//           color: #555;
//           border: 1.5px solid #ffe0c2;
//           border-radius: 10px;
//           font-weight: 800;
//           font-size: 13px;
//           cursor: pointer;
//           font-family: 'Nunito', sans-serif;
//           transition: background 0.15s, border-color 0.15s;
//         }
//         .btn-refresh:hover { background: #fff8f2; border-color: #ff6f00; color: #ff6f00; }

//         /* ── STAT CARDS ── */
//         .om-stats {
//           display: grid;
//           grid-template-columns: repeat(8, 1fr);
//           gap: 10px;
//           margin-bottom: 20px;
//         }
//         .stat-card {
//           border-radius: 14px;
//           padding: 14px 12px;
//           border: 1.5px solid;
//           text-align: center;
//           transition: transform 0.15s, box-shadow 0.15s;
//           cursor: default;
//         }
//         .stat-card:hover { transform: translateY(-2px); box-shadow: 0 6px 18px rgba(0,0,0,0.08); }
//         .stat-icon { font-size: 15px; margin-bottom: 5px; }
//         .stat-num  { font-size: 17px; font-weight: 900; line-height: 1; margin-bottom: 4px; }
//         .stat-lbl  { font-size: 10.5px; font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.3px; }

//         /* ── FILTERS ── */
//         .om-filters {
//           display: flex;
//           align-items: center;
//           gap: 12px;
//           margin-bottom: 16px;
//           flex-wrap: wrap;
//         }
//         .om-search {
//           flex: 1;
//           min-width: 220px;
//           padding: 9px 14px 9px 36px;
//           border: 1.5px solid #ffe0c2;
//           border-radius: 10px;
//           font-size: 13.5px;
//           font-family: 'Nunito', sans-serif;
//           font-weight: 600;
//           color: #333;
//           background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23aaa' stroke-width='2.5'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cpath d='m21 21-4.35-4.35'/%3E%3C/svg%3E") no-repeat 12px center;
//           outline: none;
//           transition: border-color 0.2s, box-shadow 0.2s;
//         }
//         .om-search:focus { border-color: #ff6f00; box-shadow: 0 0 0 3px rgba(255,111,0,0.1); }

//         .om-tabs { display: flex; gap: 6px; flex-wrap: wrap; }
//         .om-tab {
//           display: flex; align-items: center; gap: 5px;
//           padding: 7px 12px;
//           border-radius: 8px;
//           border: 1.5px solid #e8e8e8;
//           background: #fff;
//           font-size: 12.5px;
//           font-weight: 700;
//           color: #666;
//           cursor: pointer;
//           font-family: 'Nunito', sans-serif;
//           transition: all 0.15s;
//           white-space: nowrap;
//         }
//         .om-tab:hover { border-color: #ffcc99; color: #ff6f00; background: #fff8f2; }
//         .om-tab.active {
//           background: #ff6f00;
//           border-color: #ff6f00;
//           color: #fff;
//         }
//         .tab-cnt {
//           background: rgba(255,255,255,0.3);
//           border-radius: 10px;
//           padding: 1px 6px;
//           font-size: 11px;
//           font-weight: 900;
//           min-width: 18px;
//           text-align: center;
//         }
//         .om-tab:not(.active) .tab-cnt {
//           background: #f0e8e0;
//           color: #ff6f00;
//         }

//         /* ── TABLE WRAPPER ── */
//         .om-table-wrap {
//           background: #fff;
//           border-radius: 16px;
//           border: 1.5px solid #ffe0c2;
//           box-shadow: 0 4px 18px rgba(255,111,0,0.07);
//           overflow: hidden;
//           position: relative;
//         }
//         .om-table-wrap::before {
//           content: '';
//           position: absolute;
//           top: 0; left: 0; right: 0;
//           height: 3px;
//           background: linear-gradient(90deg, #ff6f00, #ffaa5a);
//         }
//         .om-table-scroll { overflow: visible; }

//         /* ── TABLE ── */
//         .om-table {
//           width: 100%;
//           border-collapse: collapse;
//           font-size: 13px;
//           table-layout: auto;
//         }

//         /* COLUMN WIDTHS */
//         .om-table colgroup col:nth-child(1)  { width: 90px; }
//         .om-table colgroup col:nth-child(2)  { width: 130px; }
//         .om-table colgroup col:nth-child(3)  { width: 160px; }
//         .om-table colgroup col:nth-child(4)  { width: 80px; }
//         .om-table colgroup col:nth-child(5)  { width: 100px; }
//         .om-table colgroup col:nth-child(6)  { width: 110px; }
//         .om-table colgroup col:nth-child(7)  { width: 90px; }
//         .om-table colgroup col:nth-child(8)  { width: 90px; }
//         .om-table colgroup col:nth-child(9)  { width: 150px; }

//         .om-thead tr {
//           background: #fff8f2;
//           border-bottom: 1.5px solid #ffe0c2;
//         }
//         .om-th {
//           padding: 12px 14px;
//           text-align: left;
//           font-size: 11px;
//           font-weight: 800;
//           color: #888;
//           text-transform: uppercase;
//           letter-spacing: 0.5px;
//           white-space: nowrap;
//         }

//         .om-tr {
//           border-bottom: 1px solid #fff3e6;
//           transition: background 0.13s;
//         }
//         .om-tr:last-child { border-bottom: none; }
//         .om-tr:hover { background: #fffaf6; }

//         .om-td {
//           padding: 9px 10px;
//           vertical-align: middle;
//         }

//         /* Order ID */
//         .order-id-chip {
//           display: inline-block;
//           background: #fff3e6;
//           border: 1px solid #ffe0c2;
//           color: #ff6f00;
//           font-size: 11.5px;
//           font-weight: 900;
//           padding: 3px 9px;
//           border-radius: 6px;
//           letter-spacing: 0.3px;
//           font-family: 'Courier New', monospace;
//         }

//         /* Customer */
//         .cust-name { font-weight: 800; color: #1a1a1a; font-size: 13px; margin-bottom: 2px; }
//         .cust-phone { font-size: 11.5px; color: #aaa; font-weight: 600; }

//         /* Items */
//         .item-names { font-size: 12.5px; color: #555; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 150px; }
//         .item-count { font-size: 11px; color: #aaa; font-weight: 600; margin-top: 2px; }

//         /* Amount */
//         .amount-val { font-size: 14px; font-weight: 900; color: #ff6f00; }

//         /* Badges */
//         .badge {
//           display: inline-flex;
//           align-items: center;
//           padding: 3px 9px;
//           border-radius: 20px;
//           font-size: 11px;
//           font-weight: 800;
//           border: 1px solid;
//           text-transform: capitalize;
//           white-space: nowrap;
//         }
//         .pay-method { font-size: 10.5px; color: #aaa; font-weight: 600; margin-top: 2px; }
//         .return-tag { font-size: 10px; color: #8b5cf6; font-weight: 700; margin-top: 3px; }
        

//         /* Date */
//         .date-val { font-size: 12px; color: #888; font-weight: 700; }

//         /* ── ACTIONS ── */
//         .actions-cell {
//           display: flex;
//           align-items: center;
//           gap: 5px;
//           flex-wrap: nowrap;
//         }

//         /* Eye button */
//         .act-btn {
//           width: 28px; height: 28px;
//           border-radius: 7px;
//           border: none;
//           display: flex; align-items: center; justify-content: center;
//           cursor: pointer;
//           font-size: 13px;
//           transition: background 0.15s, transform 0.1s;
//           flex-shrink: 0;
//         }
//         .act-btn:hover { transform: scale(1.1); }

//         .act-eye    { background: #eff6ff; color: #3b82f6; }
//         .act-eye:hover { background: #dbeafe; }

//         .act-cancel { background: #fef2f2; color: #ef4444; font-size: 11px; font-weight: 900; }
//         .act-cancel:hover { background: #fee2e2; }

//         .act-return { background: #f5f3ff; color: #8b5cf6; font-size: 12px; }
//         .act-return:hover { background: #ede9fe; }

//         .act-approve { background: #ecfdf5; color: #10b981; font-size: 11px; font-weight: 900; }
//         .act-approve:hover { background: #d1fae5; }

//         .act-reject  { background: #fef2f2; color: #ef4444; font-size: 11px; font-weight: 900; }
//         .act-reject:hover { background: #fee2e2; }

//         .act-refund { background: #fefce8; color: #ca8a04; font-size: 12px; }
//         .act-refund:hover { background: #fef9c3; }

//         /* Status dropdown */
//         .status-select {
//           height: 28px;
//           padding: 0 6px;
//           border: 1.5px solid #ffe0c2;
//           border-radius: 7px;
//           font-size: 11.5px;
//           font-family: 'Nunito', sans-serif;
//           font-weight: 700;
//           color: #555;
//           background: #fff8f2;
//           cursor: pointer;
//           outline: none;
//           max-width: 90px;
//           transition: border-color 0.15s;
//           flex-shrink: 0;
//         }
//         .status-select:focus { border-color: #ff6f00; }
//         .status-select:disabled { opacity: 0.5; cursor: not-allowed; }

//         /* ── EMPTY / LOADING ── */
//         .om-empty {
//           text-align: center;
//           padding: 48px 24px;
//           color: #bbb;
//           font-weight: 700;
//           font-size: 14px;
//         }
//         .om-empty-icon { font-size: 44px; margin-bottom: 12px; }

//         /* ── TOAST ── */
//         .om-toast {
//           position: fixed;
//           top: 20px; right: 20px;
//           padding: 12px 20px;
//           border-radius: 12px;
//           border: 1.5px solid;
//           font-weight: 800;
//           font-size: 13.5px;
//           z-index: 9999;
//           box-shadow: 0 6px 20px rgba(0,0,0,0.12);
//           display: flex; align-items: center; gap: 8px;
//           animation: toast-in 0.3s ease;
//         }
//         @keyframes toast-in {
//           from { opacity: 0; transform: translateY(-10px); }
//           to   { opacity: 1; transform: translateY(0); }
//         }

//         /* ── MODALS ── */
//         .om-overlay {
//           position: fixed; inset: 0;
//           background: rgba(0,0,0,0.45);
//           display: flex; align-items: center; justify-content: center;
//           z-index: 1000;
//           padding: 20px;
//           backdrop-filter: blur(3px);
//         }
//         .om-modal {
//           background: #fff;
//           border-radius: 20px;
//           width: 100%;
//           max-width: 460px;
//           border: 1.5px solid #ffe0c2;
//           box-shadow: 0 20px 60px rgba(0,0,0,0.18);
//           overflow: hidden;
//           position: relative;
//         }
//         .om-modal::before {
//           content: '';
//           position: absolute;
//           top: 0; left: 0; right: 0;
//           height: 4px;
//           background: linear-gradient(90deg, #ff6f00, #ffaa5a);
//         }
//         .modal-head {
//           display: flex;
//           justify-content: space-between;
//           align-items: center;
//           padding: 18px 22px 14px;
//           border-bottom: 1.5px solid #fff3e6;
//         }
//         .modal-title { font-size: 16px; font-weight: 900; color: #1a1a1a; }
//         .modal-close {
//           width: 30px; height: 30px;
//           border: none;
//           background: #f1f5f9;
//           border-radius: 8px;
//           cursor: pointer;
//           font-size: 14px;
//           color: #666;
//           display: flex; align-items: center; justify-content: center;
//           transition: background 0.15s;
//         }
//         .modal-close:hover { background: #e2e8f0; }
//         .modal-body { padding: 18px 22px 22px; }
//         .modal-info { font-size: 13px; color: #666; font-weight: 600; margin-bottom: 14px; line-height: 1.5; }
//         .warning-box {
//           background: #fffbeb;
//           border: 1px solid #fde68a;
//           border-radius: 10px;
//           padding: 10px 13px;
//           font-size: 12.5px;
//           color: #92400e;
//           font-weight: 700;
//           margin-bottom: 14px;
//         }
//         .info-box {
//           background: #eff6ff;
//           border: 1px solid #bfdbfe;
//           border-radius: 10px;
//           padding: 10px 13px;
//           font-size: 12.5px;
//           color: #1e40af;
//           font-weight: 700;
//           margin-bottom: 14px;
//         }
//         .field-label {
//           font-size: 12px;
//           font-weight: 800;
//           color: #888;
//           text-transform: uppercase;
//           letter-spacing: 0.4px;
//           display: block;
//           margin-bottom: 7px;
//         }
//         .modal-textarea {
//           width: 100%;
//           padding: 10px 13px;
//           border: 1.5px solid #e8e8e8;
//           border-radius: 10px;
//           font-size: 13.5px;
//           font-family: 'Nunito', sans-serif;
//           color: #333;
//           resize: vertical;
//           outline: none;
//           margin-bottom: 16px;
//           transition: border-color 0.2s;
//         }
//         .modal-textarea:focus { border-color: #ff6f00; }
//         .modal-input {
//           width: 100%;
//           padding: 10px 13px;
//           border: 1.5px solid #e8e8e8;
//           border-radius: 10px;
//           font-size: 13.5px;
//           font-family: 'Nunito', sans-serif;
//           color: #333;
//           outline: none;
//           margin-bottom: 16px;
//           transition: border-color 0.2s;
//         }
//         .modal-input:focus { border-color: #ff6f00; }
//         .modal-btns { display: flex; gap: 10px; margin-top: 4px; }
//         .modal-btn-back {
//           flex: 1; padding: 11px;
//           background: #f1f5f9; color: #555;
//           border: none; border-radius: 10px;
//           font-weight: 800; font-size: 13.5px;
//           cursor: pointer; font-family: 'Nunito', sans-serif;
//         }
//         .modal-btn-confirm {
//           flex: 1; padding: 11px;
//           background: linear-gradient(135deg, #ff6f00, #ff9500);
//           color: #fff;
//           border: none; border-radius: 10px;
//           font-weight: 800; font-size: 13.5px;
//           cursor: pointer; font-family: 'Nunito', sans-serif;
//           box-shadow: 0 3px 10px rgba(255,111,0,0.3);
//         }
//         .modal-btn-confirm.danger { background: linear-gradient(135deg, #ef4444, #dc2626); box-shadow: 0 3px 10px rgba(239,68,68,0.3); }
//         .modal-btn-confirm.purple { background: linear-gradient(135deg, #8b5cf6, #7c3aed); box-shadow: 0 3px 10px rgba(139,92,246,0.3); }
//         .modal-btn-confirm.green  { background: linear-gradient(135deg, #10b981, #059669); box-shadow: 0 3px 10px rgba(16,185,129,0.3); }

//         @media (max-width: 1024px) {
//           .om-stats { grid-template-columns: repeat(4, 1fr); }
//         }
//         @media (max-width: 640px) {
//           .om-stats { grid-template-columns: repeat(2, 1fr); }
//         }
//       `}</style>

//       <div className="om-root">

//         {/* TOAST */}
//         {toast && (
//           <div className="om-toast" style={{
//             background:  toast.type === "success" ? "#ecfdf5" : "#fef2f2",
//             borderColor: toast.type === "success" ? "#6ee7b7" : "#fca5a5",
//             color:       toast.type === "success" ? "#065f46" : "#991b1b",
//           }}>
//             {toast.type === "success" ? "✅" : "❌"} {toast.msg}
//           </div>
//         )}

//         {/* HEADER */}
//         <div style={{
//   background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
//   borderRadius: 22, padding: "26px 32px", marginBottom: 22,
//   position: "relative", overflow: "hidden",
//   boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
// }}>
//   <div style={{ position:"absolute", top:-40, right:-40, width:180, height:180, borderRadius:"50%", background:"rgba(255,255,255,0.08)" }} />
//   <div style={{ position:"absolute", bottom:-50, left:"35%", width:220, height:220, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }} />
//   <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
//     <div>
//       <h1 style={{ margin:0, fontSize:28, fontWeight:900, color:"#fff", letterSpacing:-0.5 }}>🛍️ Order Management</h1>
//       <p style={{ margin:"5px 0 0", fontSize:13, color:"rgba(255,255,255,0.8)", fontWeight:700 }}>{orders.length} total orders</p>
//     </div>
//     <div style={{ display:"flex", gap:10 }}>
//       <button className="btn-export" onClick={exportCSV} disabled={exporting||loading}>
//         {exporting ? "⏳ Exporting..." : `⬇️ Export CSV (${filtered.length})`}
//       </button>
//       <button className="btn-refresh" onClick={fetchOrders} disabled={loading}>↻ Refresh</button>
//     </div>
//   </div>
// </div>

//         {/* STAT CARDS */}
//         <div className="om-stats">
//           {STAT_CARDS.map((s, i) => (
//             <div key={i} className="stat-card" style={{
//               background: s.bg,
//               borderColor: s.color + "44",
//             }}>
//               <div className="stat-icon">{s.icon}</div>
//               <div className="stat-num" style={{ color: s.color }}>{s.value}</div>
//               <div className="stat-lbl">{s.label}</div>
//             </div>
//           ))}
//         </div>

//         {/* FILTERS */}
//         <div className="om-filters">
//           <input
//             className="om-search"
//             placeholder="Search by order ID, name or phone..."
//             value={search}
//             onChange={e => setSearch(e.target.value)}
//           />
//           <div className="om-tabs">
//             {TAB_LABELS.map(s => (
//               <button
//                 key={s}
//                 className={`om-tab ${filterStatus === s ? "active" : ""}`}
//                 onClick={() => setFilterStatus(s)}
//               >
//                 {s === "all" ? "All" : s.charAt(0).toUpperCase() + s.slice(1)}
//                 {s !== "all" && (
//                   <span className="tab-cnt">{statusCounts[s] || 0}</span>
//                 )}
//               </button>
//             ))}
//           </div>
//         </div>

//         {/* TABLE */}
//         <div className="om-table-wrap">
//           <div className="om-table-scroll">
//             {loading ? (
//               <div className="om-empty">
//                 <div className="om-empty-icon">⏳</div>
//                 Loading orders...
//               </div>
//             ) : filtered.length === 0 ? (
//               <div className="om-empty">
//                 <div className="om-empty-icon">📭</div>
//                 No orders found
//               </div>
//             ) : (
//               <table className="om-table">
//                 <colgroup>
//                   <col /><col /><col /><col /><col /><col /><col /><col />
//                 </colgroup>
//                 <thead className="om-thead">
//                   <tr>
//                     {["Order ID","Customer","Items","Amount","Payment","Status","Date","Actions"].map(h => (
//                       <th key={h} className="om-th">{h}</th>
//                     ))}
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {filtered.map(o => {
//                     const sc = STATUS_COLORS[o.status]         || STATUS_COLORS.pending;
//                     const pc = PAYMENT_COLORS[o.paymentStatus] || PAYMENT_COLORS.pending;
                    
//                     return (
//                       <tr key={o._id} className="om-tr">

//                         {/* ORDER ID */}
//                         <td className="om-td">
//                           <span className="order-id-chip">#{o._id.toString().slice(-6).toUpperCase()}</span>
//                         </td>

//                         {/* CUSTOMER */}
//                         <td className="om-td">
//                           <div className="cust-name">{o.shippingAddress?.fullName}</div>
//                           <div className="cust-phone">{o.shippingAddress?.phone}</div>
//                         </td>

//                         {/* ITEMS */}
//                         <td className="om-td">
//                           <div className="item-names">
//                             {o.orderItems?.slice(0,2).map(i => i.name).join(", ")}
//                             {o.orderItems?.length > 2 && ` +${o.orderItems.length - 2}`}
//                           </div>
//                           <div className="item-count">{o.orderItems?.length} item{o.orderItems?.length > 1 ? "s" : ""}</div>
//                         </td>

//                         {/* AMOUNT */}
//                         <td className="om-td">
//                           <span className="amount-val">₹{o.totalPrice?.toLocaleString()}</span>
//                         </td>

//                         {/* PAYMENT */}
//                         <td className="om-td">
//                           <span className="badge" style={{ background: pc.bg, color: pc.color, borderColor: pc.border }}>
//                             {o.paymentStatus}
//                           </span>
//                           <div className="pay-method">{o.paymentMethod}</div>
//                         </td>

//                         {/* STATUS */}
//                         <td className="om-td">
//                           <span className="badge" style={{ background: sc.bg, color: sc.color, borderColor: sc.border }}>
//                             {o.status}
//                           </span>
//                           {o.returnRequest?.requested && (
//                             <div className="return-tag">↩ Return: {o.returnRequest.status}</div>
//                           )}
//                         </td>

//                         {/* DATE */}
//                         <td className="om-td">
//                           <div className="date-val">
//                             {new Date(o.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
//                           </div>
//                         </td>

//                         {/* ACTIONS */}
//                         <td className="om-td">
//                           <div className="actions-cell">
//                             {/* View */}
//                             <button className="act-btn act-eye" onClick={() => setSelected(o)} title="View Order">
//                               👁
//                             </button>

//                             {/* Status dropdown */}
//                             {!["cancelled","returned"].includes(o.status) && (
//                               <select
//                                 className="status-select"
//                                 value={o.status}
//                                 onChange={e => updateStatus(o._id, e.target.value)}
//                                 disabled={updating === o._id}
//                               >
//                                 {STATUS_FLOW.map(s => (
//                                   <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
//                                 ))}
//                               </select>
//                             )}

//                             {/* Cancel */}
//                             {canCancel(o) && (
//                               <button
//                                 className="act-btn act-cancel"
//                                 onClick={() => { setCancelModal(o); setCancelReason(""); }}
//                                 title="Cancel Order"
//                               >
//                                 ✕
//                               </button>
//                             )}

//                             {/* Return */}
//                             {canReturn(o) && (
//                               <button
//                                 className="act-btn act-return"
//                                 onClick={() => { setReturnModal(o); setReturnReason(""); }}
//                                 title="Request Return"
//                               >
//                                 ↩
//                               </button>
//                             )}

//                             {/* Approve / Reject return */}
//                             {o.returnRequest?.requested && o.returnRequest?.status === "pending" && (
//                               <>
//                                 <button className="act-btn act-approve" onClick={() => handleReturn("approve", o)} title="Approve Return">✓</button>
//                                 <button className="act-btn act-reject"  onClick={() => handleReturn("reject",  o)} title="Reject Return">✕</button>
//                               </>
//                             )}

//                             {/* Refund */}
//                             {canRefund(o) && (
//                               <button
//                                 className="act-btn act-refund"
//                                 onClick={() => { setRefundModal(o); setRefundAmount(o.totalPrice); }}
//                                 title="Process Refund"
//                               >
//                                 💸
//                               </button>
//                             )}
//                           </div>
//                         </td>
//                       </tr>
//                     );
//                   })}
//                 </tbody>
//               </table>
//             )}
//           </div>
//         </div>

//         {/* ── CANCEL MODAL ── */}
//         {cancelModal && (
//           <div className="om-overlay" onClick={() => setCancelModal(null)}>
//             <div className="om-modal" onClick={e => e.stopPropagation()}>
//               <div className="modal-head">
//                 <p className="modal-title">✕ Cancel Order</p>
//                 <button className="modal-close" onClick={() => setCancelModal(null)}>✕</button>
//               </div>
//               <div className="modal-body">
//                 <p className="modal-info">
//                   Cancelling order <strong>#{cancelModal._id.toString().slice(-6).toUpperCase()}</strong> for{" "}
//                   <strong>{cancelModal.shippingAddress?.fullName}</strong> · ₹{cancelModal.totalPrice?.toLocaleString()}
//                 </p>
//                 {cancelModal.paymentStatus === "paid" && (
//                   <div className="warning-box">
//                     ⚠️ This order is already paid. A refund of ₹{cancelModal.totalPrice?.toLocaleString()} will be initiated automatically.
//                   </div>
//                 )}
//                 <label className="field-label">Cancellation Reason *</label>
//                 <textarea
//                   className="modal-textarea"
//                   value={cancelReason}
//                   onChange={e => setCancelReason(e.target.value)}
//                   placeholder="e.g. Out of stock, Customer requested, Duplicate order..."
//                   rows={3}
//                 />
//                 <div className="modal-btns">
//                   <button className="modal-btn-back" onClick={() => setCancelModal(null)}>Back</button>
//                   <button className="modal-btn-confirm danger" onClick={handleCancel}>✕ Confirm Cancel</button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         )}

//         {/* ── RETURN MODAL ── */}
//         {returnModal && (
//           <div className="om-overlay" onClick={() => setReturnModal(null)}>
//             <div className="om-modal" onClick={e => e.stopPropagation()}>
//               <div className="modal-head">
//                 <p className="modal-title">↩ Return Request</p>
//                 <button className="modal-close" onClick={() => setReturnModal(null)}>✕</button>
//               </div>
//               <div className="modal-body">
//                 <p className="modal-info">
//                   Order <strong>#{returnModal._id.toString().slice(-6).toUpperCase()}</strong> · ₹{returnModal.totalPrice?.toLocaleString()}
//                 </p>
//                 <label className="field-label">Return Reason</label>
//                 <textarea
//                   className="modal-textarea"
//                   value={returnReason}
//                   onChange={e => setReturnReason(e.target.value)}
//                   placeholder="e.g. Defective product, Wrong item, Customer changed mind..."
//                   rows={3}
//                 />
//                 <div className="info-box">ℹ️ Approving return will automatically set refund status to pending.</div>
//                 <div className="modal-btns">
//                   <button className="modal-btn-back" onClick={() => setReturnModal(null)}>Back</button>
//                   <button className="modal-btn-confirm purple" onClick={() => handleReturn("request", returnModal)}>↩ Initiate Return</button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         )}


//         {/* ── VIEW ORDER MODAL ── */}
//         {selected && (
//           <div className="om-overlay" onClick={() => setSelected(null)}>
//             <div className="om-modal" style={{ maxWidth: 540 }} onClick={e => e.stopPropagation()}>
//               <div className="modal-head">
//                 <p className="modal-title">📋 Order #{selected._id.toString().slice(-6).toUpperCase()}</p>
//                 <button className="modal-close" onClick={() => setSelected(null)}>✕</button>
//               </div>
//               <div className="modal-body" style={{ maxHeight: "80vh", overflowY: "auto" }}>
//                 {/* Customer */}
//                 <div style={{ background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 12, padding: "12px 14px", marginBottom: 14 }}>
//                   <p style={{ fontSize: 11, fontWeight: 800, color: "#aaa", textTransform: "uppercase", letterSpacing: "0.4px", marginBottom: 6 }}>Customer</p>
//                   <p style={{ fontWeight: 800, color: "#1a1a1a", fontSize: 14, marginBottom: 2 }}>{selected.shippingAddress?.fullName}</p>
//                   <p style={{ fontSize: 12, color: "#888", fontWeight: 600 }}>{selected.shippingAddress?.phone}</p>
//                   <p style={{ fontSize: 12, color: "#888", fontWeight: 600, marginTop: 2 }}>
//                     {selected.shippingAddress?.address}, {selected.shippingAddress?.city} — {selected.shippingAddress?.pincode}
//                   </p>
//                 </div>

//                 {/* Status row */}
//                 <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 14 }}>
//                   {[
//                     { label: "Status",  value: selected.status,        colors: STATUS_COLORS[selected.status] || STATUS_COLORS.pending },
//                     { label: "Payment", value: selected.paymentStatus,  colors: PAYMENT_COLORS[selected.paymentStatus] || PAYMENT_COLORS.pending },
//                     { label: "Method",  value: selected.paymentMethod,  colors: { bg: "#f8fafc", color: "#64748b", border: "#e2e8f0" } },
//                   ].map((item, i) => (
//                     <div key={i} style={{ background: item.colors.bg, border: `1px solid ${item.colors.border}`, borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
//                       <p style={{ fontSize: 10, fontWeight: 700, color: "#aaa", textTransform: "uppercase", marginBottom: 4 }}>{item.label}</p>
//                       <p style={{ fontSize: 13, fontWeight: 900, color: item.colors.color, textTransform: "capitalize" }}>{item.value}</p>
//                     </div>
//                   ))}
//                 </div>

//                 {/* Items */}
//                 <p style={{ fontSize: 11, fontWeight: 800, color: "#aaa", textTransform: "uppercase", letterSpacing: "0.4px", marginBottom: 8 }}>Order Items</p>
//                 <div style={{ border: "1.5px solid #f0e8e0", borderRadius: 12, overflow: "hidden", marginBottom: 14 }}>
//                   {selected.orderItems?.map((item, i) => (
//                     <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderBottom: i < selected.orderItems.length - 1 ? "1px solid #fff3e6" : "none", background: i % 2 === 0 ? "#fff" : "#fdfaf8" }}>
//                       <img
//                         // src={item.product?.images?.length > 0 ? item.product.images[0] : "https://dummyimage.com/60x60/fff8f2/ff6f00&text=?"}
//   src={
//     item.image
//       ? item.image.startsWith("http")
//         ? item.image
//         : `http://localhost:5000${item.image}`
//       : item.images?.[0]
//         ? item.images[0].startsWith("http")
//           ? item.images[0]
//           : `http://localhost:5000${item.images[0]}`
//         : "/placeholder.png"
//   }
//                         alt={item.name}
//                         style={{ width: 44, height: 44, borderRadius: 8, objectFit: "cover", border: "1.5px solid #ffe0c2", flexShrink: 0 }}
//                       />
//                       <div style={{ flex: 1, minWidth: 0 }}>
//                         <p style={{ fontSize: 13, fontWeight: 800, color: "#1a1a1a", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.name}</p>
//                         <p style={{ fontSize: 11.5, color: "#aaa", fontWeight: 600 }}>Qty: {item.qty}</p>
//                       </div>
//                       <p style={{ fontSize: 14, fontWeight: 900, color: "#ff6f00", flexShrink: 0 }}>₹{(item.price * item.qty).toLocaleString()}</p>
//                     </div>
//                   ))}
//                 </div>

//                 {/* Total */}
//                 <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 10, padding: "12px 14px", marginBottom: 16 }}>
//                   <span style={{ fontSize: 14, fontWeight: 700, color: "#555" }}>Total Amount</span>
//                   <span style={{ fontSize: 20, fontWeight: 900, color: "#ff6f00" }}>₹{selected.totalPrice?.toLocaleString()}</span>
//                 </div>

//                 <div style={{ display: "flex", gap: 10 }}>
//                   <button className="modal-btn-back" style={{ flex: 1 }} onClick={() => setSelected(null)}>Close</button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         )}

//         {/* ── REFUND MODAL ── */}
//         {refundModal && (
//           <div className="om-overlay" onClick={() => setRefundModal(null)}>
//             <div className="om-modal" onClick={e => e.stopPropagation()}>
//               <div className="modal-head">
//                 <p className="modal-title">💸 Process Refund</p>
//                 <button className="modal-close" onClick={() => setRefundModal(null)}>✕</button>
//               </div>
//               <div className="modal-body">
//                 <p className="modal-info">
//                   Order <strong>#{refundModal._id.toString().slice(-6).toUpperCase()}</strong> · Paid via{" "}
//                   <strong>{refundModal.paymentMethod}</strong> · ₹{refundModal.totalPrice?.toLocaleString()}
//                 </p>
//                 <label className="field-label">Refund Amount (₹)</label>
//                 <input
//                   type="number"
//                   className="modal-input"
//                   value={refundAmount}
//                   onChange={e => setRefundAmount(e.target.value)}
//                   placeholder={`Max: ₹${refundModal.totalPrice}`}
//                 />
//                 <div className="modal-btns">
//                   <button className="modal-btn-back" onClick={() => setRefundModal(null)}>Back</button>
//                   <button className="modal-btn-confirm danger" onClick={() => handleRefund("failed")}>✕ Reject</button>
//                   <button className="modal-btn-confirm green"  onClick={() => handleRefund("processed")}>✓ Approve</button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         )}

//       </div>
//     </>
//   );
// }



import { useEffect, useState } from "react";
import axios from "axios";

const P = "#ff6f00";

const STATUS_FLOW = ["pending", "confirmed", "shipped", "delivered"];
const ALL_STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled", "returned"];

const STATUS_COLORS = {
  pending:   { bg: "#fffbeb", color: "#f59e0b", border: "#fde68a" },
  confirmed: { bg: "#eff6ff", color: "#3b82f6", border: "#bfdbfe" },
  shipped:   { bg: "#f0fdf4", color: "#10b981", border: "#a7f3d0" },
  delivered: { bg: "#ecfdf5", color: "#059669", border: "#6ee7b7" },
  cancelled: { bg: "#fef2f2", color: "#ef4444", border: "#fca5a5" },
  returned:  { bg: "#f5f3ff", color: "#8b5cf6", border: "#c4b5fd" },
};

const PAYMENT_COLORS = {
  pending:  { bg: "#fffbeb", color: "#f59e0b", border: "#fde68a" },
  paid:     { bg: "#ecfdf5", color: "#10b981", border: "#6ee7b7" },
  refunded: { bg: "#f5f3ff", color: "#8b5cf6", border: "#c4b5fd" },
};
const REFUND_COLORS = {
  none:     { bg: "#f8fafc", color: "#94a3b8", border: "#e2e8f0" },
  pending:  { bg: "#fffbeb", color: "#f59e0b", border: "#fde68a" },
  refunded: { bg: "#ecfdf5", color: "#10b981", border: "#6ee7b7" },
  rejected: { bg: "#fef2f2", color: "#ef4444", border: "#fca5a5" }, // ← add
};

const BASE = "http://localhost:5000/api/orders";

export default function OrderManagement() {
  const [orders,       setOrders]       = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [selected,     setSelected]     = useState(null);
  const [search,       setSearch]       = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [updating,     setUpdating]     = useState(null);
  const [exporting,    setExporting]    = useState(false);
  const [cancelModal,  setCancelModal]  = useState(null);
  const [cancelReason, setCancelReason] = useState("");
  const [returnModal,  setReturnModal]  = useState(null);
  const [returnReason, setReturnReason] = useState("");
  const [refundModal,  setRefundModal]  = useState(null);
  const [refundAmount, setRefundAmount] = useState("");
  const [toast,        setToast]        = useState(null);

  const getToken = () =>
    JSON.parse(sessionStorage.getItem("userInfo"))?.token ||
    sessionStorage.getItem("token");
  const AUTH = () => ({ headers: { Authorization: `Bearer ${getToken()}` } });

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${BASE}/all`, AUTH());
      setOrders(res.data || []);
    } catch (e) {
      console.log("Orders error:", e.response?.data);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (id, newStatus) => {
    setUpdating(id);
    try {
      await axios.put(`${BASE}/${id}/status`, { status: newStatus }, AUTH());
      fetchOrders();
      if (selected?._id === id) setSelected(p => ({ ...p, status: newStatus }));
    } catch {
      showToast("Failed to update status", "error");
    } finally {
      setUpdating(null);
    }
  };

  const handleCancel = async () => {
    if (!cancelReason.trim()) { showToast("Please enter a cancel reason", "error"); return; }
    try {
      await axios.put(`${BASE}/${cancelModal._id}/cancel`, { reason: cancelReason }, AUTH());
      showToast("Order cancelled successfully");
      setCancelModal(null); setCancelReason(""); fetchOrders();
      if (selected?._id === cancelModal._id) setSelected(null);
    } catch (e) {
      showToast(e.response?.data?.message || "Cancel failed", "error");
    }
  };

  // ✅ FIXED: split routes for user return request vs admin approve/reject
  const handleReturn = async (action, order) => {
    try {
      if (action === "request") {
        // User/admin initiating return → /return
        await axios.put(`${BASE}/${order._id}/return`,
          { reason: returnReason || "Return requested" }, AUTH());
      } else {
        // Admin approve/reject → /handle-return
        await axios.put(`${BASE}/${order._id}/handle-return`,
          { action }, AUTH());
      }
      showToast(`Return ${action}d successfully`);
      setReturnModal(null); setReturnReason(""); fetchOrders();
      if (selected?._id === order._id) setSelected(null);
    } catch (e) {
      showToast(e.response?.data?.message || "Action failed", "error");
    }
  };

  // ✅ FIXED: always sends "refunded" — not "processed"
  // const handleRefund = async () => {
  //   try {
  //     await axios.put(
  //       `${BASE}/${refundModal._id}/refund`,
  //       { status: "refunded", amount: Number(refundAmount) || refundModal.totalPrice },
  //       AUTH()
  //     );
  //     showToast("Refund processed successfully");
  //     setRefundModal(null); setRefundAmount(""); fetchOrders();
  //     if (selected?._id === refundModal._id) setSelected(null);
  //   } catch (e) {
  //     showToast(e.response?.data?.message || "Refund failed", "error");
  //   }
  // };

  // Update handleRefund to accept status
const handleRefund = async (status = "refunded") => {
  try {
    await axios.put(
      `${BASE}/${refundModal._id}/refund`,
      { status, amount: Number(refundAmount) || refundModal.totalPrice },
      AUTH()
    );
    showToast(status === "refunded" ? "Refund approved!" : "Refund rejected");
    setRefundModal(null); setRefundAmount(""); fetchOrders();
    if (selected?._id === refundModal._id) setSelected(null);
  } catch (e) {
    showToast(e.response?.data?.message || "Refund failed", "error");
  }
};


  const exportCSV = () => {
    setExporting(true);
    try {
      const data = filtered.length > 0 ? filtered : orders;
      if (data.length === 0) { showToast("No orders to export", "error"); return; }
      const headers = ["Order ID","Customer","Phone","Items","Total (₹)","Payment","Method","Status","Refund","Date"];
      const rows = data.map(o => [
        "#" + o._id.toString().slice(-6).toUpperCase(),
        o.shippingAddress?.fullName || "",
        o.shippingAddress?.phone    || "",
        o.orderItems?.map(i => `${i.name}(x${i.qty})`).join(" | ") || "",
        o.totalPrice || 0,
        o.paymentStatus || "",
        o.paymentMethod || "",
        o.status        || "",
        o.refundStatus  || "none",
        o.createdAt ? new Date(o.createdAt).toLocaleDateString("en-IN") : "",
      ]);
      const csv  = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href = url; a.download = `orders_${new Date().toISOString().split("T")[0]}.csv`; a.click();
      URL.revokeObjectURL(url);
    } finally {
      setTimeout(() => setExporting(false), 1000);
    }
  };

  useEffect(() => { fetchOrders(); }, []);

  const filtered = orders.filter(o => {
    const matchSearch =
      o._id.toString().slice(-6).toLowerCase().includes(search.toLowerCase()) ||
      o.shippingAddress?.fullName?.toLowerCase().includes(search.toLowerCase()) ||
      o.shippingAddress?.phone?.includes(search);
    const matchStatus = filterStatus === "all" || o.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const statusCounts = ALL_STATUSES.reduce((acc, s) => {
    acc[s] = orders.filter(o => o.status === s).length;
    return acc;
  }, {});

  const totalRevenue       = orders.filter(o => o.paymentStatus === "paid").reduce((s, o) => s + o.totalPrice, 0);
  const cancelledCount     = orders.filter(o => o.status === "cancelled").length;
  const returnCount        = orders.filter(o => o.status === "returned").length;
  // ✅ FIXED: use returnInfo instead of returnRequest
  const returnRequestCount = orders.filter(o => o.returnInfo?.status === "requested").length;
  // ✅ FIXED: "refunded" not "processed"
  const refundPending      = orders.filter(o => o.refundStatus === "pending").length;

  const canCancel = (o) => !["delivered","cancelled","returned"].includes(o.status);
  const canReturn = (o) => o.status === "delivered" && !o.returnInfo?.status;
  // ✅ FIXED: check "refunded" not "processed"
  const canRefund = (o) => (["cancelled","returned"].includes(o.status) || o.refundStatus === "pending") &&!["refunded","rejected"].includes(o.refundStatus);

  const STAT_CARDS = [
    { label: "Revenue",        value: `₹${totalRevenue.toLocaleString()}`, color: P,         bg: "#fff8f2", icon: "💰" },
    { label: "Pending",        value: statusCounts.pending   || 0,         color: "#f59e0b",  bg: "#fffbeb", icon: "🕐" },
    { label: "Confirmed",      value: statusCounts.confirmed || 0,         color: "#3b82f6",  bg: "#eff6ff", icon: "✅" },
    { label: "Shipped",        value: statusCounts.shipped   || 0,         color: "#10b981",  bg: "#f0fdf4", icon: "📦" },
    { label: "Delivered",      value: statusCounts.delivered || 0,         color: "#059669",  bg: "#ecfdf5", icon: "🏠" },
    { label: "Cancelled",      value: cancelledCount,                      color: "#ef4444",  bg: "#fef2f2", icon: "✕" },
    { label: "Returned",       value: returnCount,                         color: "#8b5cf6",  bg: "#f5f3ff", icon: "↩" },
    { label: "Return Req.",    value: returnRequestCount,                  color: "#f97316",  bg: "#fff8f2", icon: "🔄" },
    { label: "Refund Pending", value: refundPending,                       color: "#f59e0b",  bg: "#fffbeb", icon: "💸" },
  ];

  const TAB_LABELS = ["all","pending","confirmed","shipped","delivered","cancelled","returned"];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
        * { box-sizing: border-box; }
        .om-root { font-family: 'Nunito', sans-serif; background: #fdf5ee; min-height: 100vh; padding: 18px 20px 40px; }
        .om-stats { display: grid; grid-template-columns: repeat(9, 1fr); gap: 10px; margin-bottom: 20px; }
        .stat-card { border-radius: 14px; padding: 14px 12px; border: 1.5px solid; text-align: center; transition: transform 0.15s, box-shadow 0.15s; cursor: default; }
        .stat-card:hover { transform: translateY(-2px); box-shadow: 0 6px 18px rgba(0,0,0,0.08); }
        .stat-icon { font-size: 15px; margin-bottom: 5px; }
        .stat-num  { font-size: 17px; font-weight: 900; line-height: 1; margin-bottom: 4px; }
        .stat-lbl  { font-size: 10.5px; font-weight: 700; color: #888; text-transform: uppercase; letter-spacing: 0.3px; }
        .om-filters { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
        .om-search { flex: 1; min-width: 220px; padding: 9px 14px 9px 36px; border: 1.5px solid #ffe0c2; border-radius: 10px; font-size: 13.5px; font-family: 'Nunito', sans-serif; font-weight: 600; color: #333; background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23aaa' stroke-width='2.5'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cpath d='m21 21-4.35-4.35'/%3E%3C/svg%3E") no-repeat 12px center; outline: none; transition: border-color 0.2s, box-shadow 0.2s; }
        .om-search:focus { border-color: #ff6f00; box-shadow: 0 0 0 3px rgba(255,111,0,0.1); }
        .om-tabs { display: flex; gap: 6px; flex-wrap: wrap; }
        .om-tab { display: flex; align-items: center; gap: 5px; padding: 7px 12px; border-radius: 8px; border: 1.5px solid #e8e8e8; background: #fff; font-size: 12.5px; font-weight: 700; color: #666; cursor: pointer; font-family: 'Nunito', sans-serif; transition: all 0.15s; white-space: nowrap; }
        .om-tab:hover { border-color: #ffcc99; color: #ff6f00; background: #fff8f2; }
        .om-tab.active { background: #ff6f00; border-color: #ff6f00; color: #fff; }
        .tab-cnt { background: rgba(255,255,255,0.3); border-radius: 10px; padding: 1px 6px; font-size: 11px; font-weight: 900; min-width: 18px; text-align: center; }
        .om-tab:not(.active) .tab-cnt { background: #f0e8e0; color: #ff6f00; }
        .om-table-wrap { background: #fff; border-radius: 16px; border: 1.5px solid #ffe0c2; box-shadow: 0 4px 18px rgba(255,111,0,0.07); overflow: hidden; position: relative; }
        .om-table-wrap::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #ff6f00, #ffaa5a); }
        .om-table { width: 100%; border-collapse: collapse; font-size: 13px; table-layout: auto; }
        .om-thead tr { background: #fff8f2; border-bottom: 1.5px solid #ffe0c2; }
        .om-th { padding: 12px 14px; text-align: left; font-size: 11px; font-weight: 800; color: #888; text-transform: uppercase; letter-spacing: 0.5px; white-space: nowrap; }
        .om-tr { border-bottom: 1px solid #fff3e6; transition: background 0.13s; }
        .om-tr:last-child { border-bottom: none; }
        .om-tr:hover { background: #fffaf6; }
        .om-td { padding: 9px 10px; vertical-align: middle; }
        .order-id-chip { display: inline-block; background: #fff3e6; border: 1px solid #ffe0c2; color: #ff6f00; font-size: 11.5px; font-weight: 900; padding: 3px 9px; border-radius: 6px; letter-spacing: 0.3px; font-family: 'Courier New', monospace; }
        .cust-name { font-weight: 800; color: #1a1a1a; font-size: 13px; margin-bottom: 2px; }
        .cust-phone { font-size: 11.5px; color: #aaa; font-weight: 600; }
        .item-names { font-size: 12.5px; color: #555; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 150px; }
        .item-count { font-size: 11px; color: #aaa; font-weight: 600; margin-top: 2px; }
        .amount-val { font-size: 14px; font-weight: 900; color: #ff6f00; }
        .badge { display: inline-flex; align-items: center; padding: 3px 9px; border-radius: 20px; font-size: 11px; font-weight: 800; border: 1px solid; text-transform: capitalize; white-space: nowrap; }
        .pay-method { font-size: 10.5px; color: #aaa; font-weight: 600; margin-top: 2px; }
        .return-tag { font-size: 10px; color: #8b5cf6; font-weight: 700; margin-top: 3px; }
        .date-val { font-size: 12px; color: #888; font-weight: 700; }
        .actions-cell { display: flex; align-items: center; gap: 5px; flex-wrap: nowrap; }
        .act-btn { width: 28px; height: 28px; border-radius: 7px; border: none; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 13px; transition: background 0.15s, transform 0.1s; flex-shrink: 0; }
        .act-btn:hover { transform: scale(1.1); }
        .act-eye    { background: #eff6ff; color: #3b82f6; }
        .act-eye:hover { background: #dbeafe; }
        .act-cancel { background: #fef2f2; color: #ef4444; font-size: 11px; font-weight: 900; }
        .act-cancel:hover { background: #fee2e2; }
        .act-return { background: #f5f3ff; color: #8b5cf6; font-size: 12px; }
        .act-return:hover { background: #ede9fe; }
        .act-approve { background: #ecfdf5; color: #10b981; font-size: 11px; font-weight: 900; }
        .act-approve:hover { background: #d1fae5; }
        .act-reject  { background: #fef2f2; color: #ef4444; font-size: 11px; font-weight: 900; }
        .act-reject:hover { background: #fee2e2; }
        .act-refund { background: #fefce8; color: #ca8a04; font-size: 12px; }
        .act-refund:hover { background: #fef9c3; }
        .status-select { height: 28px; padding: 0 6px; border: 1.5px solid #ffe0c2; border-radius: 7px; font-size: 11.5px; font-family: 'Nunito', sans-serif; font-weight: 700; color: #555; background: #fff8f2; cursor: pointer; outline: none; max-width: 90px; transition: border-color 0.15s; flex-shrink: 0; }
        .status-select:focus { border-color: #ff6f00; }
        .status-select:disabled { opacity: 0.5; cursor: not-allowed; }
        .om-empty { text-align: center; padding: 48px 24px; color: #bbb; font-weight: 700; font-size: 14px; }
        .om-empty-icon { font-size: 44px; margin-bottom: 12px; }
        .om-toast { position: fixed; top: 20px; right: 20px; padding: 12px 20px; border-radius: 12px; border: 1.5px solid; font-weight: 800; font-size: 13.5px; z-index: 9999; box-shadow: 0 6px 20px rgba(0,0,0,0.12); display: flex; align-items: center; gap: 8px; animation: toast-in 0.3s ease; }
        @keyframes toast-in { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
        .om-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 20px; backdrop-filter: blur(3px); }
        .om-modal { background: #fff; border-radius: 20px; width: 100%; max-width: 460px; border: 1.5px solid #ffe0c2; box-shadow: 0 20px 60px rgba(0,0,0,0.18); overflow: hidden; position: relative; }
        .om-modal::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px; background: linear-gradient(90deg, #ff6f00, #ffaa5a); }
        .modal-head { display: flex; justify-content: space-between; align-items: center; padding: 18px 22px 14px; border-bottom: 1.5px solid #fff3e6; }
        .modal-title { font-size: 16px; font-weight: 900; color: #1a1a1a; }
        .modal-close { width: 30px; height: 30px; border: none; background: #f1f5f9; border-radius: 8px; cursor: pointer; font-size: 14px; color: #666; display: flex; align-items: center; justify-content: center; transition: background 0.15s; }
        .modal-close:hover { background: #e2e8f0; }
        .modal-body { padding: 18px 22px 22px; }
        .modal-info { font-size: 13px; color: #666; font-weight: 600; margin-bottom: 14px; line-height: 1.5; }
        .warning-box { background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 10px 13px; font-size: 12.5px; color: #92400e; font-weight: 700; margin-bottom: 14px; }
        .info-box { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 10px; padding: 10px 13px; font-size: 12.5px; color: #1e40af; font-weight: 700; margin-bottom: 14px; }
        .field-label { font-size: 12px; font-weight: 800; color: #888; text-transform: uppercase; letter-spacing: 0.4px; display: block; margin-bottom: 7px; }
        .modal-textarea { width: 100%; padding: 10px 13px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 13.5px; font-family: 'Nunito', sans-serif; color: #333; resize: vertical; outline: none; margin-bottom: 16px; transition: border-color 0.2s; }
        .modal-textarea:focus { border-color: #ff6f00; }
        .modal-input { width: 100%; padding: 10px 13px; border: 1.5px solid #e8e8e8; border-radius: 10px; font-size: 13.5px; font-family: 'Nunito', sans-serif; color: #333; outline: none; margin-bottom: 16px; transition: border-color 0.2s; }
        .modal-input:focus { border-color: #ff6f00; }
        .modal-btns { display: flex; gap: 10px; margin-top: 4px; }
        .modal-btn-back { flex: 1; padding: 11px; background: #f1f5f9; color: #555; border: none; border-radius: 10px; font-weight: 800; font-size: 13.5px; cursor: pointer; font-family: 'Nunito', sans-serif; }
        .modal-btn-confirm { flex: 1; padding: 11px; background: linear-gradient(135deg, #ff6f00, #ff9500); color: #fff; border: none; border-radius: 10px; font-weight: 800; font-size: 13.5px; cursor: pointer; font-family: 'Nunito', sans-serif; box-shadow: 0 3px 10px rgba(255,111,0,0.3); }
        .modal-btn-confirm.danger { background: linear-gradient(135deg, #ef4444, #dc2626); box-shadow: 0 3px 10px rgba(239,68,68,0.3); }
        .modal-btn-confirm.purple { background: linear-gradient(135deg, #8b5cf6, #7c3aed); box-shadow: 0 3px 10px rgba(139,92,246,0.3); }
        .modal-btn-confirm.green  { background: linear-gradient(135deg, #10b981, #059669); box-shadow: 0 3px 10px rgba(16,185,129,0.3); }
        .btn-export { display: flex; align-items: center; gap: 7px; padding: 9px 18px; background: linear-gradient(135deg, #ff6f00, #ff9500); color: #fff; border: none; border-radius: 10px; font-weight: 800; font-size: 13px; cursor: pointer; font-family: 'Nunito', sans-serif; box-shadow: 0 3px 12px rgba(255,111,0,0.3); transition: opacity 0.2s; }
        .btn-export:hover { opacity: 0.88; }
        .btn-export:disabled { opacity: 0.55; cursor: not-allowed; }
        .btn-refresh { display: flex; align-items: center; gap: 6px; padding: 9px 16px; background: #fff; color: #555; border: 1.5px solid #ffe0c2; border-radius: 10px; font-weight: 800; font-size: 13px; cursor: pointer; font-family: 'Nunito', sans-serif; transition: background 0.15s, border-color 0.15s; }
        .btn-refresh:hover { background: #fff8f2; border-color: #ff6f00; color: #ff6f00; }
        @media (max-width: 1024px) { .om-stats { grid-template-columns: repeat(4, 1fr); } }
        @media (max-width: 640px)  { .om-stats { grid-template-columns: repeat(2, 1fr); } }
      `}</style>

      <div className="om-root">

        {/* TOAST */}
        {toast && (
          <div className="om-toast" style={{
            background:  toast.type === "success" ? "#ecfdf5" : "#fef2f2",
            borderColor: toast.type === "success" ? "#6ee7b7" : "#fca5a5",
            color:       toast.type === "success" ? "#065f46" : "#991b1b",
          }}>
            {toast.type === "success" ? "✅" : "❌"} {toast.msg}
          </div>
        )}

        {/* HEADER */}
        <div style={{
          background: "linear-gradient(135deg, #ff6f00, #ff8c00, #ffaa44)",
          borderRadius: 22, padding: "26px 32px", marginBottom: 22,
          position: "relative", overflow: "hidden",
          boxShadow: "0 10px 36px rgba(255,111,0,0.28)",
        }}>
          <div style={{ position:"absolute", top:-40, right:-40, width:180, height:180, borderRadius:"50%", background:"rgba(255,255,255,0.08)" }} />
          <div style={{ position:"absolute", bottom:-50, left:"35%", width:220, height:220, borderRadius:"50%", background:"rgba(255,255,255,0.05)" }} />
          <div style={{ position:"relative", zIndex:1, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:14 }}>
            <div>
              <h1 style={{ margin:0, fontSize:28, fontWeight:900, color:"#fff", letterSpacing:-0.5 }}>🛍️ Order Management</h1>
              <p style={{ margin:"5px 0 0", fontSize:13, color:"rgba(255,255,255,0.8)", fontWeight:700 }}>{orders.length} total orders</p>
            </div>
            <div style={{ display:"flex", gap:10 }}>
              <button className="btn-export" onClick={exportCSV} disabled={exporting||loading}>
                {exporting ? "⏳ Exporting..." : `⬇️ Export CSV (${filtered.length})`}
              </button>
              <button className="btn-refresh" onClick={fetchOrders} disabled={loading}>↻ Refresh</button>
            </div>
          </div>
        </div>

        {/* STAT CARDS */}
        <div className="om-stats">
          {STAT_CARDS.map((s, i) => (
            <div key={i} className="stat-card" style={{ background: s.bg, borderColor: s.color + "44" }}>
              <div className="stat-icon">{s.icon}</div>
              <div className="stat-num" style={{ color: s.color }}>{s.value}</div>
              <div className="stat-lbl">{s.label}</div>
            </div>
          ))}
        </div>

        {/* FILTERS */}
        <div className="om-filters">
          <input
            className="om-search"
            placeholder="Search by order ID, name or phone..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <div className="om-tabs">
            {TAB_LABELS.map(s => (
              <button
                key={s}
                className={`om-tab ${filterStatus === s ? "active" : ""}`}
                onClick={() => setFilterStatus(s)}
              >
                {s === "all" ? "All" : s.charAt(0).toUpperCase() + s.slice(1)}
                {s !== "all" && <span className="tab-cnt">{statusCounts[s] || 0}</span>}
              </button>
            ))}
          </div>
        </div>

        {/* TABLE */}
        <div className="om-table-wrap">
          {loading ? (
            <div className="om-empty"><div className="om-empty-icon">⏳</div>Loading orders...</div>
          ) : filtered.length === 0 ? (
            <div className="om-empty"><div className="om-empty-icon">📭</div>No orders found</div>
          ) : (
            <table className="om-table">
              <colgroup><col /><col /><col /><col /><col /><col /><col /><col /></colgroup>
              <thead className="om-thead">
                <tr>
                  {["Order ID","Customer","Items","Amount","Payment","Status","Date","Actions"].map(h => (
                    <th key={h} className="om-th">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(o => {
                  const sc = STATUS_COLORS[o.status]         || STATUS_COLORS.pending;
                  const pc = PAYMENT_COLORS[o.paymentStatus] || PAYMENT_COLORS.pending;
                  return (
                    <tr key={o._id} className="om-tr">

                      {/* ORDER ID */}
                      <td className="om-td">
                        <span className="order-id-chip">#{o._id.toString().slice(-6).toUpperCase()}</span>
                      </td>

                      {/* CUSTOMER */}
                      <td className="om-td">
                        <div className="cust-name">{o.shippingAddress?.fullName}</div>
                        <div className="cust-phone">{o.shippingAddress?.phone}</div>
                      </td>

                      {/* ITEMS */}
                      <td className="om-td">
                        <div className="item-names">
                          {o.orderItems?.slice(0,2).map(i => i.name).join(", ")}
                          {o.orderItems?.length > 2 && ` +${o.orderItems.length - 2}`}
                        </div>
                        <div className="item-count">{o.orderItems?.length} item{o.orderItems?.length > 1 ? "s" : ""}</div>
                      </td>

                      {/* AMOUNT */}
                      <td className="om-td">
                        <span className="amount-val">₹{o.totalPrice?.toLocaleString()}</span>
                      </td>

                      {/* PAYMENT */}
                      <td className="om-td">
                        <span className="badge" style={{ background: pc.bg, color: pc.color, borderColor: pc.border }}>
                          {o.paymentStatus}
                        </span>
                        <div className="pay-method">{o.paymentMethod}</div>
                      </td>

                      {/* STATUS */}
                      <td className="om-td">
                        <span className="badge" style={{ background: sc.bg, color: sc.color, borderColor: sc.border }}>
                          {o.status}
                        </span>
                        {/* ✅ FIXED: use returnInfo instead of returnRequest */}
                        {o.returnInfo?.status && (
                          <div className="return-tag">↩ Return: {o.returnInfo.status}</div>
                        )}
                      </td>

                      {/* DATE */}
                      <td className="om-td">
                        <div className="date-val">
                          {new Date(o.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                        </div>
                      </td>

                      {/* ACTIONS */}
                      <td className="om-td">
                        <div className="actions-cell">
                          {/* View */}
                          <button className="act-btn act-eye" onClick={() => setSelected(o)} title="View Order">👁</button>

                          {/* Status dropdown */}
                          {!["cancelled","returned"].includes(o.status) && (
                            <select
                              className="status-select"
                              value={o.status}
                              onChange={e => updateStatus(o._id, e.target.value)}
                              disabled={updating === o._id}
                            >
                              {STATUS_FLOW.map(s => (
                                <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
                              ))}
                            </select>
                          )}

                          {/* Cancel */}
                          {canCancel(o) && (
                            <button className="act-btn act-cancel" onClick={() => { setCancelModal(o); setCancelReason(""); }} title="Cancel Order">✕</button>
                          )}

                          {/* Return request (admin initiates) */}
                          {canReturn(o) && (
                            <button className="act-btn act-return" onClick={() => { setReturnModal(o); setReturnReason(""); }} title="Request Return">↩</button>
                          )}

                          {/* ✅ FIXED: use returnInfo.status instead of returnRequest */}
                          {o.returnInfo?.status === "requested" && (
                            <>
                              <button className="act-btn act-approve" onClick={() => handleReturn("approve", o)} title="Approve Return">✓</button>
                              <button className="act-btn act-reject"  onClick={() => handleReturn("reject",  o)} title="Reject Return">✕</button>
                            </>
                          )}

                          {/* Refund */}
                          {canRefund(o) && (
                            <button className="act-btn act-refund" onClick={() => { setRefundModal(o); setRefundAmount(o.totalPrice); }} title="Process Refund">💸</button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* ── CANCEL MODAL ── */}
        {cancelModal && (
          <div className="om-overlay" onClick={() => setCancelModal(null)}>
            <div className="om-modal" onClick={e => e.stopPropagation()}>
              <div className="modal-head">
                <p className="modal-title">✕ Cancel Order</p>
                <button className="modal-close" onClick={() => setCancelModal(null)}>✕</button>
              </div>
              <div className="modal-body">
                <p className="modal-info">
                  Cancelling order <strong>#{cancelModal._id.toString().slice(-6).toUpperCase()}</strong> for{" "}
                  <strong>{cancelModal.shippingAddress?.fullName}</strong> · ₹{cancelModal.totalPrice?.toLocaleString()}
                </p>
                {cancelModal.paymentStatus === "paid" && (
                  <div className="warning-box">
                    ⚠️ This order is already paid. A refund of ₹{cancelModal.totalPrice?.toLocaleString()} will be initiated automatically.
                  </div>
                )}
                <label className="field-label">Cancellation Reason *</label>
                <textarea
                  className="modal-textarea"
                  value={cancelReason}
                  onChange={e => setCancelReason(e.target.value)}
                  placeholder="e.g. Out of stock, Customer requested, Duplicate order..."
                  rows={3}
                />
                <div className="modal-btns">
                  <button className="modal-btn-back" onClick={() => setCancelModal(null)}>Back</button>
                  <button className="modal-btn-confirm danger" onClick={handleCancel}>✕ Confirm Cancel</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── RETURN MODAL ── */}
        {returnModal && (
          <div className="om-overlay" onClick={() => setReturnModal(null)}>
            <div className="om-modal" onClick={e => e.stopPropagation()}>
              <div className="modal-head">
                <p className="modal-title">↩ Return Request</p>
                <button className="modal-close" onClick={() => setReturnModal(null)}>✕</button>
              </div>
              <div className="modal-body">
                <p className="modal-info">
                  Order <strong>#{returnModal._id.toString().slice(-6).toUpperCase()}</strong> · ₹{returnModal.totalPrice?.toLocaleString()}
                </p>
                <label className="field-label">Return Reason</label>
                <textarea
                  className="modal-textarea"
                  value={returnReason}
                  onChange={e => setReturnReason(e.target.value)}
                  placeholder="e.g. Defective product, Wrong item, Customer changed mind..."
                  rows={3}
                />
                <div className="info-box">ℹ️ Approving return will automatically set refund status to pending.</div>
                <div className="modal-btns">
                  <button className="modal-btn-back" onClick={() => setReturnModal(null)}>Back</button>
                  <button className="modal-btn-confirm purple" onClick={() => handleReturn("request", returnModal)}>↩ Initiate Return</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── REFUND MODAL ── */}
        {refundModal && (
          <div className="om-overlay" onClick={() => setRefundModal(null)}>
            <div className="om-modal" onClick={e => e.stopPropagation()}>
              <div className="modal-head">
                <p className="modal-title">💸 Process Refund</p>
                <button className="modal-close" onClick={() => setRefundModal(null)}>✕</button>
              </div>
              <div className="modal-body">
                <p className="modal-info">
                  Order <strong>#{refundModal._id.toString().slice(-6).toUpperCase()}</strong> · Paid via{" "}
                  <strong>{refundModal.paymentMethod}</strong> · ₹{refundModal.totalPrice?.toLocaleString()}
                </p>
                <label className="field-label">Refund Amount (₹)</label>
                <input
                  type="number"
                  className="modal-input"
                  value={refundAmount}
                  onChange={e => setRefundAmount(e.target.value)}
                  placeholder={`Max: ₹${refundModal.totalPrice}`}
                />
                {/* <div className="modal-btns">
  <button className="modal-btn-back" onClick={() => setRefundModal(null)}>Back</button>
  <button className="modal-btn-confirm danger" onClick={() => {
    setRefundModal(null);
    setRefundAmount("");
  }}>✕ Cancel</button>
  <button className="modal-btn-confirm green" onClick={handleRefund}>✓ Approve Refund</button>
</div> */}
{/* Refund modal buttons */}
<div className="modal-btns">
  <button className="modal-btn-back" onClick={() => setRefundModal(null)}>Back</button>
  <button className="modal-btn-confirm danger" onClick={() => handleRefund("rejected")}>✕ Reject</button>
  <button className="modal-btn-confirm green"  onClick={() => handleRefund("refunded")}>✓ Approve</button>
</div>
              </div>
            </div>
          </div>
        )}

        {/* ── VIEW ORDER MODAL ── */}
        {selected && (
          <div className="om-overlay" onClick={() => setSelected(null)}>
            <div className="om-modal" style={{ maxWidth: 540 }} onClick={e => e.stopPropagation()}>
              <div className="modal-head">
                <p className="modal-title">📋 Order #{selected._id.toString().slice(-6).toUpperCase()}</p>
                <button className="modal-close" onClick={() => setSelected(null)}>✕</button>
              </div>
              <div className="modal-body" style={{ maxHeight: "80vh", overflowY: "auto" }}>

                {/* Customer */}
                <div style={{ background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 12, padding: "12px 14px", marginBottom: 14 }}>
                  <p style={{ fontSize: 11, fontWeight: 800, color: "#aaa", textTransform: "uppercase", letterSpacing: "0.4px", marginBottom: 6 }}>Customer</p>
                  <p style={{ fontWeight: 800, color: "#1a1a1a", fontSize: 14, marginBottom: 2 }}>{selected.shippingAddress?.fullName}</p>
                  <p style={{ fontSize: 12, color: "#888", fontWeight: 600 }}>{selected.shippingAddress?.phone}</p>
                  <p style={{ fontSize: 12, color: "#888", fontWeight: 600, marginTop: 2 }}>
                    {selected.shippingAddress?.address}, {selected.shippingAddress?.city} — {selected.shippingAddress?.pincode}
                  </p>
                </div>

                {/* Status row */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 14 }}>
                  {[
                    { label: "Status",  value: selected.status,        colors: STATUS_COLORS[selected.status]        || STATUS_COLORS.pending  },
                    { label: "Payment", value: selected.paymentStatus,  colors: PAYMENT_COLORS[selected.paymentStatus] || PAYMENT_COLORS.pending },
                    { label: "Method",  value: selected.paymentMethod,  colors: { bg: "#f8fafc", color: "#64748b", border: "#e2e8f0" } },
                  ].map((item, i) => (
                    <div key={i} style={{ background: item.colors.bg, border: `1px solid ${item.colors.border}`, borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
                      <p style={{ fontSize: 10, fontWeight: 700, color: "#aaa", textTransform: "uppercase", marginBottom: 4 }}>{item.label}</p>
                      <p style={{ fontSize: 13, fontWeight: 900, color: item.colors.color, textTransform: "capitalize" }}>{item.value}</p>
                    </div>
                  ))}
                </div>

                {/* Cancel Info */}
                {selected.cancelInfo?.reason && (
                  <div style={{ background: "#fef2f2", border: "1px solid #fca5a5", borderRadius: 10, padding: "10px 13px", marginBottom: 14 }}>
                    <p style={{ fontSize: 11, fontWeight: 800, color: "#aaa", textTransform: "uppercase", marginBottom: 4 }}>Cancel Info</p>
                    <p style={{ fontSize: 13, color: "#ef4444", fontWeight: 700 }}>Reason: {selected.cancelInfo.reason}</p>
                    <p style={{ fontSize: 11.5, color: "#aaa", fontWeight: 600 }}>
                      By: {selected.cancelInfo.cancelledBy} · {selected.cancelInfo.cancelledAt ? new Date(selected.cancelInfo.cancelledAt).toLocaleDateString("en-IN") : ""}
                    </p>
                  </div>
                )}

                {/* Return Info */}
                {selected.returnInfo?.status && (
                  <div style={{ background: "#f5f3ff", border: "1px solid #c4b5fd", borderRadius: 10, padding: "10px 13px", marginBottom: 14 }}>
                    <p style={{ fontSize: 11, fontWeight: 800, color: "#aaa", textTransform: "uppercase", marginBottom: 4 }}>Return Info</p>
                    <p style={{ fontSize: 13, color: "#8b5cf6", fontWeight: 700 }}>Status: {selected.returnInfo.status}</p>
                    <p style={{ fontSize: 12, color: "#666", fontWeight: 600 }}>Reason: {selected.returnInfo.reason}</p>
                  </div>
                )}

                {/* Items */}
                <p style={{ fontSize: 11, fontWeight: 800, color: "#aaa", textTransform: "uppercase", letterSpacing: "0.4px", marginBottom: 8 }}>Order Items</p>
                <div style={{ border: "1.5px solid #f0e8e0", borderRadius: 12, overflow: "hidden", marginBottom: 14 }}>
                  {selected.orderItems?.map((item, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderBottom: i < selected.orderItems.length - 1 ? "1px solid #fff3e6" : "none", background: i % 2 === 0 ? "#fff" : "#fdfaf8" }}>
                      <img
                        src={
                          item.image
                            ? item.image.startsWith("http") ? item.image : `http://localhost:5000${item.image}`
                            : item.images?.[0]
                              ? item.images[0].startsWith("http") ? item.images[0] : `http://localhost:5000${item.images[0]}`
                              : "/placeholder.png"
                        }
                        alt={item.name}
                        style={{ width: 44, height: 44, borderRadius: 8, objectFit: "cover", border: "1.5px solid #ffe0c2", flexShrink: 0 }}
                      />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: 13, fontWeight: 800, color: "#1a1a1a", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.name}</p>
                        <p style={{ fontSize: 11.5, color: "#aaa", fontWeight: 600 }}>Qty: {item.qty}</p>
                      </div>
                      <p style={{ fontSize: 14, fontWeight: 900, color: "#ff6f00", flexShrink: 0 }}>₹{(item.price * item.qty).toLocaleString()}</p>
                    </div>
                  ))}
                </div>

                {/* Total */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "#fff8f2", border: "1.5px solid #ffe0c2", borderRadius: 10, padding: "12px 14px", marginBottom: 16 }}>
                  <span style={{ fontSize: 14, fontWeight: 700, color: "#555" }}>Total Amount</span>
                  <span style={{ fontSize: 20, fontWeight: 900, color: "#ff6f00" }}>₹{selected.totalPrice?.toLocaleString()}</span>
                </div>

                <div style={{ display: "flex", gap: 10 }}>
                  <button className="modal-btn-back" style={{ flex: 1 }} onClick={() => setSelected(null)}>Close</button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </>
  );
}
