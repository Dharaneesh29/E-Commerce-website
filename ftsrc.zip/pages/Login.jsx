// import { useState, useEffect,useRef } from "react";
// import API from "../api/axios";
// import { Link, useNavigate } from "react-router-dom";
// import toast from "react-hot-toast";
// import confetti from "canvas-confetti";
 
// const slides = [
//   {
//     title: "Get access to your Orders",
//     desc: "Track, manage & reorder easily",
//   },
//   {
//     title: "Wishlist & Save",
//     desc: "Save products for later",
//   },
//   {
//     title: "Best Deals",
//     desc: "Exclusive offers just for you",
//   },
// ];
 
// const Login = () => {
//   const navigate = useNavigate();
 
//   const [form, setForm] = useState({
//     identifier: "",
//     password: "",
//   });
 
//   const [loading, setLoading] = useState(false);
//   const [showPassword, setShowPassword] = useState(false);
//   const [currentSlide, setCurrentSlide] = useState(0);
//   const [otpMode, setOtpMode] = useState(false);
// // const [otp, setOtp] = useState("");
// const [showOtpInput, setShowOtpInput] = useState(false);
// const [otp, setOtp] = useState(["", "", "", "", "", ""]);
// const otpRef = useRef([]);
 
 
//   // 🔁 Auto Slide
//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrentSlide((prev) => (prev + 1) % slides.length);
//     }, 2500);
//     return () => clearInterval(interval);
//   }, []);
 
//   // 🔐 Auto login redirect
//   useEffect(() => {
//     const user = sessionStorage.getItem("userInfo");
//     if (user) return;
//   }, []);
 
//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

//   const isEmail = (value) => {
//   return value.includes("@");
// };
 
// const isPhone = (value) => {
//   return /^[0-9]{10}$/.test(value);
// };
 
 
//   const fireConfetti = () => {
//     confetti({
//       particleCount: 100,
//       spread: 70,
//       origin: { y: 0.6 },
//     });
//   };

//   const handleOtpChange = (value, index) => {
//   if (!/^[0-9]?$/.test(value)) return;
 
//   const newOtp = [...otp];
//   newOtp[index] = value;
//   setOtp(newOtp);
 
//   // move to next box
//   if (value && index < 5) {
//     otpRef.current[index + 1].focus();
//   }
// };

// const handleKeyDown = (e, index) => {
//   if (e.key === "Backspace" && !otp[index] && index > 0) {
//     otpRef.current[index - 1].focus();
//   }
// };
 

//   const handleGenerateOtp = async () => {
//   const value = form.identifier;
  
// console.log("✅ Generate OTP button clicked");

 
//   if (!value) {
//     toast.error("Enter Email or Phone");
//     return;
//   }
 
//   try {
//     // 📧 EMAIL
//     if (isEmail(value)) {
//       toast.info("Sending OTP to Email 📧");
 
//       await API.post("/users/send-otp", {
//         email: value,
//       });
//     }
 
//     // 📱 PHONE
//     else if (isPhone(value)) {
//       toast.info("Sending OTP to Mobile 📱");
 
//       await API.post("/users/send-phone-otp", {
//         phone: value,
//       });
//     }
 
//     else {
//       toast.error("Enter valid Email or Phone");
//       return;
//     }
 
//     toast.success("OTP Sent 🔥");
//     setShowOtpInput(true);
 
//   } catch (err) {
//     toast.error(err.response?.data?.message || "OTP Failed");
//   }
// };


// const handleVerifyOtp = async () => {
//   const finalOtp = otp.join("");
//   const value = form.identifier;
 
//   try {
//     let res;
 
//     // 📧 EMAIL VERIFY
//     if (isEmail(value)) {
//       res = await API.post("/users/verify-otp", {
//         email: value,
//         otp: finalOtp,
//       });
//     }
 
//     // 📱 PHONE VERIFY
//     else if (isPhone(value)) {
//       res = await API.post("/users/verify-phone-otp", {
//         phone: value,
//         otp: finalOtp,
//       });
//     }
 
//     sessionStorage.setItem("userInfo", JSON.stringify(res.data));
 
//     toast.success("Login Success 🎉");
//     navigate("/home");
 
//   } catch (err) {
//     toast.error(err.response?.data?.message || "Invalid OTP");
//   }
// };


 

 
 
//   // 🔥 LOGIN
//   const handleLogin = async (e) => {
//     e.preventDefault();
 
//     try {
//       setLoading(true);
 
//       const res = await API.post("/users/login", {
//         identifier: form.identifier, // email or phone
//         password: form.password,
//       });
 
//       sessionStorage.setItem("userInfo", JSON.stringify(res.data));
 
//       toast.success("Login Successful 🎉");
//       fireConfetti();
 
//       // 🔐 Role based
//       if (res.data.user?.isAdmin) {
//         navigate("/dashboard");
//       } else {
//         navigate("/home");
//       }
 
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Login failed");
//     } finally {
//       setLoading(false);
//     }
//   };

 
//   return (
//     <div className="min-h-screen flex">
 
//       {/* LEFT SLIDER */}
//       <div className="hidden md:flex w-1/2 bg-gradient-to-br from-orange-500 to-pink-500 text-white flex-col justify-center items-center p-10">
 
//         <h1 className="text-3xl font-bold mb-4 transition-all duration-500">
//           {slides[currentSlide].title}
//         </h1>
 
//         <p className="mb-6 transition-all duration-500">
//           {slides[currentSlide].desc}
//         </p>
 
//         {/* Dots */}
//         <div className="flex gap-2">
//           {slides.map((_, i) => (
//             <div
//               key={i}
//               className={`w-3 h-3 rounded-full ${
//                 i === currentSlide ? "bg-white" : "bg-white/40"
//               }`}
//             />
//           ))}
//         </div>
//       </div>
 
//       {/* RIGHT FORM */}
//       <div className="flex w-full md:w-1/2 justify-center items-center bg-orange-50">
 
//         <div className="bg-white p-6 rounded-xl w-[350px] shadow-lg">
 
//           <h2 className="text-xl font-bold text-center text-orange-600 mb-4">
//             Login to your account
//           </h2>
 
//           <form onSubmit={handleLogin} className="space-y-3">
 
//             {/* EMAIL OR PHONE */}
//             <input
//               name="identifier"
//               value={form.identifier}
//               placeholder="Email or Phone"
//               className="input"
//               onChange={handleChange}
//             />
 
//             {/* PASSWORD */}
//             <div className="relative">
//               <input
//                 type={showPassword ? "text" : "password"}
//                 name="password"
//                 placeholder="Password"
//                 className="input pr-10"
//                 onChange={handleChange}
//               />
//               <span
//                 onClick={() => setShowPassword(!showPassword)}
//                 className="eye"
//               >
//                 👁
//               </span>
//             </div>
 
//             {/* OPTIONS */}
//             <div className="flex justify-between text-sm">
//               <label>
//                 <input type="checkbox" /> Remember me
//               </label>
//               <span className="text-orange-500 cursor-pointer">
//                 Forgot Password?
//               </span>
//             </div>
 
//             {/* BUTTON */}
//             <button className="submit-btn">
//               {loading ? "Logging in..." : "Login"}
//             </button>

//             {/* OR */}
// <div className="text-center my-3 text-gray-400">OR</div>
 
// {/* OTP SECTION */}
// {!otpMode && (
//   <>
//     <button
//       type="button"
//       onClick={handleGenerateOtp}
//       className="submit-btn bg-white text-black border border-gray-300 hover:bg-gray-100"
//     >
//       Generate OTP
//     </button>
 
//     {showOtpInput && (
//       <div className="flex justify-center gap-2 mt-4">
//         {otp.map((digit, i) => (
//           <input
//             key={i}
//             maxLength="1"
//             value={digit}
//             ref={(el) => (otpRef.current[i] = el)}
//             onChange={(e) => handleOtpChange(e.target.value, i)}
//             onKeyDown={(e) => handleKeyDown(e, i)}
//             className="w-10 h-10 text-center border rounded-md text-lg"
//           />
//         ))}
//       </div>
//     )}
//   </>
// )}
 
 
 
//           </form>
 
//           <p className="text-center mt-2 text-sm">
//             Don’t have account?{" "}
//             <Link to="/users/register" className="text-orange-500">
//               Register
//             </Link>
//           </p>
 
//         </div>
//       </div>
 
      // <style>{`
      //   .input {
      //     width:100%;
      //     padding:10px;
      //     border:1px solid #ddd;
      //     border-radius:8px;
      //   }
      //   .submit-btn {
      //     width:100%;
      //     padding:10px;
      //     background:linear-gradient(to right,#ff7e5f,#feb47b);
      //     color:white;
      //     border-radius:8px;
      //   }
      //   .eye {
      //     position:absolute;
      //     right:10px;
      //     top:8px;
      //     cursor:pointer;
      //   }
      // `}</style>
 
//     </div>
//   );
// };
 
// export default Login;
 
// import { useState, useEffect, useRef } from "react";
// import API from "../api/axios";
// import { Link, useNavigate } from "react-router-dom";
// import toast from "react-hot-toast";
// import confetti from "canvas-confetti";

// const slides = [
//   { title: "Get access to your Orders", desc: "Track, manage & reorder easily" },
//   { title: "Wishlist & Save", desc: "Save products for later" },
//   { title: "Best Deals", desc: "Exclusive offers just for you" },
// ];

// const Login = () => {
//   const navigate = useNavigate();

//   const [form, setForm] = useState({
//     identifier: "",
//     password: "",
//   });

//   const [loading, setLoading] = useState(false);
//   const [showPassword, setShowPassword] = useState(false);
//   const [currentSlide, setCurrentSlide] = useState(0);

//   const [showOtpInput, setShowOtpInput] = useState(false);
//   const [otp, setOtp] = useState(["", "", "", "", "", ""]);
//   const otpRef = useRef([]);

//   const [timer, setTimer] = useState(30);
// const [canResend, setCanResend] = useState(false);
 
// useEffect(() => {
//   if (!showOtpInput) return;
 
//   setTimer(30);
//   setCanResend(false);
 
//   const interval = setInterval(() => {
//     setTimer((prev) => {
//       if (prev === 1) {
//         clearInterval(interval);
//         setCanResend(true);
//         return 0;
//       }
//       return prev - 1;
//     });
//   }, 1000);
 
//   return () => clearInterval(interval);
// }, [showOtpInput]);
 

//   useEffect(() => {
//   const finalOtp = otp.join("");
 
//   if (finalOtp.length === 6) {
//     handleVerifyOtp(); // auto call
//   }
// }, [otp]);
//   // 🔁 Auto Slide
//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrentSlide((prev) => (prev + 1) % slides.length);
//     }, 2500);
//     return () => clearInterval(interval);
//   }, []);

//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };

  
// const isEmail = (value) =>
//   /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

// const isPhone = (value) =>
//   /^[0-9]{10}$/.test(value);


//   const fireConfetti = () => {
//     confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
//   };

//   const handleOtpChange = (value, index) => {
//     if (!/^[0-9]?$/.test(value)) return;

//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);

//     if (value && index < 5) otpRef.current[index + 1].focus();
//   };

//   const handleKeyDown = (e, index) => {
//     if (e.key === "Backspace" && !otp[index] && index > 0) {
//       otpRef.current[index - 1].focus();
//     }
//   };

//   // ✅ ✅ FIXED OTP GENERATE (trim added)
//   const handleGenerateOtp = async () => {
//     console.log("✅ Generate OTP button clicked");

//     const value = form?.identifier?.trim(); // ✅ FIX
//     console.log("FORM:",form)

//     if (!value) {
//       toast.error("Enter Email or Phone");
//       return;
//     }

//     try {
//       if (isEmail(value)) {
//         toast.success("Sending OTP to Email 📧");
//         await API.post("/users/send-otp", { email: value });
//       } else if (isPhone(value)) {
//         toast.success("Sending OTP to Mobile 📱");
//         await API.post("/users/send-phone-otp", { phone: value });
//       } else {
//         toast.error("Enter valid Email or Phone");
//         return;
//       }
//       console.log(" Geneate:",value)

//       toast.success("OTP Sent 🔥");
//       setShowOtpInput(true);
//     } catch (err) {
//       console.log("ERROR FULL :",err)
//       console.log("ERROR Data :",err.response?.data)
//       toast.error(err.response?.data?.message || "OTP Failed");
//     }
//   };

//   // ✅ ✅ FIXED OTP VERIFY (trim added)
//   const handleVerifyOtp = async () => {
//     const finalOtp = otp.join("");
//     const value = form.identifier.trim(); // ✅ FIX

//     try {
//       let res;

//       if (isEmail(value)) {
//         res = await API.post("/users/verify-otp", {
//           email: value,
//           otp: finalOtp,
//         });
//       } else if (isPhone(value)) {
//         res = await API.post("/users/verify-phone-otp", {
//           phone: value,
//           otp: finalOtp,
//         });
//       }

//       sessionStorage.setItem("userInfo", JSON.stringify(res.data));
//       toast.success("Login Success 🎉");
//       navigate("/home");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Invalid OTP");
//     }
//   };

//   // 🔥 PASSWORD LOGIN (unchanged)
//  const handleLogin = async (e) => {
//   e.preventDefault();

//   try {
//     setLoading(true);

//     const res = await API.post("/users/login", {
//       identifier: form.identifier.trim(),
//       password: form.password,
//     });

//     console.log("Login response:", res.data);

//     // ✅ STORE TOKEN PROPERLY
//     sessionStorage.setItem("token", res.data.token);

//     // (optional) keep user info
//     sessionStorage.setItem("userInfo", JSON.stringify(res.data));

//     toast.success("Login Successful 🎉");
//     fireConfetti();

//     if (res.data.user?.role === "admin") {
//       navigate("/dashboard");
//     } else {
//       navigate("/home");
//     }

//   } catch (err) {
//     toast.error(err.response?.data?.message || "Login failed");
//   } finally {
//     setLoading(false);
//   }
// };

//   return (
//     <div className="min-h-screen flex">
//       {/* LEFT */}
//       <div className="hidden md:flex w-1/2 bg-gradient-to-br from-orange-500 to-pink-500 text-white flex-col justify-center items-center p-10">
//         <h1 className="text-3xl font-bold mb-4">{slides[currentSlide].title}</h1>
//         <p className="mb-6">{slides[currentSlide].desc}</p>
//       </div>

//       {/* RIGHT */}
//       <div className="flex w-full md:w-1/2 justify-center items-center bg-orange-50">
//         <div className="bg-white p-6 rounded-xl w-[350px] shadow-lg">
//           <h2 className="text-xl font-bold text-center text-orange-600 mb-4">
//             Login to your account
//           </h2>

//           <form onSubmit={handleLogin} className="space-y-3">
//             <input
//               name="identifier"
//               value={form.identifier}
//               placeholder="Email or Phone"
//               className="input"
//               onChange={handleChange}
//             />

//             <div className="relative">
//               <input
//                 type={showPassword ? "text" : "password"}
//                 name="password"
//                 placeholder="Password"
//                 className="input pr-10"
//                 onChange={handleChange}
//               />
//               <span onClick={() => setShowPassword(!showPassword)} className="eye">
//                 👁
//               </span>
//             </div>

//             <button className="submit-btn">
//               {loading ? "Logging in..." : "Login"}
//             </button>

//             <div className="text-center my-3 text-gray-400">OR</div>

//             <button
//               type="button"
//               onClick={handleGenerateOtp}
//               className="submit-btn bg-white text-black border border-gray-300"
//             >
//               Generate OTP
//             </button>
// {showOtpInput && (
//   <>
//     <div className="flex justify-center gap-2 mt-4">
//       {otp.map((digit, i) => (
//         <input
//           key={i}
//           maxLength="1"
//           value={digit}
//           ref={(el) => (otpRef.current[i] = el)}
//           onChange={(e) => handleOtpChange(e.target.value, i)}
//           onKeyDown={(e) => handleKeyDown(e, i)}
//           className="w-10 h-10 text-center border rounded-md"
//         />
//       ))}
//     </div>
 
//     {/* ✅ ADD TIMER HERE */}
//     <p className="text-center mt-2 text-sm text-gray-500">
//       {canResend ? (
//         <span
//           className="text-orange-500 cursor-pointer"
//           onClick={handleGenerateOtp}
//         >
//           Resend OTP
//         </span>
//       ) : (
//         `Resend OTP in ${timer}s`
//       )}
//     </p>
 
//     {/* VERIFY BUTTON */}
//     <button
//       type="button"
//       onClick={handleVerifyOtp}
//       className="submit-btn mt-4"
//     >
//       Verify OTP
//     </button>
//   </>
// )}
 
//           </form>

//           <p className="text-center mt-2 text-sm">
//             Don’t have account?{" "}
//             <Link to="/users/register" className="text-orange-500">
//               Register
//             </Link>
//           </p>
//         </div>
//       </div>

//        <style>{`
//         .input {
//           width:100%;
//           padding:10px;
//           border:1px solid #ddd;
//           border-radius:8px;
//         }
//         .submit-btn {
//           width:100%;
//           padding:10px;
//           background:linear-gradient(to right,#ff7e5f,#feb47b);
//           color:white;
//           border-radius:8px;
//         }
//         .eye {
//           position:absolute;
//           right:10px;
//           top:8px;
//           cursor:pointer;
//         }
//       `}</style>
//     </div>
//   );
// };

// export default Login;


// import { useState, useEffect, useRef } from "react";
// import API from "../api/axios";
// import { Link, useNavigate } from "react-router-dom";
// import toast from "react-hot-toast";
// import confetti from "canvas-confetti";
// import { useContext } from "react";
// import { AuthContext } from "../context/AuthContext";
 
// import i1 from "../assets/login/i1.png";
// import i2 from "../assets/login/i2.png";
// import i3 from "../assets/login/i3.png";
 
// const slides = [
//   { img: i1 },
//   { img: i2 },
//   { img: i3 },
// ];
 
// const Login = () => {
//   const navigate = useNavigate();
//   const {login}=useContext(AuthContext)
 
//   const [form, setForm] = useState({
//     identifier: "",
//     password: "",
//   });
 
//   const [loading, setLoading] = useState(false);
//   const [showPassword, setShowPassword] = useState(false);
//   const [currentSlide, setCurrentSlide] = useState(0);
 
//   const [showOtpInput, setShowOtpInput] = useState(false);
//   const [otp, setOtp] = useState(["", "", "", "", "", ""]);
//   const otpRef = useRef([]);
 
//   const [timer, setTimer] = useState(30);
//   const [canResend, setCanResend] = useState(false);
 
//   // 🔁 SLIDE AUTO
//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrentSlide((prev) => (prev + 1) % slides.length);
//     }, 3000);
//     return () => clearInterval(interval);
//   }, []);
 
//   // ⏱ OTP TIMER
//   useEffect(() => {
//     if (!showOtpInput) return;
 
//     setTimer(30);
//     setCanResend(false);
 
//     const interval = setInterval(() => {
//       setTimer((prev) => {
//         if (prev === 1) {
//           clearInterval(interval);
//           setCanResend(true);
//           return 0;
//         }
//         return prev - 1;
//       });
//     }, 1000);
 
//     return () => clearInterval(interval);
//   }, [showOtpInput]);
 
//   useEffect(() => {
//     const finalOtp = otp.join("");
//     if (finalOtp.length === 6) handleVerifyOtp();
//   }, [otp]);
 
//   const handleChange = (e) => {
//     setForm({ ...form, [e.target.name]: e.target.value });
//   };
 
//   const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
//   const isPhone = (v) => /^[0-9]{10}$/.test(v);
 
//   const fireConfetti = () => {
//     confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
//   };
 
//   const handleOtpChange = (value, index) => {
//     if (!/^[0-9]?$/.test(value)) return;
//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);
//     if (value && index < 5) otpRef.current[index + 1].focus();
//   };
 
//   const handleKeyDown = (e, index) => {
//     if (e.key === "Backspace" && !otp[index] && index > 0) {
//       otpRef.current[index - 1].focus();
//     }
//   };
 
//   const handleGenerateOtp = async () => {
//     const value = form.identifier.trim();
//     if (!value) return toast.error("Enter Email or Phone");
 
//     try {
//       if (isEmail(value)) {
//         await API.post("/users/send-otp", { email: value });
//       } else if (isPhone(value)) {
//         await API.post("/users/send-phone-otp", { phone: value });
//       } else return toast.error("Invalid input");
 
//       toast.success("OTP Sent 🔥");
//       setShowOtpInput(true);
//     } catch (err) {
//       toast.error("OTP Failed");
//     }
//   };
 
//   const handleVerifyOtp = async () => {
//     const finalOtp = otp.join("");
//     const value = form.identifier.trim();
 
//     try {
//       let res;
//       if (isEmail(value)) {
//   res = await API.post("/users/verify-otp", {
//     email: value,
//     otp: finalOtp
//   });
// } else {
//   res = await API.post("/users/verify-phone-otp", {
//     phone: value,
//     otp: finalOtp
//   });
// }
 
// const userData = {
//   user: res.data.user || {
//     _id: res.data._id,
//     name: res.data.name,
//     email: res.data.email,
//     phone: res.data.phone,
//     role: res.data.role,
//   },
//   token: res.data.token,
// };
 
// login(userData.user,userData.token)
// console.log("Login cALLED",)
 
// toast.success("Login Success 🎉");
// navigate("/home");


//     } catch {
//       toast.error("Invalid OTP");
//     }
//   };
 
//   const handleLogin = async (e) => {
//     e.preventDefault();
//     try {
//       setLoading(true);
//       const res = await API.post("/users/login", {
//         identifier: form.identifier.trim(),
//         password: form.password,
//       });
 
//       sessionStorage.setItem("token", res.data.token);
//        sessionStorage.setItem("userInfo", JSON.stringify(res.data));
//       // login(res.data.user,res.data.token)
 
//       toast.success("Login Successful 🎉");
//       fireConfetti();
 
//       res.data.user?.role==="admin"? navigate("/dashboard") : navigate("/home");
//     } catch {
//       toast.error("Login failed");
//     } finally {
//       setLoading(false);
//     }
//   };
 
//   return (
//     <div className="min-h-screen flex items-center justify-center bg-[radial-gradient(circle_at_top,_#fff7ed,_#fed7aa,_#fdba74)]">
 
//       {/* MAIN CONTAINER */}
//       <div className="w-full max-w-4xl mx-auto flex items-center justify-center gap-18 px-10">
 
//         {/* LEFT SLIDER */}
//         <div className="relative w-[380px] h-[520px] rounded-3xl overflow-hidden shadow-[0_10px_40px_rgba(255,140,0,0.3)]">
 
//           {slides.map((s, i) => (
//             <img
//               key={i}
//               src={s.img}
//               className={`absolute w-full h-full object-cover transition-all duration-1000 ${
//                 i === currentSlide ? "opacity-100 scale-100" : "opacity-0 scale-105"
//               }`}
//             />
//           ))}
 
//           {/* SLIDE DOTS */}
//           <div className="absolute bottom-4 w-full flex justify-center gap-2">
//             {slides.map((_, i) => (
//               <div
//                 key={i}
//                 className={`h-2 rounded-full transition-all duration-300 ${
//                   i === currentSlide ? "w-6 bg-white" : "w-2 bg-white/50"
//                 }`}
//               />
//             ))}
//           </div>
//         </div>
 
//         {/* RIGHT FORM */}
//         <div className="backdrop-blur-xl bg-white/60 p-8 rounded-3xl w-[380px] md:w-[420px] shadow-[0_10px_40px_rgba(255,140,0,0.25)] animate-float">
 
//           <h2 className="text-xl font-bold text-center text-orange-600 mb-4">
//             Login to your account
//           </h2>
 
//           <form onSubmit={handleLogin} className="space-y-3">
 
//             <input
//               name="identifier"
//               placeholder="Email or Phone"
//               className="input"
//               onChange={handleChange}
//             />
 
//             <div className="relative">
//               <input
//                 type={showPassword ? "text" : "password"}
//                 placeholder="Password"
//                 name="password"
//                 className="input pr-10"
//                 onChange={handleChange}
//               />
//               <span onClick={() => setShowPassword(!showPassword)} className="eye">👁</span>
//             </div>
 
//             {/* ✨ SHINE BUTTON */}
//             <button className="submit-btn shine">
//               {loading ? "Logging in..." : "Login"}
//             </button>
 
//             <div className="text-center text-gray-400">OR</div>
 
//             <button type="button" onClick={handleGenerateOtp} className="submit-btn bg-white text-black border">
//               Generate OTP
//             </button>
 
//             {showOtpInput && (
//               <>
//                 <div className="flex justify-center gap-2 mt-4">
//                   {otp.map((d, i) => (
//                     <input
//                       key={i}
//                       maxLength="1"
//                       value={d}
//                       ref={(el) => (otpRef.current[i] = el)}
//                       onChange={(e) => handleOtpChange(e.target.value, i)}
//                       onKeyDown={(e) => handleKeyDown(e, i)}
//                       className="w-10 h-10 text-center border rounded-md"
//                     />
//                   ))}
//                 </div>
 
//                 <p className="text-center text-sm">
//                   {canResend ? (
//                     <span onClick={handleGenerateOtp} className="text-orange-500 cursor-pointer">
//                       Resend OTP
//                     </span>
//                   ) : `Resend in ${timer}s`}
//                 </p>
//               </>
//             )}
//           </form>
 
//           <p className="text-center mt-2 text-sm">
//             New to ShopEasy?{" "}
//             <Link to="/users/register" className="text-orange-500">
//               Register
//             </Link>
//           </p>
//         </div>
//       </div>
 
//       {/* CSS */}
//       <style>{`
//         .input {
//           width:100%;
//           padding:10px;
//           border-radius:10px;
//           border:1px solid #ddd;
//         }
 
//         .submit-btn {
//           width:100%;
//           padding:10px;
//           border-radius:10px;
//           background:linear-gradient(to right,#ff7e5f,#feb47b);
//           color:white;
//           position:relative;
//           overflow:hidden;
//           transition:0.3s
//         }
 
//        .submit-btn::before {
//   content: "";
//   position: absolute;
//   top: 0;
//   left: -75%;
//   width: 50%;
//   height: 100%;
//   background: linear-gradient(
//     120deg,
//     transparent,
//     rgba(255,255,255,0.6),
//     transparent
//   );
//   transform: skewX(-25deg);
// }

//         .submit-btn:hover::before {
//   left: 125%;
//   transition: 0.7s;
// }
 
// /* slight scale effect */
// .submit-btn:hover {
//   transform: scale(1.03);
// }
 
//         @keyframes shine {
//           0% { left:-75%; }
//           100% { left:125%; }
//         }
 
//         .eye {
//           position:absolute;
//           right:10px;
//           top:8px;
//           cursor:pointer;
//         }
 
      
//       `}</style>
//     </div>
//   );
// };
 
// export default Login;


import { useState, useEffect, useRef } from "react";
import API from "../api/axios";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import confetti from "canvas-confetti";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
 
import i1 from "../assets/login/i1.png";
import i2 from "../assets/login/i2.png";
import i3 from "../assets/login/i3.png";
 
const slides = [
  { img: i1 },
  { img: i2 },
  { img: i3 },
];
 
const Login = () => {
  const navigate = useNavigate();
  const {login}=useContext(AuthContext)
 
  const [form, setForm] = useState({
    identifier: "",
    password: "",
  });
 
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
 
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const otpRef = useRef([]);
 
  const [timer, setTimer] = useState(30);
  const [canResend, setCanResend] = useState(false);
 
  // 🔁 SLIDE AUTO
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);
 
  // ⏱ OTP TIMER
  useEffect(() => {
    if (!showOtpInput) return;
 
    setTimer(30);
    setCanResend(false);
 
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev === 1) {
          clearInterval(interval);
          setCanResend(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
 
    return () => clearInterval(interval);
  }, [showOtpInput]);
 
  useEffect(() => {
    const finalOtp = otp.join("");
    if (finalOtp.length === 6) handleVerifyOtp();
  }, [otp]);
 
  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
 
  const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  const isPhone = (v) => /^[0-9]{10}$/.test(v);
 
  const fireConfetti = () => {
    confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
  };
 
  const handleOtpChange = (value, index) => {
    if (!/^[0-9]?$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    if (value && index < 5) otpRef.current[index + 1].focus();
  };
 
  const handleKeyDown = (e, index) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRef.current[index - 1].focus();
    }
  };
 
  const handleGenerateOtp = async () => {
    const value = form.identifier.trim();
    if (!value) return toast.error("Enter Email or Phone");
 
    try {
      if (isEmail(value)) {
        await API.post("/users/send-otp", { email: value });
      } else if (isPhone(value)) {
        await API.post("/users/send-phone-otp", { phone: value });
      } else return toast.error("Invalid input");
 
      toast.success("OTP Sent 🔥");
      setShowOtpInput(true);
    } catch (err) {
      toast.error("OTP Failed");
    }
  };
 
  const handleVerifyOtp = async () => {
  const finalOtp = otp.join("");
  const value = form.identifier.trim();
 
  try {
    let res;
 
    if (isEmail(value)) {
      res = await API.post("/users/verify-otp", {
        email: value,
        otp: finalOtp,
      });
    } else {
      res = await API.post("/users/verify-phone-otp", {
        phone: value,
        otp: finalOtp,
      });
    }

    console.log(res.data)
 
    const userData = {
      user: res.data.user || {
        _id: res.data._id,
        name: res.data.name,
        email: res.data.email,
        phone: res.data.phone,
        role: res.data.role,
      },
      token: res.data.token,
    };
 
    sessionStorage.setItem(
      "userInfo",
      JSON.stringify(userData)
    );

    sessionStorage.setItem("token", res.data.token);
 
    toast.success("Login Success 🎉");
 
    navigate("/home");
 
  } catch {
    toast.error("Invalid OTP");
  }
};

 
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const res = await API.post("/users/login", {
        identifier: form.identifier.trim(),
        password: form.password,
      });
 
      const userData = {
  user: res.data.user,
  token: res.data.token,
};
 
sessionStorage.setItem(
  "userInfo",
  JSON.stringify(userData)
);

sessionStorage.setItem("token",res.data.token);
      // login(res.data.user,res.data.token)
 
      toast.success("Login Successful 🎉");
      fireConfetti();
 
      res.data.user?.role==="admin"? navigate("/dashboard") : navigate("/home");
    } catch {
      toast.error("Login failed");
    } finally {
      setLoading(false);
    }
  };
 
  return (
    <div className="min-h-screen flex items-center justify-center bg-[radial-gradient(circle_at_top,_#fff7ed,_#fed7aa,_#fdba74)]">
 
      {/* MAIN CONTAINER */}
      <div className="w-full max-w-4xl mx-auto flex items-center justify-center gap-18 px-10">
 
        {/* LEFT SLIDER */}
        <div className="relative w-[380px] h-[520px] rounded-3xl overflow-hidden shadow-[0_10px_40px_rgba(255,140,0,0.3)]">
 
          {slides.map((s, i) => (
            <img
              key={i}
              src={s.img}
              className={`absolute w-full h-full object-cover transition-all duration-1000 ${
                i === currentSlide ? "opacity-100 scale-100" : "opacity-0 scale-105"
              }`}
            />
          ))}
 
          {/* SLIDE DOTS */}
          <div className="absolute bottom-4 w-full flex justify-center gap-2">
            {slides.map((_, i) => (
              <div
                key={i}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === currentSlide ? "w-6 bg-white" : "w-2 bg-white/50"
                }`}
              />
            ))}
          </div>
        </div>
 
        {/* RIGHT FORM */}
        <div className="backdrop-blur-xl bg-white/60 p-8 rounded-3xl w-[380px] md:w-[420px] shadow-[0_10px_40px_rgba(255,140,0,0.25)] animate-float">
 
          <h2 className="text-xl font-bold text-center text-orange-600 mb-4">
            Login to your account
          </h2>
 
          <form onSubmit={handleLogin} className="space-y-3">
 
            <input
              name="identifier"
              placeholder="Email or Phone"
              className="input"
              onChange={handleChange}
            />
 
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Password"
                name="password"
                className="input pr-10"
                onChange={handleChange}
              />
              <span onClick={() => setShowPassword(!showPassword)} className="eye">👁</span>
            </div>
 
            {/* ✨ SHINE BUTTON */}
            <button className="submit-btn shine">
              {loading ? "Logging in..." : "Login"}
            </button>
 
            <div className="text-center text-gray-400">OR</div>
 
            <button type="button" onClick={handleGenerateOtp} className="submit-btn bg-white text-black border">
              Generate OTP
            </button>
 
            {showOtpInput && (
              <>
                <div className="flex justify-center gap-2 mt-4">
                  {otp.map((d, i) => (
                    <input
                      key={i}
                      maxLength="1"
                      value={d}
                      ref={(el) => (otpRef.current[i] = el)}
                      onChange={(e) => handleOtpChange(e.target.value, i)}
                      onKeyDown={(e) => handleKeyDown(e, i)}
                      className="w-10 h-10 text-center border rounded-md"
                    />
                  ))}
                </div>
 
                <p className="text-center text-sm">
                  {canResend ? (
                    <span onClick={handleGenerateOtp} className="text-orange-500 cursor-pointer">
                      Resend OTP
                    </span>
                  ) : `Resend in ${timer}s`}
                </p>
              </>
            )}
          </form>
 
          <p className="text-center mt-2 text-sm">
            New to ShopEasy?{" "}
            <Link to="/users/register" className="text-orange-500">
              Register
            </Link>
          </p>
        </div>
      </div>
 
      {/* CSS */}
      <style>{`
        .input {
          width:100%;
          padding:10px;
          border-radius:10px;
          border:1px solid #ddd;
        }
 
        .submit-btn {
          width:100%;
          padding:10px;
          border-radius:10px;
          background:linear-gradient(to right,#ff7e5f,#feb47b);
          color:white;
          position:relative;
          overflow:hidden;
          transition:0.3s
        }
 
       .submit-btn::before {
  content: "";
  position: absolute;
  top: 0;
  left: -75%;
  width: 50%;
  height: 100%;
  background: linear-gradient(
    120deg,
    transparent,
    rgba(255,255,255,0.6),
    transparent
  );
  transform: skewX(-25deg);
}

        .submit-btn:hover::before {
  left: 125%;
  transition: 0.7s;
}
 
/* slight scale effect */
.submit-btn:hover {
  transform: scale(1.03);
}
 
        @keyframes shine {
          0% { left:-75%; }
          100% { left:125%; }
        }
 
        .eye {
          position:absolute;
          right:10px;
          top:8px;
          cursor:pointer;
        }
 
      
      `}</style>
    </div>
  );
};
 
export default Login;




