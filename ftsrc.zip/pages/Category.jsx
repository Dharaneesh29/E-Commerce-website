import { useParams } from "react-router-dom";
import { useContext, useEffect, useState } from "react";
import axios from "axios";
import { ShopContext } from "../context/ShopContext";
 
const Category = () => {
  const { name } = useParams();
  const [products, setProducts] = useState([]);

  const {addToCart}=useContext(ShopContext)
 
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data } = await axios.get(
          `http://localhost:5000/api/products/category/${name}`
        );
        setProducts(data);
      } catch (err) {
        console.log(err);
      }
    };
 
    fetchProducts();
  }, [name]);
 
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 p-6">
  {products.map((p) => (
    <div
      key={p._id}
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition p-4 cursor-pointer"
    >
      
      <img
  src={p.image.startsWith("http") ? p.image : `http://localhost:5000${p.image}`}
  alt={p.name}
   className="w-full h-40 object-contain mb-3"
/>
    
 
      
      <h3 className="text-sm font-semibold text-gray-800">
        {p.name}
      </h3>
 
      
      <p className="text-green-600 font-bold mt-1">
        ₹{p.price}
      </p>
 
      
      <button
            onClick={() =>{console.log("Clicked Product:",p._id);
              addToCart(p._id);}}
            className="mt-3 w-full bg-orange-500 text-white py-1 rounded"
          >
            Add to Cart
          </button>
    </div>
  ))}
</div>
 
  );
};
 
export default Category;
 