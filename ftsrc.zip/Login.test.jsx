import { render, screen } from "@testing-library/react"
import { BrowserRouter } from "react-router-dom"
import Login from "./pages/Login";
import React from "react";

// ✅ Mock external dependencies
jest.mock("./api/axios")
jest.mock("react-hot-toast", () => ({
  success: jest.fn(),
  error: jest.fn(),
}))
jest.mock("canvas-confetti", () => jest.fn())

// ✅ Mock AuthContext
jest.spyOn(React,"useContext").mockReturnValue({
    login:jest.fn(),
})

describe("Login Component", () => {
  test("renders login heading and login button", () => {
    render(
      <BrowserRouter>
        <Login />
      </BrowserRouter>
    )

    // ✅ Heading
    expect(
      screen.getByText(/login to your account/i)
    ).toBeInTheDocument()

    // ✅ Login button
    expect(
      screen.getByRole("button", { name: /login/i })
    ).toBeInTheDocument()
  })
})