// ============================================================
//  TC-5: Stock Mismatch due to Async Updates
//  File: src/ProductCard.test.jsx
//  Run: npm test (in frontend folder)
// ============================================================

import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { ShopContext } from "./context/ShopContext";
import ProductCard from "./components/ProductCard";

// ── MOCKS ────────────────────────────────────────────────────
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => jest.fn(),
}));

jest.mock("lucide-react", () => ({
  Star: () => <span />,
  Heart: () => <span />,
}));

jest.mock("axios", () => ({
  create: () => ({
    get: jest.fn(),
    post: jest.fn(),
    interceptors: {
      request: { use: jest.fn() },
    },
  }),
}));

// ── MOCK addToCart ────────────────────────────────────────────
const mockAddToCart = jest.fn();

beforeEach(() => mockAddToCart.mockClear());

// ── HELPER — wraps with real ShopContext.Provider ─────────────
const renderCard = (productOverrides = {}) => {
  const defaultProduct = {
    id: "prod1",
    name: "Wireless Earbuds",
    brand: "Sony",
    price: 1499,
    originalPrice: 2999,
    image: "earbuds.jpg",
    rating: 4,
    stock: 10,
    ...productOverrides,
  };

  return render(
    <BrowserRouter>
      {/* ✅ Use real ShopContext.Provider with mock value */}
      <ShopContext.Provider value={{
        addToCart: mockAddToCart,
        cart: [],
        loading: false,
        products: [],
        updateQty: jest.fn(),
        removeItem: jest.fn(),
        fetchCart: jest.fn(),
        mergeCart: jest.fn(),
      }}>
        <ProductCard product={defaultProduct} />
      </ShopContext.Provider>
    </BrowserRouter>
  );
};

// ─────────────────────────────────────────────────────────────
// TC-5: Stock Mismatch due to Async Updates
// ─────────────────────────────────────────────────────────────
describe("TC-5: Stock Mismatch due to Async Updates", () => {

  // ✅ TEST 1 — Stock > 0 shows Add to Cart
  test("should show Add to Cart button when stock is available", () => {
    renderCard({ stock: 5 });
    const btn = screen.getByRole("button", { name: /add to cart/i });
    expect(btn).toBeInTheDocument();
    expect(btn).not.toBeDisabled();
  });

  // ✅ TEST 2 — Stock = 0 button is disabled
  test("should show disabled Out of Stock button when stock is 0", () => {
    renderCard({ stock: 0 });
    const btn = screen.getByRole("button", { name: /out of stock/i });
    expect(btn).toBeInTheDocument();
    expect(btn).toBeDisabled();
  });

  // ✅ TEST 3 — Stock = 0 shows overlay on image
  test("should show Out of Stock overlay on image when stock is 0", () => {
    renderCard({ stock: 0 });
    const overlays = screen.getAllByText(/out of stock/i);
    expect(overlays.length).toBeGreaterThanOrEqual(1);
  });

  // ✅ TEST 4 — CORE TC-5
  // User saw stock=1, another user bought it → stock=0
  // Frontend must block Add to Cart
  test("TC-5 CORE: should block Add to Cart when stock drops to 0", () => {
    renderCard({ stock: 0 });

    const addToCartBtn = screen.queryByRole("button", { name: /add to cart/i });
    const outOfStockBtn = screen.queryByRole("button", { name: /out of stock/i });

    expect(addToCartBtn).toBeNull();
    expect(outOfStockBtn).toBeInTheDocument();
    expect(outOfStockBtn).toBeDisabled();
  });

  // ✅ TEST 5 — addToCart called on click
  test("should call addToCart when stock is available and clicked", () => {
    renderCard({ stock: 5 });
    fireEvent.click(screen.getByRole("button", { name: /add to cart/i }));
    expect(mockAddToCart).toHaveBeenCalledTimes(1);
  });

  // ✅ TEST 6 — Discount badge
  test("should show 50% OFF badge when originalPrice is double price", () => {
    renderCard({ price: 1499, originalPrice: 2999, stock: 5 });
    expect(screen.getByText(/50% off/i)).toBeInTheDocument();
  });

  // ✅ TEST 7 — No discount badge
  test("should NOT show discount badge when no discount", () => {
    renderCard({ price: 1000, originalPrice: 1000, stock: 5 });
    expect(screen.queryByText(/% off/i)).toBeNull();
  });

  // ✅ TEST 8 — Product name and brand
  test("should display product name and brand", () => {
    renderCard({ name: "iPhone 15", brand: "Apple", stock: 3 });
    expect(screen.getByText("iPhone 15")).toBeInTheDocument();
    expect(screen.getByText("Apple")).toBeInTheDocument();
  });

});
