import { createContext, useState, useEffect } from "react";
import axios from "axios";

 
export const ShopContext = createContext();
 
const ShopProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(false);
  const [products, setProducts] = useState([]);

   // ✅ AXIOS INSTANCE
  const API = axios.create({
    baseURL: "http://localhost:5000/api",
  });
 
useEffect(() => {
  const fetchProducts = async () => {
    try {
      const res = await API.get("/products");
      setProducts(res.data);
    } catch (err) {
      console.error("Fetch Products Error:", err);
    }
  };
 
  fetchProducts();
}, []);
 
 
  // ✅ FIXED TOKEN (IMPORTANT)
const userInfo = JSON.parse(sessionStorage.getItem("userInfo"))
const token = userInfo?.token


  
   API.interceptors.request.use((config) => {
    const userInfo=JSON.parse(sessionStorage.getItem("userInfo"))
    const token=userInfo?.token
 
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
 
  return config;
});
 
 
  // ============================
  // 🔥 FETCH CART
  // ============================
  const fetchCart = async () => {
    try {
      if (!token) return;
 
      setLoading(true);
 
      const { data } = await API.get("/cart", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
 
      setCart(data.items || []);
    } catch (err) {
      console.error("Fetch Cart Error:", err);
    } finally {
      setLoading(false);
    }
  };
 
  // ============================
  // 🔥 ADD TO CART
  // ============================
  // const addToCart = async (productId) => {
  // const token = sessionStorage.getItem("token");

  
const addToCart = async (productId) => {
  const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
  const token = userInfo?.token; // ✅ correct key
 
  // 🟢 LOGIN USER → API
  if (token) {
    try {
      await API.post(
        "/cart/add",
        { productId },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
 
      fetchCart();
    } catch (err) {
      console.error("Add Cart Error:", err);
    }
  }
 
  // 🟡 GUEST USER → LOCAL STORAGE
  else {
    setCart((prev) => {
      
      let updated = [...prev];
 
      const existing = updated.find(
        (item) => item.product._id === productId
      );
 
      if (existing) {
        existing.qty += 1;
      } else {
        const product = products.find(p => p._id === productId);
        updated.push({
          product,
          qty: 1,
        });
      }
 
      sessionStorage.setItem("cart", JSON.stringify(updated));
 
      return updated;
    });
  }
};

const mergeCart = async () => {
  const token = sessionStorage.getItem("token");
  const localCart = JSON.parse(sessionStorage.getItem("cart")) || [];
 
  if (!token || localCart.length === 0) return;
 
  try {
    for (let item of localCart) {
      await API.post(
        "/cart/add",
        {
          productId: item.product._id,
          qty: item.qty,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    }
 
    // 🧹 clear local cart
    sessionStorage.removeItem("cart");
 
    // ✅ refresh DB cart
    fetchCart();
 
    console.log("Cart merged ✅");
  } catch (err) {
    console.error("Merge Cart Error:", err);
  }
};

 
 
  // ============================
  // 🔥 UPDATE QTY
  // ============================
//   const updateQty = async (productId, qty) => {
//   try {
//     // ❌ prevent negative or zero
//     if (qty < 1) {
//       await removeItem(productId); // auto remove
//       return;
//     }
 
//     await API.put(
//       "/cart/update",
//       { productId, qty },
//       {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       }
//     );
 
//     fetchCart(); // refresh
//   } catch (err) {
//     console.error("Update Qty Error:", err);
//   }
// };

const updateQty = async (productId, qty) => {
  // 🟡 GUEST USER
  if (!token) {
    setCart((prev) => {
      const updated = prev.map((item) =>
        item.product._id === productId
          ? { ...item, qty }
          : item
      );

      sessionStorage.setItem("cart", JSON.stringify(updated));
      return updated;
    });
    return;
  }

  // 🟢 LOGGED-IN USER
  try {
    if (qty < 1) {
      await removeItem(productId);
      return;
    }

    await API.put("/cart/update", { productId, qty });
    fetchCart();
  } catch (err) {
    console.error("Update Qty Error:", err);
  }
};
 
 
  // ============================
  // 🔥 REMOVE ITEM
  // ============================
  // const removeItem = async (productId) => {
  //   try {
  //     await API.delete(`/cart/remove/${productId}`, {
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //       },
  //     });
 
  //     fetchCart();
  //   } catch (err) {
  //     console.error("Remove Error:", err);
  //   }
  // };

  const removeItem = async (productId) => {
  // 🟡 GUEST USER
  if (!token) {
    setCart((prev) => {
      const updated = prev.filter(
        (item) => item.product._id !== productId
      );

      sessionStorage.setItem("cart", JSON.stringify(updated));
      return updated;
    });
    return;
  }

  // 🟢 LOGGED-IN USER
  try {
    await API.delete(`/cart/remove/${productId}`);
    fetchCart();
  } catch (err) {
    console.error("Remove Error:", err);
  }
};

const clearCart = async () => {
  try {
    const userInfo = JSON.parse(sessionStorage.getItem("userInfo") || "null");
    const token = userInfo?.token;
    if (token) {
      await API.delete("/cart/clear", {
        headers: { Authorization: `Bearer ${token}` }
      });
    }
    setCart([]);
    sessionStorage.removeItem("cart");
  } catch (err) {
    console.error("Clear cart error:", err);
    setCart([]);
    sessionStorage.removeItem("cart");
  }
};
 
  // ============================
  // 🔥 AUTO FETCH
  // ============================
  useEffect(() => {
    if (products.length>0){
    fetchCart();
    }
  }, [products, token]);
 
  return (
    <ShopContext.Provider
      value={{
        cart,
        loading,
        products,
        addToCart,
        updateQty,
        removeItem,
        fetchCart,
        mergeCart,
        clearCart,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};
 
export default ShopProvider;
 