import { createContext, useState, useEffect } from "react";
 
export const AuthContext = createContext();
 
const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
 
  // 🔥 AUTO LOGIN (on refresh)
  useEffect(() => {
    const storedUser = sessionStorage.getItem("user");
    const storedToken = sessionStorage.getItem("token");
 
    if (storedUser && storedToken) {
      setUser(JSON.parse(storedUser));
      setToken(storedToken);
    }
  }, []);
 
  // 🔥 LOGIN
  const login = (userData, tokenData) => {
    sessionStorage.setItem("user", JSON.stringify(userData));
    sessionStorage.setItem("token", tokenData);
 
    setUser(userData);
    setToken(tokenData);
  };
 
  // 🔥 LOGOUT
  const logout = () => {
    sessionStorage.removeItem("user");
    sessionStorage.removeItem("token");
 
    setUser(null);
    setToken(null);
  };
 
  return (
    <AuthContext.Provider value={{ user, token, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
 
export default AuthProvider;
 