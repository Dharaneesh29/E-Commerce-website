import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { useContext, useEffect } from "react";
``
import { waitFor } from "@testing-library/react";
import  ShopContextProvider , { ShopContext } from "./ShopContext";

jest.mock("axios", () => {
  const mockAxiosInstance = {
    get: jest.fn().mockResolvedValue({ data: [] }),
    post: jest.fn().mockResolvedValue({ data: { success: true } }),
    put: jest.fn().mockResolvedValue({ data: { success: true } }),
    delete: jest.fn().mockResolvedValue({ data: { success: true } }),
    interceptors: {
      request: { use: jest.fn() },
      response: { use: jest.fn() },
    },
  };

  return {
    create: jest.fn(() => mockAxiosInstance),
  };
});

/* -------------------------------------------------
   Test-only helper component
   (USED ONLY FOR TESTING CART LOGIC)
-------------------------------------------------- */
const TestCartComponent = () => {
  const { cart, addToCart, removeItem, updateQty, products } =
    useContext(ShopContext);

  useEffect(() => {
    // inject fake product into products state
    if (products.length === 0) {
      products.push({
        _id: "p1",
        name: "Laptop",
        price: 50000,
        countInStock: 5,
      });
    }
  }, []);

  return (
    <div>
      <button onClick={() => addToCart("p1")}>Add</button>
      <button onClick={() => updateQty("p1", 3)}>Update Qty</button>
      <button onClick={() => removeItem("p1")}>Remove</button>

      <div data-testid="cart-length">{cart.length}</div>
      <div data-testid="cart-qty">{cart[0]?.qty || 0}</div>
    </div>
  );
};
/* -------------------------------------------------
   CART LOGIC TESTS (REAL, NO MOCKS)
-------------------------------------------------- */
describe("ShopContext – Cart Logic Tests", () => {

  test("should add item to cart", async () => {
    render(
      <ShopContextProvider>
        <TestCartComponent />
      </ShopContextProvider>
    );

    fireEvent.click(screen.getByText("Add"));

 await waitFor(() => {
    expect(screen.getByTestId("cart-length")).toHaveTextContent("1");
    expect(screen.getByTestId("cart-qty")).toHaveTextContent("1");
  });
});


  test("should increase quantity when same item added twice", async() => {
    render(
      <ShopContextProvider>
        <TestCartComponent />
      </ShopContextProvider>
    );

    fireEvent.click(screen.getByText("Add"));
    fireEvent.click(screen.getByText("Add"));

   
 await waitFor(() => {
    expect(screen.getByTestId("cart-length")).toHaveTextContent("1");
    expect(screen.getByTestId("cart-qty")).toHaveTextContent("2");
  });
});


  test("should update item quantity", async () => {
    render(
      <ShopContextProvider>
        <TestCartComponent />
      </ShopContextProvider>
    );

    fireEvent.click(screen.getByText("Add"));
    fireEvent.click(screen.getByText("Update Qty"));

   
await waitFor(() => {
    expect(screen.getByTestId("cart-qty")).toHaveTextContent("3");
  });
});


  test("should remove item from cart", async() => {
    render(
      <ShopContextProvider>
        <TestCartComponent />
      </ShopContextProvider>
    );

    fireEvent.click(screen.getByText("Add"));
    fireEvent.click(screen.getByText("Remove"));

  await waitFor(() => {
    expect(screen.getByTestId("cart-length")).toHaveTextContent("0");
  });
});
      


});



