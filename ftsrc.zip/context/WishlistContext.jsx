import { createContext, useState, useEffect } from "react";
import {
  getWishlistAPI,
  addToWishlistAPI,
  removeFromWishlistAPI,
} from "../api/wishlist";
 
export const WishlistContext = createContext();
 
export const WishlistProvider = ({ children }) => {
  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(false);
 
  // 🔥 GET wishlist from backend
  const fetchWishlist = async () => {
    try {
      setLoading(true);
      const res = await getWishlistAPI();
      setWishlist(Array.isArray(res.data)?res.data:[]) // array of products
    } catch (err) {
      console.log("Wishlist fetch error:", err);
      setWishlist([]);
    } finally {
      setLoading(false);
    }
  };
 
  // 🔥 ADD / REMOVE toggle
  const toggleWishlist = async (productId) => {
    try {
      // check already exists
      const exists = wishlist.some((p) => p._id === productId);
 
      if (exists) {
        await removeFromWishlistAPI(productId);
      } else {
        await addToWishlistAPI(productId);
      }
 
      // refresh after change
      fetchWishlist();
    } catch (err) {
      console.log("Wishlist toggle error:", err);
    }
  };
 
  // 🔥 REMOVE directly (optional use)
  const removeFromWishlist = async (productId) => {
    try {
      await removeFromWishlistAPI(productId);
      setWishlist((prev) => prev.filter((p) => p._id !== productId));
    } catch (err) {
      console.log(err);
    }
  };
 
  // 🔥 AUTO LOAD after login
  useEffect(() => {
    const token = sessionStorage.getItem("token");
    if (token) {
      fetchWishlist();
    }
  }, []);
 
  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        loading,
        fetchWishlist,
        toggleWishlist,
        removeFromWishlist,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};
 