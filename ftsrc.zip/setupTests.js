import "@testing-library/jest-dom"

// ✅ Fix TextEncoder error
import { TextEncoder, TextDecoder } from "util"

global.TextEncoder = TextEncoder
global.TextDecoder = TextDecoder

