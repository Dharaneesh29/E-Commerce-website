import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import ShopProvider from "./context/ShopContext";
import { WishlistProvider } from "./context/WishlistContext";
import AuthProvider from "./context/AuthContext";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <AuthProvider>
    <ShopProvider>
      <WishlistProvider>
    <App />
    </WishlistProvider>
    </ShopProvider>
    </AuthProvider>
  </React.StrictMode>

  
);