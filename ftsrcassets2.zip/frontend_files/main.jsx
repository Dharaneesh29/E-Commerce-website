import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=f6c68380"; const React = __vite__cjsImport0_react;
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=f6c68380"; const ReactDOM = __vite__cjsImport1_reactDom_client;
import App from "/src/App.jsx?t=1776248760713";
import "/src/index.css?t=1776248760713";
import ShopProvider from "/src/context/ShopContext.jsx";
var _jsxFileName = "C:/Users/mohamed.afzarn/EApp/frontend/src/main.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=f6c68380"; const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(React.StrictMode, { children: /* @__PURE__ */ _jsxDEV(ShopProvider, { children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 10,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 9,
	columnNumber: 5
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 8,
	columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sY0FBYztBQUNyQixPQUFPLFNBQVM7QUFDaEIsT0FBTztBQUNQLE9BQU8sa0JBQWtCOzs7QUFFekIsU0FBUyxXQUFXLFNBQVMsZUFBZSxPQUFPLENBQUMsQ0FBQyxPQUNuRCx3QkFBQyxNQUFNLFlBQVAsWUFDRSx3QkFBQyxjQUFELFlBQ0Esd0JBQUMsS0FBRCxFQUFPOzs7O1VBQ1E7Ozs7VUFDRTs7OztTQUdwQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtYWluLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbS9jbGllbnRcIjtcbmltcG9ydCBBcHAgZnJvbSBcIi4vQXBwXCI7XG5pbXBvcnQgXCIuL2luZGV4LmNzc1wiO1xuaW1wb3J0IFNob3BQcm92aWRlciBmcm9tIFwiLi9jb250ZXh0L1Nob3BDb250ZXh0XCI7XG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyb290XCIpKS5yZW5kZXIoXG4gIDxSZWFjdC5TdHJpY3RNb2RlPlxuICAgIDxTaG9wUHJvdmlkZXI+XG4gICAgPEFwcCAvPlxuICAgIDwvU2hvcFByb3ZpZGVyPlxuICA8L1JlYWN0LlN0cmljdE1vZGU+XG5cbiAgXG4pOyJdfQ==