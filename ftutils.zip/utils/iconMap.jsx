import {
  Smartphone,
  Laptop,
  Tablet,
  Shirt,
  Home,
  Heart,
  Dumbbell,
} from "lucide-react";
 
export const iconMap = {
  Mobile: <Smartphone size={14} />,
  Smartphones: <Smartphone size={14} />,
  Laptops: <Laptop size={14} />,
  Tablets: <Tablet size={14} />,
  "Mens-shirts": <Shirt size={14} />,
  "Womens-dresses": <Shirt size={14} />,
  Furniture: <Home size={14} />,
  Beauty: <Heart size={14} />,
  "Sports-accessories": <Dumbbell size={14} />,
};
 