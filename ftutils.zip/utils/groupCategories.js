import { categoryMap } from "./categoryMap";
 
export const groupCategories = (dbCategories) => {
  const grouped = {};
 
  Object.keys(categoryMap).forEach((main) => {
    grouped[main] = dbCategories.filter((cat) =>
      categoryMap[main].includes(cat)
    );
  });
 
  return grouped;
};