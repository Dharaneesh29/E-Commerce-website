/** @type {import('jest').Config} */
module.exports = {
  testEnvironment: "jsdom",

  setupFilesAfterEnv: ["<rootDir>/src/setupTests.js"],

  moduleNameMapper: {
    "^@/(.*)$": "<rootDir>/src/$1",
    "\\.(css|less|scss|sass)$": "identity-obj-proxy",
    "\\.(png|jpg|jpeg|svg|gif)$": "<rootDir>/__mocks__/fileMock.js"
  },

  transform: {
    "^.+\\.(js|jsx)$": "babel-jest",
  },
};
