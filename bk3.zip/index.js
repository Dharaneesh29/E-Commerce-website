const express = require("express")
const mongoose = require("mongoose");


const app = express()

mongoose.connect("mongodb://localhost:27017/ecommerceDB",{
    
})

app.get("/",(req,res)=>{
    res.send("Server is ready")
})

const port = 5000

app.listen(port,()=>{
    console.log(`Serve at http://localhost:${port}`)
})


