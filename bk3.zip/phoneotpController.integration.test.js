// ============================================================
//  PhoneOtpController Integration Tests
//  No DB needed — uses in-memory phoneOtpStore
//  File: backend/phoneotpController.integration.test.js
//  Run: npx jest phoneotpController.integration.test.js
// ============================================================

const { MongoMemoryServer } = require("mongodb-memory-server");
const mongoose = require("mongoose");

const {
  sendPhoneOtp,
  verifyPhoneOtp,
} = require("./controllers/phoneotpController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}) => ({ body });

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

// =============================================================
// TC-1: Send Phone OTP
// =============================================================
describe("TC-1: Send Phone OTP", () => {

  test("should generate phone OTP successfully", () => {
    const req = mockReq({ phone: "9876543210" });
    const res = mockRes();

    sendPhoneOtp(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Phone OTP generated (check terminal)" })
    );
  });

  test("should return 400 if phone is missing", () => {
    const req = mockReq({}); // no phone
    const res = mockRes();

    sendPhoneOtp(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Phone required" })
    );
  });

  test("should store OTP for given phone number", () => {
    const req = mockReq({ phone: "9000000001" });
    const res = mockRes();

    sendPhoneOtp(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Phone OTP generated (check terminal)" })
    );
  });

  test("should overwrite OTP if sendPhoneOtp called again for same phone", () => {
    const req1 = mockReq({ phone: "9000000002" });
    const res1 = mockRes();
    sendPhoneOtp(req1, res1);

    const req2 = mockReq({ phone: "9000000002" });
    const res2 = mockRes();
    sendPhoneOtp(req2, res2);

    expect(res2.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Phone OTP generated (check terminal)" })
    );
  });

});

// =============================================================
// TC-2: Verify Phone OTP
// =============================================================
describe("TC-2: Verify Phone OTP", () => {

  test("should verify correct phone OTP successfully", () => {
    // Capture OTP via console spy
    let capturedOtp;
    const consoleSpy = jest.spyOn(console, "log").mockImplementation((...args) => {
      const msg = args.join(" ");
      if (msg.includes("PHONE OTP for")) {
        const match = msg.match(/is:\s*(\d+)/);
        if (match) capturedOtp = match[1];
      }
    });

    const sendReq = mockReq({ phone: "9111111111" });
    const sendRes = mockRes();
    sendPhoneOtp(sendReq, sendRes);
    consoleSpy.mockRestore();

    // Verify with captured OTP
    const verifyReq = mockReq({ phone: "9111111111", otp: capturedOtp });
    const verifyRes = mockRes();
    verifyPhoneOtp(verifyReq, verifyRes);

    expect(verifyRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Phone Verified ✅" })
    );
  });

  test("should return 400 for invalid phone OTP", () => {
    const sendReq = mockReq({ phone: "9222222222" });
    const sendRes = mockRes();
    sendPhoneOtp(sendReq, sendRes);

    // Wrong OTP
    const verifyReq = mockReq({ phone: "9222222222", otp: "000000" });
    const verifyRes = mockRes();
    verifyPhoneOtp(verifyReq, verifyRes);

    expect(verifyRes.status).toHaveBeenCalledWith(400);
    expect(verifyRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid Phone OTP ❌" })
    );
  });

  test("should return 400 if phone has no OTP stored", () => {
    const verifyReq = mockReq({ phone: "9999999999", otp: "123456" });
    const verifyRes = mockRes();
    verifyPhoneOtp(verifyReq, verifyRes);

    expect(verifyRes.status).toHaveBeenCalledWith(400);
    expect(verifyRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid Phone OTP ❌" })
    );
  });

  test("should delete OTP after successful verification (prevent reuse)", () => {
    // Capture OTP
    let capturedOtp;
    const consoleSpy = jest.spyOn(console, "log").mockImplementation((...args) => {
      const msg = args.join(" ");
      if (msg.includes("PHONE OTP for")) {
        const match = msg.match(/is:\s*(\d+)/);
        if (match) capturedOtp = match[1];
      }
    });

    const sendReq = mockReq({ phone: "9333333333" });
    const sendRes = mockRes();
    sendPhoneOtp(sendReq, sendRes);
    consoleSpy.mockRestore();

    // First verify — should succeed
    const verifyReq1 = mockReq({ phone: "9333333333", otp: capturedOtp });
    const verifyRes1 = mockRes();
    verifyPhoneOtp(verifyReq1, verifyRes1);
    expect(verifyRes1.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Phone Verified ✅" })
    );

    // Second verify — should fail (OTP deleted)
    const verifyReq2 = mockReq({ phone: "9333333333", otp: capturedOtp });
    const verifyRes2 = mockRes();
    verifyPhoneOtp(verifyReq2, verifyRes2);
    expect(verifyRes2.status).toHaveBeenCalledWith(400);
  });

});
