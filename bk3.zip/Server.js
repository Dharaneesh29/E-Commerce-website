

const express= require("express")
const dotenv= require("dotenv")
const cors=require("cors")
const connectDB=require("./config/db")

const http=require("http");
const {Server}=require("socket.io")

dotenv.config()
connectDB()

const app=express()
app.use(cors())
app.use(express.json())

const userRoutes=require("./routes/UserRoutes")
app.use("/api/users",userRoutes)
const productRoutes=require("./routes/ProductRoutes")
app.use("/api/products",productRoutes)
app.use("/uploads",express.static("uploads"))

const dashboardRoutes= require("./routes/DashboardRoutes")
app.use("/api/dashboard",dashboardRoutes)

const addressRoutes= require("./routes/addressRoutes")
app.use("/api/address",addressRoutes)


const orderRoutes = require("./routes/orderRoutes")
app.use("/api/orders",orderRoutes)

const walletRoutes=require("./routes/walletRoutes");
app.use("/api/wallet", walletRoutes)

const cartRoutes=require("./routes/cartRoutes")
app.use("/api/cart",cartRoutes)

const couponRoutes=require("./routes/couponRoutes")
app.use("/api/coupon",couponRoutes)

const wishlistRoutes=require("./routes/wishlistRoutes")
app.use("/api/wishlist",wishlistRoutes);

const notificationRoutes=require("./routes/notificationRoutes");
app.use("/api/notifications",notificationRoutes);

const adminMembershipRoutes = require("./routes/adminMembership");
app.use("/api/admin/membership", adminMembershipRoutes);

app.use(
  "/api/user-notifications",
  require("./routes/userNotificationRoutes")
);



// app.use("/uploads",express.static("uploads"));

app.get("/",(req,res)=>{
    res.send("API Running..")
})

app.get("/test-notify",(req,res)=>{
    res.json({message:"notification route file loaded OK"});
});

const server = http.createServer(app);
 
const io = new Server(server, {
  cors: { origin: "*" }
});
 
global.io = io; // 🔥 important
 
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);
});


if (process.env.NODE_ENV !== "test") {
  server.listen(5000, () => {
    console.log("Server running on port 5000");
  });
}
 
module.exports = app;
 

