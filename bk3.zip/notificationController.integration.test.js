// ============================================================
//  NotificationController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/notificationController.integration.test.js
//  Run: npx jest notificationController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const Notification = require("./Models/Notification");

const {
  getNotifications,
  getUnreadCount,
  markAsRead,
  markAllAsRead,
  createNotification,
  deleteNotification,
  notify,
} = require("./controllers/notificationController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}) => ({
  body,
  params,
});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri   = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await Notification.deleteMany({});
});

// ── SEED HELPER ───────────────────────────────────────────────
const seedNotification = async (overrides = {}) => {
  return await Notification.create({
    type:    "order",
    message: "Test notification",
    isRead:  false,
    refId:   null,
    ...overrides,
  });
};

// =============================================================
// TC-1: Get Notifications
// =============================================================
describe("TC-1: Get Notifications", () => {

  test("should return latest 50 notifications sorted by newest first", async () => {
    // Create 3 notifications
    await seedNotification({ message: "Notification 1", type: "order" });
    await seedNotification({ message: "Notification 2", type: "user" });
    await seedNotification({ message: "Notification 3", type: "stock" });

    const req = mockReq();
    const res = mockRes();

    await getNotifications(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(3);
  });

  test("should return empty array if no notifications", async () => {
    const req = mockReq();
    const res = mockRes();

    await getNotifications(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toEqual([]);
  });

  test("should return max 50 notifications even if more exist", async () => {
    // Create 55 notifications
    const promises = [];
    for (let i = 0; i < 55; i++) {
      promises.push(
        Notification.create({ type: "order", message: `Notification ${i}`, isRead: false })
      );
    }
    await Promise.all(promises);

    const req = mockReq();
    const res = mockRes();

    await getNotifications(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.length).toBe(50); // limited to 50
  });

  test("should return notifications sorted newest first", async () => {
    await seedNotification({ message: "First" });
    await seedNotification({ message: "Second" });
    await seedNotification({ message: "Third" });

    const req = mockReq();
    const res = mockRes();

    await getNotifications(req, res);

    const callArg = res.json.mock.calls[0][0];
    // newest first — Third should be first
    expect(callArg[0].message).toBe("Third");
  });

});

// =============================================================
// TC-2: Get Unread Count
// =============================================================
describe("TC-2: Get Unread Count", () => {

  test("should return correct unread count", async () => {
    await seedNotification({ isRead: false });
    await seedNotification({ isRead: false });
    await seedNotification({ isRead: true }); // this one is read

    const req = mockReq();
    const res = mockRes();

    await getUnreadCount(req, res);

    expect(res.json).toHaveBeenCalledWith({ count: 2 });
  });

  test("should return 0 if all notifications are read", async () => {
    await seedNotification({ isRead: true });
    await seedNotification({ isRead: true });

    const req = mockReq();
    const res = mockRes();

    await getUnreadCount(req, res);

    expect(res.json).toHaveBeenCalledWith({ count: 0 });
  });

  test("should return 0 if no notifications exist", async () => {
    const req = mockReq();
    const res = mockRes();

    await getUnreadCount(req, res);

    expect(res.json).toHaveBeenCalledWith({ count: 0 });
  });

});

// =============================================================
// TC-3: Mark As Read
// =============================================================
describe("TC-3: Mark As Read", () => {

  test("should mark a notification as read", async () => {
    const notification = await seedNotification({ isRead: false });

    const req = mockReq({}, { id: notification._id.toString() });
    const res = mockRes();

    await markAsRead(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ success: true })
    );

    // Verify in DB
    const updated = await Notification.findById(notification._id);
    expect(updated.isRead).toBe(true);
  });

  test("should return 404 if notification not found", async () => {
    const req = mockReq({}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await markAsRead(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Notification not found" })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({}, { id: "invalid-id" });
    const res = mockRes();

    await markAsRead(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Failed to mark as read" })
    );
  });

  test("should keep already-read notification as read", async () => {
    const notification = await seedNotification({ isRead: true });

    const req = mockReq({}, { id: notification._id.toString() });
    const res = mockRes();

    await markAsRead(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ success: true })
    );

    const updated = await Notification.findById(notification._id);
    expect(updated.isRead).toBe(true);
  });

});

// =============================================================
// TC-4: Mark All As Read
// =============================================================
describe("TC-4: Mark All As Read", () => {

  test("should mark all unread notifications as read", async () => {
    await seedNotification({ isRead: false });
    await seedNotification({ isRead: false });
    await seedNotification({ isRead: false });

    const req = mockReq();
    const res = mockRes();

    await markAllAsRead(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success: true,
        message: "All notifications marked as read",
      })
    );

    // Verify all marked as read in DB
    const unread = await Notification.countDocuments({ isRead: false });
    expect(unread).toBe(0);
  });

  test("should succeed even if no unread notifications exist", async () => {
    await seedNotification({ isRead: true });
    await seedNotification({ isRead: true });

    const req = mockReq();
    const res = mockRes();

    await markAllAsRead(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success: true,
        message: "All notifications marked as read",
      })
    );
  });

  test("should succeed if no notifications exist at all", async () => {
    const req = mockReq();
    const res = mockRes();

    await markAllAsRead(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ success: true })
    );
  });

});

// =============================================================
// TC-5: Create Notification
// =============================================================
describe("TC-5: Create Notification", () => {

  test("should create an order notification successfully", async () => {
    const req = mockReq({
      type:    "order",
      message: "New order placed",
      refId:   "order123",
    });
    const res = mockRes();

    await createNotification(req, res);

    expect(res.status).toHaveBeenCalledWith(201);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.type).toBe("order");
    expect(callArg.message).toBe("New order placed");

    // Verify saved in DB
    const saved = await Notification.findOne({ message: "New order placed" });
    expect(saved).not.toBeNull();
  });

  test("should create a user notification successfully", async () => {
    const req = mockReq({
      type:    "user",
      message: "New user registered",
    });
    const res = mockRes();

    await createNotification(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    const callArg = res.json.mock.calls[0][0];
    expect(callArg.type).toBe("user");
  });

  test("should create a stock notification successfully", async () => {
    const req = mockReq({
      type:    "stock",
      message: "Low stock alert",
      refId:   "product456",
    });
    const res = mockRes();

    await createNotification(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    const callArg = res.json.mock.calls[0][0];
    expect(callArg.type).toBe("stock");
  });

  test("should return 500 if required fields are missing", async () => {
    const req = mockReq({
      // type is missing — required field
      message: "Missing type",
    });
    const res = mockRes();

    await createNotification(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Failed to create notification" })
    );
  });

});

// =============================================================
// TC-6: Delete Notification
// =============================================================
describe("TC-6: Delete Notification", () => {

  test("should delete notification successfully", async () => {
    const notification = await seedNotification();

    const req = mockReq({}, { id: notification._id.toString() });
    const res = mockRes();

    await deleteNotification(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success: true,
        message: "Notification deleted",
      })
    );

    // Verify deleted from DB
    const found = await Notification.findById(notification._id);
    expect(found).toBeNull();
  });

  test("should return success even if notification id does not exist", async () => {
    const req = mockReq({}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await deleteNotification(req, res);

    // findByIdAndDelete does not throw if not found
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ success: true })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({}, { id: "invalid-id" });
    const res = mockRes();

    await deleteNotification(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Failed to delete notification" })
    );
  });

});

// =============================================================
// TC-7: notify (internal helper)
// =============================================================
describe("TC-7: notify (internal helper)", () => {

  test("should create notification via notify helper", async () => {
    await notify("order", "Order placed successfully", "order123");

    const saved = await Notification.findOne({ message: "Order placed successfully" });
    expect(saved).not.toBeNull();
    expect(saved.type).toBe("order");
    expect(saved.refId).toBe("order123");
  });

  test("should create notification without refId", async () => {
    await notify("user", "New user registered");

    const saved = await Notification.findOne({ message: "New user registered" });
    expect(saved).not.toBeNull();
    expect(saved.refId).toBeNull();
  });

  test("should create stock notification", async () => {
    await notify("stock", "Low stock alert", "product789");

    const saved = await Notification.findOne({ message: "Low stock alert" });
    expect(saved).not.toBeNull();
    expect(saved.type).toBe("stock");
  });

  test("should not throw even if notification creation fails", async () => {
    // Pass invalid type to trigger validation error — notify should silently handle it
    await expect(
      notify("invalid_type", "This should fail silently")
    ).resolves.not.toThrow();
  });

});
