// ============================================================
//  CouponController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/couponController.integration.test.js
//  Run: npx jest couponController.integration.test.js
// ============================================================

const mongoose = require("mongodb-memory-server").MongoMemoryServer
  ? require("mongoose")
  : require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const Coupon = require("./Models/Coupon");

const {
  createCoupon,
  getCoupons,
  updateCoupon,
  deleteCoupon,
  applyCoupon,
} = require("./controllers/couponController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}) => ({
  body,
  params,
});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri   = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await Coupon.deleteMany({});
});

// ── SEED HELPER ───────────────────────────────────────────────
const seedCoupon = async (overrides = {}) => {
  return await Coupon.create({
    code:          "SAVE10",
    discountType:  "percentage",
    discountValue: 10,
    minAmount:     500,
    maxDiscount:   200,
    isActive:      true,
    expiryDate:    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
    ...overrides,
  });
};

// =============================================================
// TC-1: Create Coupon
// =============================================================
describe("TC-1: Create Coupon", () => {

  test("should create a percentage coupon successfully", async () => {
    const req = mockReq({
      code:          "WELCOME20",
      discountType:  "percentage",
      discountValue: 20,
      minAmount:     300,
      maxDiscount:   500,
      expiryDate:    new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      isActive:      true,
    });
    const res = mockRes();

    await createCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success: true,
        message: "Coupon created successfully",
      })
    );

    // Verify saved in DB
    const saved = await Coupon.findOne({ code: "WELCOME20" });
    expect(saved).not.toBeNull();
    expect(saved.discountValue).toBe(20);
  });

  test("should create a flat discount coupon successfully", async () => {
    const req = mockReq({
      code:          "FLAT100",
      discountType:  "flat",
      discountValue: 100,
      minAmount:     500,
    });
    const res = mockRes();

    await createCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    const saved = await Coupon.findOne({ code: "FLAT100" });
    expect(saved.discountType).toBe("flat");
  });

  test("should store coupon code in uppercase", async () => {
    const req = mockReq({
      code:          "lowercase10",
      discountType:  "flat",
      discountValue: 50,
    });
    const res = mockRes();

    await createCoupon(req, res);

    const saved = await Coupon.findOne({ code: "LOWERCASE10" });
    expect(saved).not.toBeNull();
  });

  test("should return 400 if required fields are missing", async () => {
    const req = mockReq({
      code: "MISSING",
      // discountType and discountValue missing
    });
    const res = mockRes();

    await createCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "code, discountType and discountValue are required",
      })
    );
  });

  test("should return 400 if coupon code already exists", async () => {
    await seedCoupon({ code: "DUPLICATE" });

    const req = mockReq({
      code:          "duplicate", // same code, lowercase
      discountType:  "flat",
      discountValue: 50,
    });
    const res = mockRes();

    await createCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Coupon code already exists" })
    );
  });

  test("should create coupon with default values when optional fields missing", async () => {
    const req = mockReq({
      code:          "MINIMAL",
      discountType:  "flat",
      discountValue: 50,
      // minAmount, maxDiscount, expiryDate not provided
    });
    const res = mockRes();

    await createCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    const saved = await Coupon.findOne({ code: "MINIMAL" });
    expect(saved.minAmount).toBe(0);
    expect(saved.maxDiscount).toBeNull();
    expect(saved.expiryDate).toBeNull();
    expect(saved.isActive).toBe(true);
  });

});

// =============================================================
// TC-2: Get All Coupons
// =============================================================
describe("TC-2: Get All Coupons", () => {

  test("should return all coupons sorted by newest first", async () => {
    await seedCoupon({ code: "COUPON1" });
    await seedCoupon({ code: "COUPON2" });
    await seedCoupon({ code: "COUPON3" });

    const req = mockReq();
    const res = mockRes();

    await getCoupons(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(3);
  });

  test("should return empty array if no coupons", async () => {
    const req = mockReq();
    const res = mockRes();

    await getCoupons(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toEqual([]);
  });

});

// =============================================================
// TC-3: Update Coupon
// =============================================================
describe("TC-3: Update Coupon", () => {

  test("should update coupon successfully", async () => {
    const coupon = await seedCoupon({ code: "UPDATE10" });

    const req = mockReq(
      { discountValue: 25, isActive: false },
      { id: coupon._id.toString() }
    );
    const res = mockRes();

    await updateCoupon(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success: true,
        message: "Coupon updated",
      })
    );

    // Verify in DB
    const updated = await Coupon.findById(coupon._id);
    expect(updated.discountValue).toBe(25);
    expect(updated.isActive).toBe(false);
  });

  test("should return 404 if coupon not found", async () => {
    const req = mockReq(
      { discountValue: 30 },
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await updateCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Coupon not found" })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({ discountValue: 30 }, { id: "invalid-id" });
    const res = mockRes();

    await updateCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-4: Delete Coupon
// =============================================================
describe("TC-4: Delete Coupon", () => {

  test("should delete coupon successfully", async () => {
    const coupon = await seedCoupon({ code: "DELETE10" });

    const req = mockReq({}, { id: coupon._id.toString() });
    const res = mockRes();

    await deleteCoupon(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success: true,
        message: "Coupon deleted successfully",
      })
    );

    // Verify deleted from DB
    const found = await Coupon.findById(coupon._id);
    expect(found).toBeNull();
  });

  test("should return 404 if coupon not found", async () => {
    const req = mockReq({}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await deleteCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Coupon not found" })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({}, { id: "invalid-id" });
    const res = mockRes();

    await deleteCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-5: Apply Coupon
// =============================================================
describe("TC-5: Apply Coupon", () => {

  test("should apply percentage coupon successfully", async () => {
    await seedCoupon({
      code:          "PERCENT10",
      discountType:  "percentage",
      discountValue: 10,
      minAmount:     500,
      maxDiscount:   200,
    });

    const req = mockReq({ code: "PERCENT10", cartTotal: 1000 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success:  true,
        discount: 100, // 10% of 1000
        finalTotal: 900,
      })
    );
  });

  test("should apply flat discount coupon successfully", async () => {
    await seedCoupon({
      code:          "FLAT50",
      discountType:  "flat",
      discountValue: 50,
      minAmount:     200,
    });

    const req = mockReq({ code: "FLAT50", cartTotal: 500 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success:    true,
        discount:   50,
        finalTotal: 450,
      })
    );
  });

  test("should cap percentage discount at maxDiscount", async () => {
    await seedCoupon({
      code:          "CAPPED",
      discountType:  "percentage",
      discountValue: 50,
      minAmount:     100,
      maxDiscount:   100, // cap at ₹100
    });

    const req = mockReq({ code: "CAPPED", cartTotal: 1000 });
    const res = mockRes();

    await applyCoupon(req, res);

    // 50% of 1000 = 500, but capped at 100
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        discount:   100,
        finalTotal: 900,
      })
    );
  });

  test("should use subtotal if cartTotal not provided", async () => {
    await seedCoupon({
      code:          "SUBTOTAL",
      discountType:  "flat",
      discountValue: 50,
      minAmount:     100,
    });

    const req = mockReq({ code: "SUBTOTAL", subtotal: 600 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success:    true,
        finalTotal: 550,
      })
    );
  });

  test("should return 400 if code or cartTotal is missing", async () => {
    const req = mockReq({ code: "SAVE10" }); // cartTotal missing
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "code and cartTotal are required" })
    );
  });

  test("should return 404 if coupon code is invalid", async () => {
    const req = mockReq({ code: "INVALID", cartTotal: 500 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid coupon code" })
    );
  });

  test("should return 400 if coupon is inactive", async () => {
    await seedCoupon({ code: "INACTIVE", isActive: false });

    const req = mockReq({ code: "INACTIVE", cartTotal: 1000 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "This coupon is no longer active" })
    );
  });

  test("should return 400 if coupon has expired", async () => {
    await seedCoupon({
      code:       "EXPIRED",
      expiryDate: new Date(Date.now() - 24 * 60 * 60 * 1000), // yesterday
    });

    const req = mockReq({ code: "EXPIRED", cartTotal: 1000 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "This coupon has expired" })
    );
  });

  test("should return 400 if order amount is below minimum", async () => {
    await seedCoupon({
      code:      "MINCHECK",
      minAmount: 1000,
    });

    const req = mockReq({ code: "MINCHECK", cartTotal: 300 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: expect.stringContaining("Minimum order amount"),
      })
    );
  });

  test("should return 400 if only code is missing", async () => {
  const req = mockReq({ cartTotal: 500 }); // code missing
  const res = mockRes();

  await applyCoupon(req, res);

  expect(res.status).toHaveBeenCalledWith(400);
  expect(res.json).toHaveBeenCalledWith(
    expect.objectContaining({ message: "code and cartTotal are required" })
  );
});

test("should apply coupon with no expiryDate (never expires)", async () => {
  await seedCoupon({
    code:       "NOEXPIRY",
    expiryDate: null, // no expiry
    minAmount:  0,
  });

  const req = mockReq({ code: "NOEXPIRY", cartTotal: 1000 });
  const res = mockRes();

  await applyCoupon(req, res);

  expect(res.json).toHaveBeenCalledWith(
    expect.objectContaining({ success: true })
  );
});

  test("should not give discount more than order amount", async () => {
    await seedCoupon({
      code:          "BIGDISCOUNT",
      discountType:  "flat",
      discountValue: 1000, // bigger than cart total
      minAmount:     0,
    });

    const req = mockReq({ code: "BIGDISCOUNT", cartTotal: 200 });
    const res = mockRes();

    await applyCoupon(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        discount:   200, // capped at cart total
        finalTotal: 0,
      })
    );
  });

});
