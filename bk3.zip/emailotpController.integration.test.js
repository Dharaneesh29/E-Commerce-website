// ============================================================
//  EmailOtpController Integration Tests
//  No DB needed — uses in-memory otpStore
//  File: backend/emailotpController.integration.test.js
//  Run: npx jest emailotpController.integration.test.js
// ============================================================

const { MongoMemoryServer } = require("mongodb-memory-server");
const mongoose = require("mongoose");

const {
  sendOtp,
  verifyOtp,
} = require("./controllers/emailotpController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}) => ({ body });

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

// =============================================================
// TC-1: Send OTP
// =============================================================
describe("TC-1: Send OTP (Email)", () => {

  test("should generate OTP successfully for valid email", async () => {
    const req = mockReq({ email: "test@gmail.com" });
    const res = mockRes();

    await sendOtp(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "OTP generated (check terminal)" })
    );
  });

  test("should return 400 if email is missing", async () => {
    const req = mockReq({}); // no email
    const res = mockRes();

    await sendOtp(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Email required" })
    );
  });

  test("should store OTP in memory for given email", async () => {
    const req = mockReq({ email: "store@gmail.com" });
    const res = mockRes();

    await sendOtp(req, res);

    // OTP generated — response should be success
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "OTP generated (check terminal)" })
    );
  });

  test("should overwrite existing OTP if sendOtp called again", async () => {
    const req1 = mockReq({ email: "resend@gmail.com" });
    const res1 = mockRes();
    await sendOtp(req1, res1);

    const req2 = mockReq({ email: "resend@gmail.com" });
    const res2 = mockRes();
    await sendOtp(req2, res2);

    // Both should succeed
    expect(res2.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "OTP generated (check terminal)" })
    );
  });

});

// =============================================================
// TC-2: Verify OTP
// =============================================================
describe("TC-2: Verify OTP (Email)", () => {

  test("should verify correct OTP successfully", async () => {
    // Step 1: Send OTP
    const sendReq = mockReq({ email: "verify@gmail.com" });
    const sendRes = mockRes();
    await sendOtp(sendReq, sendRes);

    // Step 2: Get the OTP from the controller's store
    // We need to intercept — use the module directly
    const otpController = require("./controllers/emailotpController");

    // Re-send to capture OTP via mock
    let capturedOtp;
    const consoleSpy = jest.spyOn(console, "log").mockImplementation((...args) => {
      const msg = args.join(" ");
      if (msg.includes("OTP for")) {
        // Extract OTP number from log: "📩 OTP for email@gmail.com is: 123456"
        const match = msg.match(/is:\s*(\d+)/);
        if (match) capturedOtp = match[1];
      }
    });

    const req2 = mockReq({ email: "verify@gmail.com" });
    const res2 = mockRes();
    await sendOtp(req2, res2);

    consoleSpy.mockRestore();

    // Step 3: Verify with captured OTP
    const verifyReq = mockReq({ email: "verify@gmail.com", otp: capturedOtp });
    const verifyRes = mockRes();
    verifyOtp(verifyReq, verifyRes);

    expect(verifyRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "OTP Verified ✅" })
    );
  });

  test("should return 400 for invalid OTP", async () => {
    // Send OTP first
    const sendReq = mockReq({ email: "wrong@gmail.com" });
    const sendRes = mockRes();
    await sendOtp(sendReq, sendRes);

    // Try wrong OTP
    const verifyReq = mockReq({ email: "wrong@gmail.com", otp: "000000" });
    const verifyRes = mockRes();
    verifyOtp(verifyReq, verifyRes);

    expect(verifyRes.status).toHaveBeenCalledWith(400);
    expect(verifyRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid OTP ❌" })
    );
  });

  test("should return 400 if email has no OTP stored", async () => {
    const verifyReq = mockReq({ email: "nostore@gmail.com", otp: "123456" });
    const verifyRes = mockRes();
    verifyOtp(verifyReq, verifyRes);

    expect(verifyRes.status).toHaveBeenCalledWith(400);
    expect(verifyRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid OTP ❌" })
    );
  });

  test("should delete OTP from store after successful verification", async () => {
    // Capture OTP
    let capturedOtp;
    const consoleSpy = jest.spyOn(console, "log").mockImplementation((...args) => {
      const msg = args.join(" ");
      if (msg.includes("OTP for")) {
        const match = msg.match(/is:\s*(\d+)/);
        if (match) capturedOtp = match[1];
      }
    });

    const sendReq = mockReq({ email: "cleanup@gmail.com" });
    const sendRes = mockRes();
    await sendOtp(sendReq, sendRes);
    consoleSpy.mockRestore();

    // First verify — should succeed
    const verifyReq1 = mockReq({ email: "cleanup@gmail.com", otp: capturedOtp });
    const verifyRes1 = mockRes();
    verifyOtp(verifyReq1, verifyRes1);
    expect(verifyRes1.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "OTP Verified ✅" })
    );

    // Second verify with same OTP — should fail (deleted from store)
    const verifyReq2 = mockReq({ email: "cleanup@gmail.com", otp: capturedOtp });
    const verifyRes2 = mockRes();
    verifyOtp(verifyReq2, verifyRes2);
    expect(verifyRes2.status).toHaveBeenCalledWith(400);
  });

});
