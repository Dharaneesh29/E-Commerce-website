// ============================================================
//  ProductController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/productController.integration.test.js
//  Run: npx jest productController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const Product = require("./Models/Product");
const User    = require("./Models/User");

// ── MOCK notificationController ───────────────────────────────
jest.mock("./controllers/notificationController", () => ({
  notify: jest.fn(),
}));

const {
  createProduct,
  getProducts,
  deleteProduct,
  getProductById,
  updateProduct,
  getLatestProducts,
  addReview,
  getSimilarProducts,
  getProductsByGroup,
  getProductsByBrand,
} = require("./controllers/ProductController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}, user = {}, file = null, query = {}) => ({
  body,
  params,
  user,
  file,
  query,
});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri   = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await Product.deleteMany({});
  await User.deleteMany({});
});

// ── SEED HELPERS ──────────────────────────────────────────────
const bcrypt = require("bcrypt");

const seedProduct = async (overrides = {}) => {
  return await Product.create({
    name:         "Test Product",
    price:        999,
    description:  "A test product",
    images:       ["test.jpg"],
    category:     "Electronics",
    countInStock: 20,
    brand:        "TestBrand",
    ...overrides,
  });
};

const seedUser = async (overrides = {}) => {
  const hashedPassword = await bcrypt.hash("password123", 10);
  return await User.create({
    name:     "Test User",
    email:    "test@gmail.com",
    phone:    "9876543210",
    password: hashedPassword,
    role:     "user",
    ...overrides,
  });
};

// =============================================================
// TC-1: Create Product
// =============================================================
describe("TC-1: Create Product", () => {

  test("should create a product successfully", async () => {
    const req = mockReq({
      name:         "Samsung Phone",
      price:        15000,
      description:  "Latest Samsung phone",
      images:       ["samsung.jpg"],
      category:     "Mobile",
      countInStock: 50,
      brand:        "Samsung",
    });
    const res = mockRes();

    await createProduct(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.name).toBe("Samsung Phone");
    expect(callArg.price).toBe(15000);

    // Verify saved in DB
    const product = await Product.findOne({ name: "Samsung Phone" });
    expect(product).not.toBeNull();
  });

  test("should create product with image if file is uploaded", async () => {
    const req = mockReq(
      {
        name:         "Phone with Image",
        price:        10000,
        description:  "Has image",
        images:       ["default.jpg"],
        category:     "Mobile",
        countInStock: 10,
      },
      {},
      {},
      { filename: "phone.jpg" } // simulate multer file
    );
    const res = mockRes();

    await createProduct(req, res);

    expect(res.json).toHaveBeenCalled();

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.name).toBe("Phone with Image");
    const product= await Product.findOne({name:"Phone with Image"});
    expect(product).not.toBeNull();
  });

  test("should trigger low stock notify if stock <= 10", async () => {
    const { notify } = require("./controllers/notificationController");
    notify.mockClear();

    const req = mockReq({
      name:         "Low Stock Product",
      price:        500,
      description:  "Almost gone",
      images:       ["item.jpg"],
      category:     "Beauty",
      countInStock: 5, // <= 10 triggers low stock notify
    });
    const res = mockRes();

    await createProduct(req, res);

    // notify called twice — once for new product, once for low stock
    expect(notify).toHaveBeenCalledTimes(2);
  });

  test("should NOT trigger low stock notify if stock > 10", async () => {
    const { notify } = require("./controllers/notificationController");
    notify.mockClear();

    const req = mockReq({
      name:         "High Stock Product",
      price:        500,
      description:  "Plenty in stock",
      images:       ["item.jpg"],
      category:     "Beauty",
      countInStock: 50,
    });
    const res = mockRes();

    await createProduct(req, res);

    // notify called once only — for new product added
    expect(notify).toHaveBeenCalledTimes(1);
  });

  test("should return 500 on server error", async () => {
    const req = mockReq({
      // missing required fields — name, price, description, images, category
      price: 500,
    });
    const res = mockRes();

    await createProduct(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Error adding product" })
    );
  });

});

// =============================================================
// TC-2: Get All Products
// =============================================================
describe("TC-2: Get All Products", () => {

  test("should return all products", async () => {
    await seedProduct({ name: "Product 1", category: "Mobile" });
    await seedProduct({ name: "Product 2", category: "Beauty", email: "p2@test.com" });

    const req = mockReq();
    const res = mockRes();

    await getProducts(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(2);
  });

  test("should return empty array if no products", async () => {
    const req = mockReq();
    const res = mockRes();

    await getProducts(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toEqual([]);
  });

});

// =============================================================
// TC-3: Get Product By ID
// =============================================================
describe("TC-3: Get Product By ID", () => {

  test("should return product by valid id", async () => {
    const product = await seedProduct({ name: "Find Me" });

    const req = mockReq({}, { id: product._id.toString() });
    const res = mockRes();

    await getProductById(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.name).toBe("Find Me");
  });

  test("should return 404 if product not found", async () => {
    const req = mockReq({}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await getProductById(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Product not found" })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({}, { id: "invalid-id" });
    const res = mockRes();

    await getProductById(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Server error" })
    );
  });

});

// =============================================================
// TC-4: Update Product
// =============================================================
describe("TC-4: Update Product", () => {

  test("should update product successfully", async () => {
    const product = await seedProduct({ name: "Old Name", price: 100 });

    const req = mockReq(
      { name: "New Name", price: 200, countInStock: 50 },
      { id: product._id.toString() }
    );
    const res = mockRes();

    await updateProduct(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.name).toBe("New Name");
    expect(callArg.price).toBe(200);
  });

  test("should trigger low stock notify if updated stock <= 10 and > 0", async () => {
    const { notify } = require("./controllers/notificationController");
    notify.mockClear();

    const product = await seedProduct({ countInStock: 50 });

    const req = mockReq(
      { countInStock: 5 }, // low stock after update
      { id: product._id.toString() }
    );
    const res = mockRes();

    await updateProduct(req, res);

    expect(notify).toHaveBeenCalledWith(
      "stock",
      expect.stringContaining("Low stock alert"),
      product._id.toString()
    );
  });

  test("should trigger out of stock notify if updated stock === 0", async () => {
    const { notify } = require("./controllers/notificationController");
    notify.mockClear();

    const product = await seedProduct({ countInStock: 10 });

    const req = mockReq(
      { countInStock: 0 }, // out of stock
      { id: product._id.toString() }
    );
    const res = mockRes();

    await updateProduct(req, res);

    expect(notify).toHaveBeenCalledWith(
      "stock",
      expect.stringContaining("Out of stock"),
      product._id.toString()
    );
  });

  test("should return 404 if product not found", async () => {
    const req = mockReq(
      { name: "Updated" },
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await updateProduct(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Product not found" })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({ name: "Updated" }, { id: "invalid-id" });
    const res = mockRes();

    await updateProduct(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-5: Delete Product
// =============================================================
describe("TC-5: Delete Product", () => {

  test("should delete product successfully", async () => {
    const product = await seedProduct({ name: "Delete Me" });

    const req = mockReq({}, { id: product._id.toString() });
    const res = mockRes();

    await deleteProduct(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Product deleted" })
    );

    // Verify deleted from DB
    const found = await Product.findById(product._id);
    expect(found).toBeNull();
  });

  test("should return 404 if product not found", async () => {
    const req = mockReq({}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await deleteProduct(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Product not found" })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({}, { id: "invalid-id" });
    const res = mockRes();

    await deleteProduct(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-6: Get Latest Products
// =============================================================
describe("TC-6: Get Latest Products", () => {

  test("should return latest 7 products sorted by newest first", async () => {
    // Create 10 products
    for (let i = 1; i <= 10; i++) {
      await seedProduct({ name: `Product ${i}`, price: i * 100 });
    }

    const req = mockReq();
    const res = mockRes();

    await getLatestProducts(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(7); // only 7 returned
  });

  test("should return all products if less than 7 exist", async () => {
    await seedProduct({ name: "Only Product" });

    const req = mockReq();
    const res = mockRes();

    await getLatestProducts(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.length).toBe(1);
  });

});

// =============================================================
// TC-7: Add Review
// =============================================================
describe("TC-7: Add Review", () => {

  test("should add review to product successfully", async () => {
    const product = await seedProduct();
    const user    = await seedUser();

    const req = mockReq(
      { rating: 4, comment: "Great product!" },
      { id: product._id.toString() },
      { id: user._id.toString() }
    );
    const res = mockRes();

    await addReview(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Review added" })
    );

    // Verify review saved in DB
    const updated = await Product.findById(product._id);
    expect(updated.reviews.length).toBe(1);
    expect(updated.reviews[0].comment).toBe("Great product!");
    expect(updated.reviews[0].rating).toBe(4);
  });

  test("should update average rating after review", async () => {
    const product = await seedProduct();
    const user    = await seedUser();

    const req = mockReq(
      { rating: 5, comment: "Excellent!" },
      { id: product._id.toString() },
      { id: user._id.toString() }
    );
    const res = mockRes();

    await addReview(req, res);

    const updated = await Product.findById(product._id);
    expect(updated.rating).toBe(5);
  });

  test("should add review with image if file uploaded", async () => {
    const product = await seedProduct();
    const user    = await seedUser();

    const req = mockReq(
      { rating: 3, comment: "OK product" },
      { id: product._id.toString() },
      { id: user._id.toString() },
      { filename: "review.jpg" }
    );
    const res = mockRes();

    await addReview(req, res);

    const updated = await Product.findById(product._id);
    expect(updated.reviews[0].image).toBe("/uploads/review.jpg");
  });

  test("should return 404 if product not found", async () => {
    const user = await seedUser();

    const req = mockReq(
      { rating: 4, comment: "Nice" },
      { id: new mongoose.Types.ObjectId().toString() },
      { id: user._id.toString() }
    );
    const res = mockRes();

    await addReview(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Product not found" })
    );
  });

  test("should return 401 if user not found", async () => {
    const product = await seedProduct();

    const req = mockReq(
      { rating: 4, comment: "Nice" },
      { id: product._id.toString() },
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await addReview(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User not found" })
    );
  });

});

// =============================================================
// TC-8: Get Similar Products
// =============================================================
describe("TC-8: Get Similar Products", () => {

  test("should return similar products by category", async () => {
    const product = await seedProduct({ name: "Main Product", category: "Mobile" });
    await seedProduct({ name: "Similar 1", category: "Mobile" });
    await seedProduct({ name: "Similar 2", category: "Mobile" });
    await seedProduct({ name: "Different", category: "Beauty" });

    const req = mockReq({}, { id: product._id.toString() });
    const res = mockRes();

    await getSimilarProducts(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(2); // excludes current product
    callArg.forEach(p => expect(p.category).toBe("Mobile"));
  });

  test("should return 404 if product not found", async () => {
    const req = mockReq({}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await getSimilarProducts(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Product not found" })
    );
  });

  test("should return 500 on invalid id format", async () => {
    const req = mockReq({}, { id: "invalid-id" });
    const res = mockRes();

    await getSimilarProducts(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-9: Get Products By Group
// =============================================================
describe("TC-9: Get Products By Group", () => {

  test("should return products for electronics group", async () => {
    await seedProduct({ name: "Phone", category: "Mobile" });
    await seedProduct({ name: "Laptop", category: "Laptops" });
    await seedProduct({ name: "Dress", category: "Womens-dresses" });

    const req = mockReq({}, { name: "electronics" }, {}, null, {});
    const res = mockRes();

    await getProductsByGroup(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(2); // Mobile + Laptops
  });

  test("should return products filtered by sub-category", async () => {
    await seedProduct({ name: "Phone", category: "Mobile" });
    await seedProduct({ name: "Laptop", category: "Laptops" });

    const req = mockReq({}, { name: "electronics" }, {}, null, { sub: "Mobile" });
    const res = mockRes();

    await getProductsByGroup(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.length).toBe(1);
    expect(callArg[0].category).toBe("Mobile");
  });

  test("should return empty array for unknown group", async () => {
    await seedProduct({ name: "Phone", category: "Mobile" });

    const req = mockReq({}, { name: "unknown-group" }, {}, null, {});
    const res = mockRes();

    await getProductsByGroup(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toEqual([]);
  });

  test("should return all group products when sub is 'all'", async () => {
    await seedProduct({ name: "Phone", category: "Mobile" });
    await seedProduct({ name: "Laptop", category: "Laptops" });

    const req = mockReq({}, { name: "electronics" }, {}, null, { sub: "all" });
    const res = mockRes();

    await getProductsByGroup(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.length).toBe(2);
  });

});

// =============================================================
// TC-10: Get Products By Brand
// =============================================================
describe("TC-10: Get Products By Brand", () => {

  test("should return products matching brand (case insensitive)", async () => {
    await seedProduct({ name: "Samsung A52", brand: "Samsung" });
    await seedProduct({ name: "Samsung S23", brand: "Samsung" });
    await seedProduct({ name: "iPhone 14", brand: "Apple" });

    const req = mockReq({}, { brand: "samsung" });
    const res = mockRes();

    await getProductsByBrand(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.length).toBe(2);
    callArg.forEach(p => expect(p.brand.toLowerCase()).toBe("samsung"));
  });

  test("should return empty array if no products match brand", async () => {
    await seedProduct({ name: "Samsung Phone", brand: "Samsung" });

    const req = mockReq({}, { brand: "Nokia" });
    const res = mockRes();

    await getProductsByBrand(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toEqual([]);
  });

  test("should return 500 on server error", async () => {
    // Force error by passing invalid regex character
    const req = mockReq({}, { brand: "[invalid-regex" });
    const res = mockRes();

    await getProductsByBrand(req, res);

    // MongoDB regex error → 500
    expect(res.status).toHaveBeenCalledWith(500);
  });

});


