// ============================================================
//  WishlistController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/wishlistController.integration.test.js
//  Run: npx jest wishlistController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const User    = require("./Models/User");
const Product = require("./Models/Product");

const {
  addToWishlist,
  getWishlist,
  removeFromWishlist,
} = require("./controllers/wishlistController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}, user = {}) => ({
  body,
  params,
  user,
});

// ── SETUP ─────────────────────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await User.deleteMany({});
  await Product.deleteMany({});
});

// ── SEED HELPERS ──────────────────────────────────────────────
const bcrypt = require("bcrypt");

const seedUser = async (overrides = {}) => {
  const hashedPassword = await bcrypt.hash("password123", 10);
  return await User.create({
    name:     "Test User",
    email:    "test@gmail.com",
    phone:    "9876543210",
    password: hashedPassword,
    role:     "user",
    wishlist: [],
    ...overrides,
  });
};

const seedProduct = async (overrides = {}) => {
  return await Product.create({
    name:         "Test Product",
    price:        500,
    description:  "A test product",
    images:       ["test.jpg"],
    category:     "Electronics",
    countInStock: 10,
    ...overrides,
  });
};

// =============================================================
// TC-1: Add To Wishlist
// =============================================================
describe("TC-1: Add To Wishlist", () => {

  test("should return wishlist on addToWishlist call", async () => {
    const user    = await seedUser();
    const product = await seedProduct();

    const req = mockReq(
      {},
      { productId: product._id.toString() },
      { id: user._id.toString() }
    );
    const res = mockRes();

    await addToWishlist(req, res);

    // Controller calls res.json early with wishlist
    expect(res.json).toHaveBeenCalled();
  });

  test("should return 500 on invalid user id", async () => {
    const product = await seedProduct();

    const req = mockReq(
      {},
      { productId: product._id.toString() },
      { id: "invalid-id" }
    );
    const res = mockRes();

    await addToWishlist(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

  test("should return 500 if user not found", async () => {
    const product = await seedProduct();

    const req = mockReq(
      {},
      { productId: product._id.toString() },
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await addToWishlist(req, res);

    // user is null — populate fails → 500
    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-2: Get Wishlist
// =============================================================
describe("TC-2: Get Wishlist", () => {

  test("should return empty wishlist for user with no wishlist items", async () => {
    const user = await seedUser({ wishlist: [] });

    const req = mockReq({}, {}, { id: user._id.toString() });
    const res = mockRes();

    await getWishlist(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(0);
  });

  test("should return wishlist with populated products", async () => {
    const product = await seedProduct({ name: "Wishlist Product" });
    const user    = await seedUser({ wishlist: [product._id] });

    const req = mockReq({}, {}, { id: user._id.toString() });
    const res = mockRes();

    await getWishlist(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(1);
    expect(callArg[0].name).toBe("Wishlist Product");
  });

  test("should return 404 if user not found", async () => {
    const req = mockReq(
      {},
      {},
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await getWishlist(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User not found" })
    );
  });

  test("should return 500 on invalid user id", async () => {
    const req = mockReq({}, {}, { id: "invalid-id" });
    const res = mockRes();

    await getWishlist(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

  test("should return multiple wishlist items", async () => {
    const product1 = await seedProduct({ name: "Product 1" });
    const product2 = await seedProduct({ name: "Product 2" });
    const user     = await seedUser({ wishlist: [product1._id, product2._id] });

    const req = mockReq({}, {}, { id: user._id.toString() });
    const res = mockRes();

    await getWishlist(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.length).toBe(2);
  });

});

// =============================================================
// TC-3: Remove From Wishlist
// =============================================================
describe("TC-3: Remove From Wishlist", () => {

  test("should remove product from wishlist successfully", async () => {
    const product = await seedProduct();
    const user    = await seedUser({ wishlist: [product._id] });

    const req = mockReq(
      {},
      { productId: product._id.toString() },
      { id: user._id.toString() }
    );
    const res = mockRes();

    await removeFromWishlist(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Removed from wishlist" })
    );

    // Verify removed in DB
    const updated = await User.findById(user._id);
    expect(updated.wishlist.length).toBe(0);
  });

  test("should succeed even if product not in wishlist", async () => {
    const product = await seedProduct();
    const user    = await seedUser({ wishlist: [] }); // empty wishlist

    const req = mockReq(
      {},
      { productId: product._id.toString() },
      { id: user._id.toString() }
    );
    const res = mockRes();

    await removeFromWishlist(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Removed from wishlist" })
    );
  });

  test("should only remove the specified product, keep others", async () => {
    const product1 = await seedProduct({ name: "Keep Me" });
    const product2 = await seedProduct({ name: "Remove Me" });
    const user     = await seedUser({ wishlist: [product1._id, product2._id] });

    const req = mockReq(
      {},
      { productId: product2._id.toString() },
      { id: user._id.toString() }
    );
    const res = mockRes();

    await removeFromWishlist(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Removed from wishlist" })
    );

    // product1 should still be in wishlist
    const updated = await User.findById(user._id);
    expect(updated.wishlist.length).toBe(1);
    expect(updated.wishlist[0].toString()).toBe(product1._id.toString());
  });

  test("should return 500 on invalid user id", async () => {
    const product = await seedProduct();

    const req = mockReq(
      {},
      { productId: product._id.toString() },
      { id: "invalid-id" }
    );
    const res = mockRes();

    await removeFromWishlist(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

  test("should return 500 if user not found", async () => {
    const product = await seedProduct();

    const req = mockReq(
      {},
      { productId: product._id.toString() },
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await removeFromWishlist(req, res);

    // user is null — user.wishlist throws → 500
    expect(res.status).toHaveBeenCalledWith(500);
  });

});
