const mongoose = require("mongoose");
const dotenv = require("dotenv");
 
const Product = require("./Models/Product");
const products = require("./data/product");
 
dotenv.config();
 
// connect DB
mongoose.connect("mongodb://127.0.0.1:27017/ecommerceDB")
.then(() => console.log("DB Connected"))
.catch(err => console.log(err));
 
 
// IMPORT DATA
const importData = async () => {
  try {
    await Product.deleteMany(); // clear old data
    await Product.insertMany(products); // insert new data
 
    console.log("🔥 Products Imported Successfully");
    process.exit();
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

importData();

const getCategories = async () => {
  try {
    const categories = await Product.distinct("category");
 
    console.log("Categories:");
    console.log(categories);
 
    process.exit(); // stop script
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
};
 
getCategories();
 

 