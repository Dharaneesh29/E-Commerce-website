// ============================================================
//  UserController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/userController.integration.test.js
//  Run: npx jest userController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const User = require("./Models/User");

// ── MOCK notificationController (not a DB operation) ─────────
jest.mock("./controllers/notificationController", () => ({
  notify: jest.fn(),
}));

const {
  registerUser,
  registerAdmin,
  loginUser,
  getAllUsers,
  deleteUser,
  makeAdmin,
  blockUser,
  updateProfile,
  changePassword,
} = require("./controllers/UserController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}, user = {}, file = null) => ({
  body,
  params,
  user,
  file,
});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri   = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await User.deleteMany({});
});

// ── SEED HELPER ───────────────────────────────────────────────
const bcrypt = require("bcrypt");

const seedUser = async (overrides = {}) => {
  const hashedPassword = await bcrypt.hash("password123", 10);
  return await User.create({
    name:     "Test User",
    email:    "test@gmail.com",
    phone:    "9876543210",
    password: hashedPassword,
    role:     "user",
    ...overrides,
  });
};

// =============================================================
// TC-1: Register User
// =============================================================
describe("TC-1: Register User", () => {

  test("should register a new user successfully", async () => {
    const req = mockReq({
      name:     "Kavya",
      email:    "kavya@gmail.com",
      phone:    "9876543210",
      password: "pass123",
    });
    const res = mockRes();

    await registerUser(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User registered successfully" })
    );

    // Verify user saved in DB
    const user = await User.findOne({ email: "kavya@gmail.com" });
    expect(user).not.toBeNull();
    expect(user.name).toBe("Kavya");
  });

  test("should return 400 if user already exists", async () => {
    await seedUser({ email: "kavya@gmail.com", phone: "9876543210" });

    const req = mockReq({
      name:     "Kavya",
      email:    "kavya@gmail.com",
      phone:    "9876543210",
      password: "pass123",
    });
    const res = mockRes();

    await registerUser(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User already exists" })
    );
  });

  test("should return 500 on server error (missing required field)", async () => {
    const req = mockReq({
      name:  "Kavya",
      email: null, // will cause mongoose validation error
      phone: "9876543210",
      // password missing — bcrypt.hash(undefined) throws
    });
    const res = mockRes();

    await registerUser(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-2: Register Admin
// =============================================================
describe("TC-2: Register Admin", () => {

  test("should register admin with correct secret key", async () => {
    const req = mockReq({
      name:        "Admin User",
      email:       "admin@gmail.com",
      phone:       "9000000001",
      password:    "admin123",
      adminSecret: "admin123", // matches default ADMIN_SECRET
    });
    const res = mockRes();

    await registerAdmin(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Admin account created successfully" })
    );

    const admin = await User.findOne({ email: "admin@gmail.com" });
    expect(admin.role).toBe("admin");
  });

  test("should return 400 if required fields are missing", async () => {
    const req = mockReq({
      name:  "Admin",
      email: "admin@gmail.com",
      // phone, password, adminSecret missing
    });
    const res = mockRes();

    await registerAdmin(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "All fields including admin secret key are required",
      })
    );
  });

  test("should return 403 if admin secret is wrong", async () => {
    const req = mockReq({
      name:        "Admin",
      email:       "admin@gmail.com",
      phone:       "9000000002",
      password:    "admin123",
      adminSecret: "wrongsecret",
    });
    const res = mockRes();

    await registerAdmin(req, res);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "Invalid admin secret key. Contact your system administrator.",
      })
    );
  });

  test("should return 400 if email or phone already exists", async () => {
    await seedUser({ email: "admin@gmail.com", phone: "9000000003", role: "admin" });

    const req = mockReq({
      name:        "Admin Duplicate",
      email:       "admin@gmail.com",
      phone:       "9000000003",
      password:    "admin123",
      adminSecret: "admin123",
    });
    const res = mockRes();

    await registerAdmin(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "An account with this email or phone already exists",
      })
    );
  });

});

// =============================================================
// TC-3: Login User
// =============================================================
describe("TC-3: Login User", () => {

  test("should login successfully with email", async () => {
    await seedUser({ email: "login@gmail.com", phone: "9111111111" });

    const req = mockReq({ identifier: "login@gmail.com", password: "password123" });
    const res = mockRes();

    await loginUser(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Login successful", token: expect.any(String) })
    );
  });

  test("should login successfully with phone number", async () => {
    await seedUser({ email: "login2@gmail.com", phone: "9222222222" });

    const req = mockReq({ identifier: "9222222222", password: "password123" });
    const res = mockRes();

    await loginUser(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Login successful" })
    );
  });

  test("should return 401 if user not found", async () => {
    const req = mockReq({ identifier: "notexist@gmail.com", password: "pass123" });
    const res = mockRes();

    await loginUser(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User not found" })
    );
  });

  test("should return 401 if password is wrong", async () => {
    await seedUser({ email: "wrong@gmail.com", phone: "9333333333" });

    const req = mockReq({ identifier: "wrong@gmail.com", password: "wrongpassword" });
    const res = mockRes();

    await loginUser(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid password" })
    );
  });

});

// =============================================================
// TC-4: Get All Users
// =============================================================
describe("TC-4: Get All Users", () => {

  test("should return all users without password field", async () => {
    await seedUser({ email: "u1@gmail.com", phone: "9400000001" });
    await seedUser({ email: "u2@gmail.com", phone: "9400000002" });

    const req = mockReq();
    const res = mockRes();

    await getAllUsers(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(2);

    // Password should NOT be in response
    callArg.forEach(u => {
      expect(u.password).toBeUndefined();
    });
  });

  test("should return empty array if no users", async () => {
    const req = mockReq();
    const res = mockRes();

    await getAllUsers(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toEqual([]);
  });

});

// =============================================================
// TC-5: Delete User
// =============================================================
describe("TC-5: Delete User", () => {

  test("should delete a user by id", async () => {
    const user = await seedUser();

    const req = mockReq({}, { id: user._id.toString() });
    const res = mockRes();

    await deleteUser(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User deleted" })
    );

    // Verify deleted from DB
    const found = await User.findById(user._id);
    expect(found).toBeNull();
  });

});

// =============================================================
// TC-6: Make Admin
// =============================================================
describe("TC-6: Make Admin", () => {

  test("should promote user to admin role", async () => {
    const user = await seedUser();
    expect(user.role).toBe("user");

    const req = mockReq({}, { id: user._id.toString() });
    const res = mockRes();

    await makeAdmin(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User promoted to admin" })
    );

    // Verify in DB
    const updated = await User.findById(user._id);
    expect(updated.role).toBe("admin");
  });

});

// =============================================================
// TC-7: Block / Unblock User
// =============================================================
describe("TC-7: Block / Unblock User", () => {

  test("should block an unblocked user", async () => {
    const user = await seedUser({ isBlocked: false });

    const req = mockReq({}, { id: user._id.toString() });
    const res = mockRes();

    await blockUser(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User blocked" })
    );

    const updated = await User.findById(user._id);
    expect(updated.isBlocked).toBe(true);
  });

  test("should unblock a blocked user", async () => {
    const user = await seedUser({ isBlocked: true });

    const req = mockReq({}, { id: user._id.toString() });
    const res = mockRes();

    await blockUser(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User unblocked" })
    );

    const updated = await User.findById(user._id);
    expect(updated.isBlocked).toBe(false);
  });

  test("should return 500 if user not found", async () => {
    const req = mockReq({}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await blockUser(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-8: Update Profile
// =============================================================
describe("TC-8: Update Profile", () => {

  test("should update user profile fields", async () => {
    const user = await seedUser();

    const req = mockReq(
      { name: "Updated Name", city: "Chennai", bio: "Developer" },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await updateProfile(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Profile updated successfully" })
    );

    const updated = await User.findById(user._id);
    expect(updated.name).toBe("Updated Name");
    expect(updated.city).toBe("Chennai");
    expect(updated.bio).toBe("Developer");
  });

  test("should update profile picture if file is uploaded", async () => {
    const user = await seedUser();

    const req = mockReq(
      {},
      {},
      { id: user._id.toString() },
      { filename: "avatar.jpg" } // simulate multer file
    );
    const res = mockRes();

    await updateProfile(req, res);

    const updated = await User.findById(user._id);
    expect(updated.profilePic).toBe("/uploads/avatar.jpg");
  });

  test("should return 500 if user id is invalid", async () => {
    const req = mockReq(
      { name: "Test" },
      {},
      { id: new mongoose.Types.ObjectId().toString() } // valid ObjectId but no user
    );
    const res = mockRes();

    await updateProfile(req, res);

    // user.save() will throw because user is null
    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-9: Change Password
// =============================================================
describe("TC-9: Change Password", () => {

  test("should change password successfully", async () => {
    const user = await seedUser();

    const req = mockReq(
      { oldPassword: "password123", newPassword: "newpass456" },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await changePassword(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Password changed successfully" })
    );

    // Verify new password works
    const updated = await User.findById(user._id);
    const isMatch = await bcrypt.compare("newpass456", updated.password);
    expect(isMatch).toBe(true);
  });

  test("should return 400 if fields are missing", async () => {
    const user = await seedUser();

    const req = mockReq(
      { oldPassword: "", newPassword: "" },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await changePassword(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Both fields are required" })
    );
  });

  test("should return 400 if new password is less than 6 characters", async () => {
    const user = await seedUser();

    const req = mockReq(
      { oldPassword: "password123", newPassword: "abc" },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await changePassword(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "New password must be at least 6 characters",
      })
    );
  });

  test("should return 401 if old password is incorrect", async () => {
    const user = await seedUser();

    const req = mockReq(
      { oldPassword: "wrongpassword", newPassword: "newpass456" },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await changePassword(req, res);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Current password is incorrect" })
    );
  });

  test("should return 400 if new password is same as old password", async () => {
    const user = await seedUser();

    const req = mockReq(
      { oldPassword: "password123", newPassword: "password123" },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await changePassword(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "New password cannot be the same as your current password",
      })
    );
  });

  test("should return 404 if user not found", async () => {
    const req = mockReq(
      { oldPassword: "password123", newPassword: "newpass456" },
      {},
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await changePassword(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User not found" })
    );
  });

});


