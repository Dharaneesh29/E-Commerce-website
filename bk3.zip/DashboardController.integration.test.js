// ============================================================
//  DashboardController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/dashboardController.integration.test.js
//  Run: npx jest dashboardController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const User    = require("./Models/User");
const Product = require("./Models/Product");
const Order   = require("./Models/Order");

const { getDashboardStats } = require("./controllers/dashboardController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = () => ({});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await User.deleteMany({});
  await Product.deleteMany({});
  await Order.deleteMany({});
});

// ── SEED HELPERS ──────────────────────────────────────────────
const bcrypt = require("bcrypt");

const seedUser = async (overrides = {}) => {
  const hashedPassword = await bcrypt.hash("password123", 10);
  return await User.create({
    name:     "Test User",
    email:    `user_${Date.now()}_${Math.random()}@gmail.com`,
    phone:    `9${Math.floor(100000000 + Math.random() * 900000000)}`,
    password: hashedPassword,
    role:     "user",
    ...overrides,
  });
};

const seedProduct = async (overrides = {}) => {
  return await Product.create({
    name:         "Test Product",
    price:        500,
    description:  "A test product",
    images:       ["test.jpg"],
    category:     "Electronics",
    countInStock: 10,
    ...overrides,
  });
};

const seedOrder = async (userId, overrides = {}) => {
  return await Order.create({
    user: userId,
    orderItems: [{ name: "Test Product", qty: 1, price: 500 }],
    shippingAddress: {
      fullName: "Test User",
      phone:    "9876543210",
      address:  "Street 1",
      city:     "Chennai",
      state:    "Tamil Nadu",
      pincode:  "600001",
    },
    totalPrice:    500,
    paymentMethod: "COD",
    paymentStatus: "pending",
    status:        "pending",
    ...overrides,
  });
};

// =============================================================
// TC-1: Get Dashboard Stats — empty database
// =============================================================
describe("TC-1: Dashboard Stats with empty database", () => {

  test("should return all zeros when database is empty", async () => {
    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        totalUsers:    0,
        totalProducts: 0,
        orders:        0,
        revenue:       0,
        salesChart:    [],
        usersChart:    [],
      })
    );
  });

});

// =============================================================
// TC-2: Dashboard Stats — correct counts
// =============================================================
describe("TC-2: Dashboard Stats correct counts", () => {

  test("should return correct user, product and order counts", async () => {
    await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedUser({ email: "u2@gmail.com", phone: "9222222222" });
    await seedProduct({ name: "Product 1" });
    await seedProduct({ name: "Product 2" });
    await seedProduct({ name: "Product 3" });

    const user  = await seedUser({ email: "u3@gmail.com", phone: "9333333333" });
    await seedOrder(user._id);
    await seedOrder(user._id);

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.totalUsers).toBe(3);
    expect(callArg.totalProducts).toBe(3);
    expect(callArg.orders).toBe(2);
  });

});

// =============================================================
// TC-3: Dashboard Stats — revenue calculation
// =============================================================
describe("TC-3: Revenue Calculation", () => {

  test("should calculate revenue from paid orders only", async () => {
    const user = await seedUser({ email: "u1@gmail.com", phone: "9111111111" });

    // Paid orders — should be counted
    await seedOrder(user._id, { totalPrice: 1000, paymentStatus: "paid" });
    await seedOrder(user._id, { totalPrice: 500,  paymentStatus: "paid" });

    // Pending order — should NOT be counted
    await seedOrder(user._id, { totalPrice: 2000, paymentStatus: "pending" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.revenue).toBe(1500); // 1000 + 500 only
  });

  test("should return 0 revenue if no paid orders", async () => {
    const user = await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedOrder(user._id, { paymentStatus: "pending" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.revenue).toBe(0);
  });

  test("should sum all paid orders for total revenue", async () => {
    const user = await seedUser({ email: "u1@gmail.com", phone: "9111111111" });

    await seedOrder(user._id, { totalPrice: 200,  paymentStatus: "paid" });
    await seedOrder(user._id, { totalPrice: 300,  paymentStatus: "paid" });
    await seedOrder(user._id, { totalPrice: 500,  paymentStatus: "paid" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.revenue).toBe(1000);
  });

});

// =============================================================
// TC-4: Dashboard Stats — sales chart
// =============================================================
describe("TC-4: Sales Chart Data", () => {

  test("should return salesChart array with month data", async () => {
    const user = await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedOrder(user._id, { totalPrice: 1000, paymentStatus: "paid" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg.salesChart)).toBe(true);
    expect(callArg.salesChart.length).toBeGreaterThan(0);

    // Each entry should have name, sales, orders
    callArg.salesChart.forEach(entry => {
      expect(entry).toHaveProperty("name");
      expect(entry).toHaveProperty("sales");
      expect(entry).toHaveProperty("orders");
    });
  });

  test("should return correct month name in salesChart", async () => {
    const user = await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedOrder(user._id, { totalPrice: 500 });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    const validMonths = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    callArg.salesChart.forEach(entry => {
      expect(validMonths).toContain(entry.name);
    });
  });

  test("should count orders correctly in salesChart", async () => {
    const user = await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedOrder(user._id, { totalPrice: 500 });
    await seedOrder(user._id, { totalPrice: 300 });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    // Total orders across all months should be 2
    const totalOrders = callArg.salesChart.reduce((sum, e) => sum + e.orders, 0);
    expect(totalOrders).toBe(2);
  });

});

// =============================================================
// TC-5: Dashboard Stats — users chart
// =============================================================
describe("TC-5: Users Chart Data", () => {

  test("should return usersChart array with month data", async () => {
    await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedUser({ email: "u2@gmail.com", phone: "9222222222" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg.usersChart)).toBe(true);
    expect(callArg.usersChart.length).toBeGreaterThan(0);

    // Each entry should have name and users
    callArg.usersChart.forEach(entry => {
      expect(entry).toHaveProperty("name");
      expect(entry).toHaveProperty("users");
    });
  });

  test("should return correct month name in usersChart", async () => {
    await seedUser({ email: "u1@gmail.com", phone: "9111111111" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    const validMonths = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

    callArg.usersChart.forEach(entry => {
      expect(validMonths).toContain(entry.name);
    });
  });

  test("should count total users correctly across usersChart", async () => {
    await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedUser({ email: "u2@gmail.com", phone: "9222222222" });
    await seedUser({ email: "u3@gmail.com", phone: "9333333333" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    const totalUsers = callArg.usersChart.reduce((sum, e) => sum + e.users, 0);
    expect(totalUsers).toBe(3);
  });

});

// =============================================================
// TC-6: Dashboard Stats — combined data
// =============================================================
describe("TC-6: Combined Dashboard Data", () => {

  test("should return all required fields in response", async () => {
    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toHaveProperty("totalUsers");
    expect(callArg).toHaveProperty("totalProducts");
    expect(callArg).toHaveProperty("orders");
    expect(callArg).toHaveProperty("revenue");
    expect(callArg).toHaveProperty("salesChart");
    expect(callArg).toHaveProperty("usersChart");
  });

  test("should return accurate combined stats", async () => {
    const user = await seedUser({ email: "u1@gmail.com", phone: "9111111111" });
    await seedProduct({ name: "Product 1" });
    await seedProduct({ name: "Product 2" });
    await seedOrder(user._id, { totalPrice: 800, paymentStatus: "paid" });
    await seedOrder(user._id, { totalPrice: 200, paymentStatus: "paid" });

    const req = mockReq();
    const res = mockRes();

    await getDashboardStats(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.totalUsers).toBe(1);
    expect(callArg.totalProducts).toBe(2);
    expect(callArg.orders).toBe(2);
    expect(callArg.revenue).toBe(1000);
  });

});
