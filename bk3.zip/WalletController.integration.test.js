// ============================================================
//  WalletController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/walletController.integration.test.js
//  Run: npx jest walletController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const User  = require("./Models/User");
const Order = require("./Models/Order");

const {
  getWallet,
  addMoneyToWallet,
  deductWalletMoney,
  refundToWallet,
} = require("./controllers/walletController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}, user = {}) => ({
  body,
  params,
  user,
});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri   = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await User.deleteMany({});
  await Order.deleteMany({});
});

// ── SEED HELPERS ──────────────────────────────────────────────
const bcrypt = require("bcrypt");

const seedUser = async (overrides = {}) => {
  const hashedPassword = await bcrypt.hash("password123", 10);
  return await User.create({
    name:     "Test User",
    email:    "test@gmail.com",
    phone:    "9876543210",
    password: hashedPassword,
    role:     "user",
    wallet: {
      balance: 0,
      transactions: [],
    },
    ...overrides,
  });
};

const seedOrder = async (userId, overrides = {}) => {
  return await Order.create({
    user: userId,
    orderItems: [{ name: "Test Product", qty: 1, price: 500 }],
    shippingAddress: {
      fullName: "Test User",
      phone:    "9876543210",
      address:  "Street 1",
      city:     "Chennai",
      state:    "Tamil Nadu",
      pincode:  "600001",
    },
    totalPrice:    500,
    paymentMethod: "WALLET",
    status:        "delivered",
    ...overrides,
  });
};

// =============================================================
// TC-1: Get Wallet
// =============================================================
describe("TC-1: Get Wallet", () => {

  test("should return wallet balance and transactions for valid user", async () => {
    const user = await seedUser({
      wallet: { balance: 1000, transactions: [] },
    });

    const req = mockReq({}, {}, { id: user._id.toString() });
    const res = mockRes();

    await getWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        balance:      1000,
        transactions: expect.any(Array),
      })
    );
  });

  test("should return 404 if user not found", async () => {
    const req = mockReq({}, {}, { id: new mongoose.Types.ObjectId().toString() });
    const res = mockRes();

    await getWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User not found" })
    );
  });

  test("should return 500 on server error (invalid id format)", async () => {
    const req = mockReq({}, {}, { id: "invalid-id" });
    const res = mockRes();

    await getWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-2: Add Money to Wallet
// =============================================================
describe("TC-2: Add Money to Wallet", () => {

  test("should add money to wallet successfully", async () => {
    const user = await seedUser({ wallet: { balance: 500, transactions: [] } });

    const req = mockReq({ amount: 200 }, {}, { id: user._id.toString() });
    const res = mockRes();

    await addMoneyToWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(200);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({
        message: "Money added successfully",
        balance: 700,
      })
    );

    // Verify in DB
    const updated = await User.findById(user._id);
    expect(updated.wallet.balance).toBe(700);
    expect(updated.wallet.transactions[0].type).toBe("ADD_MONEY");
    expect(updated.wallet.transactions[0].description).toBe("Money added to wallet");
  });

  test("should return 400 if amount is 0", async () => {
    const user = await seedUser();

    const req = mockReq({ amount: 0 }, {}, { id: user._id.toString() });
    const res = mockRes();

    await addMoneyToWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid amount" })
    );
  });

  test("should return 400 if amount is negative", async () => {
    const user = await seedUser();

    const req = mockReq({ amount: -100 }, {}, { id: user._id.toString() });
    const res = mockRes();

    await addMoneyToWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid amount" })
    );
  });

  test("should return 400 if amount is missing", async () => {
    const user = await seedUser();

    const req = mockReq({}, {}, { id: user._id.toString() });
    const res = mockRes();

    await addMoneyToWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Invalid amount" })
    );
  });

  test("should return 404 if user not found", async () => {
    const req = mockReq(
      { amount: 100 },
      {},
      { id: new mongoose.Types.ObjectId().toString() }
    );
    const res = mockRes();

    await addMoneyToWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "User not found" })
    );
  });

  test("should return 500 on server error (invalid id format)", async () => {
    const req = mockReq({ amount: 100 }, {}, { id: "invalid-id" });
    const res = mockRes();

    await addMoneyToWallet(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-3: Deduct Wallet Money
// =============================================================
describe("TC-3: Deduct Wallet Money", () => {

  test("should deduct money from wallet successfully", async () => {
    const user  = await seedUser({ wallet: { balance: 1000, transactions: [] } });
    const order = await seedOrder(user._id);

    await deductWalletMoney(user._id.toString(), 300, order._id.toString());

    // Verify in DB
    const updated = await User.findById(user._id);
    expect(updated.wallet.balance).toBe(700);
    expect(updated.wallet.transactions[0].type).toBe("PURCHASE");
    expect(updated.wallet.transactions[0].amount).toBe(300);
    expect(updated.wallet.transactions[0].description).toContain(order._id.toString());
  });

  test("should throw error if user not found", async () => {
    const fakeId = new mongoose.Types.ObjectId().toString();

    await expect(
      deductWalletMoney(fakeId, 100, "orderId123")
    ).rejects.toThrow("User not found");
  });

  test("should throw error if wallet balance is insufficient", async () => {
    const user  = await seedUser({ wallet: { balance: 50, transactions: [] } });
    const order = await seedOrder(user._id);

    await expect(
      deductWalletMoney(user._id.toString(), 200, order._id.toString())
    ).rejects.toThrow("Insufficient wallet balance");

    // Verify balance unchanged in DB
    const updated = await User.findById(user._id);
    expect(updated.wallet.balance).toBe(50);
  });

  test("should deduct exact balance amount (boundary check)", async () => {
    const user  = await seedUser({ wallet: { balance: 500, transactions: [] } });
    const order = await seedOrder(user._id);

    await deductWalletMoney(user._id.toString(), 500, order._id.toString());

    const updated = await User.findById(user._id);
    expect(updated.wallet.balance).toBe(0);
  });

});


// =============================================================
// TC-4: Refund to Wallet
// =============================================================
describe("TC-4: Refund to Wallet", () => {

  test("should refund order amount to user wallet", async () => {
    const user  = await seedUser({ wallet: { balance: 200, transactions: [] } });
    const order = await seedOrder(user._id, {
      totalPrice:    500,
      paymentStatus: "paid",
    });

    await refundToWallet(order);

    // Verify wallet balance updated
    const updated = await User.findById(user._id);
    expect(updated.wallet.balance).toBe(700); // 200 + 500

    // Verify transaction recorded
    expect(updated.wallet.transactions[0].type).toBe("REFUND");
    expect(updated.wallet.transactions[0].amount).toBe(500);

    // Verify order updated
    expect(order.refundStatus).toBe("refunded");
    expect(order.paymentStatus).toBe("refunded");
    expect(order.refundAmount).toBe(500);
    expect(order.refundedAt).toBeDefined();
  });

  test("should throw error if user not found", async () => {
    const fakeUserId = new mongoose.Types.ObjectId();

    const order = {
      user:         fakeUserId,
      totalPrice:   500,
      refundStatus: undefined,   // ← not "refunded" so passes the check
      _id:          new mongoose.Types.ObjectId(),
      save:         jest.fn(),
    };

    await expect(refundToWallet(order)).rejects.toThrow("User not found");
  });

  test("should throw error if order already refunded", async () => {
    const user  = await seedUser({ wallet: { balance: 200, transactions: [] } });
    const order = await seedOrder(user._id, {
      totalPrice:   500,
      refundStatus: "refunded", // already refunded
    });

    await expect(refundToWallet(order)).rejects.toThrow("Already refunded");

    // Verify wallet balance NOT changed
    const updated = await User.findById(user._id);
    expect(updated.wallet.balance).toBe(200);
  });

  test("should add REFUND transaction with correct description", async () => {
    const user  = await seedUser({ wallet: { balance: 0, transactions: [] } });
    const order = await seedOrder(user._id, {
      totalPrice: 300,
      // no refundStatus — defaults to undefined, passes the check
    });

    await refundToWallet(order);

    const updated = await User.findById(user._id);
    expect(updated.wallet.transactions[0].description).toContain(
      order._id.toString()
    );
  });

});

