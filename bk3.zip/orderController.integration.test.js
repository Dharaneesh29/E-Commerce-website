// ============================================================
//  E-Commerce Integration Tests — Using MongoDB Memory Server
//  Real mongoose models, no mocks!
//  File: backend/orderController.integration.test.js
//  Run: npx jest orderController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const Order   = require("./Models/Order");
const Product = require("./Models/Product");
const Address = require("./Models/Address");
const User    = require("./Models/User");

// ── MOCK notify only (not a DB operation) ────────────────────
jest.mock("./controllers/notificationController", () => ({
  notify: jest.fn(),
}));

const {
  createOrder,
  cancelOrder,
  returnOrder,
} = require("./controllers/orderController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}, user = {}) => ({
  body,
  params,
  user,
});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri   = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

// Clean collections after each test
afterEach(async () => {
  await Order.deleteMany({});
  await Product.deleteMany({});
  await Address.deleteMany({});
  await User.deleteMany({});
});

// ── SEED HELPERS ──────────────────────────────────────────────

// Create a real user in memory DB
const seedUser = async () => {
  return await User.create({
    name: "Test User",
    email: "test@gmail.com",
    password: "hashedpassword123",
    phone: "9876543210",
    role: "user",
  });
};

// Create a real product in memory DB (using your real product structure)
const seedProduct = async (overrides = {}) => {
  return await Product.create({
    name: "Eyeshadow Palette with Mirror",
    brand: "Glamour Beauty",
    category: "Beauty",
    price: 1659,
    originalPrice: 1824.9,
    description: "A versatile eyeshadow palette with mirror.",
    images: ["https://cdn.dummyjson.com/product-images/beauty/eyeshadow-palette-with-mirror/1.webp"],
    countInStock: 31, // ← your real stock value
    ...overrides,
  });
};

// Create a real address in memory DB (using your real address data)
const seedAddress = async (userId) => {
  return await Address.create({
    user: userId,
    name: "Afzar",
    phone: "9876543210",
    pincode: "600001",
    address: "Street 1",
    city: "Chennai",
    state: "Tamil Nadu",
    landmark: "Near Bus Stop",
  });
};

// ─────────────────────────────────────────────────────────────
// TC-1: Race Condition in Stock Update
// ─────────────────────────────────────────────────────────────
describe("TC-1: Race Condition in Stock Update", () => {

  test("should NOT allow stock to go below 0 when two orders placed simultaneously", async () => {
    const user    = await seedUser();
    const product = await seedProduct({ countInStock: 1 }); // only 1 left
    const address = await seedAddress(user._id);

    const orderData = {
      orderItems: [{ product: product._id, qty: 1, name: product.name, price: product.price }],
      addressId: address._id,
      totalPrice: product.price,
      paymentMethod: "COD",
    };

    const req1 = mockReq(orderData, {}, { id: user._id.toString(), role: "user" });
    const req2 = mockReq(orderData, {}, { id: user._id.toString(), role: "user" });

    const res1 = mockRes();
    const res2 = mockRes();

    // // Place both orders
    // await createOrder(req1, res1);
    // await createOrder(req2, res2);

    // Place both orders CONCURRENTLY (race condition simulation)
await Promise.all([
  createOrder(req1, res1),
  createOrder(req2, res2),
]);
    // ✅ First order should succeed
    expect(res1.status).not.toHaveBeenCalledWith(400);

    // ✅ Second order must fail — stock is now 0
    expect(res2.status).toHaveBeenCalledWith(400);
    expect(res2.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: expect.stringContaining("out of stock") })
    );

    // ✅ Verify stock in DB is not negative
    const updatedProduct = await Product.findById(product._id);
    expect(updatedProduct.countInStock).toBeGreaterThanOrEqual(0);
  });

});

// ─────────────────────────────────────────────────────────────
// TC-2: Overselling During Flash Sale
// ─────────────────────────────────────────────────────────────
describe("TC-2: Overselling During Flash Sale", () => {

  test("should reject order when requested qty exceeds available stock", async () => {
    const user    = await seedUser();
    const product = await seedProduct({ countInStock: 2 }); // only 2 left
    const address = await seedAddress(user._id);

    const req = mockReq({
      orderItems: [{ product: product._id, qty: 5, name: product.name, price: product.price }],
      addressId: address._id,
      totalPrice: product.price * 5,
      paymentMethod: "COD",
    }, {}, { id: user._id.toString(), role: "user" });

    const res = mockRes();
    await createOrder(req, res);

    // ✅ Must block overselling
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: expect.stringContaining("out of stock") })
    );

    // ✅ Stock must remain unchanged in DB
    const updatedProduct = await Product.findById(product._id);
    expect(updatedProduct.countInStock).toBe(2);
  });

  test("should reject if stock is exactly 0", async () => {
    const user    = await seedUser();
    const product = await seedProduct({ countInStock: 0 }); // sold out
    const address = await seedAddress(user._id);

    const req = mockReq({
      orderItems: [{ product: product._id, qty: 1, name: product.name, price: product.price }],
      addressId: address._id,
      totalPrice: product.price,
      paymentMethod: "COD",
    }, {}, { id: user._id.toString(), role: "user" });

    const res = mockRes();
    await createOrder(req, res);

    expect(res.status).toHaveBeenCalledWith(400);
  });

});

// ─────────────────────────────────────────────────────────────
// TC-3: Order Service Crash / Data Loss
// ─────────────────────────────────────────────────────────────
describe("TC-3: Order Service Crash / Data Loss", () => {

  test("should return 404 if address not found", async () => {
    const user = await seedUser();
    const product = await seedProduct();

    const req = mockReq({
      orderItems: [{ product: product._id, qty: 1, name: product.name, price: product.price }],
      addressId: new mongoose.Types.ObjectId(), // non-existent address
      totalPrice: product.price,
      paymentMethod: "COD",
    }, {}, { id: user._id.toString(), role: "user" });

    const res = mockRes();
    await createOrder(req, res);

    // ✅ Must return 404 for missing address
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Address not found" })
    );
  });

  test("should return 404 if product not found", async () => {
    const user    = await seedUser();
    const address = await seedAddress(user._id);

    const req = mockReq({
      orderItems: [{ product: new mongoose.Types.ObjectId(), qty: 1, name: "Ghost Product", price: 500 }],
      addressId: address._id,
      totalPrice: 500,
      paymentMethod: "COD",
    }, {}, { id: user._id.toString(), role: "user" });

    const res = mockRes();
    await createOrder(req, res);

    // ✅ Must return 404 for missing product
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Product not found" })
    );
  });

});

// ─────────────────────────────────────────────────────────────
// TC-4: Microservices Inconsistency
// Stock reduces but if order fails, stock should ideally rollback
// ─────────────────────────────────────────────────────────────
describe("TC-4: Microservices Inconsistency (Eventual Consistency)", () => {

  test("should successfully create order and reduce stock atomically", async () => {
    const user    = await seedUser();
    const product = await seedProduct({ countInStock: 10 });
    const address = await seedAddress(user._id);

    const req = mockReq({
      orderItems: [{ product: product._id, qty: 3, name: product.name, price: product.price }],
      addressId: address._id,
      totalPrice: product.price * 3,
      paymentMethod: "COD",
    }, {}, { id: user._id.toString(), role: "user" });

    const res = mockRes();
    await createOrder(req, res);

    // ✅ Order created successfully
    expect(res.status).toHaveBeenCalledWith(201);

    // ✅ Stock reduced by 3 in real DB
    const updatedProduct = await Product.findById(product._id);
    expect(updatedProduct.countInStock).toBe(7); // 10 - 3 = 7

    // ✅ Order exists in real DB
    const orders = await Order.find({ user: user._id });
    expect(orders.length).toBe(1);
    expect(orders[0].totalPrice).toBe(product.price * 3);
  });

});

// ─────────────────────────────────────────────────────────────
// TC-5: Stock Mismatch due to Async Updates
// ─────────────────────────────────────────────────────────────
describe("TC-5: Stock Mismatch due to Async Updates", () => {

  test("should block checkout if stock becomes 0 after cart add", async () => {
    const user    = await seedUser();
    const product = await seedProduct({ countInStock: 1 }); // only 1 left
    const address = await seedAddress(user._id);

    // User A buys it first
    const reqA = mockReq({
      orderItems: [{ product: product._id, qty: 1, name: product.name, price: product.price }],
      addressId: address._id,
      totalPrice: product.price,
      paymentMethod: "COD",
    }, {}, { id: user._id.toString(), role: "user" });

    const resA = mockRes();
    await createOrder(reqA, resA);

    // ✅ User A order success
    expect(resA.status).toHaveBeenCalledWith(201);

    // User B tries to checkout same product (stock now 0)
    const userB   = await User.create({
      name: "User B", email: "userb@gmail.com",
      password: "pass123", phone: "9999999999", role: "user",
    });

    const reqB = mockReq({
      orderItems: [{ product: product._id, qty: 1, name: product.name, price: product.price }],
      addressId: address._id,
      totalPrice: product.price,
      paymentMethod: "COD",
    }, {}, { id: userB._id.toString(), role: "user" });

    const resB = mockRes();
    await createOrder(reqB, resB);

    // ✅ User B must be blocked — stock mismatch caught at checkout
    expect(resB.status).toHaveBeenCalledWith(400);
    expect(resB.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: expect.stringContaining("out of stock") })
    );
  });

});

// ─────────────────────────────────────────────────────────────
// TC-6: Multiple Return Requests (Same Item)
// ─────────────────────────────────────────────────────────────
describe("TC-6: Multiple Return Requests (Same Item)", () => {

  test("should allow return request on delivered order", async () => {
    const user = await seedUser();

    // Create a delivered order directly in DB
    const order = await Order.create({
      user: user._id,
      orderItems: [{ name: "Test Product", qty: 1, price: 500 }],
      shippingAddress: {
        fullName: "Afzar", phone: "9876543210",
        address: "Street 1", city: "Chennai",
        state: "Tamil Nadu", pincode: "600001",
      },
      totalPrice: 500,
      paymentMethod: "COD",
      status: "delivered", // ← already delivered
    });

    const req = mockReq(
      { reason: "Item damaged", items: [] },
      { id: order._id.toString() },
      { id: user._id.toString(), role: "user" }
    );

    const res = mockRes();
    await returnOrder(req, res);

    // ✅ Return request accepted
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Return requested successfully" })
    );

    // ✅ Verify returnInfo saved in real DB
    const updatedOrder = await Order.findById(order._id);
    expect(updatedOrder.returnInfo.status).toBe("requested");
    expect(updatedOrder.returnInfo.reason).toBe("Item damaged");
  });

  test("should NOT allow return if order is not delivered", async () => {
    const user = await seedUser();

    const order = await Order.create({
      user: user._id,
      orderItems: [{ name: "Test Product", qty: 1, price: 500 }],
      shippingAddress: {
        fullName: "Afzar", phone: "9876543210",
        address: "Street 1", city: "Chennai",
        state: "Tamil Nadu", pincode: "600001",
      },
      totalPrice: 500,
      paymentMethod: "COD",
      status: "shipped", // ← not delivered yet
    });

    const req = mockReq(
      { reason: "Changed mind" },
      { id: order._id.toString() },
      { id: user._id.toString(), role: "user" }
    );

    const res = mockRes();
    await returnOrder(req, res);

    // ✅ Must block — not delivered
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Can only return delivered orders" })
    );
  });

  test("should prevent duplicate return request", async () => {
    const user = await seedUser();

    // Order already has a return request
    const order = await Order.create({
      user: user._id,
      orderItems: [{ name: "Test Product", qty: 1, price: 500 }],
      shippingAddress: {
        fullName: "Afzar", phone: "9876543210",
        address: "Street 1", city: "Chennai",
        state: "Tamil Nadu", pincode: "600001",
      },
      totalPrice: 500,
      paymentMethod: "COD",
      status: "delivered",
      returnInfo: {
        reason: "First request",
        status: "requested", // ← already requested
        returnedAt: new Date(),
      },
    });

    const req = mockReq(
      { reason: "Second return attempt" },
      { id: order._id.toString() },
      { id: user._id.toString(), role: "user" }
    );

    const res = mockRes();
    await returnOrder(req, res);

    // ✅ Must block duplicate return
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Return already requested" })
    );
  });

});
