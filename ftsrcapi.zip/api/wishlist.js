import axios from "axios";
 
const API = axios.create({
  baseURL: "http://localhost:5000/api",
});
 
// 🔥 attach token automatically
API.interceptors.request.use((req) => {
  
 const userInfo = JSON.parse(
  sessionStorage.getItem("userInfo")
);
 
const token = userInfo?.token;
 
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
 
  return req;
});
 
// ✅ GET wishlist
export const getWishlistAPI = () => API.get("/wishlist");
 
// ✅ ADD product
export const addToWishlistAPI = (productId) =>
  API.post(`/wishlist/add/${productId}`);
 
// ✅ REMOVE product
export const removeFromWishlistAPI = (productId) =>
  API.delete(`/wishlist/remove/${productId}`);
 