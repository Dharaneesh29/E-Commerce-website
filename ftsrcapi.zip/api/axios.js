// import axios from "axios";

// const API = axios.create({
//   baseURL: "http://localhost:5000/api",
// });



// export default API;

import axios from "axios";
 
const API = axios.create({
  baseURL: "http://localhost:5000/api",
});
 
API.interceptors.request.use((req) => {
  const userInfo = JSON.parse(sessionStorage.getItem("userInfo")|| "null");
const token = userInfo?.token;
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});
 
export default API;