const express = require("express");
const router = express.Router();
const {
  addAddress,
  getAddresses,
  deleteAddress,
} = require("../controllers/addressController");
 
const authMiddleware = require("../middleware/authMiddleware");
 
// 🔐 all routes protected
router.post("/", authMiddleware, addAddress);
router.get("/", authMiddleware, getAddresses);
router.delete("/:id", authMiddleware, deleteAddress);

 
module.exports = router;