const express = require("express");
const router = express.Router();
const User = require("../Models/User"); // ✅ ADD THIS
const MembershipPlan = require("../Models/MembershipPlan");


console.log("UserRoutes Loaded successfully");

const {
  registerAdmin,
  registerUser,
  loginUser,
  getAllUsers,
  makeAdmin,
  deleteUser,
  blockUser,
  updateProfile,
  changePassword
} = require("../controllers/UserController");

const authMiddleware = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");
const upload = require("../middleware/upload");

const { sendOtp, verifyOtp } = require("../controllers/emailotpController");
const { sendPhoneOtp, verifyPhoneOtp } = require("../controllers/phoneotpController");

// ── Auth ──────────────────────────────────────────────────────
router.post("/register", registerUser);
router.post("/login", loginUser);
router.post("/admin/register", registerAdmin);

// ── Profile ───────────────────────────────────────────────────
// ✅ Single PUT route with upload middleware
router.put("/profile", authMiddleware, upload.single("profilePic"), updateProfile);

// ✅ Fixed GET route
router.get("/profile", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
  .select("-password")
  .populate("membership.planId", "name price discount benefits duration");
    res.json(user);
  } catch (error) { // ✅ fixed
    res.status(500).json({ message: error.message });
  }
});

// ── Password ──────────────────────────────────────────────────
router.put("/change-password", authMiddleware, changePassword);

// ── Admin ─────────────────────────────────────────────────────
router.get("/all", authMiddleware, adminMiddleware, getAllUsers);
router.delete("/:id", authMiddleware, adminMiddleware, deleteUser);
router.put("/make-admin/:id", authMiddleware, adminMiddleware, makeAdmin);
router.put("/block/:id", authMiddleware, adminMiddleware, blockUser);

// ── OTP ───────────────────────────────────────────────────────
router.post("/send-otp", sendOtp);
router.post("/verify-otp", verifyOtp);
router.post("/send-phone-otp", sendPhoneOtp);
router.post("/verify-phone-otp", verifyPhoneOtp);

// GET current user's membership
router.get("/my-membership", authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user._id || req.user.id)
      .populate("membership.planId"); // ✅ remove field filter — populate ALL fields

    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user.membership || null);
  } catch (err) {
    console.log("membership error:", err);
    res.status(500).json({ message: "Failed to fetch membership" });
  }
});

// GET all active plans (public)
router.get("/membership/plans-public", async (req, res) => {
  try {
    const MembershipPlan = require("../Models/MembershipPlan");
    const plans = await MembershipPlan.find({ isActive: true }).sort({ price: 1 });
    res.json(plans);
  } catch (err) {
    console.log("plans error", err);
    res.status(500).json({ message: "Failed to fetch plans" });
  }
});


// POST subscribe to a plan
router.post("/membership/subscribe", authMiddleware, async (req, res) => {
  try {
    const { planId } = req.body;
    const MembershipPlan = require("../Models/MembershipPlan");

    const plan = await MembershipPlan.findById(planId);
    if (!plan) return res.status(404).json({ message: "Plan not found" });

    const startDate = new Date();
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + plan.duration);

    const user = await User.findByIdAndUpdate(
      req.user._id || req.user.id,
      {
        membership: {
          planId: plan._id,
          startDate,
          expiryDate,
          isActive: true,
        },
      },
      { new: true }
    ).populate("membership.planId", "name price discount duration benefits");

    res.json({ message: "Subscribed successfully", membership: user.membership });
  } catch (err) {
    res.status(500).json({ message: "Failed to subscribe" });
  }
});


module.exports = router;