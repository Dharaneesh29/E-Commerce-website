const express = require("express");
 
const router = express.Router();
 
const {
  getUserNotifications,
  markAllRead,
} = require("../controllers/userNotificationController");
 
const protect  = require("../middleware/authMiddleware");
 
router.get("/", protect, getUserNotifications);
 
router.put("/read-all", protect, markAllRead);
 
module.exports = router;
 