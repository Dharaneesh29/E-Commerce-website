// const express = require("express");
// const router = express.Router();

// const {
//   createOrder,
//   getMyOrders,
//   getAllOrders,
//   updateOrderStatus,
//   cancelOrder,
//   handleReturn,
//   processRefund,
//   returnOrder,
//   getMyOrderById
// } = require("../controllers/orderController");

// const authMiddleware = require("../middleware/authMiddleware");
// const adminMiddleware = require("../middleware/adminMiddleware");

// // ✅ Specific routes BEFORE /:id routes
// router.get("/all", authMiddleware, adminMiddleware, getAllOrders);
// router.get("/my", authMiddleware, getMyOrders);
// router.post("/", authMiddleware, createOrder);

// router.get("/:id", authMiddleware, getMyOrderById); // ✅ GET not POST

// router.put("/:id/status", authMiddleware, adminMiddleware, updateOrderStatus);
// router.put("/:id/cancel", authMiddleware, cancelOrder); // ✅ removed duplicate
// router.put("/:id/return", authMiddleware, adminMiddleware, handleReturn);
// router.put("/:id/refund", authMiddleware, adminMiddleware, processRefund);
// router.put(":id/return",  authMiddleware, returnOrder);

// module.exports = router;


const express = require("express");
const router = express.Router();

const {
  createOrder,
  getMyOrders,
  getAllOrders,
  updateOrderStatus,
  cancelOrder,
  handleReturn,
  processRefund,
  returnOrder,
  getMyOrderById,
} = require("../controllers/orderController");

const authMiddleware  = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

// ✅ Specific routes BEFORE /:id routes
router.get("/all", authMiddleware, adminMiddleware, getAllOrders);
router.get("/my",  authMiddleware, getMyOrders);
router.post("/",   authMiddleware, createOrder);

router.get("/:id",          authMiddleware, getMyOrderById);
router.put("/:id/status",   authMiddleware, adminMiddleware, updateOrderStatus);
router.put("/:id/cancel",   authMiddleware, cancelOrder);               // user or admin
router.put("/:id/return",   authMiddleware, returnOrder);               // ✅ user return request
router.put("/:id/handle-return", authMiddleware, adminMiddleware, handleReturn); // ✅ admin approve/reject
router.put("/:id/refund",   authMiddleware, adminMiddleware, processRefund);

module.exports = router;
