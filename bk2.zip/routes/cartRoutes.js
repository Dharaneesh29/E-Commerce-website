const express = require("express");
const protect = require("../middleware/authMiddleware.js");
const Cart = require("../Models/Cart");
 
const router = express.Router();
 
router.get("/", protect, async (req, res) => {
  let cart = await Cart.findOne({ user: req.user.id })
    .populate("items.product");
 
  if (!cart) {
    cart = await Cart.create({ user: req.user.id, items: [] });
  }
 
  res.json(cart);
});
 

router.post("/add", protect, async (req, res) => {
  const { productId } = req.body;
 
  let cart = await Cart.findOne({ user: req.user.id });
 
  if (!cart) {
    cart = await Cart.create({ user: req.user.id, items: [] });
  }
 
  const item = cart.items.find(
    (i) => i.product.toString() === productId
  );
 
  if (item) {
    item.qty += 1;
  } else {
    cart.items.push({ product: productId, qty: 1 });
  }
 
  await cart.save();
  res.json(cart);
});
 
router.put("/update", protect, async (req, res) => {
  const { productId, qty } = req.body;
 
  const cart = await Cart.findOne({ user: req.user.id });
 
  const item = cart.items.find(
    (i) => i.product.toString() === productId
  );
 
  if (item) {
    item.qty = qty;
  }
 
  await cart.save();
  res.json(cart);
});
 

router.delete("/remove/:id", protect, async (req, res) => {
  const cart = await Cart.findOne({ user: req.user.id });
 
  cart.items = cart.items.filter(
    (i) => i.product.toString() !== req.params.id
  );
 
  await cart.save();
  res.json(cart);
});

// DELETE /api/cart/clear
router.delete("/clear", protect , async (req, res) => {
  try {
    await Cart.findOneAndUpdate(
      { user: req.user._id || req.user.id },
      { items: [] }
    );
    res.json({ message: "Cart cleared" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

 
module.exports = router;
 