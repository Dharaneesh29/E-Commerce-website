// const express = require("express");
// const router = express.Router();
 
// const User = require("../Models/User");
// const Product = require("../Models/Product");
 
// router.get("/", async (req, res) => {
//   try {
//     const totalUsers = await User.countDocuments();
//     const totalProducts = await Product.countDocuments();
 
    
//     const products = await Product.find();
//     const revenue = products.reduce((acc, p) => acc + (p.price || 0), 0);
 
//     res.json({
//       totalUsers,
//       totalProducts,
//       revenue,
//       orders: 80, 
//     });
 
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// });
 
// module.exports = router;

const express = require("express");
const router = express.Router();
const { getDashboardStats } = require("../controllers/dashboardController");
const authMiddleware = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

router.get("/", authMiddleware, adminMiddleware, getDashboardStats);

module.exports = router;
