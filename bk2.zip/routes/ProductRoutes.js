const express=require("express")
const { createProduct, getProducts, deleteProduct, getProductById, updateProduct, getLatestProducts ,addReview, getSimilarProducts,getProductsByGroup,getProductsByBrand}=require("../controllers/ProductController");
const authMiddleware=require("../middleware/authMiddleware");
const adminMiddleware=require("../middleware/adminMiddleware");
const upload= require("../middleware/upload")
const Product=require("../Models/Product")

const router = express.Router();
router.get("/latest",getLatestProducts)
router.get("/", getProducts);
router.get("/:id", getProductById);
router.put("/:id", authMiddleware, adminMiddleware, updateProduct);
router.post(
    "/",
    authMiddleware,
    adminMiddleware,
    upload.single("image"),
    createProduct
)

router.delete("/:id", authMiddleware, adminMiddleware, deleteProduct);
router.get("/category/:name",async(req,res)=>{
    const products=await Product.find({
        category:new RegExp(`^${req.params.name}$`,"i")
    });

    res.json(products)
})

router.get("/latest",getLatestProducts)

router.post(
  "/:id/review",
  authMiddleware,
  upload.single("image"), // 👈 IMPORTANT
  addReview
);

router.get("/:id/similar",getSimilarProducts)

router.get("/category-count", async (req, res) => {
  try {
    const data = await Product.aggregate([
      {
        $group: {
          _id: "$category",
          count: { $sum: 1 },
        },
      },
    ]);
 
    res.json(data);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
 
router.get("/group/:name",getProductsByGroup)
 
router.get("/brand/:brand", getProductsByBrand)
 

module.exports= router
