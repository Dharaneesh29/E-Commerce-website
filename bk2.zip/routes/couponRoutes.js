// const express=require("express")
// const { createCoupon,applyCoupon,getCoupons }=require("../controllers/couponController.js")
 
 
// const protect=require("../middleware/authMiddleware.js");
// const adminMiddleware=require("../middleware/adminMiddleware.js")
 
// const router = express.Router();
 
// // 🔒 Admin only
// router.post("/create", protect, adminMiddleware, createCoupon);
 
// // 👤 User can apply
// router.post("/apply", protect, applyCoupon);

// router.get("/",getCoupons)
// module.exports=router


const express = require("express");
const router  = express.Router();

const {
  createCoupon,
  getCoupons,
  updateCoupon,
  deleteCoupon,
  applyCoupon,
} = require("../controllers/couponController.js");

const protect         = require("../middleware/authMiddleware.js");
const adminMiddleware = require("../middleware/adminMiddleware.js");

// ── Admin routes ──────────────────────────────────────────────
router.post("/create",  protect, adminMiddleware, createCoupon);  // Create
router.get("/",         protect, getCoupons);     // Get all
router.put("/:id",      protect, adminMiddleware, updateCoupon);   // Update / toggle
router.delete("/:id",   protect, adminMiddleware, deleteCoupon);   // Delete

// ── User route ────────────────────────────────────────────────
router.post("/apply",   protect, applyCoupon);                     // Apply at checkout

module.exports = router;
 