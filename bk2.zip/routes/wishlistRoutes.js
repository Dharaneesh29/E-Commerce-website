const express=require("express");
const {
  addToWishlist,
  getWishlist,
  removeFromWishlist,
}=require("../controllers/wishlistController.js");
const  authMiddleware =require("../middleware/authMiddleware.js");

console.log({ addToWishlist, getWishlist, removeFromWishlist, authMiddleware });
 
 
const router = express.Router();
 
router.post("/add/:productId", authMiddleware, addToWishlist);
router.get("/", authMiddleware, getWishlist);
router.delete("/remove/:productId", authMiddleware, removeFromWishlist);
 
module.exports=router;
 