const express = require("express");
 
const router = express.Router();
 
const {
    getWallet,
    addMoneyToWallet
} = require("../controllers/walletController");
 
const protect  = require("../middleware/authMiddleware");
 
 
// GET WALLET
router.get("/", protect, getWallet);
 
 
// ADD MONEY
router.post("/add", protect, addMoneyToWallet);
 
 
module.exports = router;