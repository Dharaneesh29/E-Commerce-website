const express = require("express");
const router  = express.Router();

const {
  getNotifications,
  getUnreadCount,
  markAsRead,
  markAllAsRead,
  createNotification,
  deleteNotification,
} = require("../controllers/notificationController");

const protect         = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

// All notification routes are admin-only
router.get("/",              protect, adminMiddleware, getNotifications);
router.get("/unread-count",  protect, adminMiddleware, getUnreadCount);
router.post("/",             protect, adminMiddleware, createNotification);

router.put("/mark-all-read", protect, adminMiddleware, markAllAsRead);
router.put("/:id/read",      protect, adminMiddleware, markAsRead);
router.delete("/:id",        protect, adminMiddleware, deleteNotification);

module.exports = router;
