const express = require("express");
const router = express.Router();
const MembershipPlan = require("../Models/MembershipPlan");
const User = require("../Models/User");
const authMiddleware = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

// ─── PLANS CRUD ───────────────────────────────────────────

// GET all plans
router.get("/plans", authMiddleware, async (req, res) => {
  try {
    const plans = await MembershipPlan.find().sort({ price: 1 });
    res.json(plans);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch plans", error: err.message });
  }
});

// POST create new plan
router.post("/plans", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { name, price, duration, discount, benefits, isActive } = req.body;

    const existing = await MembershipPlan.findOne({ name });
    if (existing) {
      return res.status(400).json({ message: "Plan with this name already exists" });
    }

    const plan = new MembershipPlan({
      name,
      price,
      duration,
      discount,
      benefits: benefits || [],
      isActive: isActive !== undefined ? isActive : true,
    });

    await plan.save();
    res.status(201).json({ message: "Plan created successfully", plan });
  } catch (err) {
    res.status(500).json({ message: "Failed to create plan", error: err.message });
  }
});

// PUT update a plan
router.put("/plans/:id", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { name, price, duration, discount, benefits, isActive } = req.body;

    const plan = await MembershipPlan.findByIdAndUpdate(
      req.params.id,
      { name, price, duration, discount, benefits, isActive },
      { new: true, runValidators: true }
    );

    if (!plan) {
      return res.status(404).json({ message: "Plan not found" });
    }

    res.json({ message: "Plan updated successfully", plan });
  } catch (err) {
    res.status(500).json({ message: "Failed to update plan", error: err.message });
  }
});

// DELETE a plan
router.delete("/plans/:id", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const plan = await MembershipPlan.findByIdAndDelete(req.params.id);

    if (!plan) {
      return res.status(404).json({ message: "Plan not found" });
    }

    res.json({ message: "Plan deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete plan", error: err.message });
  }
});

// PATCH toggle isActive
router.patch("/plans/:id/toggle", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const plan = await MembershipPlan.findById(req.params.id);

    if (!plan) {
      return res.status(404).json({ message: "Plan not found" });
    }

    plan.isActive = !plan.isActive;
    await plan.save();

    res.json({ message: `Plan ${plan.isActive ? "activated" : "deactivated"}`, plan });
  } catch (err) {
    res.status(500).json({ message: "Failed to toggle plan status", error: err.message });
  }
});

// ─── MEMBERS LIST ─────────────────────────────────────────

// GET all users with membership
router.get("/members", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const members = await User.find({
      "membership.planId": { $exists: true, $ne: null },
    })
      .populate("membership.planId", "name price discount")
      .select("name email membership createdAt")
      .sort({ "membership.startDate": -1 });

    res.json(members);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch members", error: err.message });
  }
});

// PATCH assign plan to user
router.patch("/members/:userId/assign", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const { planId } = req.body;

    const plan = await MembershipPlan.findById(planId);
    if (!plan) {
      return res.status(404).json({ message: "Plan not found" });
    }

    const startDate = new Date();
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + plan.duration);

    const user = await User.findByIdAndUpdate(
      req.params.userId,
      {
        membership: {
          planId: plan._id,
          startDate,
          expiryDate,
          isActive: true,
        },
      },
      { new: true }
    ).populate("membership.planId", "name price discount");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: "Plan assigned successfully", user });
  } catch (err) {
    res.status(500).json({ message: "Failed to assign plan", error: err.message });
  }
});

// PATCH revoke membership
router.patch("/members/:userId/revoke", authMiddleware, adminMiddleware, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.userId,
      { "membership.isActive": false },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ message: "Membership revoked successfully", user });
  } catch (err) {
    res.status(500).json({ message: "Failed to revoke membership", error: err.message });
  }
});

module.exports = router;

