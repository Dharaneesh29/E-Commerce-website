// ============================================================
//  AddressController Integration Tests — MongoMemoryServer
//  Real mongoose models, no mocks!
//  File: backend/addressController.integration.test.js
//  Run: npx jest addressController.integration.test.js
// ============================================================

const mongoose = require("mongoose");
const { MongoMemoryServer } = require("mongodb-memory-server");

const Address = require("./Models/Address");
const User    = require("./Models/User");

const {
  addAddress,
  getAddresses,
  deleteAddress,
} = require("./controllers/addressController");

// ── HELPERS ───────────────────────────────────────────────────
let mongoServer;

const mockRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json   = jest.fn().mockReturnValue(res);
  return res;
};

const mockReq = (body = {}, params = {}, user = {}) => ({
  body,
  params,
  user,
});

// ── SETUP MEMORY SERVER ───────────────────────────────────────
beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  const uri   = mongoServer.getUri();
  await mongoose.connect(uri);
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await mongoServer.stop();
});

afterEach(async () => {
  await Address.deleteMany({});
  await User.deleteMany({});
});

// ── SEED HELPERS ──────────────────────────────────────────────
const bcrypt = require("bcrypt");

const seedUser = async (overrides = {}) => {
  const hashedPassword = await bcrypt.hash("password123", 10);
  return await User.create({
    name:     "Test User",
    email:    "test@gmail.com",
    phone:    "9876543210",
    password: hashedPassword,
    role:     "user",
    ...overrides,
  });
};

const seedAddress = async (userId, overrides = {}) => {
  return await Address.create({
    user:     userId,
    name:     "Test User",
    phone:    "9876543210",
    pincode:  "600001",
    address:  "123 Main Street",
    city:     "Chennai",
    state:    "Tamil Nadu",
    landmark: "Near Bus Stop",
    ...overrides,
  });
};

// =============================================================
// TC-1: Add Address
// =============================================================
describe("TC-1: Add Address", () => {

  test("should add a new address successfully", async () => {
    const user = await seedUser();

    const req = mockReq(
      {
        name:     "Kavya",
        phone:    "9876543210",
        pincode:  "600001",
        address:  "123 Anna Nagar",
        city:     "Chennai",
        state:    "Tamil Nadu",
        landmark: "Near Metro",
      },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await addAddress(req, res);

    expect(res.status).toHaveBeenCalledWith(201);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.name).toBe("Kavya");
    expect(callArg.city).toBe("Chennai");

    // Verify saved in DB
    const saved = await Address.findOne({ user: user._id });
    expect(saved).not.toBeNull();
    expect(saved.pincode).toBe("600001");
  });

  test("should save address with correct user id", async () => {
    const user = await seedUser();

    const req = mockReq(
      {
        name:    "Test",
        phone:   "9000000001",
        pincode: "500001",
        address: "Street 5",
        city:    "Hyderabad",
        state:   "Telangana",
      },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await addAddress(req, res);

    const saved = await Address.findOne({ user: user._id });
    expect(saved.user.toString()).toBe(user._id.toString());
  });

  test("should add address without optional landmark field", async () => {
    const user = await seedUser();

    const req = mockReq(
      {
        name:    "No Landmark",
        phone:   "9000000002",
        pincode: "400001",
        address: "MG Road",
        city:    "Mumbai",
        state:   "Maharashtra",
        // landmark not provided
      },
      {},
      { id: user._id.toString() }
    );
    const res = mockRes();

    await addAddress(req, res);

    expect(res.status).toHaveBeenCalledWith(201);
    const saved = await Address.findOne({ city: "Mumbai" });
    expect(saved).not.toBeNull();
  });

  test("should return 500 on server error (invalid user id)", async () => {
    const req = mockReq(
      {
        name:    "Error Test",
        phone:   "9000000003",
        pincode: "600001",
        address: "Error Street",
        city:    "Chennai",
        state:   "Tamil Nadu",
      },
      {},
      { id: "invalid-id" } // invalid ObjectId causes error
    );
    const res = mockRes();

    await addAddress(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-2: Get All Addresses
// =============================================================
describe("TC-2: Get Addresses", () => {

  test("should return all addresses for logged in user", async () => {
    const user = await seedUser();

    await seedAddress(user._id, { city: "Chennai" });
    await seedAddress(user._id, { city: "Bangalore", phone: "9000000004" });

    const req = mockReq({}, {}, { id: user._id.toString() });
    const res = mockRes();

    await getAddresses(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(Array.isArray(callArg)).toBe(true);
    expect(callArg.length).toBe(2);
    callArg.forEach(a => expect(a.user.toString()).toBe(user._id.toString()));
  });

  test("should return only addresses of logged in user (not others)", async () => {
    const user1 = await seedUser({ email: "user1@gmail.com", phone: "9111111111" });
    const user2 = await seedUser({ email: "user2@gmail.com", phone: "9222222222" });

    await seedAddress(user1._id, { city: "Chennai" });
    await seedAddress(user2._id, { city: "Mumbai", phone: "9000000005" });

    const req = mockReq({}, {}, { id: user1._id.toString() });
    const res = mockRes();

    await getAddresses(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg.length).toBe(1);
    expect(callArg[0].city).toBe("Chennai");
  });

  test("should return empty array if user has no addresses", async () => {
    const user = await seedUser();

    const req = mockReq({}, {}, { id: user._id.toString() });
    const res = mockRes();

    await getAddresses(req, res);

    const callArg = res.json.mock.calls[0][0];
    expect(callArg).toEqual([]);
  });

  test("should return 500 on server error (invalid user id)", async () => {
    const req = mockReq({}, {}, { id: "invalid-id" });
    const res = mockRes();

    await getAddresses(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});

// =============================================================
// TC-3: Delete Address
// =============================================================
describe("TC-3: Delete Address", () => {

  test("should delete address successfully", async () => {
    const user    = await seedUser();
    const address = await seedAddress(user._id);

    const req = mockReq({}, { id: address._id.toString() }, { id: user._id.toString() });
    const res = mockRes();

    await deleteAddress(req, res);

    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Address deleted" })
    );

    // Verify deleted from DB
    const found = await Address.findById(address._id);
    expect(found).toBeNull();
  });

  test("should return success even if address id does not exist", async () => {
    const req = mockReq(
      {},
      { id: new mongoose.Types.ObjectId().toString() },
      {}
    );
    const res = mockRes();

    await deleteAddress(req, res);

    // findByIdAndDelete does not throw if not found — still returns success
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message: "Address deleted" })
    );
  });

  test("should return 500 on server error (invalid id format)", async () => {
    const req = mockReq({}, { id: "invalid-id" }, {});
    const res = mockRes();

    await deleteAddress(req, res);

    expect(res.status).toHaveBeenCalledWith(500);
  });

});
