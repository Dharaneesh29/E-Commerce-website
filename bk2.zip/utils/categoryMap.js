// utils/categoryMap.js
 
const categoryMap = {
  electronics: {
    Mobile: ["Mobile", "Smartphones"],
    Laptops: ["Laptops"],
    Tablets: ["Tablets"],
    Accessories: ["Mobile-accessories"]
  },
 
  fashion: {
    "Men Wear": ["Mens-shirts", "Mens-shoes", "Mens-watches"],
    "Women Wear": [
      "Womens-dresses",
      "Womens-shoes",
      "Womens-bags",
      "Womens-jewellery",
      "Womens-watches"
    ],
    Others: ["Tops", "Sunglasses"]
  },
 
  "home-&-kitchen": {
    Furniture: ["Furniture"],
    Decor: ["Home-decoration"],
    Kitchen: ["Kitchen-accessories"]
  },
 
  appliances: {
    Grocery: ["Groceries", "Grocery"]
  },
 
  beauty: {
    Beauty: ["Beauty", "Skin-care", "Fragrances"]
  },
 
  sports: {
    Sports: ["Sports-accessories"]
  },
 
  books: {}
};
 
    module.exports={categoryMap}