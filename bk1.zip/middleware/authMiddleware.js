const jwt = require("jsonwebtoken");

const authMiddleware = (req, res, next) => {
  let token = req.headers.authorization;

  // check token exists
  if (!token) {
    return res.status(401).json({ message: "No token, access denied" });
  }

  try {
    // remove "Bearer " if present
    if (token.startsWith("Bearer ")) {
      token = token.split(" ")[1];
    }

    // verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "secret123");

    // store user data in request
    req.user = decoded;

    next(); // go to next (controller)
  } catch (error) {
    res.status(401).json({ message: "Invalid token" });
  }
};

module.exports = authMiddleware;