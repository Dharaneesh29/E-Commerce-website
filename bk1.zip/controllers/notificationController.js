const Notification = require("../Models/Notification");

// ── GET all notifications ────────────────────────────────────
const getNotifications = async (req, res) => {
  try {
    const notifications = await Notification.find()
      .sort({ createdAt: -1 })
      .limit(50); // latest 50
    res.json(notifications);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch notifications" });
  }
};

// ── GET unread count ─────────────────────────────────────────
const getUnreadCount = async (req, res) => {
  try {
    const count = await Notification.countDocuments({ isRead: false });
    res.json({ count });
  } catch (err) {
    res.status(500).json({ message: "Failed to get count" });
  }
};

// ── MARK single notification as read ────────────────────────
const markAsRead = async (req, res) => {
  try {
    const notification = await Notification.findByIdAndUpdate(
      req.params.id,
      { isRead: true },
      { new: true }
    );
    if (!notification) {
      return res.status(404).json({ message: "Notification not found" });
    }
    res.json({ success: true, notification });
  } catch (err) {
    res.status(500).json({ message: "Failed to mark as read" });
  }
};

// ── MARK ALL as read ─────────────────────────────────────────
const markAllAsRead = async (req, res) => {
  try {
    await Notification.updateMany({ isRead: false }, { isRead: true });
    res.json({ success: true, message: "All notifications marked as read" });
  } catch (err) {
    res.status(500).json({ message: "Failed to mark all as read" });
  }
};

// ── CREATE notification (used internally) ───────────────────
const createNotification = async (req, res) => {
  try {
    const { type, message, refId } = req.body;
    const notification = await Notification.create({ type, message, refId });
    res.status(201).json(notification);
  } catch (err) {
    res.status(500).json({ message: "Failed to create notification" });
  }
};

// ── DELETE a notification ────────────────────────────────────
const deleteNotification = async (req, res) => {
  try {
    await Notification.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Notification deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete notification" });
  }
};

// ── INTERNAL HELPER — call this from other controllers ───────
const notify = async (type, message, refId = null) => {
  try {
    await Notification.create({ type, message, refId });
  } catch (err) {
    console.error("Failed to create notification:", err.message);
  }
};

module.exports = {
  getNotifications,
  getUnreadCount,
  markAsRead,
  markAllAsRead,
  createNotification,
  deleteNotification,
  notify, // helper used in other controllers
};
