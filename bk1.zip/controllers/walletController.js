const User = require("../Models/User");
 
 
// =====================================================
// GET WALLET
// =====================================================
 
const getWallet = async (req, res) => {
 
    try {
 
        const user = await User.findById(req.user.id);
 
        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }
 
        res.status(200).json({
            balance: user.wallet.balance,
            transactions: user.wallet.transactions
        });
 
    } catch (error) {
 
        res.status(500).json({
            message: error.message
        });
 
    }
 
};
 
 
// =====================================================
// ADD MONEY
// =====================================================
 
const addMoneyToWallet = async (req, res) => {
 
    try {
 
        const { amount } = req.body;
 
        if (!amount || amount <= 0) {
            return res.status(400).json({
                message: "Invalid amount"
            });
        }
 
        const user = await User.findById(req.user.id);
 
        if (!user) {
            return res.status(404).json({
                message: "User not found"
            });
        }
 
        // ADD BALANCE
        user.wallet.balance += Number(amount);
 
        // TRANSACTION
        user.wallet.transactions.unshift({
            type: "ADD_MONEY",
            amount,
            description: "Money added to wallet"
        });
 
        await user.save();
 
        res.status(200).json({
            message: "Money added successfully",
            balance: user.wallet.balance
        });
 
    } catch (error) {
 
        res.status(500).json({
            message: error.message
        });
 
    }
 
};
 
 
// =====================================================
// DEDUCT WALLET MONEY
// =====================================================
 
const deductWalletMoney = async (userId, amount, orderId) => {
 
    const user = await User.findById(userId);
 
    if (!user) {
        throw new Error("User not found");
    }
 
    if (user.wallet.balance < amount) {
        throw new Error("Insufficient wallet balance");
    }
 
    // DEDUCT
    user.wallet.balance -= amount;
 
    // TRANSACTION
    user.wallet.transactions.unshift({
        type: "PURCHASE",
        amount,
        description: `Payment for Order ${orderId}`
    });
 
    await user.save();
 
};
 
 
// =====================================================
// REFUND TO WALLET
// =====================================================
 
const refundToWallet = async (order) => {
 
    const user = await User.findById(order.user);
 
    if (!user) {
        throw new Error("User not found");
    }
 
    // PREVENT DOUBLE REFUND
    if (order.refundStatus === "refunded") {
        throw new Error("Already refunded");
    }
 
    // ADD MONEY
    user.wallet.balance += order.totalPrice;
 
    // TRANSACTION
    user.wallet.transactions.unshift({
        type: "REFUND",
        amount: order.totalPrice,
        description: `Refund for Order ${order._id}`
    });
 
    await user.save();
 
    // UPDATE ORDER
    order.refundStatus = "refunded";
 
    order.paymentStatus = "refunded";
 
    order.refundAmount = order.totalPrice;
 
    order.refundedAt = new Date();
 
    await order.save();
 
};
 
 
module.exports = {
    getWallet,
    addMoneyToWallet,
    deductWalletMoney,
    refundToWallet
};
 