// const Coupon =require("../Models/Coupon.js");

 
//  const createCoupon = async (req, res) => {
//   try {
//     const coupon = new Coupon(req.body);
//     await coupon.save();
 
//     res.status(201).json({
//       success: true,
//       message: "Coupon created",
//       coupon,
//     });
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// const getCoupons = async (req, res) => {
//   try {
//     const coupons = await Coupon.find({ isActive: true });
//     res.json(coupons);
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };
 
 
//  const applyCoupon = async (req, res) => {
//   try {
//     const { code, subtotal } = req.body;
 
//     // 1. Find coupon
//     const coupon = await Coupon.findOne({ code });
 
//     if (!coupon || !coupon.isActive) {
//       return res.status(400).json({
//         success: false,
//         message: "Invalid or inactive coupon",
//       });
//     }
 
//     // 2. Check minimum amount
//     if (subtotal < coupon.minAmount) {
//       return res.status(400).json({
//         success: false,
//         message: `Minimum ₹${coupon.minAmount} required`,
//       });
//     }
 
//     // 3. Check expiry
//     if (coupon.expiryDate && coupon.expiryDate < new Date()) {
//       return res.status(400).json({
//         success: false,
//         message: "Coupon expired",
//       });
//     }
 
//     // 4. Calculate discount
//     let discount = 0;
//     const {cartTotal}=req.body
 
//     if (coupon.discountType === "percentage") {
//       discount = (cartTotal * coupon.discountValue) / 100;
 
//       if (coupon.maxDiscount) {
//         discount = Math.min(discount, coupon.maxDiscount);
//       }
//     } else {
//       discount = coupon.discountValue;
//     }
    
//     const finalTotal =cartTotal-discount
//     // 5. Send response
//     res.json({
//       success: true,
//       discount: Math.floor(discount),
//       finalTotal:Math.floor(finalTotal),
//       code: coupon.code,
//     });
 
//   } catch (error) {
//     console.error("Coupon Error:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server error",
//     });
//   }
// };
 
// module.exports={
//     createCoupon,
//     applyCoupon,
//     getCoupons,
// }



const Coupon = require("../Models/Coupon.js");

// ─── CREATE COUPON (Admin) ───────────────────────────────────────────────────
const createCoupon = async (req, res) => {
  try {
    const {
      code, discountType, discountValue,
      minAmount, maxDiscount, expiryDate, isActive,
    } = req.body;

    if (!code || !discountType || !discountValue) {
      return res.status(400).json({
        success: false,
        message: "code, discountType and discountValue are required",
      });
    }

    // Check duplicate code
    const existing = await Coupon.findOne({ code: code.toUpperCase().trim() });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: "Coupon code already exists",
      });
    }

    const coupon = new Coupon({
      code:          code.toUpperCase().trim(),
      discountType,
      discountValue: Number(discountValue),
      minAmount:     minAmount     ? Number(minAmount)     : 0,
      maxDiscount:   maxDiscount   ? Number(maxDiscount)   : null,
      expiryDate:    expiryDate    ? new Date(expiryDate)  : null,
      isActive:      isActive !== undefined ? isActive : true,
    });

    await coupon.save();

    res.status(201).json({
      success: true,
      message: "Coupon created successfully",
      coupon,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ─── GET ALL COUPONS (Admin) ─────────────────────────────────────────────────
const getCoupons = async (req, res) => {
  try {
    const coupons = await Coupon.find().sort({ createdAt: -1 });
    res.json(coupons);
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ─── UPDATE COUPON (Admin) ───────────────────────────────────────────────────
const updateCoupon = async (req, res) => {
  try {
    const coupon = await Coupon.findByIdAndUpdate(
      req.params.id,
      { ...req.body },
      { new: true, runValidators: true }
    );
    if (!coupon) {
      return res.status(404).json({ success: false, message: "Coupon not found" });
    }
    res.json({ success: true, message: "Coupon updated", coupon });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ─── DELETE COUPON (Admin) ───────────────────────────────────────────────────
const deleteCoupon = async (req, res) => {
  try {
    const coupon = await Coupon.findByIdAndDelete(req.params.id);
    if (!coupon) {
      return res.status(404).json({ success: false, message: "Coupon not found" });
    }
    res.json({ success: true, message: "Coupon deleted successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// ─── APPLY COUPON (User at checkout) ────────────────────────────────────────
const applyCoupon = async (req, res) => {
  try {
    const { code, cartTotal, subtotal } = req.body;
    const orderAmount = cartTotal || subtotal;

    if (!code || !orderAmount) {
      return res.status(400).json({
        success: false,
        message: "code and cartTotal are required",
      });
    }

    // Find coupon
    const coupon = await Coupon.findOne({ code: code.toUpperCase().trim() });

    if (!coupon) {
      return res.status(404).json({
        success: false,
        message: "Invalid coupon code",
      });
    }

    if (!coupon.isActive) {
      return res.status(400).json({
        success: false,
        message: "This coupon is no longer active",
      });
    }

    // Check expiry
    if (coupon.expiryDate && new Date(coupon.expiryDate) < new Date()) {
      return res.status(400).json({
        success: false,
        message: "This coupon has expired",
      });
    }

    // Check minimum amount
    if (orderAmount < coupon.minAmount) {
      return res.status(400).json({
        success: false,
        message: `Minimum order amount of ₹${coupon.minAmount} required to use this coupon`,
      });
    }

    // Calculate discount
    let discount = 0;

    if (coupon.discountType === "percentage") {
      discount = (orderAmount * coupon.discountValue) / 100;
      if (coupon.maxDiscount) {
        discount = Math.min(discount, coupon.maxDiscount);
      }
    } else {
      // flat discount
      discount = coupon.discountValue;
    }

    // Discount cannot exceed order amount
    discount = Math.min(discount, orderAmount);

    const finalTotal = orderAmount - discount;

    res.json({
      success:    true,
      discount:   Math.floor(discount),
      finalTotal: Math.floor(finalTotal),
      code:       coupon.code,
      message:    `Coupon applied! You save ₹${Math.floor(discount)}`,
    });
  } catch (error) {
    console.error("Coupon Error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

module.exports = {
  createCoupon,
  getCoupons,
  updateCoupon,
  deleteCoupon,
  applyCoupon,
};
