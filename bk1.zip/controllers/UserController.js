const User = require("../Models/User");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { notify } = require("./notificationController");

// 🔥 REGISTER USER

const registerAdmin = async (req, res) => {
  try {
    const { name, email, phone, password, adminSecret } = req.body;

    // 1. Validate required fields
    if (!name || !email || !phone || !password || !adminSecret) {
      return res.status(400).json({
        message: "All fields including admin secret key are required",
      });
    }

    // 2. Check admin secret key
    const ADMIN_SECRET = process.env.ADMIN_SECRET || "admin123";
    if (adminSecret !== ADMIN_SECRET) {
      return res.status(403).json({
        message: "Invalid admin secret key. Contact your system administrator.",
      });
    }

    // 3. Check if user already exists
    const exists = await User.findOne({ $or: [{ email }, { phone }] });
    if (exists) {
      return res.status(400).json({
        message: "An account with this email or phone already exists",
      });
    }

    // 4. Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // 5. Create user with role: "admin"
    const user = await User.create({
      name,
      email,
      phone,
      password: hashedPassword,
      role:     "admin",           // ← sets role as admin directly
    });

    // 6. Generate token
    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET || "secret123",
      { expiresIn: "7d" }
    );

    res.status(201).json({
      message: "Admin account created successfully",
      token,
      user: {
        id:    user._id,
        name:  user.name,
        email: user.email,
        phone: user.phone,
        role:  user.role,
      },
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const registerUser = async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;

    const userExists = await User.findOne({ email, phone });
    if (userExists) {
      return res.status(400).json({ message: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email,
      phone,
      password: hashedPassword,
    });

    res.status(201).json({
      message: "User registered successfully",
      user: {
        id:    user._id,
        name:  user.name,
        email: user.email,
        phone: user.phone,
        role:  user.role,
      },
    });

    notify("user", `New user registered: ${user.name}`);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 🔐 LOGIN USER
const loginUser = async (req, res) => {
  try {
    const { identifier, password } = req.body;

    const user = await User.findOne({
      $or: [{ email: identifier }, { phone: identifier }],
    });

    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid password" });
    }

    const token = jwt.sign(
      { id: user._id, role: user.role },
      process.env.JWT_SECRET || "secret123",
      { expiresIn: "7d" }
    );

    res.json({
      message: "Login successful",
      token,
      user: {
        id:    user._id,
        name:  user.name,
        email: user.email,
        phone: user.phone,
        role:  user.role,
        city:user.city,
        gender:user.gender,
        dob:user.dob,
        bio:user.bio,
        profilePic:user.profilePic,
        membership:user.membership,
      },
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ GET ALL USERS
const getAllUsers = async (req, res) => {
  const users = await User.find().select("-password");
  res.json(users);
};

// ✅ DELETE USER
const deleteUser = async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ message: "User deleted" });
};

// ✅ MAKE ADMIN
const makeAdmin = async (req, res) => {
  const user = await User.findById(req.params.id);
  user.role = "admin";
  await user.save();
  res.json({ message: "User promoted to admin" });
};

// ✅ BLOCK / UNBLOCK USER
const blockUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    user.isBlocked = !user.isBlocked;
    await user.save();
    res.json({ message: user.isBlocked ? "User blocked" : "User unblocked" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// // ✅ UPDATE PROFILE (name, email, password)
// const updateProfile = async (req, res) => {
//   try {
//     const user = await User.findById(req.user.id);

//     if (!user) {
//       return res.status(404).json({ message: "User not found" });
//     }

//     // Update name and email if provided
//     if (req.body.name)  user.name  = req.body.name;
//     if (req.body.email) user.email = req.body.email;
//     if(req.body.phone && req.body.phone.trim() !==""){
//       user.phone=req.body.phone;
//     } 

//     if (req.body.address &&req.body.address.trim()!=="") {
//       user.address=req.body.address;
//     }

  

//     // Update password if provided
//     if (req.body.newPassword) {
//       // Verify current password first
//       if (!req.body.currentPassword) {
//         return res.status(400).json({
//           message: "Current password is required to set a new password",
//         });
//       }

//       const isMatch = await bcrypt.compare(
//         req.body.currentPassword,
//         user.password
//       );

//       if (!isMatch) {
//         return res.status(401).json({ message: "Current password is incorrect" });
//       }

//       if (req.body.newPassword.length < 6) {
//         return res.status(400).json({
//           message: "New password must be at least 6 characters",
//         });
//       }

//       user.password = await bcrypt.hash(req.body.newPassword, 10);
//     }

//     await user.save();

//     res.json({
//       message: "Profile updated successfully",
//       user: {
//         id:    user._id,
//         name:  user.name,
//         email: user.email,
//         phone: user.phone,
//         address:user.address,
//         role:  user.role,
//       },
//     });

//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

 
const updateProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
 
    // ✅ Update all fields
    user.name = req.body.name || user.name;
    user.phone = req.body.phone || user.phone;
    user.dob = req.body.dob || user.dob;
    user.gender = req.body.gender || user.gender;
    user.city = req.body.city || user.city;
    user.bio = req.body.bio || user.bio;
    user.address=req.body.address || user.address;
 
    // ✅ Image upload
    if (req.file) {
      user.profilePic = `/uploads/${req.file.filename}`;
    }
 
    const updatedUser = await user.save();
 
    res.json({
      user: updatedUser,
      message: "Profile updated successfully",
    });
 
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: err.message });
  }
};


 
const changePassword = async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;
 
    // ── 1. Basic validation ──────────────────────────────────
    if (!oldPassword || !newPassword) {
      return res.status(400).json({ message: "Both fields are required" });
    }
 
    if (newPassword.length < 6) {
      return res.status(400).json({ message: "New password must be at least 6 characters" });
    }
 
    // ── 2. Find user (req.user is set by your auth middleware) ─
    const user = await User.findById(req.user.id).select("+password");
 
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
 
    // ── 3. Verify old password ───────────────────────────────
    const isMatch = await bcrypt.compare(oldPassword, user.password);
 
    if (!isMatch) {
      return res.status(401).json({ message: "Current password is incorrect" });
    }
 
    // ── 4. Prevent reusing the same password ─────────────────
    const isSame = await bcrypt.compare(newPassword, user.password);
 
    if (isSame) {
      return res.status(400).json({ message: "New password cannot be the same as your current password" });
    }
 
    // ── 5. Hash new password & save ──────────────────────────
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);
    await user.save();
 
    res.status(200).json({ message: "Password changed successfully" });
 
  } catch (error) {
    console.error("changePassword error:", error);
    res.status(500).json({ message: "Server error" });
  }
};

const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .select("-password")
      .populate("membership.planId", "name price discount benefits");
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
 
module.exports = {
  registerAdmin,
  registerUser,
  loginUser,
  getAllUsers,
  deleteUser,
  makeAdmin,
  blockUser,
  updateProfile, // ✅ new
  changePassword,
  getProfile,
};
