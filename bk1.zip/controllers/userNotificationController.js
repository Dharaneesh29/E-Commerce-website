const UserNotification = require("../Models/UserNotification");
 
// GET USER NOTIFICATIONS
const getUserNotifications = async (req, res) => {
  try {
 
    const notifications = await UserNotification.find({
      userId: req.user.id,
    }).sort({ createdAt: -1 });
 
    res.json(notifications);
 
  } catch (err) {
    res.status(500).json({
      message: "Failed to fetch notifications",
    });
  }
};
 
// MARK ALL READ
const markAllRead = async (req, res) => {
  try {
 
    await UserNotification.updateMany(
      {
        userId: req.user.id,
        isRead: false,
      },
      {
        isRead: true,
      }
    );
 
    res.json({
      success: true,
    });
 
  } catch (err) {
    res.status(500).json({
      message: "Failed",
    });
  }
};
 
module.exports = {
  getUserNotifications,
  markAllRead,
};
 