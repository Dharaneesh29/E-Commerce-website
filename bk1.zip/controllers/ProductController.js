const Product = require("../Models/Product");
const User=require("../Models/User");
const { notify } = require("./notificationController");

const LOW_STOCK_THRESHOLD = 10;

// ── CREATE PRODUCT ───────────────────────────────────────────
const createProduct = async (req, res) => {
  try {
    const product = new Product({
      ...req.body,
      image: req.file ? `/uploads/${req.file.filename}` : "",
    });

    const saved = await product.save();

    // ✅ Notify — new product added
    notify(
      "stock",
      `New product added: "${saved.name}" — ₹${saved.price} (Stock: ${saved.countInStock})`,
      saved._id.toString()
    );

    // ✅ Notify if added with low stock
    if (saved.countInStock <= LOW_STOCK_THRESHOLD && saved.countInStock > 0) {
      notify(
        "stock",
        `⚠️ Low stock on new product: "${saved.name}" has only ${saved.countInStock} units`,
        saved._id.toString()
      );
    }

    res.json(saved);
  } catch (err) {
    res.status(500).json({ message: "Error adding product" });
  }
};

// ── GET ALL PRODUCTS ─────────────────────────────────────────
const getProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ── DELETE PRODUCT ───────────────────────────────────────────
const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    await Product.findByIdAndDelete(req.params.id);

    // ✅ Notify — product deleted
    notify(
      "stock",
      `Product deleted: "${product.name}" has been removed from inventory`,
      null
    );

    res.json({ message: "Product deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ── GET PRODUCT BY ID ────────────────────────────────────────
const getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
    res.json(product);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};

// ── UPDATE PRODUCT ───────────────────────────────────────────
const updateProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const updated = await Product.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    // ✅ Notify if low stock after update
    if (updated.countInStock <= LOW_STOCK_THRESHOLD && updated.countInStock > 0) {
      notify(
        "stock",
        `⚠️ Low stock alert: "${updated.name}" has only ${updated.countInStock} units left`,
        updated._id.toString()
      );
    }

    // ✅ Notify if out of stock
    if (updated.countInStock === 0) {
      notify(
        "stock",
        `🚫 Out of stock: "${updated.name}" is now completely out of stock`,
        updated._id.toString()
      );
    }

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: "Error updating product" });
  }
};

// GET LATEST PRODUCTS
const getLatestProducts = async (req, res) => {
  try {
    
    const products = await Product.find()
      .sort({_id:-1 }) // newest first
      .limit(7); // only 7 products
 
    res.json(products);
  } catch (error) {
    console.log("LATEST ERROR:",error)
    res.status(500).json({ message: error.message });
  }
};

const addReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;
 
    const product = await Product.findById(req.params.id);
 
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const user = await User.findById(req.user.id)
    if(!user){
      return res.status(401).json({ message: "User not found" });
    }
 
    const review = {
      name: user.name, // 👈 from token
      rating: Number(rating),
      comment,
      image: req.file ? `/uploads/${req.file.filename}` : "",
    };
 
    product.reviews.push(review);
 
    // ⭐ update average rating
    product.rating =
      product.reviews.reduce((acc, item) => acc + item.rating, 0) /
      product.reviews.length;
 
    await product.save();
 
    res.json({ message: "Review added" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET SIMILAR PRODUCTS
const getSimilarProducts = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
 
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }
 
    const similar = await Product.find({
      category: product.category,
      _id: { $ne: product._id }, // exclude current product
    }).limit(10);
 
    res.json(similar);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

 
// controllers/productController.js
 
const getProductsByGroup = async (req, res) => {
  try {
    const group = req.params.name;
    const sub = req.query.sub;
 
    const categoryMap = {
      electronics: ["Mobile", "Smartphones", "Laptops", "Tablets"],
      fashion: ["Mens-shirts", "Mens-shoes", "Womens-dresses"],
      "home-&-kitchen": ["Furniture","Home-decoration", "Kitchen-accessories"],
      appliances: ["Groceries", "Grocery"],
      beauty: ["Beauty", "Skin-care", "Fragrances"],
      sports: ["Sports-accessories"],
    };
 
    let categories = categoryMap[group] || [];
 
    if (sub && sub !== "all") {
      categories = [sub];
    }
 
    const products = await Product.find({
      category: { $in: categories },
    });
 
    res.json(products); // ✅ SIMPLE
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
 

// import Product from "../models/Product.js";
 
const getProductsByBrand = async (req, res) => {
  try {
    const brand = req.params.brand;
 
    const products = await Product.find({
      brand: { $regex: brand, $options: "i" } // case insensitive
    });
 
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
 
 

module.exports = {
  createProduct,
  getProducts,
  deleteProduct,
  getProductById,
  updateProduct,
  getLatestProducts,
  addReview,
  getSimilarProducts,
  getProductsByGroup,
  getProductsByBrand,
  
};
