const mongoose = require("mongoose");
const User = require("../Models/User.js");
 
const addToWishlist = async (req, res) => {
  try {
    console.log("User:", req.user);
 
    const user = await User.findById(req.user.id).populate("wishlist");
    res.json(user.wishlist);
    const { productId } = req.params;
 
    const exists = user.wishlist.some(
      (id) => id.toString() === productId
    );
 
    if (!exists) {
      user.wishlist.push(new mongoose.Types.ObjectId(productId));
    }
 
    await user.save();
 
    res.json({ message: "Added to wishlist" });
  } catch (err) {
    console.log("ERROR:", err); // 👈 ADD THIS
    res.status(500).json({ message: err.message });
  }
};


// GET
const getWishlist = async (req, res) => {
  try {
        console.log("User:",req.user)

    const user = await User.findById(req.user.id).populate("wishlist");

    if(!user){
      return res.status(404).json({message:"User not found"});
    }
 
    res.json(user.wishlist);
  } catch (err) {
    console.error("Wishlist error:",err);
    res.status(500).json({ message: err.message });
  }
};
 
// REMOVE
const removeFromWishlist = async (req, res) => {
  try {
        console.log("User:",req.user)

    const user = await User.findById(req.user.id);
 
    const { productId } = req.params;
 
    user.wishlist = user.wishlist.filter(
      (id) => id.toString() !== productId
    );
 
    await user.save();
 
    res.json({ message: "Removed from wishlist" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
 

module.exports={
    addToWishlist,
    getWishlist,
    removeFromWishlist,
};