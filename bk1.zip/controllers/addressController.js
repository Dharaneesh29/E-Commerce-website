const Address = require("../Models/Address");
 
// ➕ Add Address
const addAddress = async (req, res) => {
  try {
    const { name, phone, pincode, address, city, state, landmark } = req.body;
 
    const newAddress = await Address.create({
      user: req.user.id, // 🔥 from authMiddleware
      name,
      phone,
      pincode,
      address,
      city,
      state,
      landmark,
    });
 
    res.status(201).json(newAddress);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
// 📥 Get All Addresses of Logged User
const getAddresses = async (req, res) => {
  try {
    const addresses = await Address.find({ user: req.user.id });
    res.json(addresses);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
// ❌ Delete Address
const deleteAddress = async (req, res) => {
  try {
    await Address.findByIdAndDelete(req.params.id);
    res.json({ message: "Address deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
 
module.exports = {
  addAddress,
  getAddresses,
  deleteAddress,
};