const User = require("../Models/User");
const Product = require("../Models/Product");
const Order = require("../Models/Order");

const getDashboardStats = async (req, res) => {
  try {
    // ── KPI TOTALS ──────────────────────────────────────────
    const totalUsers = await User.countDocuments();
    const totalProducts = await Product.countDocuments();
    const totalOrders = await Order.countDocuments();

    const revenueResult = await Order.aggregate([
      { $match: { paymentStatus: "paid" } },
      { $group: { _id: null, total: { $sum: "$totalPrice" } } },
    ]);
    const totalRevenue = revenueResult[0]?.total || 0;

    // ── MONTHLY SALES CHART (all time, grouped by month) ────
    const months = ["Jan","Feb","Mar","Apr","May","Jun",
                    "Jul","Aug","Sep","Oct","Nov","Dec"];

    const monthlySales = await Order.aggregate([
      { $match: {} }, // no date filter — show all orders
      {
        $group: {
          _id: {
            month: { $month: "$createdAt" },
            year: { $year: "$createdAt" }
          },
          sales: { $sum: "$totalPrice" },
          orders: { $sum: 1 },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1 } },
    ]);

    // console.log("monthlysales raw:",monthlySales);

    const salesChart = monthlySales.map(d => ({
      name: months[d._id.month - 1],
      sales: d.sales,
      orders: d.orders,
    }));

    // ── MONTHLY USER GROWTH (all time) ───────────────────────
    const monthlyUsers = await User.aggregate([
      { $match: {} }, // no date filter — show all users
      {
        $group: {
          _id: {
            month: { $month: "$createdAt" },
            year: { $year: "$createdAt" }
          },
          users: { $sum: 1 },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1 } },
    ]);

    // console.log("monthlyusers raw:",monthlyUsers);

    const usersChart = monthlyUsers.map(d => ({
      name: months[d._id.month - 1],
      users: d.users,
    }));

    res.json({
      totalUsers,
      totalProducts,
      orders: totalOrders,
      revenue: totalRevenue,
      salesChart,
      usersChart,
    });

  } catch (error) {
    console.error("Dashboard error:", error.message);
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getDashboardStats };