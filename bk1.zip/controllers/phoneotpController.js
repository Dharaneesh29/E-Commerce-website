// const phoneOtpStore = {};
 
// // 📤 SEND PHONE OTP
// const sendPhoneOtp = (req, res) => {
//   try {
//     const { phone } = req.body;
 
//     if (!phone) {
//       return res.status(400).json({ message: "Phone required" });
//     }
 
//     const otp = Math.floor(100000 + Math.random() * 900000);
 
//     // store OTP
//     phoneOtpStore[phone] = otp;
 
//     // 👇 THIS IS YOUR TERMINAL OTP
//     console.log(`📱 PHONE OTP for ${phone} is: ${otp}`);
 
//     res.json({ message: "Phone OTP generated (check terminal)" });
 
//   } catch (err) {
//     console.log(err);
//     res.status(500).json({ message: "Phone OTP error" });
//   }
// };
 
// // ✅ VERIFY PHONE OTP
// const verifyPhoneOtp = (req, res) => {
//   const { phone, otp } = req.body;
 
//   if (phoneOtpStore[phone] == otp) {
//     delete phoneOtpStore[phone]; // cleanup
//     return res.json({ message: "Phone Verified ✅" });
//   } else {
//     return res.status(400).json({ message: "Invalid Phone OTP ❌" });
//   }
// };
 
// module.exports = { sendPhoneOtp, verifyPhoneOtp };
 

const jwt = require("jsonwebtoken");
const User = require("../Models/User");

const phoneOtpStore = {};
 
// 📤 SEND PHONE OTP
const sendPhoneOtp = (req, res) => {
  try {
    const { phone } = req.body;
 
    if (!phone) {
      return res.status(400).json({ message: "Phone required" });
    }
 
    const otp = Math.floor(100000 + Math.random() * 900000);
 
    // store OTP
    phoneOtpStore[phone] = otp;
 
    // 👇 THIS IS YOUR TERMINAL OTP
    console.log(`📱 PHONE OTP for ${phone} is: ${otp}`);
 
    res.json({ message: "Phone OTP generated (check terminal)" });
 
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "Phone OTP error" });
  }
};
 
// ✅ VERIFY PHONE OTP
const verifyPhoneOtp = async (req, res) => {
  try {
 
    const { phone, otp } = req.body;
 
    if (phoneOtpStore[phone] == otp) {
 
      delete phoneOtpStore[phone];
 
      // 🔥 find existing user
      let user = await User.findOne({ phone });
 
      // 🔥 create new user if not exists
      if (!user) {
        user = await User.create({
          name: "User",
          phone,
        });
      }
 
      // 🔥 create token
      const token = jwt.sign(
        { id: user._id },
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
      );
 
      return res.json({
        success: true,
        user,
        token,
      });
 
    } else {
 
      return res.status(400).json({
        message: "Invalid Phone OTP ❌"
      });
 
    }
 
  } catch (err) {
 
    console.log(err);
 
    res.status(500).json({
      message: "Phone OTP error"
    });
 
  }
};
 
 
module.exports = { sendPhoneOtp, verifyPhoneOtp };
 