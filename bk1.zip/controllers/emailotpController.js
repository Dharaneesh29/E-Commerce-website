// const nodemailer=require("nodemailer");
// const Otp=require("../Models/Otp.js");
 
// // 🔐 MAIL TRANSPORTER
// const transporter = nodemailer.createTransport({
//   service: "gmail",
//   auth: {
//     user: "afzar0111@gmail.com",       // 👈 your gmail
//     pass: "ultyqcxthlttgeob",         // 👈 app password (no spaces)
//   },
// });
 
// // 📤 SEND OTP
//  const sendOtp = async (req, res) => {
//   console.log("BODY:",req.body)
//   const { email } = req.body;
//   console.log("verify Clicked")
//   try {
//     if (!email) {
//       return res.status(400).json({ message: "Email is required" });
//     }
 
//     // Generate 6 digit OTP
//     const otp = Math.floor(100000 + Math.random() * 900000).toString();
 
//     // Remove old OTP
//     await Otp.deleteMany({ email });
 
//     // Save new OTP (valid 5 mins)
//     await Otp.create({
//       email,
//       otp,
//       expiresAt: new Date(Date.now() + 5 * 60 * 1000),
//     });
 
//     // Send Email
//     await transporter.sendMail({
//       from: "yourgmail@gmail.com",
//       to: email,
//       subject: "OTP Verification",
//       html: `
//         <h2>Your OTP Code</h2>
//         <p>Your OTP is:</p>
//         <h1 style="color:#ff6a00;">${otp}</h1>
//         <p>This OTP is valid for 5 minutes.</p>
//       `,
//     });
 
//     res.json({ message: "OTP sent successfully" });
 
//   } catch (err) {
//     console.log("Send OTP Error:", err);
//     res.status(500).json({ message: "Error sending OTP" });
//   }
// };
 
// // ✅ VERIFY OTP
//  const verifyOtp = async (req, res) => {
//   const { email, otp } = req.body;
 
//   try {
//     if (!email || !otp) {
//       return res.status(400).json({ message: "Email & OTP required" });
//     }
 
//     const record = await Otp.findOne({ email, otp });
 
//     if (!record) {
//       return res.status(400).json({ message: "Invalid OTP" });
//     }
 
//     // Check expiry
//     if (record.expiresAt < new Date()) {
//       await Otp.deleteMany({ email });
//       return res.status(400).json({ message: "OTP expired" });
//     }
 
//     // Delete OTP after success
//     await Otp.deleteMany({ email });
 
//     res.json({ message: "Email verified successfully" });
 
//   } catch (err) {
//     console.log("Verify OTP Error:", err);
//     res.status(500).json({ message: "Verification failed" });
//   }
// };

// module.exports = {
//     sendOtp,
//     verifyOtp,

// };

// const otpStore = {}; // temporary storage
 
// // SEND OTP
// const sendOtp = async (req, res) => {
  
// // console.log("✅ sendOtp API HIT");
// //  / console.log("BODY RECEIVED:", req.body);

//   try {
//     const { email } = req.body;
 
//     if (!email) {
//       return res.status(400).json({ message: "Email required" });
//     }
 
//     const otp = Math.floor(100000 + Math.random() * 900000);
 
//     // store OTP in memory
//     otpStore[email] = otp;
 
//     console.log("📩 OTP for", email, "is:", otp); // 👈 IMPORTANT
 
//     res.json({ message: "OTP generated (check terminal)" });
 
//   } catch (err) {
//     console.log(err);
//     res.status(500).json({ message: "OTP error" });
//   }
// };
 
// // VERIFY OTP
// const verifyOtp = (req, res) => {
//   const { email, otp } = req.body;
 
//   if (otpStore[email] == otp) {
//     delete otpStore[email]; // cleanup
//     return res.json({ message: "OTP Verified ✅" });
//   } else {
//     return res.status(400).json({ message: "Invalid OTP ❌" });
//   }
// };
 
// module.exports = { sendOtp, verifyOtp };
 

const jwt = require("jsonwebtoken");
const User = require("../Models/User");
const otpStore = {}; // temporary storage
 
// SEND OTP
const sendOtp = async (req, res) => {
  
console.log("✅ sendOtp API HIT");
  console.log("BODY RECEIVED:", req.body);

  try {
    const { email } = req.body;
 
    if (!email) {
      return res.status(400).json({ message: "Email required" });
    }
 
    const otp = Math.floor(100000 + Math.random() * 900000);
 
    // store OTP in memory
    otpStore[email] = otp;
 
    console.log("📩 OTP for", email, "is:", otp); // 👈 IMPORTANT
 
    res.json({ message: "OTP generated (check terminal)" });
 
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: "OTP error" });
  }
};
 
// VERIFY OTP
const verifyOtp = async (req, res) => {
 
  try {
 
    const { email, otp } = req.body;
 
    if (otpStore[email] == otp) {
 
      delete otpStore[email];
 
      // 🔥 find user
      let user = await User.findOne({ email });
 
      // 🔥 create if not exists
      if (!user) {
        user = await User.create({
          name: "User",
          email,
        });
      }
 
      // 🔥 token
      const token = jwt.sign(
        { id: user._id },
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
      );
 
      return res.json({
        success: true,
        user,
        token,
      });
 
    } else {
 
      return res.status(400).json({
        message: "Invalid OTP ❌"
      });
 
    }
 
  } catch (err) {
 
    console.log(err);
 
    res.status(500).json({
      message: "OTP error"
    });
 
  }
 
};
 
 
module.exports = { sendOtp, verifyOtp };
 