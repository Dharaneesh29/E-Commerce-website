// const Order   = require("../Models/Order");
// const Address = require("../Models/Address");
// const Product = require("../Models/Product");
// const { notify } = require("./notificationController");

// // ── CREATE ORDER ─────────────────────────────────────────────
// const createOrder = async (req, res) => {
//   try {
//     const { orderItems, addressId, totalPrice, paymentMethod, estimatedDelivery} = req.body;
//     console.log("Req :",req.body)
    

//     const address = await Address.findById(addressId);
//     if (!address) {
//       return res.status(404).json({ message: "Address not found" });
//     }

//     const shippingAddress = {
//       fullName: address.name,
//       phone:    address.phone,
//       address:  address.address,
//       city:     address.city,
//       state:    address.state,
//       pincode:  address.pincode,
//       landmark: address.landmark,
//     };


//      // ================================
//     // 🔥 3. REDUCE STOCK HERE
//     // ================================
//     for (let item of orderItems) {
//       const product = await Product.findById(item.product);
 
//       if (!product) {
//         return res.status(404).json({ message: "Product not found" });
//       }
 
//       if (product.countInStock < item.qty) {
//         return res.status(400).json({
//           message: `${product.name} out of stock`,
//         });
//       }
 
//       product.countInStock -= item.qty;
//       await product.save();
//     }
    

//     const order = await Order.create({
//       user: req.user.id,
//       orderItems,
//       shippingAddress,
//       totalPrice,
//       paymentMethod,
//       estimatedDelivery,
//       paymentStatus: paymentMethod === "COD" ? "pending" : "paid",
//     });

//     // ✅ Notify new order
//     notify(
//       "order",
//       `🛒 New order #${order._id.toString().slice(-6).toUpperCase()} placed by ${shippingAddress.fullName} for ₹${totalPrice} (${paymentMethod})`,
//       order._id.toString()
//     );

//     res.status(201).json({
//       message: "Order placed successfully ✅",
//       order,
//     });
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// // ✅ CANCEL ORDER
// const cancelOrder = async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);
//     if (!order) return res.status(404).json({ message: "Order not found" });

//     if (order.status === "delivered") {
//       return res.status(400).json({ message: "Cannot cancel a delivered order" });
//     }

//     order.status       = "cancelled";
//     order.cancelReason = req.body.reason || "Cancelled by admin";
//     order.cancelledAt  = new Date();

//     // Auto-set refund if already paid
//     if (order.paymentStatus === "paid") {
//       order.refundStatus = "pending";
//       order.refundAmount = order.totalPrice;
//     }

//     await order.save();

//     notify(
//       "order",
//       `❌ Order #${order._id.toString().slice(-6).toUpperCase()} cancelled. Reason: ${order.cancelReason}`,
//       order._id.toString()
//     );

//     res.json({ message: "Order cancelled", order });
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// // ✅ HANDLE RETURN REQUEST
// const handleReturn = async (req, res) => {
//   try {
//     const order  = await Order.findById(req.params.id);
//     if (!order) return res.status(404).json({ message: "Order not found" });

//     const { action, reason } = req.body; // action: "request" | "approve" | "reject"

//     if (action === "request") {
//       order.returnRequest = {
//         requested:   true,
//         reason:      reason || "Return requested by admin",
//         status:      "pending",
//         requestedAt: new Date(),
//       };
//     } else if (action === "approve") {
//       order.returnRequest.status = "approved";
//       order.status               = "returned";
//       // Auto trigger refund
//       order.refundStatus = "pending";
//       order.refundAmount = order.totalPrice;
//     } else if (action === "reject") {
//       order.returnRequest.status = "rejected";
//     }

//     await order.save();

//     notify(
//       "order",
//       `🔄 Return ${action}d for Order #${order._id.toString().slice(-6).toUpperCase()}`,
//       order._id.toString()
//     );

//     res.json({ message: `Return ${action}d`, order });
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// // ✅ PROCESS REFUND
// const processRefund = async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);
//     if (!order) return res.status(404).json({ message: "Order not found" });

//     const { status, amount } = req.body; // status: "processed" | "failed"

//     order.refundStatus = status || "processed";
//     order.refundAmount = amount || order.totalPrice;
//     order.refundedAt   = status === "processed" ? new Date() : null;

//     if (status === "processed") {
//       order.paymentStatus = "refunded";
//     }

//     await order.save();

//     notify(
//       "order",
//       `💸 Refund ${status} for Order #${order._id.toString().slice(-6).toUpperCase()} — ₹${order.refundAmount}`,
//       order._id.toString()
//     );

//     res.json({ message: `Refund ${status}`, order });
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// const autoUpdateStatus = async (order) => {
//   if (order.status === "cancelled" || order.status === "delivered") return order;
 
//   const now = new Date();
//   const created = new Date(order.createdAt);
 
//   const diffHours = (now - created) / (1000 * 60 * 60);
//   const diffDays = (now - created) / (1000 * 60 * 60 * 24);
 
//   if (diffHours > 2 && order.status === "pending") {
//     order.status = "confirmed";
//   }
 
//   if (diffDays > 1 && order.status === "confirmed") {
//     order.status = "shipped";
//   }
 
//   if (diffDays > 2 && order.status === "shipped") {
//     order.status = "delivered";
//   }
 
//   await order.save();
//   global.io.emit("orderUpdated", order)
//   return order;
// };
 


// // ── GET MY ORDERS ────────────────────────────────────────────
// const getMyOrders = async (req, res) => {
//   try {
//     const orders = await Order.find({ user: req.user.id }).sort({ createdAt: -1 });
//     res.json(orders);
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

// // ── GET ALL ORDERS (admin) ───────────────────────────────────
// const getAllOrders = async (req, res) => {
//   try {
//     const orders = await Order.find().sort({ createdAt: -1 });
//     res.json(orders);
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };


// const getMyOrderById = async (req, res) => {
//   try {
//     let order = await Order.findById(req.params.id).populate("orderItems.product");
 
//     if (!order) {
//       return res.status(404).json({ message: "Order not found" });
//     }
    
//     order = await autoUpdateStatus(order);
 
//     // ✅ FIXED HERE
//     if (order.user.toString() !== req.user.id) {
//       return res.status(401).json({ message: "Not authorized" });
//     }
 
//     res.json(order);
 
//   } catch (err) {
//     console.log("ERROR IN ORDER:", err);
//     res.status(500).json({ message: err.message });
//   }
// };


// // ── UPDATE ORDER STATUS (admin) ──────────────────────────────
// const updateOrderStatus = async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);
//     if (!order) return res.status(404).json({ message: "Order not found" });

//     const prevStatus = order.status;
//     order.status     = req.body.status;
//     await order.save();

//     // ✅ Notify status change
//     const statusEmoji = {
//       confirmed:  "✅",
//       shipped:    "🚚",
//       delivered:  "📦",
//       pending:    "🕐",
//     };
//     notify(
//       "order",
//       `${statusEmoji[req.body.status] || "📋"} Order #${order._id.toString().slice(-6).toUpperCase()} status changed: ${prevStatus} → ${req.body.status}`,
//       order._id.toString()
//     );

//     res.json({ message: "Status updated", order });
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };


// const returnOrder = async (req, res) => {
//   try {
//     const { reason } = req.body;
 
//     const order = await Order.findById(req.params.id);
 
//     if (!order) {
//       return res.status(404).json({ message: "Order not found" });
//     }
 
//     order.returnInfo = {
//       reason,
//       returnedAt: new Date(),
//       status: "requested",
//     };
 
//     await order.save();
 
//     res.json({ message: "Return requested" });
 
//   } catch (err) {
//     res.status(500).json({ message: err.message });
//   }
// };

// module.exports = {
//   createOrder,
//   getMyOrders,
//   getAllOrders,
//   getMyOrderById,
//   updateOrderStatus,
//   cancelOrder,
//   handleReturn,
//   processRefund,
//   returnOrder,
// };

const Order   = require("../Models/Order");
const Address = require("../Models/Address");
const Product = require("../Models/Product");
const User = require("../Models/User");

const { deductWalletMoney, refundToWallet }= require("./walletController")
const { notify } = require("./notificationController");

// ── CREATE ORDER ─────────────────────────────────────────────
const createOrder = async (req, res) => {
  try {
    const { orderItems, addressId, totalPrice, paymentMethod, estimatedDelivery } = req.body;
    console.log("Req :", req.body);


// ✅ Check membership discount

let finalPrice = totalPrice;
let membershipDiscount = 0;

try {
  const userWithMembership = await User.findById(req.user.id)
    .populate("membership.planId", "discount");

  if (
    userWithMembership?.membership?.isActive &&
    userWithMembership?.membership?.planId?.discount > 0 &&
    new Date(userWithMembership.membership.expiryDate) > new Date()
  ) {
    const discountPercent = userWithMembership.membership.planId.discount;
    membershipDiscount = Math.round((totalPrice * discountPercent) / 100);
    finalPrice = totalPrice - membershipDiscount;
  }
} catch (memErr) {
  console.log("Membership check skipped:", memErr.message);
  // Continue without discount if membership check fails
}


    const address = await Address.findById(addressId);
    if (!address) {
      return res.status(404).json({ message: "Address not found" });
    }

    const shippingAddress = {
      fullName: address.name,
      phone:    address.phone,
      address:  address.address,
      city:     address.city,
      state:    address.state,
      pincode:  address.pincode,
      landmark: address.landmark,
    };

    
for (let item of orderItems) {

  // ✅ Step 1: Check product existence (no stock mutation)
  const productExists = await Product.exists({ _id: item.product });
  if (!productExists) {
    return res.status(404).json({ message: "Product not found" });
  }

  // ✅ Step 2: Atomic stock deduction
  const updatedProduct = await Product.findOneAndUpdate(
    {
      _id: item.product,
      countInStock: { $gte: item.qty },
    },
    {
      $inc: { countInStock: -item.qty },
    },
    {
      returnDocument: "after", // ✅ fixes Mongoose warning too
    }
  );

  if (!updatedProduct) {
    return res.status(400).json({ message: "Product out of stock" });
  }
}

let paymentStatus = paymentMethod === "COD"
  ? "pending"
  : "paid";
 
if (paymentMethod === "WALLET") {
  
  if (finalPrice <= 0) {
  return res.status(400).json({
    message: "Invalid wallet payment"
  });
}
 
  // deduct wallet balance
  await deductWalletMoney(
    req.user.id,
    finalPrice,
    "TEMP_ORDER"
  );
 
  paymentStatus = "paid";
}

    const order = await Order.create({
      user: req.user.id,
      orderItems,
      shippingAddress,
      totalPrice:finalPrice,
      originalPrice:totalPrice,
      membershipDiscount,
      paymentMethod,
      estimatedDelivery,
      paymentStatus,
    });

    notify(
      "order",
      `🛒 New order #${order._id.toString().slice(-6).toUpperCase()} placed by ${shippingAddress.fullName} for ₹${totalPrice} (${paymentMethod})`,
      order._id.toString()
    );

    res.status(201).json({
      message: "Order placed successfully ✅",
      order,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 
const cancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: "Order not found" });

    // ❗ Prevent cancelling twice
    if (order.status === "cancelled") {
      return res.status(400).json({ message: "Order already cancelled" });
    }

    // ❌ Delivered orders cannot be cancelled
    if (order.status === "delivered") {
      return res.status(400).json({ message: "Cannot cancel a delivered order" });
    }

    // 🔐 Check permissions
    const isAdmin = req.user.role === "admin";
    if (!isAdmin && order.user.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    // 🔥 RESTORE STOCK — ATOMIC OPERATION
    for (let item of order.orderItems) {
      await Product.findByIdAndUpdate(
        item.product,
        { $inc: { countInStock: item.qty } }
      );
    }

    // 🟠 Update order fields
    order.status = "cancelled";
    order.cancelInfo = {
      reason: req.body.reason || (isAdmin ? "Cancelled by admin" : "Cancelled by user"),
      cancelledAt: new Date(),
      cancelledBy: isAdmin ? "admin" : "user",
    };

    // 💰 If already paid, mark refund pending
    if (order.paymentStatus === "paid") {
      order.refundStatus = "pending";
      order.refundAmount = order.totalPrice;
    }
   
    if (
  order.paymentStatus === "paid" &&
  order.paymentMethod !== "COD" && order.refundStatus!=="refunded"
) {
 
  await refundToWallet(order);
 
}
 
    await order.save();

    // 📢 Notify
    notify(
      "order",
      `❌ Order #${order._id.toString().slice(-6).toUpperCase()} cancelled. Stock restored.`,
      order._id.toString()
    );

    // 🔄 Emit live update
    if (global.io) global.io.emit("orderUpdated", order);

    res.json({
      message: "Order cancelled and stock restored",
      order
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// ── HANDLE RETURN (admin) ─────────────────────────────────────
const handleReturn = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: "Order not found" });

    const { action, reason } = req.body; // action: "approve" | "reject"

    if (action === "approve") {
      // ✅ FIXED: use returnInfo instead of returnRequest
      order.returnInfo.status = "approved";
      order.status            = "returned";
   

      await refundToWallet(order)
    } else if (action === "reject") {
      // ✅ FIXED: use returnInfo
      order.returnInfo.status = "rejected";
    }

    await order.save();

    notify(
      "order",
      `🔄 Return ${action}d for Order #${order._id.toString().slice(-6).toUpperCase()}`,
      order._id.toString()
    );

    res.json({ message: `Return ${action}d`, order });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ── PROCESS REFUND (admin) ────────────────────────────────────
// const processRefund = async (req, res) => {
//   try {
//     const order = await Order.findById(req.params.id);
//     if (!order) return res.status(404).json({ message: "Order not found" });

//     const { status, amount } = req.body;

//     order.refundStatus = status || "refunded";
//     order.refundAmount = amount || order.totalPrice;
//     order.refundedAt   = status === "refunded" ? new Date() : null;

//     if (status === "refunded") {
//       order.paymentStatus = "refunded";
//     }

//     await order.save();

//     notify(
//       "order",
//       `💸 Refund ${status} for Order #${order._id.toString().slice(-6).toUpperCase()} — ₹${order.refundAmount}`,
//       order._id.toString()
//     );

//     res.json({ message: `Refund ${status}`, order });
//   } catch (error) {
//     res.status(500).json({ message: error.message });
//   }
// };

const processRefund = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: "Order not found" });

    const { status, amount } = req.body; // "refunded" or "rejected"

    order.refundStatus = status;
    order.refundAmount = amount || order.totalPrice;
    order.refundedAt   = status === "refunded" ? new Date() : null;

    if (status === "refunded") {
      order.paymentStatus = "refunded";
    }

    await order.save();

    notify(
      "order",
      `💸 Refund ${status} for Order #${order._id.toString().slice(-6).toUpperCase()} — ₹${order.refundAmount}`,
      order._id.toString()
    );

    res.json({ message: `Refund ${status}`, order });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ── AUTO UPDATE STATUS ────────────────────────────────────────
const autoUpdateStatus = async (order) => {
  if (order.status === "cancelled" || order.status === "delivered") return order;

  const now      = new Date();
  const created  = new Date(order.createdAt);
  const diffHours = (now - created) / (1000 * 60 * 60);
  const diffDays  = (now - created) / (1000 * 60 * 60 * 24);

  if (diffHours > 2  && order.status === "pending")   order.status = "confirmed";
  if (diffDays  > 1  && order.status === "confirmed")  order.status = "shipped";
  if (diffDays  > 2  && order.status === "shipped")    order.status = "delivered";

  await order.save();
  global.io.emit("orderUpdated", order);
  return order;
};

// ── GET MY ORDERS ─────────────────────────────────────────────
const getMyOrders = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user.id }).sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ── GET ALL ORDERS (admin) ────────────────────────────────────
const getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ── GET ORDER BY ID ───────────────────────────────────────────
const getMyOrderById = async (req, res) => {
  try {
    let order = await Order.findById(req.params.id).populate("orderItems.product");

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    order = await autoUpdateStatus(order);

    const isAdmin = req.user.role === "admin";
    if (!isAdmin && order.user.toString() !== req.user.id) {
      return res.status(401).json({ message: "Not authorized" });
    }

    res.json(order);
  } catch (err) {
    console.log("ERROR IN ORDER:", err);
    res.status(500).json({ message: err.message });
  }
};

// ── UPDATE ORDER STATUS (admin) ───────────────────────────────
const updateOrderStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: "Order not found" });

    const prevStatus = order.status;
    order.status     = req.body.status;
    await order.save();

    const statusEmoji = {
      confirmed: "✅",
      shipped:   "🚚",
      delivered: "📦",
      pending:   "🕐",
    };

    notify(
      "order",
      `${statusEmoji[req.body.status] || "📋"} Order #${order._id.toString().slice(-6).toUpperCase()} status changed: ${prevStatus} → ${req.body.status}`,
      order._id.toString()
    );

    res.json({ message: "Status updated", order });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ── RETURN ORDER (user) ───────────────────────────────────────
const returnOrder = async (req, res) => {
  try {
    console.log("req.user:",req.user);
    const { reason,items } = req.body;

    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    // ✅ Allow admin OR the order owner
    const isAdmin = req.user.role === "admin";
    if (!isAdmin && order.user.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    if (order.status !== "delivered") {
      return res.status(400).json({ message: "Can only return delivered orders" });
    }

    if(order.returnInfo && order.returnInfo.status){
      return res.status(400).json({message:"Return already requested"});
    }
    // ✅ Uses returnInfo (matches schema)
    order.returnInfo = {
      reason,
      items,
      returnedAt: new Date(),
      status: "requested",
    };

    await order.save();

    res.json({ message: "Return requested successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  createOrder,
  getMyOrders,
  getAllOrders,
  getMyOrderById,
  updateOrderStatus,
  cancelOrder,
  handleReturn,
  processRefund,
  returnOrder,
};


