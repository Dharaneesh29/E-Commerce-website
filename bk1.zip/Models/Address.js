const mongoose=require("mongoose")
const addressSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  name: String,
  phone: String,
  pincode: String,
  address: String,
  city: String,
  state: String,
  landmark: String,

  type:{
    type:String,
    enum:["Home","Work"],
    default:"Home",
  },
}, { timestamps: true });
 
module.exports = mongoose.model("Address", addressSchema);
 