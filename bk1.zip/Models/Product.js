const mongoose=require("mongoose")

const reviewSchema = new mongoose.Schema({
  name: String,
  rating: Number,
  comment: String,
  image: String, // 👈 NEW
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // optional
  createdAt: { type: Date, default: Date.now }
});

const productSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    

    price: {
        type: Number,
        required: true
    },

    originalPrice:Number,

    description: {
        type: String,
        required: true
    },
    images: {
        type: [String],
        required: true
    },

    sizes: {
        type:[String],
        default: []
    },

    colors: {
        type: [String],
        default: [],
    },

    brand: {
        type: String
    },
    category: {
        type: String,
        required: true
    },
    countInStock: {
        type: Number,
        required: true,
        default: 0
    },
    rating: {
        type: Number,
        default: 0
    },

    reviews: [reviewSchema],

    numReviews: {
        type: Number,
        default: 0
    },
    isFeatured: {
        type: Boolean,
        default: false
    },
    delivery: {
       type:String,
       default: "3-5 Days",
    },

    returnPolicy:{
        type:String,
        default:"7 Days Return",
    },


    discount: {
        type: Number,
        default: 0
    }
}, { timestamps: true });

module.exports=mongoose.model("Product", productSchema);
