const mongoose = require("mongoose");
 
const userNotificationSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
 
    type: {
      type: String,
      enum: ["order"],
      default: "order",
    },
 
    message: {
      type: String,
      required: true,
    },
 
    orderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
    },
 
    isRead: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);
 
module.exports = mongoose.model(
  "UserNotification",
  userNotificationSchema
);
 