const mongoose = require("mongoose")

const userSchema= new mongoose.Schema({
    name:{
        type:String,
        required:true,
        trim:true
    },
    email:{
        type:String,
        required:true,
        unique:true,
        lowercase:true,
    },

    phone:{
        type:String,
        required:false,
        unique:true,
    },
    password:{
        type: String,
        required:true,
    },
    role:{
        type:String,
        enum:["user","admin"],
        default:"user"
    },

    wishlist : [
        {
            type:mongoose.Schema.Types.ObjectId,
            ref:"Product"
        },
    ],

    profilePic: {
        type:String,
        default:"",
    },

    dob: {
        type:Date,
    },

    gender: {
        type:String,
        enum: ["Male","Female","Other"],
    },

    bio: {
        type:String,
        trim:true,
        maxLength: 200,
    },


    isBlocked:{
        type: Boolean,
        default: false
    },

    address:{
        type:String,
    },

    city: {
        type:String,
    },

    pincode:{
        type:String,
    },

    lastLogin: {
        type :Date,
    },

    profileImage:{
        type:String,
    },

    profileImage:{
   type:String,
},
 
wallet: {
 
    balance: {
        type: Number,
        default: 0,
    },
 
    transactions: [
 
        {
 
            type: {
                type: String,
 
                enum: [
                    "CREDIT",
                    "DEBIT",
                    "REFUND",
                    "ADD_MONEY",
                    "PURCHASE"
                ],
            },
 
            amount: {
                type: Number,
            },
 
            description: {
                type: String,
            },
 
            date: {
                type: Date,
                default: Date.now,
            },
 
        }
 
    ],
 
},

membership: {
  planId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "MembershipPlan",
    default: null,
  },
  startDate: {
    type: Date,
    default: null,
  },
  expiryDate: {
    type: Date,
    default: null,
  },
  isActive: {
    type: Boolean,
    default: false,
  },
},
 

 
   

},{timestamps:true});

module.exports=mongoose.model("Users",userSchema)