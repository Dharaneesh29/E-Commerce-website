// const mongoose = require("mongoose");

// const statusHistorySchema = new mongoose.Schema({
//   status: {
//     type: String,
//     enum: ["pending", "confirmed", "shipped", "out_for_delivery", "delivered", "cancelled"],
//   },
//   location: String,
//   updatedAt: {
//     type: Date,
//     default: Date.now,
//   },
// });

// const deliveryPartnerSchema = new mongoose.Schema({
//   name: String,
//   phone: String,
// });
 
// const orderSchema = new mongoose.Schema(
//   {
//     // 🔹 USER
//     user: {
//       type: mongoose.Schema.Types.ObjectId,
//       ref: "User",
//       required: true,
//     },
 
//     // 🔹 ORDER ITEMS (SNAPSHOT)
//     orderItems: [
//       {
//         name: { type: String, required: true },
//         price: { type: Number, required: true },
//         qty: { type: Number, required: true },
//         image: { type: String },
 
//         // optional reference
//         product: {
//           type: mongoose.Schema.Types.ObjectId,
//           ref: "Product",
//         },
//       },
//     ],
 
//     // 🔹 SHIPPING ADDRESS (COPIED FROM ADDRESS DB)
//     shippingAddress: {
//       fullName: { type: String, required: true },
//       phone: { type: String, required: true },
//       address: { type: String, required: true },
//       city: { type: String, required: true },
//       state: { type: String, required: true },
//       pincode: { type: String, required: true },
//       landmark: { type: String },
//     },
 
//     // 🔹 PAYMENT (NO THIRD PARTY)
//     paymentMethod: {
//       type: String,
//       enum: ["COD", "UPI", "CARD"],
//       default: "COD",
//     },
 
//     paymentStatus: {
//       type: String,
//       enum: ["pending", "paid","refunded"],
//       default: "pending",
//     },
 
//     // 🔹 PRICE
//     totalPrice: {
//       type: Number,
//       required: true,
//     },

//     cancelReason:    { type: String, default: null },
//   cancelledAt:     { type: Date,   default: null },
//   returnRequest:   {
//     requested:  { type: Boolean, default: false },
//     reason:     { type: String,  default: null  },
//     status:     { type: String,  default:"pending"},
//     requestedAt:{ type: Date,   default: null  },
//   },
//   refundStatus:    { type: String, default: "none" },
//   refundAmount:    { type: Number, default: 0  },
//   refundedAt:      { type: Date,   default: null },
 
//     // 🔹 ORDER STATUS
//     status: {
//       type: String,
//       enum: ["pending", "confirmed", "shipped", "delivered","cancelled","returned"],
//       default: "pending",
//     },
  
//   // 🔥 DELIVERY DATE (from frontend)
//     estimatedDelivery: {
//       type: String,
//     },
 
//     // 🔥 CURRENT LOCATION (NO HARD CODE)
//     currentLocation: {
//       type: String,
//       default: "Order Placed",
//     },
 
//     // 🔥 TRACK HISTORY
//     statusHistory: [statusHistorySchema],
 
//     // 🔥 DELIVERY PARTNER
//     deliveryPartner: deliveryPartnerSchema,
//   },
//   { timestamps: true }
// );
 
// module.exports = mongoose.model("Order", orderSchema);
 


// const mongoose = require("mongoose");
 
// // 🔹 STATUS HISTORY
// const statusHistorySchema = new mongoose.Schema({
//   status: {
//     type: String,
//     enum: ["pending", "confirmed", "shipped", "out_for_delivery", "delivered", "cancelled"],
//   },
//   location: String,
//   updatedAt: {
//     type: Date,
//     default: Date.now,
//   },
// });
 
// // 🔹 DELIVERY PARTNER
// const deliveryPartnerSchema = new mongoose.Schema({
//   name: String,
//   phone: String,
// });
 
// // 🔹 MAIN ORDER SCHEMA
// const orderSchema = new mongoose.Schema(
//   {
//     user: {
//       type: mongoose.Schema.Types.ObjectId,
//       ref: "User",
//     },
 
//     orderItems: [
//       {
//         name: String,
//         qty: Number,
//         price: Number,
//         product: {
//           type: mongoose.Schema.Types.ObjectId,
//           ref: "Product",
//         },
//       },
//     ],
 
//     shippingAddress: {
//       fullName: String,
//       phone: String,
//       address: String,
//       city: String,
//       pincode: String,
//     },
 
//     paymentMethod: {
//       type: String,
//       default: "COD",
//     },
 
//     totalPrice: {
//       type: Number,
//       required: true,
//     },
 
//     // 🔥 MAIN STATUS
//     status: {
//       type: String,
//       enum: ["pending", "confirmed", "shipped", "out_for_delivery", "delivered", "cancelled"],
//       default: "pending",
//     },
 
//     // 🔥 DELIVERY DATE
//     estimatedDelivery: {
//       type: String,
//     },
 
//     // 🔥 CURRENT LOCATION
//     currentLocation: {
//       type: String,
//       default: "Order Placed",
//     },
 
//     // 🔥 TRACK HISTORY
//     statusHistory: [statusHistorySchema],
 
//     // 🔥 DELIVERY PARTNER
//     deliveryPartner: deliveryPartnerSchema,
 
//     // ❌ CANCEL INFO (✅ INSIDE schema)
//     cancelInfo: {
//       reason: {
//         type: String,
//         default: null,
//       },
//       cancelledAt: {
//         type: Date,
//         default: null,
//       },
//     },
 
//     // 🔁 RETURN INFO (✅ INSIDE schema)
//     returnInfo: {
//       reason: {
//         type: String,
//         default: null,
//       },
//       returnedAt: {
//         type: Date,
//         default: null,
//       },
//       status: {
//         type: String,
//         enum: ["requested", "approved", "rejected"],
//         default: null,
//       },
//     },
//   },
//   { timestamps: true }
// );
 
// module.exports = mongoose.model("Order", orderSchema);


const mongoose = require("mongoose");

// 🔹 STATUS HISTORY
const statusHistorySchema = new mongoose.Schema({
  status: {
    type: String,
    enum: ["pending", "confirmed", "shipped", "out_for_delivery", "delivered", "cancelled"],
  },
  location: String,
  updatedAt: {
    type: Date,
    default: Date.now,
  },
});

// 🔹 DELIVERY PARTNER
const deliveryPartnerSchema = new mongoose.Schema({
  name: String,
  phone: String,
});

// 🔹 MAIN ORDER SCHEMA
const orderSchema = new mongoose.Schema(
  {
    // 🔹 USER
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    // 🔹 ORDER ITEMS (SNAPSHOT)
    orderItems: [
      {
        name: { type: String, required: true },
        qty: { type: Number, required: true },
        price: { type: Number, required: true },
        image: { type: String },
        product: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Product",
        },
      },
    ],

    // 🔹 SHIPPING ADDRESS (COPIED FROM ADDRESS DB)
    shippingAddress: {
      fullName: { type: String, required: true },
      phone: { type: String, required: true },
      address: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String },
      pincode: { type: String, required: true },
      landmark: { type: String },
    },

    // 🔹 PAYMENT
    paymentMethod: {
      type: String,
      enum: ["COD", "UPI", "CARD","WALLET"],
      default: "COD",
    },

    paymentStatus: {
      type: String,
      enum: ["pending", "paid", "refunded"],
      default: "pending",
    },

    // 🔹 PRICE
    totalPrice: {
      type: Number,
      required: true,
    },

    // 🔥 MAIN STATUS
    status: {
      type: String,
      enum: ["pending", "confirmed", "shipped", "out_for_delivery", "delivered", "cancelled", "returned"],
      default: "pending",
    },

    // 🔥 DELIVERY DATE (from frontend)
    estimatedDelivery: {
      type: String,
    },

    // 🔥 CURRENT LOCATION
    currentLocation: {
      type: String,
      default: "Order Placed",
    },

    // 🔥 TRACK HISTORY
    statusHistory: [statusHistorySchema],

    // 🔥 DELIVERY PARTNER
    deliveryPartner: deliveryPartnerSchema,

    // ❌ CANCEL INFO
    // → User cancel: set cancelInfo.reason + cancelledBy: "user"
    // → Admin cancel: set cancelInfo.reason + cancelledBy: "admin"
    cancelInfo: {
      reason: { type: String, default: null },
      cancelledAt: { type: Date, default: null },
      cancelledBy: {
        type: String,
        enum: ["user", "admin"],
        default: null,
      },
    },

    // 🔁 RETURN INFO
    returnInfo: {
      reason: { type: String, default: null },
      items:[{type:mongoose.Schema.Types.ObjectId,ref:"Product",}],
      returnedAt: { type: Date, default: null },
      status: {
        type: String,
        enum: ["requested", "approved", "rejected"],
        default: null,
      },
    },

    originalPrice: {
  type: Number,
  default: 0,
},
membershipDiscount: {
  type: Number,
  default: 0,
},


    // 💰 REFUND INFO
    refundStatus: {
      type: String,
      enum: ["none", "pending", "refunded","rejected"],
      default: "none",
    },
    refundAmount: { type: Number, default: 0 },
    refundedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", orderSchema);
