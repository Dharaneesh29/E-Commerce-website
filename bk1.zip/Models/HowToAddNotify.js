// ─────────────────────────────────────────────────────────────────────────────
// HOW TO ADD NOTIFICATIONS TO YOUR EXISTING CONTROLLERS
// Just add the notify() call after the main action in each controller
// ─────────────────────────────────────────────────────────────────────────────

// ── 1. In your orderController.js ────────────────────────────────────────────
// Add this import at the top:
const { notify } = require("./notificationController");

// Then inside your createOrder function, after saving the order:
exports.createOrder = async (req, res) => {
  try {
    // ... your existing order creation code ...
    const order = await Order.create(req.body);

    // ✅ ADD THIS LINE — triggers notification
    await notify(
      "order",
      `New order #${order._id.toString().slice(-6).toUpperCase()} placed by ${order.shippingAddress?.fullName} for ₹${order.totalPrice}`,
      order._id.toString()
    );

    res.status(201).json(order);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


// ── 2. In your userController.js (register) ──────────────────────────────────
// Add this import at the top:
// const { notify } = require("./notificationController");

// Then inside your register function, after saving the user:
exports.registerUser = async (req, res) => {
  try {
    // ... your existing register code ...
    const user = await User.create({ name, email, password: hashedPassword });

    // ✅ ADD THIS LINE — triggers notification
    await notify(
      "user",
      `New user registered: ${user.name} (${user.email})`,
      user._id.toString()
    );

    res.status(201).json({ message: "User created", user });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


// ── 3. In your productController.js (update stock) ───────────────────────────
// Add this import at the top:
// const { notify } = require("./notificationController");

// Call this helper whenever stock is updated:
const LOW_STOCK_THRESHOLD = 10; // change as needed

const checkLowStock = async (product) => {
  if (product.countInStock <= LOW_STOCK_THRESHOLD) {
    await notify(
      "stock",
      `Low stock alert: "${product.name}" has only ${product.countInStock} units left`,
      product._id.toString()
    );
  }
};

// Example — call after updating product:
exports.updateProduct = async (req, res) => {
  try {
    const product = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });

    // ✅ ADD THIS LINE — check stock after update
    await checkLowStock(product);

    res.json(product);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};